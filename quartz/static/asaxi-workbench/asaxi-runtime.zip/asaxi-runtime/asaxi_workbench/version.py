"""Release identifiers shared without importing the package facade."""

WORKBENCH_VERSION = "0.5.16"
