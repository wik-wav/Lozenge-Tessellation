"""Strict readers for the Markdown conventions used by the Asaxi vault.

The source frontmatter is YAML, but the authoritative notes use a deliberately
small subset: scalar keys and indented scalar lists. Supporting that subset
locally avoids making PyYAML a runtime requirement while still rejecting
structures the compiler cannot interpret safely.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
import re
from typing import Any, Iterable


FRONTMATTER_KEY_RE = re.compile(r"^([^\s:#][^:]*?):(?:[ \t]*(.*))?$")
LIST_ITEM_RE = re.compile(r"^[ \t]+-[ \t]*(.*)$")
HEADING_RE = re.compile(r"^(#{1,6})[ \t]+(.+?)[ \t]*$")
LEVEL_THREE_RE = re.compile(r"^###[ \t]+(.+?)[ \t]*$")
WIKI_LINK_RE = re.compile(r"\[\[([^\]]+)\]\]")
HTML_TAG_RE = re.compile(r"<[^>]+>")
MARKUP_RE = re.compile(r"(\*\*|__|(?<!\*)\*(?!\*)|(?<!_)_(?!_)|`)")


@dataclass(frozen=True)
class ParseProblem:
    message: str
    line: int


@dataclass(frozen=True)
class MarkdownSection:
    title: str
    body: str
    line: int


@dataclass(frozen=True)
class ParsedMarkdown:
    frontmatter: dict[str, Any]
    frontmatter_lines: dict[str, int]
    body: str
    sections: tuple[MarkdownSection, ...]
    headings: tuple[tuple[int, str, int], ...]
    problems: tuple[ParseProblem, ...]

    def frontmatter_value(
        self,
        name: str,
    ) -> tuple[object | None, bool, int | None]:
        wanted = name.casefold()
        for key, value in self.frontmatter.items():
            if key.casefold() == wanted:
                return value, True, self.frontmatter_lines.get(key)
        return None, False, None

    def section(self, *names: str) -> MarkdownSection | None:
        wanted = {normalize_heading(name) for name in names}
        for section in self.sections:
            if normalize_heading(section.title) in wanted:
                return section
        return None


def _parse_inline_list(text: str) -> list[str] | None:
    stripped = text.strip()
    if not (stripped.startswith("[") and stripped.endswith("]")):
        return None
    inner = stripped[1:-1].strip()
    if not inner:
        return []
    items: list[str] = []
    current: list[str] = []
    quote: str | None = None
    escaped = False
    for character in inner:
        if escaped:
            current.append(character)
            escaped = False
            continue
        if character == "\\" and quote == '"':
            current.append(character)
            escaped = True
            continue
        if quote:
            current.append(character)
            if character == quote:
                quote = None
            continue
        if character in {'"', "'"}:
            quote = character
            current.append(character)
            continue
        if character == ",":
            items.append(str(_parse_scalar("".join(current).strip())))
            current = []
            continue
        current.append(character)
    if quote:
        return None
    items.append(str(_parse_scalar("".join(current).strip())))
    return items


def _parse_scalar(text: str) -> object:
    value = text.strip()
    inline = _parse_inline_list(value)
    if inline is not None:
        return inline
    if len(value) >= 2 and value[0] == value[-1] == '"':
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            return value[1:-1]
    if len(value) >= 2 and value[0] == value[-1] == "'":
        return value[1:-1].replace("''", "'")
    if re.fullmatch(r"-?\d+", value):
        try:
            return int(value)
        except ValueError:
            pass
    if value.casefold() == "true":
        return True
    if value.casefold() == "false":
        return False
    # Keep Null as source text. It is a meaningful unresolved-placeholder
    # state in this corpus rather than an interchangeable Python None.
    return value


def parse_markdown(text: str) -> ParsedMarkdown:
    normalized = text.replace("\r\n", "\n").replace("\r", "\n")
    lines = normalized.split("\n")
    frontmatter: dict[str, Any] = {}
    frontmatter_lines: dict[str, int] = {}
    problems: list[ParseProblem] = []
    body_start = 0

    if lines and lines[0].strip() == "---":
        closing = next(
            (index for index in range(1, len(lines))
             if lines[index].strip() == "---"),
            None,
        )
        if closing is None:
            problems.append(ParseProblem("Unclosed YAML frontmatter", 1))
            closing = 0
        else:
            index = 1
            while index < closing:
                line = lines[index]
                if not line.strip() or line.lstrip().startswith("#"):
                    index += 1
                    continue
                match = FRONTMATTER_KEY_RE.match(line)
                if not match:
                    problems.append(
                        ParseProblem(
                            "Unsupported frontmatter syntax; expected a "
                            "top-level scalar key",
                            index + 1,
                        )
                    )
                    index += 1
                    continue
                key = match.group(1).strip()
                raw_value = (match.group(2) or "").strip()
                frontmatter_lines[key] = index + 1
                if key in frontmatter:
                    problems.append(
                        ParseProblem(f"Duplicate frontmatter key: {key}", index + 1)
                    )
                if raw_value:
                    frontmatter[key] = _parse_scalar(raw_value)
                    index += 1
                    continue

                list_values: list[str] = []
                cursor = index + 1
                while cursor < closing:
                    item = LIST_ITEM_RE.match(lines[cursor])
                    if item:
                        list_values.append(str(_parse_scalar(item.group(1))))
                        cursor += 1
                        continue
                    if not lines[cursor].strip():
                        cursor += 1
                        continue
                    break
                if list_values:
                    frontmatter[key] = list_values
                    index = cursor
                else:
                    frontmatter[key] = ""
                    index += 1
            body_start = closing + 1

    body_lines = lines[body_start:]
    body = "\n".join(body_lines)
    headings: list[tuple[int, str, int]] = []
    for offset, line in enumerate(body_lines):
        match = HEADING_RE.match(line)
        if match:
            headings.append(
                (len(match.group(1)), match.group(2).strip(), body_start + offset + 1)
            )

    sections: list[MarkdownSection] = []
    level_three = [
        (index, LEVEL_THREE_RE.match(line))
        for index, line in enumerate(body_lines)
        if LEVEL_THREE_RE.match(line)
    ]
    for position, (index, match) in enumerate(level_three):
        assert match is not None
        end = (
            level_three[position + 1][0]
            if position + 1 < len(level_three)
            else len(body_lines)
        )
        sections.append(
            MarkdownSection(
                title=match.group(1).strip(),
                # Preserve leading blank lines so offsets within a section
                # still map to the original source line. Consumers already
                # normalize field text when whitespace is semantically empty.
                body="\n".join(body_lines[index + 1:end]).rstrip(),
                line=body_start + index + 1,
            )
        )

    return ParsedMarkdown(
        frontmatter=frontmatter,
        frontmatter_lines=frontmatter_lines,
        body=body,
        sections=tuple(sections),
        headings=tuple(headings),
        problems=tuple(problems),
    )


def normalize_heading(value: str) -> str:
    normalized = value.strip().casefold().rstrip(":")
    normalized = re.sub(r"\s+", " ", normalized)
    return normalized


def wiki_links(text: str) -> tuple[str, ...]:
    targets: set[str] = set()
    for match in WIKI_LINK_RE.finditer(text):
        content = match.group(1)
        target = content.split("|", 1)[0].split("#", 1)[0].strip()
        if target:
            targets.add(target)
    return tuple(sorted(targets, key=str.casefold))


def _replace_wiki_link(match: re.Match[str]) -> str:
    content = match.group(1)
    if "|" in content:
        return content.rsplit("|", 1)[1]
    return content.split("#", 1)[0]


def plain_markdown_value(text: str) -> str:
    """Reduce one short metadata section to plain source text.

    This deliberately does not attempt to be a complete Markdown renderer.
    It is only used for single-value fields such as noun class and IPA.
    """

    value = WIKI_LINK_RE.sub(_replace_wiki_link, text)
    value = HTML_TAG_RE.sub("", value)
    value = MARKUP_RE.sub("", value)
    lines = []
    for line in value.splitlines():
        cleaned = re.sub(r"^\s*(?:[-*+]|\d+\.)\s*", "", line).strip()
        if cleaned:
            lines.append(cleaned)
    return "\n".join(lines).strip()


EXAMPLE_LABEL_RE = re.compile(
    r"^\s*-\s*\*\*(Asaxi|English|Polish):\*\*\s*(.*?)\s*$",
    re.IGNORECASE,
)
EXAMPLE_HEADING_RE = re.compile(r"^####\s+Example\s+(\d+)\s*$", re.IGNORECASE)


@dataclass(frozen=True)
class ParsedExample:
    asaxi: str | None
    english: str | None
    polish: str | None
    line: int


def parse_examples(
    section: MarkdownSection,
) -> tuple[tuple[ParsedExample, ...], tuple[ParseProblem, ...]]:
    """Parse canonical language-separated example records.

    Unlabelled legacy prose is reported instead of being split heuristically.
    """

    records: list[ParsedExample] = []
    problems: list[ParseProblem] = []
    current: dict[str, str] = {}
    record_line = section.line + 1
    saw_label = False

    def flush() -> None:
        nonlocal current, record_line
        if not current:
            return
        records.append(
            ParsedExample(
                asaxi=current.get("asaxi"),
                english=current.get("english"),
                polish=current.get("polish"),
                line=record_line,
            )
        )
        current = {}

    meaningful_unparsed: list[tuple[int, str]] = []
    for offset, line in enumerate(section.body.splitlines(), start=1):
        heading = EXAMPLE_HEADING_RE.match(line.strip())
        if heading:
            flush()
            record_line = section.line + offset
            continue
        label = EXAMPLE_LABEL_RE.match(line)
        if label:
            key = label.group(1).casefold()
            if key in current:
                flush()
                record_line = section.line + offset
            current[key] = label.group(2).strip()
            saw_label = True
            continue
        stripped = line.strip()
        if (
            stripped
            and stripped.casefold().rstrip(".")
            not in {"null", "x", "-", "n/a"}
            and not stripped.startswith("<!--")
        ):
            meaningful_unparsed.append((section.line + offset, stripped))
    flush()

    if meaningful_unparsed and not saw_label:
        line, _ = meaningful_unparsed[0]
        problems.append(
            ParseProblem(
                "Example section is not in language-separated record format",
                line,
            )
        )
    return tuple(records), tuple(problems)


def frontmatter_list(value: object | None) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, list):
        return tuple(str(item).strip() for item in value if str(item).strip())
    text = str(value).strip()
    return (text,) if text else ()


def first_matching_line(
    text: str,
    patterns: Iterable[re.Pattern[str]],
) -> str | None:
    for pattern in patterns:
        match = pattern.search(text)
        if match:
            return match.group(1).strip()
    return None
