"""Local HTTP service for the Asaxi Workbench browser interface."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import secrets
import socket
from typing import Any
from urllib.parse import parse_qs, urlsplit
import webbrowser

from .compiler import CompileConfig, compile_language
from .grammar_coverage import build_grammar_coverage
from .phrase_memory import (
    AuthoredPhrase,
    DEFAULT_PHRASE_MEMORY_PATH,
    PhraseMemoryConflictError,
    PhraseMemoryError,
    PhraseMemoryStore,
    suggest_phrase_variants,
)
from .syntax import (
    DiscourseReferent,
    DiscourseState,
    Nominal,
    PronounAnimacy,
    PronounKind,
    PronounPerson,
)
from .translation_document import TranslationDocumentAnalyzer
from .translation_models import (
    TRANSLATION_ENGINE_VERSION,
    TranslationDirection,
)
from .translator import Translator


WEB_ROOT = Path(__file__).resolve().parent / "web"
MAX_REQUEST_BYTES = 1_000_000


@dataclass(frozen=True)
class WorkbenchService:
    translator: Translator
    document_analyzer: TranslationDocumentAnalyzer
    statistics: dict[str, int]
    grammar_model: dict[str, Any]
    grammar_coverage: dict[str, Any]
    phrase_memory: PhraseMemoryStore
    developer_phrase_authoring: bool = False

    @classmethod
    def load(
        cls,
        config: CompileConfig,
        *,
        phrase_memory_path: Path | None = None,
        developer_phrase_authoring: bool = False,
    ) -> "WorkbenchService":
        database = compile_language(config)
        phrase_memory = PhraseMemoryStore(
            phrase_memory_path or DEFAULT_PHRASE_MEMORY_PATH
        )
        translator = Translator(database, phrase_memory=phrase_memory)
        coverage = build_grammar_coverage(
            database,
            config.vault_root,
            claim_manifest_path=config.grammar_claim_manifest,
        )
        return cls(
            translator=translator,
            document_analyzer=TranslationDocumentAnalyzer(translator),
            statistics=dict(database.statistics),
            grammar_model=translator.grammar_model.to_dict(),
            grammar_coverage=coverage.to_summary_dict(),
            phrase_memory=phrase_memory,
            developer_phrase_authoring=developer_phrase_authoring,
        )

    @property
    def phrase_memory_status(self) -> dict[str, Any]:
        return {
            "enabled": True,
            "writable": self.developer_phrase_authoring,
            "count": self.phrase_memory.count,
            "verified_count": self.phrase_memory.verified_count,
        }

    @staticmethod
    def _parse_payload(
        payload: object,
    ) -> tuple[str, TranslationDirection]:
        if not isinstance(payload, dict):
            raise ValueError("Request body must be a JSON object")
        text = payload.get("text")
        direction = payload.get("direction")
        if not isinstance(text, str):
            raise ValueError("'text' must be a string")
        if len(text) > 100_000:
            raise ValueError("'text' exceeds the 100,000 character limit")
        try:
            selected = TranslationDirection(direction)
        except (TypeError, ValueError) as error:
            choices = ", ".join(item.value for item in TranslationDirection)
            raise ValueError(
                f"'direction' must be one of: {choices}"
            ) from error
        return text, selected

    @staticmethod
    def _parse_discourse_state(
        payload: object,
    ) -> DiscourseState | None:
        if not isinstance(payload, dict):
            raise ValueError("Request body must be a JSON object")
        raw_state = payload.get("discourse_state")
        if raw_state is None:
            return None
        if not isinstance(raw_state, dict):
            raise ValueError("'discourse_state' must be an object or null")
        raw_topic = raw_state.get("topic")
        if raw_topic is None:
            return DiscourseState()
        if not isinstance(raw_topic, dict):
            raise ValueError("'discourse_state.topic' must be an object")
        raw_nominal = raw_topic.get("nominal")
        if not isinstance(raw_nominal, dict):
            raise ValueError(
                "'discourse_state.topic.nominal' must be an object"
            )
        surface = raw_nominal.get("surface")
        english_text = raw_topic.get("english_text")
        if not isinstance(surface, str) or not surface.strip():
            raise ValueError(
                "'discourse_state.topic.nominal.surface' "
                "must be a non-empty string"
            )
        if not isinstance(english_text, str) or not english_text.strip():
            raise ValueError(
                "'discourse_state.topic.english_text' "
                "must be a non-empty string"
            )
        optional_fields: dict[str, str | None] = {}
        for name in ("lexeme_id", "noun_class", "pronoun_base"):
            value = raw_nominal.get(name)
            if value is not None and not isinstance(value, str):
                raise ValueError(
                    f"'discourse_state.topic.nominal.{name}' "
                    "must be a string or null"
                )
            optional_fields[name] = value
        number = raw_nominal.get("number", "singular")
        if number not in {"singular", "plural"}:
            raise ValueError(
                "'discourse_state.topic.nominal.number' must be "
                "'singular' or 'plural'"
            )

        def optional_enum(name: str, enum_type: type) -> Any:
            value = raw_nominal.get(name)
            if value is None:
                return None
            if not isinstance(value, str):
                raise ValueError(
                    f"'discourse_state.topic.nominal.{name}' "
                    "must be a string or null"
                )
            try:
                return enum_type(value)
            except ValueError as error:
                raise ValueError(
                    f"'discourse_state.topic.nominal.{name}' has "
                    f"unsupported value {value!r}"
                ) from error

        return DiscourseState(
            topic=DiscourseReferent(
                nominal=Nominal(
                    surface=surface.strip(),
                    lexeme_id=optional_fields["lexeme_id"],
                    noun_class=optional_fields["noun_class"],
                    number=number,
                    person=optional_enum("person", PronounPerson),
                    animacy=optional_enum("animacy", PronounAnimacy),
                    pronoun_kind=optional_enum(
                        "pronoun_kind",
                        PronounKind,
                    ),
                    pronoun_base=optional_fields["pronoun_base"],
                ),
                english_text=english_text.strip(),
            )
        )

    def translate_payload(self, payload: object) -> dict[str, Any]:
        text, selected = self._parse_payload(payload)
        discourse_state = self._parse_discourse_state(payload)
        return self.translator.translate(
            text,
            selected,
            discourse_state=discourse_state,
        ).to_dict()

    def translate_document_payload(
        self,
        payload: object,
    ) -> dict[str, Any]:
        text, selected = self._parse_payload(payload)
        discourse_state = self._parse_discourse_state(payload)
        return self.document_analyzer.analyze(
            text,
            selected,
            discourse_state=discourse_state,
        ).to_dict()

    def search_phrases(
        self,
        query: str,
        direction: str | None,
        *,
        limit: int = 50,
    ) -> dict[str, Any]:
        selected = TranslationDirection(direction) if direction else None
        hits = self.phrase_memory.search(
            query,
            selected,
            verified_only=True,
            limit=limit,
        )
        return {
            "query": query,
            "direction": selected.value if selected else None,
            "authorship": "reviewed-human-authored",
            "count": len(hits),
            "results": [hit.to_dict() for hit in hits],
        }

    def _require_phrase_authoring(self) -> None:
        if not self.developer_phrase_authoring:
            raise PermissionError(
                "Developer phrase authoring is disabled for this server"
            )

    def developer_phrase_list(self) -> dict[str, Any]:
        self._require_phrase_authoring()
        return {
            "entries": [
                entry.to_dict() for entry in self.phrase_memory.entries
            ]
        }

    def developer_phrase_suggestions(self, payload: object) -> dict[str, Any]:
        self._require_phrase_authoring()
        text, direction = self._parse_payload(payload)
        return {
            "source_text": text,
            "direction": direction.value,
            "variants": list(suggest_phrase_variants(text, direction)),
        }

    def developer_phrase_save(self, payload: object) -> dict[str, Any]:
        self._require_phrase_authoring()
        if not isinstance(payload, dict):
            raise ValueError("Request body must be a JSON object")
        allowed_fields = {
            "id",
            "expected_revision",
            "direction",
            "source_text",
            "target_text",
            "variants",
            "verified",
            "reverify",
            "reviewed_by",
            "verification_source",
            "developer_note",
        }
        unknown = set(payload) - allowed_fields
        if unknown:
            raise ValueError(
                "Unknown phrase-save fields: " + ", ".join(sorted(unknown))
            )
        variants = payload.get("variants", [])
        if not isinstance(variants, list) or not all(
            isinstance(item, str) for item in variants
        ):
            raise ValueError("'variants' must be a list of strings")
        identifier = payload.get("id")
        if identifier is not None and not isinstance(identifier, str):
            raise ValueError("'id' must be a string or null")
        expected_revision = payload.get("expected_revision")
        if expected_revision is not None and type(expected_revision) is not int:
            raise ValueError("'expected_revision' must be an integer or null")
        verified = payload.get("verified", False)
        if not isinstance(verified, bool):
            raise ValueError("'verified' must be a boolean")
        reverify = payload.get("reverify", False)
        if not isinstance(reverify, bool):
            raise ValueError("'reverify' must be a boolean")
        if reverify and not verified:
            raise ValueError("'reverify' requires 'verified' to be true")
        developer_note = payload.get("developer_note", "")
        if not isinstance(developer_note, str):
            raise ValueError("'developer_note' must be a string")
        reviewed_by = payload.get("reviewed_by")
        verification_source = payload.get("verification_source")
        if verified and not isinstance(reviewed_by, str):
            raise ValueError("'reviewed_by' must be a string for verification")
        if verified and not isinstance(verification_source, str):
            raise ValueError(
                "'verification_source' must be a string for verification"
            )
        current = self.phrase_memory.entry(identifier) if identifier else None
        if identifier is not None and current is None:
            raise KeyError(identifier)
        if current is not None and expected_revision is None:
            raise PhraseMemoryConflictError(
                "Updating an authored phrase requires expected_revision"
            )
        if current is None and expected_revision is not None:
            raise PhraseMemoryConflictError(
                "A new authored phrase cannot specify expected_revision"
            )
        refresh_verification = verified and (
            current is None or not current.verified or reverify
        )
        if current is not None and current.verified and verified and not reverify:
            if reviewed_by != current.reviewed_by:
                raise ValueError(
                    "Changing the reviewer requires an explicit reverify action"
                )
            if verification_source != current.verification_source:
                raise ValueError(
                    "Changing the verification source requires an explicit "
                    "reverify action"
                )
            reviewed_model = current.reviewed_with_grammar_model
            reviewed_engine = (
                current.reviewed_with_translation_engine_version
            )
            reviewed_digest = current.reviewed_with_source_digest
            reviewed_at = current.reviewed_at
        elif refresh_verification:
            reviewed_digest = self.grammar_model.get(
                "current_source_digest"
            )
            reviewed_model = self.grammar_model.get("model_version")
            if not reviewed_model and isinstance(reviewed_digest, str):
                reviewed_model = f"source-snapshot:{reviewed_digest[:12]}"
            reviewed_engine = TRANSLATION_ENGINE_VERSION
            reviewed_at = (
                datetime.now(timezone.utc)
                .isoformat(timespec="seconds")
                .replace("+00:00", "Z")
            )
        else:
            reviewed_model = None
            reviewed_engine = None
            reviewed_digest = None
            reviewed_at = None
        entry = AuthoredPhrase.create(
            identifier=identifier,
            direction=payload.get("direction"),
            source_text=payload.get("source_text", ""),
            target_text=payload.get("target_text", ""),
            variants=variants,
            verified=verified,
            revision=current.revision if current is not None else 1,
            reviewed_with_grammar_model=reviewed_model,
            reviewed_with_translation_engine_version=reviewed_engine,
            reviewed_with_source_digest=reviewed_digest,
            reviewed_by=reviewed_by,
            reviewed_at=reviewed_at,
            verification_source=verification_source,
            developer_note=developer_note,
        )
        if current is None:
            saved = self.phrase_memory.insert(entry)
            verification_cleared = False
        else:
            saved, verification_cleared = self.phrase_memory.update(
                entry,
                expected_revision=expected_revision,
            )
        return {
            "entry": saved.to_dict(),
            "verification_cleared": verification_cleared,
            "verification_refreshed": refresh_verification and not verification_cleared,
            **self.phrase_memory_status,
        }

    def developer_phrase_delete(self, payload: object) -> dict[str, Any]:
        self._require_phrase_authoring()
        if not isinstance(payload, dict):
            raise ValueError("Request body must be a JSON object")
        if set(payload) != {"id", "expected_revision"}:
            raise ValueError(
                "Phrase deletion requires only 'id' and 'expected_revision'"
            )
        if not isinstance(payload.get("id"), str):
            raise ValueError("'id' must be a string")
        expected_revision = payload.get("expected_revision")
        if type(expected_revision) is not int:
            raise ValueError("'expected_revision' must be an integer")
        identifier = payload["id"]
        if not self.phrase_memory.delete(
            identifier,
            expected_revision=expected_revision,
        ):
            raise KeyError(identifier)
        return {"deleted_id": identifier, **self.phrase_memory_status}


class WorkbenchServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = False

    def server_bind(self) -> None:
        # On Windows, SO_REUSEADDR does not provide Unix-style protection
        # against a second process binding the same local port. An exclusive
        # bind prevents a stale Workbench process from serving old code beside
        # a newly launched instance.
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            self.socket.setsockopt(
                socket.SOL_SOCKET,
                socket.SO_EXCLUSIVEADDRUSE,
                1,
            )
        super().server_bind()

    def __init__(
        self,
        address: tuple[str, int],
        service: WorkbenchService,
    ):
        self.csrf_token = secrets.token_urlsafe(32)
        super().__init__(address, WorkbenchRequestHandler)
        self.service = service


class WorkbenchRequestHandler(BaseHTTPRequestHandler):
    server: WorkbenchServer

    STATIC_ROUTES = {
        "/": ("index.html", "text/html; charset=utf-8"),
        "/index.html": ("index.html", "text/html; charset=utf-8"),
        "/styles.css": ("styles.css", "text/css; charset=utf-8"),
        "/app.js": ("app.js", "text/javascript; charset=utf-8"),
        "/config.js": ("config.js", "text/javascript; charset=utf-8"),
        "/developer.js": (
            "developer.js",
            "text/javascript; charset=utf-8",
        ),
        "/assets/Asaxi-alphabet-Merriweather24pt-Medium.ttf": (
            "assets/Asaxi-alphabet-Merriweather24pt-Medium.ttf",
            "font/ttf",
        ),
        "/assets/AsaxiAbugida.ttf": (
            "assets/AsaxiAbugida.ttf",
            "font/ttf",
        ),
    }

    _LOOPBACK_HOSTS = frozenset({"127.0.0.1", "localhost", "::1"})
    _DEVELOPER_MUTATION_ROUTES = frozenset(
        {
            "/api/developer/phrases/suggest-variants",
            "/api/developer/phrases/save",
            "/api/developer/phrases/delete",
        }
    )

    def _request_host_allowed(self) -> bool:
        raw_host = self.headers.get("Host", "")
        try:
            parsed = urlsplit(f"//{raw_host}")
            host = parsed.hostname
            port = parsed.port
        except ValueError:
            return False
        return (
            host in self._LOOPBACK_HOSTS
            and port == self.server.server_address[1]
        )

    def _developer_origin_allowed(self) -> bool:
        raw_origin = self.headers.get("Origin", "")
        try:
            parsed = urlsplit(raw_origin)
            port = parsed.port
        except ValueError:
            return False
        return (
            parsed.scheme == "http"
            and parsed.hostname in self._LOOPBACK_HOSTS
            and port == self.server.server_address[1]
        )

    def _reject_untrusted_host(self) -> bool:
        if self._request_host_allowed():
            return False
        self._json(
            HTTPStatus.FORBIDDEN,
            {
                "error": "UNTRUSTED_HOST",
                "message": "The Workbench only accepts loopback Host headers",
            },
        )
        return True

    def do_GET(self) -> None:
        if self._reject_untrusted_host():
            return
        request = urlsplit(self.path)
        if request.path == "/api/health":
            phrase_status = dict(self.server.service.phrase_memory_status)
            if phrase_status["writable"]:
                phrase_status["csrf_token"] = self.server.csrf_token
            self._json(
                HTTPStatus.OK,
                {
                    "status": "ok",
                    "statistics": self.server.service.statistics,
                    "grammar_model": self.server.service.grammar_model,
                    "grammar_coverage": (
                        self.server.service.grammar_coverage
                    ),
                    "phrase_memory": phrase_status,
                },
            )
            return
        if request.path == "/api/phrases/search":
            query = parse_qs(request.query, keep_blank_values=True)
            phrase = query.get("q", [""])[0]
            direction = query.get("direction", [None])[0]
            try:
                limit = int(query.get("limit", ["50"])[0])
                result = self.server.service.search_phrases(
                    phrase,
                    direction,
                    limit=limit,
                )
            except (TypeError, ValueError) as error:
                self._json(
                    HTTPStatus.BAD_REQUEST,
                    {"error": "INVALID_REQUEST", "message": str(error)},
                )
                return
            self._json(HTTPStatus.OK, result)
            return
        if request.path == "/api/developer/phrases":
            try:
                result = self.server.service.developer_phrase_list()
            except PermissionError as error:
                self._json(
                    HTTPStatus.FORBIDDEN,
                    {"error": "DEVELOPER_MODE_DISABLED", "message": str(error)},
                )
                return
            self._json(HTTPStatus.OK, result)
            return
        route = self.STATIC_ROUTES.get(request.path)
        if route is None:
            self._json(
                HTTPStatus.NOT_FOUND,
                {"error": "NOT_FOUND", "message": "Route not found"},
            )
            return
        filename, content_type = route
        try:
            payload = (WEB_ROOT / filename).read_bytes()
        except FileNotFoundError:
            if filename == "assets/AsaxiAbugida.ttf":
                self._json(
                    HTTPStatus.NOT_FOUND,
                    {
                        "error": "OPTIONAL_FONT_NOT_INSTALLED",
                        "message": "The optional Asaxi abugida font is not installed",
                    },
                )
                return
            self._json(
                HTTPStatus.INTERNAL_SERVER_ERROR,
                {
                    "error": "STATIC_FILE_ERROR",
                    "message": "A required Workbench asset is missing",
                },
            )
            return
        except OSError:
            self._json(
                HTTPStatus.INTERNAL_SERVER_ERROR,
                {
                    "error": "STATIC_FILE_ERROR",
                    "message": "The Workbench could not read a static asset",
                },
            )
            return
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(payload)

    def do_POST(self) -> None:
        if self._reject_untrusted_host():
            return
        request = urlsplit(self.path)
        if request.path not in {
            "/api/translate",
            "/api/translate-document",
            "/api/developer/phrases/suggest-variants",
            "/api/developer/phrases/save",
            "/api/developer/phrases/delete",
        }:
            self._json(
                HTTPStatus.NOT_FOUND,
                {"error": "NOT_FOUND", "message": "Route not found"},
            )
            return
        content_type = self.headers.get("Content-Type", "")
        if content_type.split(";", 1)[0].strip().lower() != "application/json":
            self._json(
                HTTPStatus.UNSUPPORTED_MEDIA_TYPE,
                {
                    "error": "JSON_REQUIRED",
                    "message": "POST requests require application/json",
                },
            )
            return
        if request.path in self._DEVELOPER_MUTATION_ROUTES:
            supplied_token = self.headers.get("X-Asaxi-CSRF", "")
            if (
                not self._developer_origin_allowed()
                or not secrets.compare_digest(
                    supplied_token,
                    self.server.csrf_token,
                )
            ):
                self._json(
                    HTTPStatus.FORBIDDEN,
                    {
                        "error": "UNTRUSTED_DEVELOPER_REQUEST",
                        "message": (
                            "Developer writes require the same loopback origin "
                            "and the current CSRF token"
                        ),
                    },
                )
                return
        try:
            content_length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            content_length = -1
        if content_length < 0 or content_length > MAX_REQUEST_BYTES:
            self._json(
                HTTPStatus.REQUEST_ENTITY_TOO_LARGE,
                {
                    "error": "REQUEST_TOO_LARGE",
                    "message": "Request body is too large",
                },
            )
            return
        try:
            payload = json.loads(
                self.rfile.read(content_length).decode("utf-8")
            )
            if request.path == "/api/translate-document":
                result = self.server.service.translate_document_payload(
                    payload
                )
            elif request.path == "/api/developer/phrases/suggest-variants":
                result = self.server.service.developer_phrase_suggestions(
                    payload
                )
            elif request.path == "/api/developer/phrases/save":
                result = self.server.service.developer_phrase_save(payload)
            elif request.path == "/api/developer/phrases/delete":
                result = self.server.service.developer_phrase_delete(payload)
            else:
                result = self.server.service.translate_payload(payload)
        except PermissionError as error:
            self._json(
                HTTPStatus.FORBIDDEN,
                {"error": "DEVELOPER_MODE_DISABLED", "message": str(error)},
            )
            return
        except KeyError as error:
            self._json(
                HTTPStatus.NOT_FOUND,
                {
                    "error": "PHRASE_NOT_FOUND",
                    "message": f"Authored phrase not found: {error.args[0]}",
                },
            )
            return
        except PhraseMemoryConflictError as error:
            self._json(
                HTTPStatus.CONFLICT,
                {"error": "PHRASE_MEMORY_CONFLICT", "message": str(error)},
            )
            return
        except PhraseMemoryError as error:
            self._json(
                HTTPStatus.BAD_REQUEST,
                {"error": "INVALID_PHRASE_MEMORY", "message": str(error)},
            )
            return
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as error:
            self._json(
                HTTPStatus.BAD_REQUEST,
                {"error": "INVALID_REQUEST", "message": str(error)},
            )
            return
        self._json(HTTPStatus.OK, result)

    def _json(self, status: HTTPStatus, payload: object) -> None:
        rendered = json.dumps(
            payload,
            ensure_ascii=False,
            sort_keys=True,
        ).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(rendered)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(rendered)

    def log_message(self, format: str, *args: object) -> None:
        return


def run_server(
    config: CompileConfig,
    *,
    host: str = "127.0.0.1",
    port: int = 8765,
    open_browser: bool = False,
    phrase_memory_path: Path | None = None,
    developer_phrase_authoring: bool = False,
) -> None:
    if developer_phrase_authoring and host not in {
        "127.0.0.1",
        "localhost",
        "::1",
    }:
        raise ValueError(
            "Developer phrase authoring may only bind to a loopback host"
        )
    service = WorkbenchService.load(
        config,
        phrase_memory_path=phrase_memory_path,
        developer_phrase_authoring=developer_phrase_authoring,
    )
    server = WorkbenchServer((host, port), service)
    actual_port = server.server_address[1]
    rendered_host = f"[{host}]" if ":" in host else host
    url = f"http://{rendered_host}:{actual_port}/"
    print(
        f"Asaxi Workbench: {url}\n"
        f"Loaded {service.statistics['lexemes']} lexemes and "
        f"{service.statistics['morphemes']} formal morphemes."
    )
    if open_browser:
        webbrowser.open(url)
    try:
        server.serve_forever(poll_interval=0.2)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
