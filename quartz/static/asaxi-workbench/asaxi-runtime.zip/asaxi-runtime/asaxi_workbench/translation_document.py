"""Deterministic multi-clause translation records for browser frontends.

The clause translator deliberately understands one bounded clause.  This
module preserves that boundary and adds document segmentation, exact source
spans, output composition, and interlinear display records without teaching
the browser a second grammar.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import re
from typing import Any, Iterable

from .models import GrammarModelReference, Lexeme
from .syntax import (
    DiscourseReferent,
    DiscourseState,
    PredicateKind,
)
from .translation_lexicon import split_english_gloss
from .translation_models import (
    TRANSLATION_ENGINE_VERSION,
    TranslationAlternative,
    TranslationDirection,
    TranslationResult,
    TranslationStatus,
    TranslationToken,
)
from .translator import Translator


DOCUMENT_SCHEMA_VERSION = "0.4.0-provisional"
_TERMINATORS = frozenset(".!?;")
_CLOSERS = frozenset("\"'”’»)]}")


class TranslationDocumentStatus(str, Enum):
    OK = "ok"
    AMBIGUOUS = "ambiguous"
    PARTIAL = "partial"
    UNSUPPORTED = "unsupported"


@dataclass(frozen=True)
class InterlinearToken:
    token_index: int
    surface: str
    role: str | None
    lemma: str
    morphemes: tuple[str, ...]
    gloss: str
    features: tuple[tuple[str, str], ...] = ()
    confidence: str = "surface"
    provenance: str = "surface"

    def to_dict(self) -> dict[str, Any]:
        return {
            "token_index": self.token_index,
            "surface": self.surface,
            "role": self.role,
            "lemma": self.lemma,
            "morphemes": list(self.morphemes),
            "gloss": self.gloss,
            "features": dict(self.features),
            "confidence": self.confidence,
            "provenance": self.provenance,
        }


@dataclass(frozen=True)
class TranslationDocumentClause:
    identifier: str
    index: int
    source_text: str
    start: int
    end: int
    separator_after: str
    translation: TranslationResult
    interlinear_by_alternative: tuple[
        tuple[str, tuple[InterlinearToken, ...]],
        ...,
    ] = ()

    @property
    def selected_output(self) -> str:
        preferred = self.translation.preferred_output_text
        if preferred is not None:
            return preferred
        # Retaining unsupported source text avoids a silent hole in a partial
        # document translation.  The document status still marks it clearly.
        return self.translation.fallback_output_text or self.source_text

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.identifier,
            "index": self.index,
            "source_text": self.source_text,
            "span": {"start": self.start, "end": self.end},
            "separator_after": self.separator_after,
            "translation": self.translation.to_dict(),
            "interlinear_by_alternative": {
                identifier: [token.to_dict() for token in tokens]
                for identifier, tokens in self.interlinear_by_alternative
            },
        }


@dataclass(frozen=True)
class TranslationDocument:
    direction: TranslationDirection
    input_text: str
    leading_text: str
    clauses: tuple[TranslationDocumentClause, ...]
    status: TranslationDocumentStatus
    selected_clause_id: str | None
    grammar_model: GrammarModelReference
    discourse_state: DiscourseState | None = None
    schema_version: str = DOCUMENT_SCHEMA_VERSION
    engine_version: str = TRANSLATION_ENGINE_VERSION

    @property
    def default_output_text(self) -> str:
        return self.leading_text + "".join(
            clause.selected_output + clause.separator_after
            for clause in self.clauses
        )

    def to_dict(self) -> dict[str, Any]:
        counts = {
            "clauses": len(self.clauses),
            "translated": sum(
                clause.translation.status is not TranslationStatus.UNSUPPORTED
                for clause in self.clauses
            ),
            "review": sum(
                clause.translation.status is TranslationStatus.AMBIGUOUS
                for clause in self.clauses
            ),
            "unsupported": sum(
                clause.translation.status is TranslationStatus.UNSUPPORTED
                for clause in self.clauses
            ),
            "authored": sum(
                bool(clause.translation.authored_matches)
                for clause in self.clauses
            ),
        }
        return {
            "schema_version": self.schema_version,
            "engine_version": self.engine_version,
            "grammar_model": self.grammar_model.to_dict(),
            "direction": self.direction.value,
            "input_text": self.input_text,
            "leading_text": self.leading_text,
            "status": self.status.value,
            "selected_clause_id": self.selected_clause_id,
            "discourse_state": (
                self.discourse_state.to_dict()
                if self.discourse_state is not None
                else None
            ),
            "default_output_text": self.default_output_text,
            "counts": counts,
            "clauses": [clause.to_dict() for clause in self.clauses],
        }


@dataclass(frozen=True)
class _ClauseSpan:
    start: int
    end: int


def _is_terminal_boundary(text: str, index: int) -> int | None:
    """Return the exclusive boundary end for punctuation at ``index``."""

    character = text[index]
    if character not in _TERMINATORS:
        return None
    if (
        character == "."
        and index > 0
        and index + 1 < len(text)
        and text[index - 1].isdigit()
        and text[index + 1].isdigit()
    ):
        return None
    end = index + 1
    while end < len(text) and text[end] in _TERMINATORS:
        end += 1
    while end < len(text) and text[end] in _CLOSERS:
        end += 1
    if end < len(text) and not text[end].isspace():
        return None
    return end


def segment_document(text: str) -> tuple[_ClauseSpan, ...]:
    """Split a document while retaining exact offsets and separators.

    Sentence punctuation, semicolons, and physical line boundaries terminate
    a clause. Decimal points do not. Whitespace belongs to the separator
    between adjacent clause spans and is never rewritten.
    """

    spans: list[_ClauseSpan] = []
    segment_start = 0

    def append_trimmed(start: int, end: int) -> None:
        while start < end and text[start].isspace():
            start += 1
        while end > start and text[end - 1].isspace():
            end -= 1
        if end > start:
            spans.append(_ClauseSpan(start=start, end=end))

    index = 0
    while index < len(text):
        if text[index] in "\r\n":
            append_trimmed(segment_start, index)
            if text[index] == "\r" and index + 1 < len(text):
                if text[index + 1] == "\n":
                    index += 1
            index += 1
            segment_start = index
            continue
        boundary_end = _is_terminal_boundary(text, index)
        if boundary_end is not None:
            append_trimmed(segment_start, boundary_end)
            segment_start = boundary_end
            index = boundary_end
            continue
        index += 1
    append_trimmed(segment_start, len(text))
    return tuple(spans)


class TranslationDocumentAnalyzer:
    """Translate and serialize a document through one retained translator."""

    def __init__(self, translator: Translator):
        self.translator = translator
        self._lexemes_by_id = {
            lexeme.identifier: lexeme
            for lexeme in translator.database.lexemes
        }
        self._lexemes_by_lemma: dict[str, tuple[Lexeme, ...]] = {}
        work: dict[str, list[Lexeme]] = {}
        for lexeme in translator.database.lexemes:
            work.setdefault(lexeme.lemma.casefold(), []).append(lexeme)
        self._lexemes_by_lemma = {
            lemma: tuple(sorted(items, key=lambda item: item.identifier))
            for lemma, items in work.items()
        }

    def analyze(
        self,
        text: str,
        direction: TranslationDirection | str,
        *,
        discourse_state: DiscourseState | None = None,
    ) -> TranslationDocument:
        selected_direction = TranslationDirection(direction)
        spans = segment_document(text)
        clauses: list[TranslationDocumentClause] = []
        current_discourse = discourse_state
        for index, span in enumerate(spans):
            source_text = text[span.start:span.end]
            result = self.translator.translate(
                source_text,
                selected_direction,
                discourse_state=current_discourse,
            )
            next_start = (
                spans[index + 1].start
                if index + 1 < len(spans)
                else len(text)
            )
            interlinear = tuple(
                (
                    alternative.identifier,
                    self._interlinear(
                        alternative,
                        selected_direction,
                        source_text,
                    ),
                )
                for alternative in result.alternatives
            )
            clauses.append(
                TranslationDocumentClause(
                    identifier=f"clause-{index + 1:03d}",
                    index=index,
                    source_text=source_text,
                    start=span.start,
                    end=span.end,
                    separator_after=text[span.end:next_start],
                    translation=result,
                    interlinear_by_alternative=interlinear,
                )
            )
            current_discourse = self._advance_discourse(
                current_discourse,
                result.selected,
                selected_direction,
            )

        status = self._document_status(clauses)
        selected_clause = next(
            (
                clause
                for clause in clauses
                if clause.translation.status
                is TranslationStatus.UNSUPPORTED
            ),
            None,
        )
        if selected_clause is None:
            selected_clause = next(
                (
                    clause
                    for clause in clauses
                    if clause.translation.status
                    is TranslationStatus.AMBIGUOUS
                ),
                clauses[0] if clauses else None,
            )
        return TranslationDocument(
            direction=selected_direction,
            input_text=text,
            leading_text=text[:spans[0].start] if spans else text,
            clauses=tuple(clauses),
            status=status,
            selected_clause_id=(
                selected_clause.identifier if selected_clause else None
            ),
            grammar_model=self.translator.grammar_model,
            discourse_state=current_discourse,
        )

    @staticmethod
    def _advance_discourse(
        current: DiscourseState | None,
        selected: TranslationAlternative | None,
        direction: TranslationDirection,
    ) -> DiscourseState | None:
        """Carry the selected overt subject into the next clause.

        Pro-drop clauses consume the existing referent but do not replace it.
        Only the Asaxi analysis path currently exposes a source-grounded
        English subject realization; English-to-Asaxi document transfer keeps
        caller-provided discourse unchanged until its frontend supplies the
        equivalent typed record.
        """

        if (
            selected is None
            or direction is not TranslationDirection.ASAXI_TO_ENGLISH
            or selected.canonical_clause is None
            or selected.canonical_clause.subject is None
            or selected.canonical_clause.omitted_subject
            or not selected.subject_text
            or selected.subject_text.startswith("[")
        ):
            return current
        return DiscourseState(
            topic=DiscourseReferent(
                nominal=selected.canonical_clause.subject,
                english_text=selected.subject_text,
            )
        )

    @staticmethod
    def _document_status(
        clauses: Iterable[TranslationDocumentClause],
    ) -> TranslationDocumentStatus:
        statuses = [clause.translation.status for clause in clauses]
        if not statuses or all(
            status is TranslationStatus.UNSUPPORTED for status in statuses
        ):
            return TranslationDocumentStatus.UNSUPPORTED
        if any(
            status is TranslationStatus.UNSUPPORTED for status in statuses
        ):
            return TranslationDocumentStatus.PARTIAL
        if any(status is TranslationStatus.AMBIGUOUS for status in statuses):
            return TranslationDocumentStatus.AMBIGUOUS
        return TranslationDocumentStatus.OK

    def _interlinear(
        self,
        alternative: TranslationAlternative,
        direction: TranslationDirection,
        source_text: str,
    ) -> tuple[InterlinearToken, ...]:
        analysis_alternative = alternative
        analysis_direction = direction
        if direction is TranslationDirection.ENGLISH_TO_ASAXI:
            reverse = self.translator.translate(
                alternative.output_text,
                TranslationDirection.ASAXI_TO_ENGLISH,
            )
            source_key = self._comparison_text(source_text)
            analysis_alternative = next(
                (
                    candidate
                    for candidate in reverse.alternatives
                    if self._comparison_text(candidate.output_text)
                    == source_key
                ),
                reverse.selected,
            )
            if analysis_alternative is None:
                return ()
            analysis_direction = TranslationDirection.ASAXI_TO_ENGLISH
        return tuple(
            self._interlinear_token(
                token,
                analysis_alternative,
                analysis_direction,
            )
            for token in analysis_alternative.tokens
        )

    @staticmethod
    def _comparison_text(text: str) -> str:
        collapsed = " ".join(text.casefold().split())
        return re.sub(r"\s+([.,!?;:])", r"\1", collapsed)

    def _interlinear_token(
        self,
        token: TranslationToken,
        alternative: TranslationAlternative,
        direction: TranslationDirection,
    ) -> InterlinearToken:
        analysis = token.morphology[0] if token.morphology else None
        lemma = analysis.lemma if analysis else token.normalized
        morphemes = (
            analysis.morphemes
            if analysis and analysis.morphemes
            else (token.surface,)
        )
        features = analysis.features if analysis else ()
        confidence = analysis.confidence if analysis else "surface"
        provenance = (
            f"lexicon:{analysis.lexeme_id}"
            if analysis and analysis.lexeme_id
            else (
                "morphology"
                if analysis
                else "surface"
            )
        )
        gloss = self._token_gloss(token, alternative, direction, analysis)
        return InterlinearToken(
            token_index=token.index,
            surface=token.surface,
            role=token.role,
            lemma=lemma,
            morphemes=tuple(morphemes),
            gloss=gloss,
            features=tuple(features),
            confidence=confidence,
            provenance=provenance,
        )

    def _token_gloss(
        self,
        token: TranslationToken,
        alternative: TranslationAlternative,
        direction: TranslationDirection,
        analysis: Any,
    ) -> str:
        role = token.role
        normalized = token.normalized
        if role == "punctuation" or token.kind == "punctuation":
            return token.surface
        if role == "subject-marker":
            return "SBJ.OBJ" if normalized == "to" else "SBJ.SUBJ"
        if role == "nested-subject-marker":
            return "SBJ"
        if role == "question":
            return "Q"
        if role == "nominal-connector":
            return "AND"
        if role == "clause-connector":
            return {
                "ŕa": "AND",
                "si": "OR",
                "dzè": "BUT",
            }.get(normalized, "CONN")
        if role == "genitive-marker":
            return "GEN"
        if role and role.startswith("wh-"):
            return {
                "kshá": "WHO",
                "kjo": "WHAT",
                "ksi": "WHERE",
                "kvå": "WHEN",
                "ksè": "WHY",
                "ksá": "HOW",
            }.get(normalized, "WH")
        if role == "determiner":
            return {
                "anő": "INDF",
                "onă": "DEF",
                "onýj": "DEF",
                "a": "INDF",
                "an": "INDF",
                "the": "DEF",
            }.get(normalized, "DET")
        if role == "auxiliary":
            return alternative.canonical_clause.tense.value.upper()
        if role == "negation":
            return "NEG"

        clause = alternative.canonical_clause
        if direction is TranslationDirection.ENGLISH_TO_ASAXI:
            if role == "subject" and clause.subject is not None:
                return clause.subject.surface
            if role == "object" and clause.object is not None:
                return clause.object.surface
            if role == "predicate":
                return clause.predicate
            return normalized

        selected_sense = self._selected_sense(alternative, role)
        if selected_sense:
            return selected_sense
        lexeme_id = getattr(analysis, "lexeme_id", None)
        lexeme = self._lexemes_by_id.get(lexeme_id)
        if lexeme is None and role in {"predicate", "relative-predicate"}:
            candidates = self._lexemes_by_lemma.get(clause.predicate, ())
            lexeme = candidates[0] if candidates else None
        if lexeme is not None:
            glosses = split_english_gloss(lexeme)
            if glosses:
                return glosses[0]
        if role == "predicate":
            return {
                PredicateKind.IDENTITY: "BE.ID",
                PredicateKind.PERFORMANCE: "BE.PERF",
                PredicateKind.EXISTENCE: "EXIST",
                PredicateKind.CONSTITUTION: "BE.CONST",
                PredicateKind.LOCATION: "LOC",
                PredicateKind.POSSESSION: "POSS",
                PredicateKind.RELATION: "REL",
            }.get(clause.predicate_kind, token.surface)
        if (
            role
            in {
                "subject",
                "object",
                "complement",
                "location",
                "possessor",
                "modifier",
                "relative-subject",
            }
            and token.surface.isupper()
        ):
            return token.normalized[:1].upper() + token.normalized[1:]
        return token.surface

    @staticmethod
    def _selected_sense(
        alternative: TranslationAlternative,
        role: str | None,
    ) -> str | None:
        for ambiguity in alternative.ambiguities:
            if (
                role == "predicate"
                and ambiguity.code == "UNSPLIT_SOURCE_GLOSS"
            ):
                return ambiguity.selected
            if (
                role
                in {
                    "subject",
                    "object",
                    "complement",
                    "location",
                    "possessor",
                    "modifier",
                    "relative-subject",
                }
                and ambiguity.code == "NOMINAL_LEXICAL_AMBIGUITY"
            ):
                return ambiguity.selected.split(" [", 1)[0]
        return None


def translate_document(
    translator: Translator,
    text: str,
    direction: TranslationDirection | str,
    *,
    discourse_state: DiscourseState | None = None,
) -> TranslationDocument:
    """Convenience API for callers that retain only the clause translator."""

    return TranslationDocumentAnalyzer(translator).analyze(
        text,
        direction,
        discourse_state=discourse_state,
    )
