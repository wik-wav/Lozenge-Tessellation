"""Deterministic lexical indexes used by both translation directions."""

from __future__ import annotations

from dataclasses import dataclass
import re

from .models import (
    LanguageDatabase,
    Lexeme,
    LexicalVariant,
    SpecificationStatus,
)
from .thesaurus import (
    SUPPORTED_PARTS_OF_SPEECH,
    ThesaurusCandidate,
    ThesaurusProvider,
)


GLOSS_SEPARATOR_RE = re.compile(r"\s*(?:[,;/]|\bor\b)\s*", re.IGNORECASE)
LEADING_TO_RE = re.compile(r"^to\s+", re.IGNORECASE)
EDITORIAL_GLOSS_SUFFIX_RE = re.compile(
    r"\s+\((?:noun|verb|adjective|adverb|particle|warm|cold|"
    r"warm\s+noun|cold\s+noun)\)\s*$",
    re.IGNORECASE,
)
PARENTHETICAL_GLOSS_QUALIFIER_RE = re.compile(
    r"\s+\((?:general|generic|broad|formal|informal|colloquial|"
    r"literary|technical|medical|literal|figurative)\)\s*$",
    re.IGNORECASE,
)
OUTER_EDITORIAL_PARENTHESES_RE = re.compile(r"^\(([^()]+)\)$")
OUTER_QUOTE_PAIRS = {
    '"': '"',
    "'": "'",
    "“": "”",
    "‘": "’",
}
VERB_GLOSS_BASE_OVERRIDES = {
    # The source entry explicitly lexicalizes this manner-bearing gloss as
    # ordinary walking.  This is an exact licensed mapping, not a general
    # rule that strips ``on foot`` from unrelated predicates.
    "walk on foot": ("walk",),
}
GERUND_GLOSS_EQUIVALENTS = {
    # The gerund-list example in Relative Clauses section 5 translates the
    # lexical ``write (notes)`` verb idiomatically as English ``take notes``.
    # Keep that source-attested lexical equivalence local to gerund lookup;
    # it is not a general write/take substitution rule.
    "write (notes)": ("take notes", "write notes"),
}


def _strip_outer_quotes(text: str) -> str:
    """Remove editorial quotation marks surrounding a complete gloss."""

    value = text.strip()
    while (
        len(value) >= 2
        and value[0] in OUTER_QUOTE_PAIRS
        and value[-1] == OUTER_QUOTE_PAIRS[value[0]]
    ):
        value = value[1:-1].strip()
    return value


def split_english_gloss_value(value: str) -> tuple[str, ...]:
    """Split one source gloss field with the lexicon's normal safeguards."""

    values: list[str] = []

    def append(term: str) -> None:
        if term and term.casefold() not in {
            value.casefold() for value in values
        }:
            values.append(term)

    for part in GLOSS_SEPARATOR_RE.split(value):
        term = _strip_outer_quotes(part)
        term = LEADING_TO_RE.sub("", term)
        term = _strip_outer_quotes(term.strip(" .?!"))
        term = EDITORIAL_GLOSS_SUFFIX_RE.sub("", term).strip()
        # A whole gloss term in parentheses is an editorially secondary
        # synonym, not literal punctuation in the translated sentence.
        # The untouched source field remains available as provenance.
        match = OUTER_EDITORIAL_PARENTHESES_RE.fullmatch(term)
        if match:
            term = match.group(1).strip()
        append(term)
        # Parenthetical qualifiers disambiguate a documented sense but do
        # not prevent lookup by its ordinary lexical head. Keep both so a
        # query for ``doctor`` can find ``doctor (general)`` while the
        # qualified source gloss remains traceable.
        append(PARENTHETICAL_GLOSS_QUALIFIER_RE.sub("", term).strip())
    return tuple(values)


def split_english_gloss(lexeme: Lexeme) -> tuple[str, ...]:
    """Return source-order English terms without hiding qualified glosses."""

    values: list[str] = []
    for sense in lexeme.senses:
        if not sense.gloss_en.is_present or not sense.gloss_en.value:
            continue
        for term in split_english_gloss_value(str(sense.gloss_en.value)):
            if term.casefold() not in {item.casefold() for item in values}:
                values.append(term)
    return tuple(values)


def _english_verb_bases_from_terms(
    terms: tuple[str, ...],
) -> tuple[str, ...]:
    """Return one-word verb bases from already parsed source glosses."""

    values: list[str] = []
    for term in terms:
        normalized = term.casefold()
        candidates = [normalized] if " " not in normalized else []
        candidates.extend(
            VERB_GLOSS_BASE_OVERRIDES.get(normalized, ())
        )
        for candidate in candidates:
            if candidate not in values:
                values.append(candidate)
    return tuple(values)


def english_verb_bases(lexeme: Lexeme) -> tuple[str, ...]:
    """Return documented one-word verb bases plus safe manner contraction.

    The source gloss ``walk on foot`` licenses ``walk`` through an explicit
    override. Other multiword predicates remain atomic so phrasal verbs and
    arbitrary ``X on foot`` strings cannot be reduced to misleading heads.
    """

    return _english_verb_bases_from_terms(split_english_gloss(lexeme))


def present_third_person(base: str) -> str:
    word = base.casefold()
    irregular = {
        "be": "is",
        "have": "has",
        "do": "does",
        "go": "goes",
    }
    if word in irregular:
        return irregular[word]
    if word.endswith(("s", "sh", "ch", "x", "z", "o")):
        return word + "es"
    if (
        word.endswith("y")
        and len(word) > 1
        and word[-2] not in "aeiou"
    ):
        return word[:-1] + "ies"
    return word + "s"


def past_tense(base: str) -> str:
    word = base.casefold()
    irregular = {
        "be": "was",
        "begin": "began",
        "come": "came",
        "do": "did",
        "drink": "drank",
        "eat": "ate",
        "find": "found",
        "fight": "fought",
        "get": "got",
        "give": "gave",
        "go": "went",
        "have": "had",
        "know": "knew",
        "leave": "left",
        "make": "made",
        "read": "read",
        "run": "ran",
        "say": "said",
        "see": "saw",
        "take": "took",
        "think": "thought",
        "write": "wrote",
    }
    if word in irregular:
        return irregular[word]
    if word.endswith("e"):
        return word + "d"
    if (
        word.endswith("y")
        and len(word) > 1
        and word[-2] not in "aeiou"
    ):
        return word[:-1] + "ied"
    return word + "ed"


def past_participle(base: str) -> str:
    word = base.casefold()
    irregular = {
        "be": "been",
        "begin": "begun",
        "come": "come",
        "do": "done",
        "drink": "drunk",
        "eat": "eaten",
        "find": "found",
        "get": "gotten",
        "give": "given",
        "go": "gone",
        "have": "had",
        "know": "known",
        "leave": "left",
        "make": "made",
        "read": "read",
        "run": "run",
        "say": "said",
        "see": "seen",
        "take": "taken",
        "think": "thought",
        "write": "written",
    }
    return irregular.get(word, past_tense(word))


def present_participle(base: str) -> str:
    word = base.casefold()
    irregular = {
        "be": "being",
        "die": "dying",
        "lie": "lying",
        "tie": "tying",
    }
    if word in irregular:
        return irregular[word]
    if word.endswith("ie"):
        return word[:-2] + "ying"
    if word.endswith("e") and not word.endswith(("ee", "ye", "oe")):
        return word[:-1] + "ing"
    if (
        len(word) >= 3
        and word[-1] not in "aeiouwxy"
        and word[-2] in "aeiou"
        and word[-3] not in "aeiou"
    ):
        return word + word[-1] + "ing"
    return word + "ing"


def present_participle_phrase(base: str) -> str:
    """Inflect only the verbal head of an exact documented gloss phrase."""

    words = base.casefold().split()
    if not words:
        return ""
    return " ".join((present_participle(words[0]), *words[1:]))


def english_gerund_forms(base: str) -> tuple[str, ...]:
    """Return source-attested and literal gerund renderings in rank order."""

    candidates = (
        *GERUND_GLOSS_EQUIVALENTS.get(base.casefold(), ()),
        base,
    )
    return tuple(
        dict.fromkeys(
            form
            for candidate in candidates
            if (form := present_participle_phrase(candidate))
        )
    )


def plural_noun(noun: str) -> str:
    word = noun.casefold()
    irregular = {
        "person": "people",
        "child": "children",
        "mouse": "mice",
    }
    if word in irregular:
        return irregular[word]
    if word.endswith(("s", "sh", "ch", "x", "z")):
        return word + "es"
    if (
        word.endswith("y")
        and len(word) > 1
        and word[-2] not in "aeiou"
    ):
        return word[:-1] + "ies"
    return word + "s"


@dataclass(frozen=True)
class EnglishVerbMatch:
    lexeme: Lexeme
    base: str
    tense_hint: str
    asaxi_surface: str
    explicit_derived_term: bool = False
    thesaurus_candidate: ThesaurusCandidate | None = None


@dataclass(frozen=True)
class EnglishGerundMatch:
    """An exact English gerund licensed by a documented verb gloss."""

    lexeme: Lexeme
    base: str


@dataclass(frozen=True)
class EnglishLexicalCandidate:
    """One exact or synonym-mediated route to a documented Asaxi lexeme."""

    lexeme: Lexeme
    source_term: str
    matched_term: str
    category: str
    thesaurus_candidate: ThesaurusCandidate | None = None

    @property
    def is_direct(self) -> bool:
        return self.thesaurus_candidate is None


@dataclass(frozen=True)
class AsaxiLexicalMatch:
    """A canonical lexeme match plus optional source-variant provenance."""

    lexeme: Lexeme
    variant: LexicalVariant | None = None


class TranslationLexicon:
    def __init__(self, database: LanguageDatabase):
        self.database = database
        self.by_surface: dict[str, tuple[Lexeme, ...]] = {}
        surface_work: dict[str, list[Lexeme]] = {}
        variant_work: dict[str, list[AsaxiLexicalMatch]] = {}
        english_work: dict[tuple[str, str], list[Lexeme]] = {}
        verb_form_work: dict[str, list[EnglishVerbMatch]] = {}
        gerund_form_work: dict[str, list[EnglishGerundMatch]] = {}
        for lexeme in database.lexemes:
            surface_work.setdefault(
                lexeme.surface_form.casefold(),
                [],
            ).append(lexeme)
            for variant in lexeme.variants:
                variant_work.setdefault(
                    variant.surface.casefold(),
                    [],
                ).append(
                    AsaxiLexicalMatch(
                        lexeme=lexeme,
                        variant=variant,
                    )
                )
            for term in split_english_gloss(lexeme):
                english_work.setdefault(
                    (lexeme.category, term.casefold()),
                    [],
                ).append(lexeme)
            if lexeme.category == "verb":
                for base in split_english_gloss(lexeme):
                    for form in english_gerund_forms(base):
                        gerund_form_work.setdefault(form, []).append(
                            EnglishGerundMatch(
                                lexeme=lexeme,
                                base=base.casefold(),
                            )
                        )
                for base in english_verb_bases(lexeme):
                    variants = (
                        (base, "nonpast"),
                        (present_third_person(base), "nonpast"),
                        (past_tense(base), "past"),
                        (present_participle(base), "nonpast"),
                    )
                    for form, tense_hint in variants:
                        verb_form_work.setdefault(form, []).append(
                            EnglishVerbMatch(
                                lexeme=lexeme,
                                base=base,
                                tense_hint=tense_hint,
                                asaxi_surface=lexeme.lemma,
                            )
                        )
            for term in lexeme.derived_terms:
                if (
                    term.surface is None
                    or " " in term.surface.strip()
                    or term.category != "verb"
                    or term.status is SpecificationStatus.INCOMPLETE
                    or not term.gloss_en.is_present
                    or not term.gloss_en.value
                ):
                    continue
                derived_glosses = split_english_gloss_value(
                    str(term.gloss_en.value)
                )
                for base in _english_verb_bases_from_terms(
                    derived_glosses
                ):
                    variants = (
                        (base, "nonpast"),
                        (present_third_person(base), "nonpast"),
                        (past_tense(base), "past"),
                        (present_participle(base), "nonpast"),
                    )
                    for form, tense_hint in variants:
                        verb_form_work.setdefault(form, []).append(
                            EnglishVerbMatch(
                                lexeme=lexeme,
                                base=base,
                                tense_hint=tense_hint,
                                asaxi_surface=term.surface.casefold(),
                                explicit_derived_term=True,
                            )
                        )
        self.by_surface = {
            key: tuple(
                sorted(values, key=lambda lexeme: lexeme.identifier)
            )
            for key, values in surface_work.items()
        }
        self.by_variant = {
            key: tuple(
                sorted(
                    values,
                    key=lambda match: (
                        match.lexeme.identifier,
                        match.variant.contexts if match.variant else (),
                    ),
                )
            )
            for key, values in variant_work.items()
        }
        self.by_english = {
            key: tuple(
                sorted(values, key=lambda lexeme: lexeme.identifier)
            )
            for key, values in english_work.items()
        }
        self.english_verb_forms = {
            key: tuple(
                sorted(
                    {
                        (
                            value.lexeme.identifier,
                            value.base,
                            value.tense_hint,
                            value.asaxi_surface,
                            value.explicit_derived_term,
                        ): value
                        for value in values
                    }.values(),
                    key=lambda match: (
                        match.lexeme.identifier,
                        match.asaxi_surface,
                        match.base,
                        match.tense_hint,
                    ),
                )
            )
            for key, values in verb_form_work.items()
        }
        self.english_gerund_forms = {
            key: tuple(
                sorted(
                    {
                        (value.lexeme.identifier, value.base): value
                        for value in values
                    }.values(),
                    key=lambda match: (
                        match.lexeme.identifier,
                        match.base,
                    ),
                )
            )
            for key, values in gerund_form_work.items()
        }

    def asaxi_matches(
        self,
        surface: str,
        *,
        has_following_material: bool = False,
    ) -> tuple[AsaxiLexicalMatch, ...]:
        """Return canonical and positionally licensed source-form matches."""

        key = surface.casefold()
        matches = [
            AsaxiLexicalMatch(lexeme=lexeme)
            for lexeme in self.by_surface.get(key, ())
        ]
        for match in self.by_variant.get(key, ()):
            variant = match.variant
            if variant is None:
                continue
            if (
                "before-following-material" in variant.contexts
                and not has_following_material
            ):
                continue
            matches.append(match)
        unique: dict[tuple[str, str], AsaxiLexicalMatch] = {}
        for match in matches:
            unique[
                (
                    match.lexeme.identifier,
                    match.variant.surface.casefold()
                    if match.variant is not None
                    else "",
                )
            ] = match
        return tuple(unique[key] for key in sorted(unique))

    def english_gerund_matches(
        self,
        term: str,
    ) -> tuple[EnglishGerundMatch, ...]:
        """Return exact lexical gerunds; never infer from ``-ing`` alone."""

        return self.english_gerund_forms.get(term.casefold(), ())

    def english_matches(
        self,
        term: str,
        *categories: str,
    ) -> tuple[Lexeme, ...]:
        selected: list[Lexeme] = []
        for category in categories:
            selected.extend(
                self.by_english.get((category, term.casefold()), ())
            )
        unique = {lexeme.identifier: lexeme for lexeme in selected}
        return tuple(unique[key] for key in sorted(unique))

    def english_candidates(
        self,
        term: str,
        *categories: str,
        thesaurus: ThesaurusProvider | None = None,
    ) -> tuple[EnglishLexicalCandidate, ...]:
        """Resolve exact glosses first, then same-POS synonyms if necessary.

        Synonyms only widen English lookup. Every target remains a compiled
        Asaxi lexeme, and any exact match suppresses thesaurus expansion.
        """

        source = term.casefold()
        direct: list[EnglishLexicalCandidate] = []
        for category in categories:
            for lexeme in self.by_english.get((category, source), ()):
                direct.append(
                    EnglishLexicalCandidate(
                        lexeme=lexeme,
                        source_term=source,
                        matched_term=source,
                        category=category,
                    )
                )
        if direct:
            return self._unique_english_candidates(direct)
        if thesaurus is None or not thesaurus.available:
            return ()

        widened: list[EnglishLexicalCandidate] = []
        for category in categories:
            if category not in SUPPORTED_PARTS_OF_SPEECH:
                continue
            for synonym in thesaurus.lookup(source, category):
                if synonym.relation != "synonym":
                    continue
                matched_term = synonym.term.casefold()
                for lexeme in self.by_english.get(
                    (category, matched_term),
                    (),
                ):
                    widened.append(
                        EnglishLexicalCandidate(
                            lexeme=lexeme,
                            source_term=source,
                            matched_term=matched_term,
                            category=category,
                            thesaurus_candidate=synonym,
                        )
                    )
        return self._unique_english_candidates(widened)

    def english_verb_matches(
        self,
        term: str,
        *,
        thesaurus: ThesaurusProvider | None = None,
    ) -> tuple[EnglishVerbMatch, ...]:
        """Resolve an English verb form with exact-first synonym fallback."""

        source = term.casefold()
        direct = self.english_verb_forms.get(source, ())
        if direct:
            return direct
        if thesaurus is None or not thesaurus.available:
            return ()

        widened: list[EnglishVerbMatch] = []
        for synonym in thesaurus.lookup(source, "verb"):
            if synonym.relation != "synonym":
                continue
            matched_term = synonym.term.casefold()
            synonym_forms = self.english_verb_forms.get(
                matched_term,
                (),
            )
            if synonym_forms:
                widened.extend(
                    EnglishVerbMatch(
                        lexeme=match.lexeme,
                        base=match.base,
                        tense_hint=self._source_tense_hint(
                            source,
                            synonym.query_lemma,
                        ),
                        asaxi_surface=match.asaxi_surface,
                        explicit_derived_term=match.explicit_derived_term,
                        thesaurus_candidate=synonym,
                    )
                    for match in synonym_forms
                )
                continue
            for lexeme in self.by_english.get(
                ("verb", matched_term),
                (),
            ):
                widened.append(
                    EnglishVerbMatch(
                        lexeme=lexeme,
                        base=matched_term,
                        tense_hint=self._source_tense_hint(
                            source,
                            synonym.query_lemma,
                        ),
                        asaxi_surface=lexeme.lemma,
                        thesaurus_candidate=synonym,
                    )
                )
        unique: list[EnglishVerbMatch] = []
        seen: set[tuple[object, ...]] = set()
        for match in widened:
            key = (
                match.lexeme.identifier,
                match.asaxi_surface,
                match.explicit_derived_term,
                match.base,
                match.tense_hint,
                (
                    match.thesaurus_candidate.provider,
                    match.thesaurus_candidate.provider_version,
                    match.thesaurus_candidate.sense_id,
                    match.thesaurus_candidate.term,
                    match.thesaurus_candidate.query_lemma,
                )
                if match.thesaurus_candidate is not None
                else None,
            )
            if key in seen:
                continue
            seen.add(key)
            unique.append(match)
        # Provider order carries sense and lemma preference. Re-sorting here
        # by an opaque target identifier can promote a weaker synonym.
        return tuple(unique)

    @staticmethod
    def _source_tense_hint(
        source: str,
        query_lemma: str | None,
    ) -> str:
        lemma = (query_lemma or source).casefold()
        return "past" if past_tense(lemma) == source else "nonpast"

    @staticmethod
    def _unique_english_candidates(
        candidates: list[EnglishLexicalCandidate],
    ) -> tuple[EnglishLexicalCandidate, ...]:
        unique: list[EnglishLexicalCandidate] = []
        seen: set[tuple[object, ...]] = set()
        for candidate in candidates:
            thesaurus = candidate.thesaurus_candidate
            key = (
                candidate.lexeme.identifier,
                candidate.category,
                candidate.matched_term,
                thesaurus.provider if thesaurus else None,
                thesaurus.provider_version if thesaurus else None,
                thesaurus.sense_id if thesaurus else None,
                thesaurus.query_lemma if thesaurus else None,
            )
            if key in seen:
                continue
            seen.add(key)
            unique.append(candidate)
        return tuple(unique)
