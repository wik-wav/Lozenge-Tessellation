"""Typed semantic clause records and a minimal canonical Asaxi generator."""

from __future__ import annotations

from dataclasses import dataclass, replace
from enum import Enum
from typing import Any, Iterable

from .morphology import verbalize_nominal
from .productive_morphology import (
    VerbAspect,
    VerbComplexSpec,
    VerbMood,
    VerbPolarity,
    VerbRootKind,
    VerbTense,
    VerbVoice,
    reduce_class_suffix,
    realize_verb_complex,
)


class Tense(str, Enum):
    NONPAST = "nonpast"
    PAST = "past"
    FUTURE = "future"


class Polarity(str, Enum):
    POSITIVE = "positive"
    NEGATIVE = "negative"


class Register(str, Enum):
    OBJECTIVE = "objective"
    SUBJECTIVE = "subjective"


class DeicticDistance(str, Enum):
    PROXIMAL = "proximal"
    MEDIAL = "medial"
    DISTAL = "distal"
    INDEFINITE = "indefinite"


class PredicateKind(str, Enum):
    ACTION = "action"
    IDENTITY = "identity"
    PERFORMANCE = "performance"
    EXISTENCE = "existence"
    CONSTITUTION = "constitution"
    LOCATION = "location"
    POSSESSION = "possession"
    RELATION = "relation"
    FRAGMENT = "fragment"


class ResultativeMode(str, Enum):
    NONE = "none"
    CESSATIVE = "cessative"


class PotentialMode(str, Enum):
    NONE = "none"
    AFFIRMATIVE = "affirmative"
    NEGATIVE = "negative"


class SubjunctiveMode(str, Enum):
    NONE = "none"
    HYPOTHETICAL = "hypothetical"
    OPTATIVE = "optative"
    AVERSIVE = "aversive"
    SUPPLICATIVE = "supplicative"


class Modality(str, Enum):
    NONE = "none"
    DESIDERATIVE = "desiderative"
    CONATIVE = "conative"


class CausativeVoice(str, Enum):
    PERMISSIVE = "permissive"
    COERCIVE = "coercive"
    PROHIBITIVE = "prohibitive"


class DirectiveKind(str, Enum):
    COMMAND = "command"
    PROHIBITION = "prohibition"
    ABSOLUTE_PROHIBITION = "absolute-prohibition"
    REQUEST = "request"
    INSTRUCTION = "instruction"
    POLITE_PROHIBITION = "polite-prohibition"
    CESSATION = "cessation"
    CONTINUATION = "continuation"
    SWITCH = "switch"
    HORTATIVE = "hortative"
    POLITE_HORTATIVE = "polite-hortative"


class DirectivePlacement(str, Enum):
    PREFIX = "prefix"
    SUFFIX = "suffix"
    CIRCUMFIX = "circumfix"


class DirectiveFocus(str, Enum):
    """Documented pragmatic focus contributed by flow-marker placement."""

    UNMARKED = "unmarked"
    REACTIONARY = "reactionary"
    PREEMPTIVE_SHARP = "preemptive-sharp"
    SUSTAINMENT = "sustainment"
    PERSISTENCE = "persistence"


def directive_focus_for(
    kind: DirectiveKind,
    placement: DirectivePlacement,
) -> DirectiveFocus:
    """Return the source-documented focus for one flow-command position."""

    if kind is DirectiveKind.CESSATION:
        return (
            DirectiveFocus.PREEMPTIVE_SHARP
            if placement is DirectivePlacement.PREFIX
            else DirectiveFocus.REACTIONARY
            if placement is DirectivePlacement.SUFFIX
            else DirectiveFocus.UNMARKED
        )
    if kind is DirectiveKind.CONTINUATION:
        return (
            DirectiveFocus.PERSISTENCE
            if placement is DirectivePlacement.PREFIX
            else DirectiveFocus.SUSTAINMENT
            if placement is DirectivePlacement.SUFFIX
            else DirectiveFocus.UNMARKED
        )
    return DirectiveFocus.UNMARKED


class TemporalAspect(str, Enum):
    NONE = "none"
    CURRENT = "current"
    PROSPECTIVE = "prospective"
    RETROSPECTIVE = "retrospective"
    PERSISTIVE = "persistive"


class WordTimeOrientation(str, Enum):
    """Temporal direction contributed by a word-level time modifier."""

    RETROSPECTIVE = "retrospective"
    PROSPECTIVE = "prospective"


class WordTimePlacement(str, Enum):
    """Surface position of a floating time modifier around its host."""

    PREFIX = "prefix"
    SUFFIX = "suffix"


class WordTimeScope(str, Enum):
    """Lexical category whose timeline is modified independently."""

    NOUN = "noun"
    ADJECTIVE = "adjective"
    ADVERBIAL_PREDICATE = "adverbial-predicate"


class ValidityMode(str, Enum):
    NONE = "none"
    ESSENTIAL = "essential"
    CIRCUMSTANTIAL = "circumstantial"
    DYNAMIC = "dynamic"


class VerbalizationMode(str, Enum):
    PERFORMANCE = "performance"
    INTERACTION = "interaction"
    SEMBLANCE = "semblance"
    TRANSFORMATIVE = "transformative"
    GENERATIVE = "generative"
    PRIVATIVE = "privative"
    SUBJECTIVE = "subjective"
    VISUAL = "visual"
    AUDITORY = "auditory"
    OLFACTORY = "olfactory"
    TACTILE = "tactile"
    GUSTATORY = "gustatory"


class FrequencyKind(str, Enum):
    INTERMITTENT = "intermittent"
    OFTEN = "often"
    SOMETIME = "sometime"
    ETERNAL = "eternal"
    USUAL = "usual"
    NEVER = "never"
    EMPHATIC_NEVER = "emphatic-never"
    DAILY = "daily"
    ALTERNATE_DAILY = "alternate-daily"
    WHENEVER = "whenever"
    EVERY_TIME = "every-time"
    YEARLY = "yearly"


class DistributionKind(str, Enum):
    GENERAL = "general"
    SEQUENTIAL = "sequential"
    SPATIAL = "spatial"


class DistributionScope(str, Enum):
    NOMINAL = "nominal"
    EVENT = "event"


class NominalQuantifierKind(str, Enum):
    UNIVERSAL = "universal"


class NominalExtentKind(str, Enum):
    COMPLETE = "complete"
    FRACTIONAL = "fractional"


class WhRole(str, Enum):
    SUBJECT = "subject"
    OBJECT = "object"
    COMPLEMENT = "complement"
    LOCATION = "location"
    TIME = "time"
    REASON = "reason"
    MANNER = "manner"


class ClauseConnector(str, Enum):
    AND = "and"
    OR = "or"
    BUT = "but"
    IF = "if"
    UNLESS = "unless"
    EVEN_IF = "even-if"
    BECAUSE = "because"
    SO = "so"
    WHEN = "when"
    WHILE = "while"
    THEN = "then"
    BY_THE_TIME = "by-the-time"


class PreclausalMarkerKind(str, Enum):
    REACTIVE_OBJECTION = "reactive-objection"
    REACTIVE_CONTINUATION = "reactive-continuation"
    AWE = "awe"
    EMOTIONAL_REALIZATION = "emotional-realization"


class DiscourseMarkerKind(str, Enum):
    AGREEMENT = "agreement"
    ASSERTION = "assertion"
    CASUAL_EMPHASIS = "casual-emphasis"
    SKEPTICISM = "skepticism"
    RESIGNATION = "resignation"
    CONTENTION = "contention"


class EpistemicStance(str, Enum):
    """Documented certainty or temporal judgment over a proposition."""

    SURE = "sure"
    KNOWN = "known"
    THINK = "think"
    UNSURE = "unsure"
    DOUBT = "doubt"
    SUBJECTIVE_PAST = "subjective-past"
    MEMORY_FACT = "memory-fact"
    FUTURE_FACT = "future-fact"


class TteFunction(str, Enum):
    """Documented grammatical functions of the generalized ``tte`` binder."""

    BARE = "bare"
    QUOTATIVE = "quotative"
    EXPLANATORY = "explanatory"
    TOPIC = "topic"
    EPISTEMIC = "epistemic"


ASAXI_DETERMINERS = frozenset({"anő", "onă", "onýj", "ponă", "ponýj"})


ASAXI_TEMPORAL_ASPECT_MARKERS = {
    TemporalAspect.CURRENT: "nå",
    TemporalAspect.PROSPECTIVE: "panå",
    TemporalAspect.RETROSPECTIVE: "hùnå",
    TemporalAspect.PERSISTIVE: "vanå",
}

ASAXI_RESULTATIVE_MARKERS = {
    ResultativeMode.CESSATIVE: "tomo'",
}

ASAXI_POTENTIAL_MARKERS = {
    PotentialMode.AFFIRMATIVE: "ken",
    PotentialMode.NEGATIVE: "ken.ná",
}

ASAXI_SUBJUNCTIVE_MARKERS = {
    SubjunctiveMode.HYPOTHETICAL: "xăxă",
    SubjunctiveMode.OPTATIVE: "dăxă",
    SubjunctiveMode.AVERSIVE: "pùxă",
    SubjunctiveMode.SUPPLICATIVE: "xădăchỏxă",
}

ASAXI_FREQUENCY_MARKERS = {
    FrequencyKind.INTERMITTENT: "izånixå",
    FrequencyKind.OFTEN: "nanå",
    FrequencyKind.SOMETIME: "gănå",
    FrequencyKind.ETERNAL: "onå",
    FrequencyKind.USUAL: "opùnå",
    FrequencyKind.NEVER: "nåsi",
    FrequencyKind.EMPHATIC_NEVER: "náxănåsi",
    FrequencyKind.DAILY: "ximă",
    FrequencyKind.ALTERNATE_DAILY: "tammă",
    FrequencyKind.WHENEVER: "gămă",
    FrequencyKind.EVERY_TIME: "åmă",
    FrequencyKind.YEARLY: "txămă",
}

ASAXI_DISTRIBUTIVE_MARKERS = {
    DistributionKind.GENERAL: "ojano",
    DistributionKind.SEQUENTIAL: "jonojo",
    DistributionKind.SPATIAL: "okonoko",
}

ASAXI_CLAUSE_CONNECTOR_MARKERS = {
    ClauseConnector.AND: "ŕa",
    ClauseConnector.OR: "si",
    ClauseConnector.BUT: "dzè",
    ClauseConnector.IF: "chě",
    ClauseConnector.UNLESS: "chěná",
    ClauseConnector.EVEN_IF: "chěxa",
    ClauseConnector.BECAUSE: "sèwo",
    ClauseConnector.SO: "sèni",
    ClauseConnector.WHEN: "vå",
    ClauseConnector.WHILE: "nivå",
    ClauseConnector.THEN: "zå",
    ClauseConnector.BY_THE_TIME: "måniåkam",
}

ASAXI_PRECLAUSAL_MARKERS = {
    PreclausalMarkerKind.REACTIVE_OBJECTION: "dzè",
    PreclausalMarkerKind.REACTIVE_CONTINUATION: "ŕa",
    PreclausalMarkerKind.AWE: "wå",
    PreclausalMarkerKind.EMOTIONAL_REALIZATION: "ox",
}

ASAXI_DISCOURSE_MARKER_FORMS = {
    DiscourseMarkerKind.AGREEMENT: ("ë", "në"),
    DiscourseMarkerKind.ASSERTION: ("ő", "wő"),
    DiscourseMarkerKind.CASUAL_EMPHASIS: ("jỏ",),
    DiscourseMarkerKind.SKEPTICISM: ("e", "me"),
    DiscourseMarkerKind.RESIGNATION: ("aŕa",),
    DiscourseMarkerKind.CONTENTION: ("iŕè",),
}

ASAXI_EPISTEMIC_FORMS = {
    EpistemicStance.SURE: ("tte", "xăcè"),
    EpistemicStance.KNOWN: ("tte", "cè"),
    EpistemicStance.THINK: ("tte", "ŕima"),
    EpistemicStance.UNSURE: ("tte", "pùŕima"),
    EpistemicStance.DOUBT: ("tte", "náŕima"),
    EpistemicStance.SUBJECTIVE_PAST: ("tte", "ŕima", "zèxiŕa"),
    EpistemicStance.MEMORY_FACT: ("tte", "sỏxiŕa"),
    EpistemicStance.FUTURE_FACT: ("tte", "paxiŕa"),
}

# Discourse allomorphy is marker-specific. The grammar explicitly attests
# ``shěsonů ë`` and ``shánă ů e`` but ``... ů wő``; treating ů as globally
# postvocalic would therefore invent unattested agreement and skepticism forms.
_BASIC_POSTVOCALIC_DISCOURSE_ENDINGS = frozenset(
    {"a", "e", "i", "ý", "ù", "o", "á", "è"}
)
ASAXI_DISCOURSE_POSTVOCALIC_ENDINGS = {
    DiscourseMarkerKind.AGREEMENT: _BASIC_POSTVOCALIC_DISCOURSE_ENDINGS,
    DiscourseMarkerKind.ASSERTION: (
        _BASIC_POSTVOCALIC_DISCOURSE_ENDINGS | {"ů"}
    ),
    DiscourseMarkerKind.SKEPTICISM: _BASIC_POSTVOCALIC_DISCOURSE_ENDINGS,
}


def discourse_marker_form(
    kind: DiscourseMarkerKind,
    preceding: str,
) -> str:
    """Choose the documented allomorph for one marker and left context."""

    forms = ASAXI_DISCOURSE_MARKER_FORMS[kind]
    if len(forms) == 1:
        return forms[0]
    endings = ASAXI_DISCOURSE_POSTVOCALIC_ENDINGS.get(
        kind,
        _BASIC_POSTVOCALIC_DISCOURSE_ENDINGS,
    )
    return forms[1] if preceding[-1:] in endings else forms[0]

ASAXI_CIRCUMSTANTIAL_PREDICATES = frozenset(
    {"sè", "då", "izo", "bă", "zá", "ni", "måmå"}
)

ASAXI_VERBALIZATION_BRIDGES = {
    VerbalizationMode.PERFORMANCE: "n",
    VerbalizationMode.INTERACTION: "x",
    VerbalizationMode.SEMBLANCE: "w",
    VerbalizationMode.TRANSFORMATIVE: "k",
    VerbalizationMode.GENERATIVE: "ŕ",
    VerbalizationMode.PRIVATIVE: "sh",
    VerbalizationMode.SUBJECTIVE: "ch",
    VerbalizationMode.VISUAL: "j",
    VerbalizationMode.AUDITORY: "s",
    VerbalizationMode.OLFACTORY: "ŋ",
    VerbalizationMode.TACTILE: "p",
    VerbalizationMode.GUSTATORY: "zh",
}

CLAUSE_CONNECTOR_RULES = {
    ClauseConnector.AND: "clause.coordination-tail",
    ClauseConnector.OR: "clause.coordination-tail",
    ClauseConnector.BUT: "clause.coordination-tail",
    ClauseConnector.IF: "clause.conditional-tail",
    ClauseConnector.UNLESS: "clause.conditional-tail",
    ClauseConnector.EVEN_IF: "clause.conditional-tail",
    ClauseConnector.BECAUSE: "clause.causal-tail",
    ClauseConnector.SO: "clause.causal-tail",
    ClauseConnector.WHEN: "clause.temporal-tail",
    ClauseConnector.WHILE: "clause.temporal-tail",
    ClauseConnector.THEN: "clause.temporal-tail",
    ClauseConnector.BY_THE_TIME: "clause.temporal-tail",
}


class CaseRelation(str, Enum):
    DATIVE = "dative"
    TRANSFER_DATIVE = "transfer-dative"
    ABLATIVE = "ablative"
    ALLATIVE = "allative"
    COMITATIVE = "comitative"
    INSTRUMENTAL = "instrumental"
    TERMINATIVE = "terminative"
    TOPICAL = "topical"


class RelativeRole(str, Enum):
    SUBJECT = "subject"
    OBJECT = "object"
    OBLIQUE = "oblique"


class PronounPerson(str, Enum):
    FIRST = "first"
    SECOND = "second"
    THIRD = "third"


class PronounAnimacy(str, Enum):
    ANIMATE = "animate"
    INANIMATE = "inanimate"


class PronounKind(str, Enum):
    PERSONAL = "personal"
    REFLEXIVE = "reflexive"
    RECIPROCAL = "reciprocal"


ASAXI_VOWELS = frozenset("aeioùýáèůåăěëỏő")


def _nominal_tokens(surface: str) -> tuple[str, ...]:
    """Normalize native words while preserving all-cap retained terms."""

    return tuple(
        token if token.isupper() else token.casefold()
        for token in surface.strip().split()
    )


@dataclass(frozen=True)
class NominalQuantifier:
    marker: str
    kind: NominalQuantifierKind
    source_form: str | None = None

    def to_dict(self) -> dict[str, str | None]:
        return {
            "marker": self.marker,
            "kind": self.kind.value,
            "source_form": self.source_form,
        }


@dataclass(frozen=True)
class NominalExtent:
    """Extent of one nominal, distinct from set quantification.

    ``să-``/``săsă-`` select the complete referent. ``pù`` plus a
    denominator selects a fraction of it. The denominator is retained both
    as an Asaxi numeral and, where known, as a numeric value so frontends do
    not have to recover semantics from the rendered compound.
    """

    marker: str
    kind: NominalExtentKind
    denominator: str | None = None
    denominator_value: int | None = None
    emphasized: bool = False
    source_form: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "marker": self.marker,
            "kind": self.kind.value,
            "denominator": self.denominator,
            "denominator_value": self.denominator_value,
            "emphasized": self.emphasized,
            "source_form": self.source_form,
        }


@dataclass(frozen=True)
class VerbalNominalization:
    """A lexical verb used as a cold nominal under ``anő``.

    ``specific`` records the documented proximal ``o-`` contrast.  The
    nominalizer and proximal marker remain explicit so serialization does not
    flatten grammatical structure into an opaque surface string.
    """

    predicate: str
    predicate_lexeme_id: str | None = None
    nominalizer: str = "anő"
    specific: bool = False
    proximal_marker: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "predicate": self.predicate,
            "predicate_lexeme_id": self.predicate_lexeme_id,
            "nominalizer": self.nominalizer,
            "specific": self.specific,
            "proximal_marker": self.proximal_marker,
        }


@dataclass(frozen=True)
class WordTimeBinding:
    """A typed ``sỏni``/``pỏni`` modifier with lexical, not clause, scope.

    Prefix position is the documented neutral order. Suffix position has the
    same truth conditions but carries dramatic or emphatic rhythm. ``fused``
    records orthography independently of semantic placement.
    """

    marker: str
    orientation: WordTimeOrientation
    scope: WordTimeScope
    placement: WordTimePlacement = WordTimePlacement.PREFIX
    fused: bool = True
    source_form: str | None = None

    def __post_init__(self) -> None:
        marker = self.marker.strip().casefold()
        expected = {
            WordTimeOrientation.RETROSPECTIVE: "sỏni",
            WordTimeOrientation.PROSPECTIVE: "pỏni",
        }[self.orientation]
        if marker != expected:
            raise ValueError(
                "Word-time marker does not match its typed orientation: "
                f"{marker!r} != {expected!r}"
            )
        if self.source_form is not None and not self.source_form.strip():
            raise ValueError("Word-time source form cannot be blank")

    @property
    def emphatic(self) -> bool:
        return self.placement is WordTimePlacement.SUFFIX

    def to_dict(self) -> dict[str, Any]:
        return {
            "marker": self.marker,
            "orientation": self.orientation.value,
            "scope": self.scope.value,
            "placement": self.placement.value,
            "fused": self.fused,
            "emphatic": self.emphatic,
            "source_form": self.source_form,
        }

    def rule_trace(self) -> tuple[str, ...]:
        """Return the auditable runtime rules contributed by this binding."""

        return (
            "word-time.binding",
            "word-time.independent-of-clause-tense",
            f"word-time.{self.orientation.value}",
            f"word-time.scope.{self.scope.value}",
            f"word-time.placement.{self.placement.value}",
            (
                "word-time.orthography.fused"
                if self.fused
                else "word-time.orthography.separate"
            ),
            "word-time.emphatic" if self.emphatic else "word-time.neutral",
        )


@dataclass(frozen=True)
class RelativeClause:
    predicate: str
    role: RelativeRole
    subject: Nominal | None = None
    object: Nominal | None = None
    tense: Tense = Tense.NONPAST
    polarity: Polarity = Polarity.POSITIVE
    modality: Modality = Modality.NONE

    def to_dict(self) -> dict[str, Any]:
        return {
            "predicate": self.predicate,
            "role": self.role.value,
            "subject": self.subject.to_dict() if self.subject else None,
            "object": self.object.to_dict() if self.object else None,
            "tense": self.tense.value,
            "polarity": self.polarity.value,
            "modality": self.modality.value,
        }


@dataclass(frozen=True)
class Nominal:
    surface: str
    lexeme_id: str | None = None
    noun_class: str | None = None
    determiner: str | None = None
    number: str = "singular"
    possessor: Nominal | None = None
    modifiers: tuple[Nominal, ...] = ()
    coordinated: tuple[Nominal, ...] = ()
    relative_clause: RelativeClause | None = None
    relation: str | None = None
    wh_word: str | None = None
    person: PronounPerson | None = None
    animacy: PronounAnimacy | None = None
    pronoun_kind: PronounKind | None = None
    pronoun_base: str | None = None
    distribution: DistributiveModifier | None = None
    deixis: DeicticDistance | None = None
    quantifier: NominalQuantifier | None = None
    extent: NominalExtent | None = None
    verbal_nominalization: VerbalNominalization | None = None
    word_time_binding: WordTimeBinding | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "surface": self.surface,
            "lexeme_id": self.lexeme_id,
            "noun_class": self.noun_class,
            "determiner": self.determiner,
            "number": self.number,
            "possessor": (
                self.possessor.to_dict() if self.possessor else None
            ),
            "modifiers": [
                modifier.to_dict() for modifier in self.modifiers
            ],
            "coordinated": [
                nominal.to_dict() for nominal in self.coordinated
            ],
            "relative_clause": (
                self.relative_clause.to_dict()
                if self.relative_clause
                else None
            ),
            "relation": self.relation,
            "wh_word": self.wh_word,
            "person": self.person.value if self.person else None,
            "animacy": self.animacy.value if self.animacy else None,
            "pronoun_kind": (
                self.pronoun_kind.value if self.pronoun_kind else None
            ),
            "pronoun_base": self.pronoun_base,
            "distribution": (
                self.distribution.to_dict()
                if self.distribution
                else None
            ),
            "deixis": self.deixis.value if self.deixis else None,
            "quantifier": (
                self.quantifier.to_dict()
                if self.quantifier
                else None
            ),
            "extent": (
                self.extent.to_dict() if self.extent else None
            ),
            "verbal_nominalization": (
                self.verbal_nominalization.to_dict()
                if self.verbal_nominalization
                else None
            ),
            "word_time_binding": (
                self.word_time_binding.to_dict()
                if self.word_time_binding
                else None
            ),
        }


def _surface_tokens_with_time(
    surface: str,
    binding: WordTimeBinding | None,
) -> tuple[str, ...]:
    """Realize one lexical time modifier without flattening its semantics."""

    tokens = list(_nominal_tokens(surface))
    if binding is None or not tokens:
        return tuple(tokens)
    marker = binding.marker.strip().casefold()
    if binding.fused:
        if binding.placement is WordTimePlacement.PREFIX:
            tokens[0] = marker + tokens[0]
        else:
            tokens[-1] = tokens[-1] + marker
    elif binding.placement is WordTimePlacement.PREFIX:
        tokens.insert(0, marker)
    else:
        tokens.append(marker)
    return tuple(tokens)


def _nominal_tokens_with_time(nominal: Nominal) -> tuple[str, ...]:
    return _surface_tokens_with_time(
        nominal.surface,
        nominal.word_time_binding,
    )


def _word_time_rule_trace(binding: WordTimeBinding) -> tuple[str, ...]:
    return binding.rule_trace()


@dataclass(frozen=True)
class VerbalDerivation:
    """Productive noun-to-Activity derivation retained in clause semantics."""

    source: Nominal
    mode: VerbalizationMode
    bridge: str
    aspectual_class: str = "activity"
    lexicalized_predicate_id: str | None = None
    attested_derived_term_id: str | None = None
    attested_derived_surface: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "source": self.source.to_dict(),
            "mode": self.mode.value,
            "bridge": self.bridge,
            "aspectual_class": self.aspectual_class,
            "lexicalized_predicate_id": self.lexicalized_predicate_id,
            "attested_derived_term_id": self.attested_derived_term_id,
            "attested_derived_surface": self.attested_derived_surface,
        }


@dataclass(frozen=True)
class DerivedTermAttestation:
    """A compiler-issued derived-term identity accepted by the generator."""

    identifier: str
    source_lexeme_id: str
    surface: str

    def __post_init__(self) -> None:
        if not self.identifier.strip():
            raise ValueError("Derived-term attestation id is empty")
        if not self.source_lexeme_id.strip():
            raise ValueError("Derived-term source lexeme id is empty")
        if not self.surface.strip() or " " in self.surface.strip():
            raise ValueError("Derived-term attestation requires one surface")


@dataclass(frozen=True)
class DiscourseReferent:
    nominal: Nominal
    english_text: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "nominal": self.nominal.to_dict(),
            "english_text": self.english_text,
        }


@dataclass(frozen=True)
class DiscourseState:
    topic: DiscourseReferent | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "topic": self.topic.to_dict() if self.topic else None,
        }


@dataclass(frozen=True)
class RelationalPhrase:
    marker: str
    relation: CaseRelation
    nominal: Nominal
    function: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "marker": self.marker,
            "relation": self.relation.value,
            "nominal": self.nominal.to_dict(),
            "function": self.function,
        }


@dataclass(frozen=True)
class CausativeAgency:
    """Core causative relation without erasing source argument structure.

    In Asaxi the overt grammatical subject is the causee/doer.  The causer is
    introduced by ``bă`` even though idiomatic English normally promotes that
    causer to matrix-subject position.
    """

    voice: CausativeVoice
    causer: Nominal
    marker: str = "bă"
    source_subject_role: str = "causee"

    def to_dict(self) -> dict[str, Any]:
        return {
            "voice": self.voice.value,
            "causer": self.causer.to_dict(),
            "marker": self.marker,
            "source_subject_role": self.source_subject_role,
        }


@dataclass(frozen=True)
class Directive:
    """Clause-force record for commands, kept separate from verb voice."""

    kind: DirectiveKind
    placement: DirectivePlacement
    markers: tuple[str, ...]
    addressee: Nominal
    implicit_addressee: bool = True
    fused: bool = False
    rapid_speech: bool = False
    joint_participant: Nominal | None = None
    focus: DirectiveFocus | None = None

    def __post_init__(self) -> None:
        """Infer focus for old callers and reject contradictory records."""

        expected = directive_focus_for(self.kind, self.placement)
        if self.focus is None:
            object.__setattr__(self, "focus", expected)
        elif self.focus is not expected:
            raise ValueError(
                "Directive focus must agree with kind and placement: "
                f"{self.kind.value}/{self.placement.value} requires "
                f"{expected.value}, not {self.focus.value}"
            )

    def to_dict(self) -> dict[str, Any]:
        return {
            "kind": self.kind.value,
            "placement": self.placement.value,
            "markers": list(self.markers),
            "addressee": self.addressee.to_dict(),
            "implicit_addressee": self.implicit_addressee,
            "fused": self.fused,
            "rapid_speech": self.rapid_speech,
            "focus": self.focus.value,
            "joint_participant": (
                self.joint_participant.to_dict()
                if self.joint_participant
                else None
            ),
        }


@dataclass(frozen=True)
class PreclausalMarker:
    """Sentence-initial pragmatic framing, outside clause argument syntax."""

    kind: PreclausalMarkerKind
    form: str = ""

    def to_dict(self) -> dict[str, str]:
        return {"kind": self.kind.value, "form": self.form}


@dataclass(frozen=True)
class DiscourseMarker:
    """Post-predicate social force with an optional preserved allomorph."""

    kind: DiscourseMarkerKind
    form: str = ""

    def to_dict(self) -> dict[str, str]:
        return {"kind": self.kind.value, "form": self.form}


@dataclass(frozen=True)
class EpistemicQualification:
    """A typed ``tte`` construction qualifying one complete proposition.

    ``forms`` may preserve an analyzed source sequence. An empty tuple asks
    the generator to use the canonical documented sequence for ``stance``.
    """

    stance: EpistemicStance
    forms: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return {
            "stance": self.stance.value,
            "forms": list(self.forms),
        }


@dataclass(frozen=True)
class TteBinder:
    """A low-binding ``tte`` relation with explicit function and scope.

    The bound proposition is the :class:`CanonicalClause` carrying this
    record. Quotatives point to a following matrix clause; explanations use a
    result fragment; casual topics prefix a nominal to the comment clause.
    Epistemic certainty is one documented subtype, not the definition of
    ``tte`` itself.
    """

    function: TteFunction
    marker: str = "tte"
    qualification: EpistemicQualification | None = None
    matrix_clause: CanonicalClause | None = None
    matrix_fragment: Nominal | None = None
    topic: Nominal | None = None
    quoted: bool = False
    comma_after_marker: bool = False
    cognizer: Nominal | None = None
    cognizer_omitted: bool = True
    provenance: str = "documented"

    def to_dict(self) -> dict[str, Any]:
        return {
            "function": self.function.value,
            "marker": self.marker,
            "qualification": (
                self.qualification.to_dict()
                if self.qualification
                else None
            ),
            "matrix_clause": (
                self.matrix_clause.to_dict()
                if self.matrix_clause
                else None
            ),
            "matrix_fragment": (
                self.matrix_fragment.to_dict()
                if self.matrix_fragment
                else None
            ),
            "topic": self.topic.to_dict() if self.topic else None,
            "quoted": self.quoted,
            "comma_after_marker": self.comma_after_marker,
            "cognizer": (
                self.cognizer.to_dict() if self.cognizer else None
            ),
            "cognizer_omitted": self.cognizer_omitted,
            "provenance": self.provenance,
        }


@dataclass(frozen=True)
class EventFrequency:
    marker: str
    kind: FrequencyKind
    scope: str = "event"

    def to_dict(self) -> dict[str, str]:
        return {
            "marker": self.marker,
            "kind": self.kind.value,
            "scope": self.scope,
        }


@dataclass(frozen=True)
class DistributiveModifier:
    marker: str
    kind: DistributionKind
    scope: DistributionScope
    target_role: str | None = None

    def to_dict(self) -> dict[str, str | None]:
        return {
            "marker": self.marker,
            "kind": self.kind.value,
            "scope": self.scope.value,
            "target_role": self.target_role,
        }


@dataclass(frozen=True)
class PostVerbalScope:
    """Inner semantic scope of the documented post-verbal tail.

    Inquiry, discourse, and clause connection already have richer typed
    records on ``CanonicalClause``.  This record owns the three inner slots
    that compose directly over the predicate, in their grammatical order.
    """

    resultative: ResultativeMode = ResultativeMode.NONE
    potential: PotentialMode = PotentialMode.NONE
    subjunctive: SubjunctiveMode = SubjunctiveMode.NONE

    @property
    def is_empty(self) -> bool:
        return (
            self.resultative is ResultativeMode.NONE
            and self.potential is PotentialMode.NONE
            and self.subjunctive is SubjunctiveMode.NONE
        )

    def to_dict(self) -> dict[str, str]:
        return {
            "resultative": self.resultative.value,
            "potential": self.potential.value,
            "subjunctive": self.subjunctive.value,
        }


@dataclass(frozen=True)
class ActionSwitch:
    """A prior action discontinued before an immediate replacement action."""

    discontinued_clause: CanonicalClause
    cessation_marker: str = "tomo"

    def to_dict(self) -> dict[str, Any]:
        return {
            "discontinued_clause": self.discontinued_clause.to_dict(),
            "cessation_marker": self.cessation_marker,
        }


@dataclass(frozen=True)
class CanonicalClause:
    predicate: str
    subject: Nominal | None = None
    object: Nominal | None = None
    tense: Tense = Tense.NONPAST
    polarity: Polarity = Polarity.POSITIVE
    register: Register = Register.OBJECTIVE
    interrogative: bool = False
    predicate_kind: PredicateKind = PredicateKind.ACTION
    complement: Nominal | None = None
    location: Nominal | None = None
    time: Nominal | None = None
    modality: Modality = Modality.NONE
    validity_mode: ValidityMode = ValidityMode.NONE
    verbal_derivation: VerbalDerivation | None = None
    causative_agency: CausativeAgency | None = None
    directive: Directive | None = None
    predicate_time_binding: WordTimeBinding | None = None
    temporal_aspect: TemporalAspect = TemporalAspect.NONE
    frequency: EventFrequency | None = None
    distribution: DistributiveModifier | None = None
    post_verbal_scope: PostVerbalScope = PostVerbalScope()
    action_switch: ActionSwitch | None = None
    wh_role: WhRole | None = None
    connector: ClauseConnector | None = None
    coordinated_clause: CanonicalClause | None = None
    preclausal_marker: PreclausalMarker | None = None
    discourse_marker: DiscourseMarker | None = None
    tte_binder: TteBinder | None = None
    obliques: tuple[RelationalPhrase, ...] = ()
    omitted_subject: bool = False
    discourse_subject: bool = False
    zero_copula: bool = False
    subject_marked: bool = True

    def to_dict(self) -> dict[str, Any]:
        return {
            "predicate": self.predicate,
            "subject": self.subject.to_dict() if self.subject else None,
            "object": self.object.to_dict() if self.object else None,
            "tense": self.tense.value,
            "polarity": self.polarity.value,
            "register": self.register.value,
            "interrogative": self.interrogative,
            "predicate_kind": self.predicate_kind.value,
            "complement": (
                self.complement.to_dict() if self.complement else None
            ),
            "location": (
                self.location.to_dict() if self.location else None
            ),
            "time": self.time.to_dict() if self.time else None,
            "modality": self.modality.value,
            "validity_mode": self.validity_mode.value,
            "verbal_derivation": (
                self.verbal_derivation.to_dict()
                if self.verbal_derivation
                else None
            ),
            "causative_agency": (
                self.causative_agency.to_dict()
                if self.causative_agency
                else None
            ),
            "directive": (
                self.directive.to_dict() if self.directive else None
            ),
            "predicate_time_binding": (
                self.predicate_time_binding.to_dict()
                if self.predicate_time_binding
                else None
            ),
            "temporal_aspect": self.temporal_aspect.value,
            "frequency": (
                self.frequency.to_dict() if self.frequency else None
            ),
            "distribution": (
                self.distribution.to_dict()
                if self.distribution
                else None
            ),
            "post_verbal_scope": self.post_verbal_scope.to_dict(),
            "action_switch": (
                self.action_switch.to_dict()
                if self.action_switch
                else None
            ),
            "wh_role": self.wh_role.value if self.wh_role else None,
            "connector": (
                self.connector.value if self.connector else None
            ),
            "coordinated_clause": (
                self.coordinated_clause.to_dict()
                if self.coordinated_clause
                else None
            ),
            "preclausal_marker": (
                self.preclausal_marker.to_dict()
                if self.preclausal_marker
                else None
            ),
            "discourse_marker": (
                self.discourse_marker.to_dict()
                if self.discourse_marker
                else None
            ),
            "tte_binder": (
                self.tte_binder.to_dict()
                if self.tte_binder
                else None
            ),
            "obliques": [
                oblique.to_dict() for oblique in self.obliques
            ],
            "omitted_subject": self.omitted_subject,
            "discourse_subject": self.discourse_subject,
            "zero_copula": self.zero_copula,
            "subject_marked": self.subject_marked,
        }


@dataclass(frozen=True)
class Realization:
    text: str
    tokens: tuple[str, ...]
    assumptions: tuple[str, ...]
    rule_trace: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "text": self.text,
            "tokens": list(self.tokens),
            "assumptions": list(self.assumptions),
            "rule_trace": list(self.rule_trace),
        }


class CanonicalGenerator:
    """Generate the deliberately small canonical-clause foundation.

    Canonical mode preserves the explicitly selected subject marking and
    zero-copula structure. It does not infer either omission on its own.
    """

    def __init__(
        self,
        *,
        derived_term_attestations: Iterable[DerivedTermAttestation] = (),
    ) -> None:
        attestations: dict[str, DerivedTermAttestation] = {}
        for attestation in derived_term_attestations:
            previous = attestations.get(attestation.identifier)
            if previous is not None and previous != attestation:
                raise ValueError(
                    "A derived-term attestation id names conflicting records"
                )
            attestations[attestation.identifier] = attestation
        self._derived_term_attestations = attestations

    def has_derived_attestation(
        self,
        derivation: VerbalDerivation | None,
        surface: str,
    ) -> bool:
        """Return whether provenance matches this generator's compiled bank."""

        if (
            derivation is None
            or derivation.attested_derived_term_id is None
            or derivation.attested_derived_surface is None
            or derivation.source.lexeme_id is None
        ):
            return False
        attestation = self._derived_term_attestations.get(
            derivation.attested_derived_term_id
        )
        normalized = surface.strip().casefold()
        return bool(
            attestation is not None
            and attestation.source_lexeme_id == derivation.source.lexeme_id
            and attestation.surface.casefold() == normalized
            and derivation.attested_derived_surface.casefold() == normalized
        )

    def realize(self, clause: CanonicalClause) -> Realization:
        has_connector = clause.connector is not None
        has_linked_clause = clause.coordinated_clause is not None
        if has_connector != has_linked_clause:
            raise ValueError(
                "A clause connector and linked clause must be supplied together"
            )
        if has_connector:
            return self._realize_linked_clause(clause)
        if clause.predicate_kind is PredicateKind.FRAGMENT:
            return self._realize_fragment(clause)
        predicate = clause.predicate.strip().casefold()
        if not predicate:
            raise ValueError("Clause predicate is empty")
        (
            predicate,
            effective_validity,
            semantic_trace,
        ) = self._validate_structured_predicate(clause, predicate)
        if clause.directive is not None:
            if clause.tte_binder is not None:
                raise ValueError(
                    "The tte binder requires a proposition, not a directive"
                )
            return self._apply_pragmatics(
                clause,
                self._realize_directive(clause, predicate),
            )
        trace = ["syntax.canonical-sov", *semantic_trace]
        tokens: list[str] = []
        assumptions: list[str] = []
        if clause.time is not None:
            tokens.extend(_nominal_tokens_with_time(clause.time))
            if clause.time.word_time_binding is not None:
                trace.extend(
                    _word_time_rule_trace(clause.time.word_time_binding)
                )
            trace.append("clause.time-nominal.fronted")
        if clause.subject is not None:
            subject_distribution = self._nominal_distribution_marker(
                clause.subject,
                target_role="subject",
            )
            if subject_distribution is not None:
                tokens.append(subject_distribution)
                trace.extend(
                    (
                        "noun.floating-distributive",
                        "distribution.scope.nominal",
                        "distribution.target.subject",
                    )
                )
            subject_tokens = list(
                _nominal_tokens_with_time(clause.subject)
            )
            if clause.subject.word_time_binding is not None:
                trace.extend(
                    _word_time_rule_trace(
                        clause.subject.word_time_binding
                    )
                )
            if clause.subject_marked:
                marker = (
                    "to"
                    if clause.register is Register.OBJECTIVE
                    else "ă"
                )
                if (
                    marker == "to"
                    and subject_tokens
                    and subject_tokens[0] in ASAXI_DETERMINERS
                ):
                    tokens.append(marker + subject_tokens[0])
                    tokens.extend(subject_tokens[1:])
                    trace.append("clause.fused-subject-determiner")
                    if subject_tokens[0] in {"onă", "onýj"}:
                        trace.append(
                            "clause.fused-subject-definite-determiner"
                        )
                else:
                    tokens.append(marker)
                    tokens.extend(subject_tokens)
                trace.append(
                    f"subject.explicit-{clause.register.value}"
                )
            else:
                tokens.extend(subject_tokens)
                trace.append("subject.unmarked-canonical-order")
        else:
            assumptions.append("No explicit subject was supplied.")
        if clause.causative_agency is not None:
            agency = clause.causative_agency
            if clause.predicate_kind is not PredicateKind.ACTION:
                raise ValueError(
                    "Causative agency requires an action predicate"
                )
            if agency.marker.strip().casefold() != "bă":
                raise ValueError(
                    "Causative causers require the documented bă marker"
                )
            if agency.source_subject_role != "causee":
                raise ValueError(
                    "Canonical Asaxi causatives keep the causee as subject"
                )
            causer_distribution = self._nominal_distribution_marker(
                agency.causer,
                target_role="causer",
            )
            if causer_distribution is not None:
                tokens.append(causer_distribution)
                trace.extend(
                    (
                        "noun.floating-distributive",
                        "distribution.scope.nominal",
                        "distribution.target.causer",
                    )
                )
            tokens.append("bă")
            tokens.extend(_nominal_tokens_with_time(agency.causer))
            if agency.causer.word_time_binding is not None:
                trace.extend(
                    _word_time_rule_trace(
                        agency.causer.word_time_binding
                    )
                )
            trace.extend(
                (
                    "clause.causative-agency",
                    "clause.causative-source-subject-is-causee",
                    f"voice.{agency.voice.value}",
                )
            )
        for oblique in clause.obliques:
            oblique_distribution = self._nominal_distribution_marker(
                oblique.nominal,
                target_role=oblique.function,
            )
            if oblique_distribution is not None:
                tokens.append(oblique_distribution)
                trace.extend(
                    (
                        "noun.floating-distributive",
                        "distribution.scope.nominal",
                        f"distribution.target.{oblique.function}",
                    )
                )
            tokens.append(oblique.marker)
            tokens.extend(_nominal_tokens_with_time(oblique.nominal))
            if oblique.nominal.word_time_binding is not None:
                trace.extend(
                    _word_time_rule_trace(
                        oblique.nominal.word_time_binding
                    )
                )
            trace.append(
                f"oblique.{oblique.relation.value}.pre-object"
            )
        if clause.object is not None:
            object_distribution = self._nominal_distribution_marker(
                clause.object,
                target_role="object",
            )
            if object_distribution is not None:
                tokens.append(object_distribution)
                trace.extend(
                    (
                        "noun.floating-distributive",
                        "distribution.scope.nominal",
                        "distribution.target.object",
                    )
                )
            tokens.extend(_nominal_tokens_with_time(clause.object))
            if clause.object.word_time_binding is not None:
                trace.extend(
                    _word_time_rule_trace(
                        clause.object.word_time_binding
                    )
                )
            trace.append("object.zero-accusative")
        if clause.complement is not None:
            complement_distribution = self._nominal_distribution_marker(
                clause.complement,
                target_role="complement",
            )
            if complement_distribution is not None:
                tokens.append(complement_distribution)
                trace.extend(
                    (
                        "noun.floating-distributive",
                        "distribution.scope.nominal",
                        "distribution.target.complement",
                    )
                )
            if (
                clause.zero_copula
                and effective_validity is ValidityMode.CIRCUMSTANTIAL
            ):
                tokens.append(predicate)
                tokens.extend(_nominal_tokens_with_time(clause.complement))
                trace.extend(
                    (
                        "copula.zero-omission",
                        "clause.frontloaded-npcp-predicate",
                        "complement.after-frontloaded-predicate",
                    )
                )
            else:
                tokens.extend(_nominal_tokens_with_time(clause.complement))
                trace.append("complement.pre-predicate")
            if clause.complement.word_time_binding is not None:
                trace.extend(
                    _word_time_rule_trace(
                        clause.complement.word_time_binding
                    )
                )
        if clause.location is not None:
            location_distribution = self._nominal_distribution_marker(
                clause.location,
                target_role="location",
            )
            if location_distribution is not None:
                tokens.append(location_distribution)
                trace.extend(
                    (
                        "noun.floating-distributive",
                        "distribution.scope.nominal",
                        "distribution.target.location",
                    )
                )
            tokens.extend(_nominal_tokens_with_time(clause.location))
            if clause.location.word_time_binding is not None:
                trace.extend(
                    _word_time_rule_trace(
                        clause.location.word_time_binding
                    )
                )
            trace.append("location.pre-predicate")
        if clause.frequency is not None:
            if clause.frequency.scope != "event":
                raise ValueError(
                    "Canonical frequency realization requires event scope"
                )
            marker = clause.frequency.marker.strip().casefold()
            expected_marker = ASAXI_FREQUENCY_MARKERS[
                clause.frequency.kind
            ]
            if not marker:
                marker = expected_marker
            if marker != expected_marker:
                raise ValueError(
                    "Frequency marker does not match its typed meaning: "
                    f"{marker!r} != {expected_marker!r}"
                )
            tokens.append(marker)
            trace.append("clause.frequency-adverb")
            trace.append("syntax.frequency.pre-predicate")

        if clause.zero_copula:
            if effective_validity is ValidityMode.ESSENTIAL:
                trace.extend(
                    (
                        "copula.zero-omission",
                        "clause.validity-essential",
                    )
                )
        elif clause.causative_agency is not None:
            predicate, predicate_trace = realize_causative_predicate(
                predicate,
                tense=clause.tense,
                polarity=clause.polarity,
                modality=clause.modality,
                voice=clause.causative_agency.voice,
                derived_root=clause.verbal_derivation is not None,
            )
            trace.extend(predicate_trace)
            tokens.extend(
                _surface_tokens_with_time(
                    predicate,
                    clause.predicate_time_binding,
                )
            )
        elif effective_validity is ValidityMode.ESSENTIAL:
            predicate, predicate_trace = realize_validity_predicate(
                predicate,
                tense=clause.tense,
                polarity=clause.polarity,
            )
            trace.extend(predicate_trace)
            tokens.extend(
                _surface_tokens_with_time(
                    predicate,
                    clause.predicate_time_binding,
                )
            )
        elif (
            effective_validity is ValidityMode.CIRCUMSTANTIAL
            and predicate in ASAXI_CIRCUMSTANTIAL_PREDICATES
        ):
            predicate, predicate_trace = realize_circumstantial_predicate(
                predicate,
                tense=clause.tense,
                polarity=clause.polarity,
            )
            trace.extend(predicate_trace)
            if "clause.validity-productivity-unresolved" in predicate_trace:
                assumptions.append(
                    "The tense/polarity stacking on this bare relational "
                    "particle is a reviewable productive inference; the "
                    "notes directly attest only the positive base and "
                    "future-negative panáni contrast."
                )
            tokens.extend(
                _surface_tokens_with_time(
                    predicate,
                    clause.predicate_time_binding,
                )
            )
        else:
            predicate, predicate_trace = realize_predicate(
                predicate,
                tense=clause.tense,
                polarity=clause.polarity,
                modality=clause.modality,
            )
            trace.extend(predicate_trace)
            tokens.extend(
                _surface_tokens_with_time(
                    predicate,
                    clause.predicate_time_binding,
                )
            )
        if clause.predicate_time_binding is not None:
            trace.extend(
                _word_time_rule_trace(clause.predicate_time_binding)
            )
        if clause.temporal_aspect is not TemporalAspect.NONE:
            tokens.append(
                ASAXI_TEMPORAL_ASPECT_MARKERS[clause.temporal_aspect]
            )
            trace.append("clause.temporal-aspect-tail")
            trace.append("syntax.temporal-aspect.post-predicate")
        tail = clause.post_verbal_scope
        if tail.resultative is not ResultativeMode.NONE:
            result_marker = ASAXI_RESULTATIVE_MARKERS[tail.resultative]
            if (
                tail.potential is not PotentialMode.NONE
                or tail.subjunctive is not SubjunctiveMode.NONE
                or clause.interrogative
                or clause.discourse_marker is not None
                or clause.connector is not None
            ):
                result_marker = result_marker.rstrip("'")
            tokens.append(result_marker)
            trace.extend(
                (
                    "post-verbal.result",
                    "post-verbal.strict-slot-order",
                )
            )
        if tail.potential is not PotentialMode.NONE:
            tokens.append(ASAXI_POTENTIAL_MARKERS[tail.potential])
            trace.extend(
                (
                    "post-verbal.potential",
                    "post-verbal.strict-slot-order",
                )
            )
        if tail.subjunctive is not SubjunctiveMode.NONE:
            tokens.append(ASAXI_SUBJUNCTIVE_MARKERS[tail.subjunctive])
            trace.extend(
                (
                    "post-verbal.subjunctive",
                    "post-verbal.strict-slot-order",
                )
            )
        if clause.distribution is not None:
            if clause.distribution.scope is not DistributionScope.EVENT:
                raise ValueError(
                    "Clause-level distribution requires event scope"
                )
            if clause.distribution.target_role not in {None, "event"}:
                raise ValueError(
                    "Event distribution cannot target a nominal role"
                )
            marker = self._validated_distribution_marker(
                clause.distribution
            )
            tokens.append(marker)
            trace.extend(
                (
                    "clause.event-distributive",
                    "distribution.scope.event",
                    f"distribution.{clause.distribution.kind.value}",
                )
            )
        if clause.interrogative:
            if clause.wh_role is None:
                tokens.append("kè")
                trace.append("tail.interrogative")
            else:
                # An in-situ wh form already marks the information gap. The
                # attested zèvo example uses the documented kè-drop option.
                trace.append("tail.interrogative-wh-kè-omission")
        punctuation = "?" if clause.interrogative else "."
        realization = Realization(
            text=" ".join(tokens) + punctuation,
            tokens=tuple(tokens),
            assumptions=tuple(assumptions),
            rule_trace=tuple(trace),
        )
        return self._apply_pragmatics(
            clause,
            self._apply_tte_binder(clause, realization),
        )

    @staticmethod
    def _realize_fragment(clause: CanonicalClause) -> Realization:
        if clause.subject is None:
            raise ValueError("A nominal fragment requires a nominal payload")
        if any(
            value is not None
            for value in (
                clause.object,
                clause.complement,
                clause.location,
                clause.time,
                clause.directive,
                clause.action_switch,
            )
        ):
            raise ValueError("A nominal fragment cannot carry clause arguments")
        if not clause.post_verbal_scope.is_empty:
            raise ValueError("A nominal fragment cannot carry verbal scope")
        tokens = _nominal_tokens_with_time(clause.subject)
        punctuation = "?" if clause.interrogative else "."
        return Realization(
            text=" ".join(tokens) + punctuation,
            tokens=tokens,
            assumptions=(),
            rule_trace=("syntax.nominal-fragment",),
        )

    def _apply_tte_binder(
        self,
        clause: CanonicalClause,
        realization: Realization,
    ) -> Realization:
        """Apply one typed generalized binder around its scoped proposition."""

        binder = clause.tte_binder
        if binder is None:
            return realization
        marker = binder.marker.strip().casefold() or "tte"
        if marker != "tte":
            raise ValueError(
                f"The generalized binder marker must be 'tte', not {marker!r}"
            )
        text = realization.text
        punctuation = text[-1] if text[-1:] in {".", "?", "!"} else "."
        body = text[:-1] if text[-1:] in {".", "?", "!"} else text
        tokens = list(realization.tokens)
        trace = list(realization.rule_trace)

        if binder.function is TteFunction.EPISTEMIC:
            qualification = binder.qualification
            if qualification is None:
                raise ValueError("Epistemic tte requires a typed qualification")
            if clause.interrogative:
                raise ValueError(
                    "Epistemic qualification requires a statement proposition"
                )
            expected = ASAXI_EPISTEMIC_FORMS[qualification.stance]
            explicit = tuple(
                form.strip().casefold()
                for form in qualification.forms
                if form.strip()
            )
            if explicit and explicit != expected:
                raise ValueError(
                    "Epistemic forms do not match their typed stance: "
                    f"{explicit!r} != {expected!r}"
                )
            forms = explicit or expected
            body = f"{body} {' '.join(forms)}"
            tokens.extend(forms)
            trace.extend(
                (
                    "clause.tte-binder",
                    "tte.epistemic",
                    f"epistemic.{qualification.stance.value}",
                )
            )
        elif binder.function is TteFunction.BARE:
            if any(
                value is not None
                for value in (
                    binder.qualification,
                    binder.matrix_clause,
                    binder.matrix_fragment,
                    binder.topic,
                )
            ):
                raise ValueError("Bare tte cannot carry a complement")
            body = f"{body} {marker}"
            tokens.append(marker)
            trace.extend(("clause.tte-binder", "tte.bare"))
        elif binder.function is TteFunction.QUOTATIVE:
            matrix = binder.matrix_clause
            if matrix is None:
                raise ValueError("Quotative tte requires a matrix clause")
            matrix_realization = self.realize(matrix)
            matrix_text = matrix_realization.text
            matrix_punctuation = (
                matrix_text[-1]
                if matrix_text[-1:] in {".", "?", "!"}
                else "."
            )
            matrix_body = (
                matrix_text[:-1]
                if matrix_text[-1:] in {".", "?", "!"}
                else matrix_text
            )
            bound = f"„{body}{punctuation}”" if binder.quoted else body
            comma = "," if binder.comma_after_marker else ""
            body = f"{bound} {marker}{comma} {matrix_body}"
            punctuation = matrix_punctuation
            tokens.extend((marker, *matrix_realization.tokens))
            trace.extend(
                (
                    "clause.tte-binder",
                    "tte.quotative",
                    *matrix_realization.rule_trace,
                )
            )
        elif binder.function is TteFunction.EXPLANATORY:
            fragment = binder.matrix_fragment
            if fragment is None:
                raise ValueError("Explanatory tte requires a result fragment")
            result_tokens = _nominal_tokens_with_time(fragment)
            body = f"{body} {marker}, {' '.join(result_tokens)}"
            tokens.extend((marker, *result_tokens))
            trace.extend(("clause.tte-binder", "tte.explanatory"))
        elif binder.function is TteFunction.TOPIC:
            topic = binder.topic
            if topic is None:
                raise ValueError("Topic tte requires a topic nominal")
            topic_tokens = _nominal_tokens_with_time(topic)
            body = f"{' '.join(topic_tokens)} {marker}, {body}"
            tokens = [*topic_tokens, marker, *tokens]
            trace.extend(("clause.tte-binder", "tte.topic"))
        else:  # pragma: no cover - exhaustive enum guard
            raise ValueError(f"Unsupported tte function: {binder.function!r}")

        return Realization(
            text=body + punctuation,
            tokens=tuple(tokens),
            assumptions=realization.assumptions,
            rule_trace=tuple(trace),
        )

    @staticmethod
    def _apply_pragmatics(
        clause: CanonicalClause,
        realization: Realization,
    ) -> Realization:
        """Apply utterance framing without changing the clause's truth value."""

        text = realization.text
        punctuation = text[-1] if text[-1:] in {".", "?", "!"} else "."
        body = text[:-1] if text[-1:] in {".", "?", "!"} else text
        tokens = list(realization.tokens)
        trace = list(realization.rule_trace)

        discourse = clause.discourse_marker
        if discourse is not None:
            forms = ASAXI_DISCOURSE_MARKER_FORMS[discourse.kind]
            explicit = discourse.form.strip().casefold()
            if explicit and explicit not in forms:
                raise ValueError(
                    "Discourse-marker form does not match its typed force: "
                    f"{explicit!r} not in {forms!r}"
                )
            preceding = tokens[-1] if tokens else ""
            expected = discourse_marker_form(discourse.kind, preceding)
            if explicit and explicit != expected:
                raise ValueError(
                    "Discourse-marker allomorph is not licensed in this "
                    f"context: {explicit!r} != {expected!r}"
                )
            marker = explicit or expected
            trace.append(
                "discourse.explicit-allomorph"
                if explicit
                else "discourse.invariant-form"
                if len(forms) == 1
                else "discourse.postvocalic-allomorph"
                if marker == forms[1]
                else "discourse.base-allomorph"
            )
            body = f"{body} {marker}"
            tokens.append(marker)
            trace.extend(
                (
                    "post-verbal.discourse",
                    f"discourse.{discourse.kind.value}",
                )
            )
            if discourse.kind in {
                DiscourseMarkerKind.AGREEMENT,
                DiscourseMarkerKind.SKEPTICISM,
            }:
                punctuation = "?"
            elif discourse.kind is DiscourseMarkerKind.CONTENTION:
                punctuation = "!"

        preclausal = clause.preclausal_marker
        if preclausal is not None:
            expected = ASAXI_PRECLAUSAL_MARKERS[preclausal.kind]
            explicit = preclausal.form.strip().casefold()
            if explicit and explicit != expected:
                raise ValueError(
                    "Preclausal-marker form does not match its typed force: "
                    f"{explicit!r} != {expected!r}"
                )
            marker = explicit or expected
            body = f"{marker}, {body}"
            tokens.insert(0, marker)
            trace.extend(
                (
                    "pragmatics.preclausal-marker",
                    f"pragmatics.{preclausal.kind.value}",
                )
            )
            if preclausal.kind is PreclausalMarkerKind.AWE:
                punctuation = "!"

        return Realization(
            text=body + punctuation,
            tokens=tuple(tokens),
            assumptions=realization.assumptions,
            rule_trace=tuple(trace),
        )

    @classmethod
    def _validate_structured_predicate(
        cls,
        clause: CanonicalClause,
        predicate: str,
    ) -> tuple[str, ValidityMode, tuple[str, ...]]:
        """Reject contradictory semantic records before realizing a surface."""

        trace: list[str] = []
        binding = clause.predicate_time_binding
        if binding is not None:
            if binding.scope is not WordTimeScope.ADVERBIAL_PREDICATE:
                raise ValueError(
                    "Predicate time binding requires adverbial-predicate scope"
                )
            if clause.predicate_kind not in {
                PredicateKind.ACTION,
                PredicateKind.PERFORMANCE,
            }:
                raise ValueError(
                    "Adverbial word-time binding requires an event predicate"
                )
            if clause.zero_copula or clause.directive is not None:
                raise ValueError(
                    "Adverbial word-time binding requires an overt, "
                    "non-directive predicate"
                )
        if clause.verbal_derivation is not None:
            derivation = clause.verbal_derivation
            expected_bridge = ASAXI_VERBALIZATION_BRIDGES[derivation.mode]
            bridge = derivation.bridge.strip("-").casefold()
            if bridge != expected_bridge:
                raise ValueError(
                    "Verbal-derivation bridge does not match its typed mode: "
                    f"{bridge!r} != {expected_bridge!r}"
                )
            if clause.predicate_kind is not PredicateKind.ACTION:
                raise ValueError(
                    "Productive verbal derivation requires an action predicate"
                )
            source = derivation.source.surface.strip()
            if not source or " " in source:
                raise ValueError(
                    "Productive verbal derivation requires one source nominal"
                )
            reduced = reduce_class_suffix(source)
            generated = verbalize_nominal(
                reduced.surface,
                bridge=bridge,
                reduce_syllabic_nasal=(reduced.surface == source.casefold()),
            )
            if predicate != generated.surface:
                raise ValueError(
                    "Predicate surface contradicts its verbal derivation: "
                    f"{predicate!r} != {generated.surface!r}"
                )
            trace.extend(
                (
                    "verbalization.regenerated-surface-validation",
                    f"verbalization.mode.{derivation.mode.value}",
                    *reduced.rule_trace,
                    *generated.rule_trace,
                )
            )

        effective_validity = clause.validity_mode
        if effective_validity is ValidityMode.NONE:
            if predicate == "xiŕa" or (
                clause.predicate_kind
                not in {PredicateKind.ACTION, PredicateKind.PERFORMANCE}
                and predicate.endswith("ŕa")
            ):
                effective_validity = ValidityMode.ESSENTIAL
                trace.append("clause.validity-essential-inferred")

        if clause.verbal_derivation is not None and (
            effective_validity is not ValidityMode.NONE
        ):
            raise ValueError(
                "Productive active verbalization cannot carry stative validity"
            )

        if effective_validity is ValidityMode.ESSENTIAL:
            if clause.predicate_kind in {
                PredicateKind.ACTION,
                PredicateKind.PERFORMANCE,
            }:
                raise ValueError(
                    "Essential validity cannot annotate an action or performance"
                )
            if predicate != "xiŕa" and not predicate.endswith("ŕa"):
                raise ValueError(
                    "Essential validity requires xiŕa or an overt -ŕa compound"
                )
            if clause.modality is not Modality.NONE:
                raise ValueError(
                    "Essential validity has no documented action-modality form"
                )
        elif effective_validity is ValidityMode.CIRCUMSTANTIAL:
            if clause.predicate_kind not in {
                PredicateKind.LOCATION,
                PredicateKind.POSSESSION,
                PredicateKind.RELATION,
            }:
                raise ValueError(
                    "Circumstantial validity requires a relational predicate"
                )
            if (
                predicate not in ASAXI_CIRCUMSTANTIAL_PREDICATES
                and predicate not in {"o", "no", "ko", "gă"}
            ):
                raise ValueError(
                    "Circumstantial validity requires an independent documented "
                    "particle"
                )
        elif effective_validity is ValidityMode.DYNAMIC:
            if clause.predicate_kind not in {
                PredicateKind.PERFORMANCE,
                PredicateKind.LOCATION,
            }:
                raise ValueError(
                    "Dynamic validity requires performance or location"
                )
            if predicate == "xiŕa" or predicate.endswith("ŕa"):
                raise ValueError(
                    "Dynamic validity cannot use an essential -ŕa predicate"
                )

        if clause.zero_copula:
            cls._validate_zero_copula(
                clause,
                predicate,
                effective_validity,
            )
        return predicate, effective_validity, tuple(trace)

    @staticmethod
    def _validate_zero_copula(
        clause: CanonicalClause,
        predicate: str,
        validity: ValidityMode,
    ) -> None:
        if clause.tense is not Tense.NONPAST or clause.polarity is not Polarity.POSITIVE:
            raise ValueError(
                "Zero copula is licensed only for positive nonpast validity"
            )
        if clause.modality is not Modality.NONE:
            raise ValueError("Zero copula cannot carry action modality")
        if clause.causative_agency is not None or clause.directive is not None:
            raise ValueError("Zero copula cannot carry voice or directive force")
        if clause.object is not None or clause.obliques:
            raise ValueError("Zero copula cannot silently omit verbal arguments")
        if (
            clause.temporal_aspect is not TemporalAspect.NONE
            or clause.frequency is not None
            or clause.distribution is not None
        ):
            raise ValueError(
                "Zero copula has no documented event-modifier realization"
            )
        if validity is ValidityMode.ESSENTIAL:
            if predicate != "xiŕa":
                raise ValueError(
                    "Essential zero copula omits the pure xiŕa predicate"
                )
            if clause.complement is not None and clause.location is not None:
                raise ValueError(
                    "Zero copula cannot select both complement and location"
                )
            return
        if validity is ValidityMode.CIRCUMSTANTIAL:
            if predicate not in ASAXI_CIRCUMSTANTIAL_PREDICATES:
                raise ValueError(
                    "Front-loaded zero copula requires a relational particle"
                )
            if clause.complement is None or clause.location is not None:
                raise ValueError(
                    "Front-loaded relational zero copula requires one complement"
                )
            return
        raise ValueError(
            "Zero copula requires essential or circumstantial validity"
        )

    @staticmethod
    def _validated_distribution_marker(
        distribution: DistributiveModifier,
    ) -> str:
        expected = ASAXI_DISTRIBUTIVE_MARKERS[distribution.kind]
        marker = distribution.marker.strip().casefold() or expected
        if marker != expected:
            raise ValueError(
                "Distributive marker does not match its typed meaning: "
                f"{marker!r} != {expected!r}"
            )
        return marker

    @classmethod
    def _nominal_distribution_marker(
        cls,
        nominal: Nominal,
        *,
        target_role: str,
    ) -> str | None:
        distribution = nominal.distribution
        if distribution is None:
            return None
        if distribution.scope is not DistributionScope.NOMINAL:
            raise ValueError(
                "Nominal distribution requires nominal scope"
            )
        if distribution.target_role not in {None, target_role}:
            raise ValueError(
                "Nominal distribution target does not match its argument: "
                f"{distribution.target_role!r} != {target_role!r}"
            )
        return cls._validated_distribution_marker(distribution)

    def _realize_linked_clause(self, clause: CanonicalClause) -> Realization:
        """Realize two already ordered semantic clauses with a tail linker."""

        connector = clause.connector
        linked = clause.coordinated_clause
        if connector is None or linked is None:
            raise ValueError("Linked-clause realization is incomplete")
        first = self.realize(
            replace(
                clause,
                connector=None,
                coordinated_clause=None,
                preclausal_marker=None,
                tte_binder=None,
            )
        )
        second = self.realize(linked)
        marker = ASAXI_CLAUSE_CONNECTOR_MARKERS[connector]
        first_body = first.text.rstrip(".?!")
        realization = Realization(
            text=f"{first_body} {marker}, {second.text}",
            tokens=(*first.tokens, marker, *second.tokens),
            assumptions=(*first.assumptions, *second.assumptions),
            rule_trace=(
                *first.rule_trace,
                CLAUSE_CONNECTOR_RULES[connector],
                f"syntax.connector.{connector.value}",
                *second.rule_trace,
            ),
        )
        return self._apply_pragmatics(
            replace(clause, discourse_marker=None),
            self._apply_tte_binder(clause, realization),
        )

    def _realize_directive(
        self,
        clause: CanonicalClause,
        predicate: str,
    ) -> Realization:
        """Realize one documented command without an overt subject marker.

        Directive force owns its polarity and command morphology, so ordinary
        tense/negation realization must not run over the same predicate.
        """

        directive = clause.directive
        if directive is None:
            raise ValueError("Directive realization requires a directive")
        if clause.tense is not Tense.NONPAST or clause.interrogative:
            raise ValueError(
                "Directive realization supports nonpast nonquestions only"
            )
        if clause.modality is not Modality.NONE:
            raise ValueError("Directive force and action modality cannot stack")
        if clause.causative_agency is not None:
            raise ValueError("Directive and causative force cannot stack")
        expected_focus = directive_focus_for(
            directive.kind,
            directive.placement,
        )
        if directive.focus is not expected_focus:
            raise ValueError(
                "Directive focus is inconsistent with its kind and placement"
            )
        if not clause.post_verbal_scope.is_empty:
            raise ValueError("Directive force cannot carry a modal tail")
        expected_polarity = (
            Polarity.NEGATIVE
            if directive.kind
            in {
                DirectiveKind.PROHIBITION,
                DirectiveKind.ABSOLUTE_PROHIBITION,
                DirectiveKind.POLITE_PROHIBITION,
            }
            else Polarity.POSITIVE
        )
        if clause.polarity is not expected_polarity:
            raise ValueError(
                "Directive kind and canonical polarity are inconsistent"
            )
        hortative = directive.kind in {
            DirectiveKind.HORTATIVE,
            DirectiveKind.POLITE_HORTATIVE,
        }
        if hortative:
            if (
                directive.joint_participant is None
                or directive.joint_participant.surface.casefold() != "wa"
            ):
                raise ValueError(
                    "Hortatives require the documented inclusive wa participant"
                )
        elif directive.joint_participant is not None:
            raise ValueError(
                "Only hortatives license a joint-participant pronoun"
            )

        tokens: list[str] = []
        trace = [
            "syntax.canonical-directive",
            "clause.directive",
            f"directive.{directive.kind.value}",
            f"directive.placement.{directive.placement.value}",
            f"directive.focus.{directive.focus.value}",
        ]
        if not directive.implicit_addressee:
            tokens.append(directive.addressee.surface + ",")
            trace.append("clause.directive-vocative")
        else:
            trace.append("clause.implicit-second-person-addressee")
        if hortative:
            trace.append("clause.inclusive-joint-participant")
        if directive.rapid_speech:
            trace.append("directive.rapid-speech-vowel-elision")
        if clause.action_switch is not None:
            if directive.kind is not DirectiveKind.SWITCH:
                raise ValueError(
                    "An action-switch source requires a switch directive"
                )
            marker = clause.action_switch.cessation_marker.strip().casefold()
            if marker not in {"tomo", "tomo'"}:
                raise ValueError(
                    "Action switching requires the documented tomo marker"
                )
            discontinued = self.realize(
                replace(
                    clause.action_switch.discontinued_clause,
                    subject=None,
                    omitted_subject=True,
                    discourse_subject=True,
                    subject_marked=False,
                    connector=None,
                    coordinated_clause=None,
                    preclausal_marker=None,
                    discourse_marker=None,
                    tte_binder=None,
                )
            )
            tokens.extend(discontinued.tokens)
            tokens.append("tomo")
            trace.extend(
                (
                    *discontinued.rule_trace,
                    "clause.action-switch",
                    "post-verbal.result",
                )
            )
        for oblique in clause.obliques:
            tokens.append(oblique.marker)
            tokens.extend(_nominal_tokens_with_time(oblique.nominal))
            if oblique.nominal.word_time_binding is not None:
                trace.extend(
                    _word_time_rule_trace(
                        oblique.nominal.word_time_binding
                    )
                )
            trace.extend(
                (
                    "clause.relational-phrase",
                    f"case.{oblique.relation.value}",
                )
            )
        if clause.object is not None:
            tokens.extend(_nominal_tokens_with_time(clause.object))
            if clause.object.word_time_binding is not None:
                trace.extend(
                    _word_time_rule_trace(
                        clause.object.word_time_binding
                    )
                )
            trace.append("object.zero-accusative")
        if clause.complement is not None or clause.location is not None:
            raise ValueError(
                "Directive generation does not accept copular complements"
            )
        if (
            clause.temporal_aspect is not TemporalAspect.NONE
            or clause.frequency is not None
            or clause.distribution is not None
        ):
            raise ValueError(
                "Directive generation does not yet license clause-tail modifiers"
            )
        tokens.append(
            _realize_directive_predicate(
                predicate,
                directive,
                source_attested_contraction=self.has_derived_attestation(
                    clause.verbal_derivation,
                    predicate,
                ),
            )
        )
        punctuation = (
            "?"
            if directive.kind is DirectiveKind.POLITE_HORTATIVE
            else "."
            if directive.kind
            in {
                DirectiveKind.REQUEST,
                DirectiveKind.INSTRUCTION,
                DirectiveKind.POLITE_PROHIBITION,
            }
            else "!"
        )
        return Realization(
            text=" ".join(tokens) + punctuation,
            tokens=tuple(tokens),
            assumptions=(),
            rule_trace=tuple(trace),
        )


def realize_directive_predicate(
    root: str,
    directive: Directive,
) -> str:
    """Attach a directive without granting source-restricted contraction.

    Canonical generation validates compiled derived-term provenance before it
    calls the private implementation. A bare helper call cannot manufacture
    that capability from a surface string.
    """

    return _realize_directive_predicate(
        root,
        directive,
        source_attested_contraction=False,
    )


def _realize_directive_predicate(
    root: str,
    directive: Directive,
    *,
    source_attested_contraction: bool,
) -> str:
    """Attach exactly one documented directive form to a lexical verb root."""

    if directive.kind in {
        DirectiveKind.REQUEST,
        DirectiveKind.INSTRUCTION,
        DirectiveKind.POLITE_PROHIBITION,
    }:
        return realize_solicitative_predicate(root, directive)

    predicate = root.strip().casefold()
    if not predicate or " " in predicate:
        raise ValueError("Directive realization requires one verb root")
    placement = directive.placement
    markers = directive.markers
    kind = directive.kind

    if directive.rapid_speech and kind is not DirectiveKind.HORTATIVE:
        raise ValueError(
            "Rapid-speech vowel elision is licensed only for hortatives"
        )

    if kind is DirectiveKind.HORTATIVE:
        if placement is not DirectivePlacement.SUFFIX or not markers:
            raise ValueError("Hortatives require suffix directive placement")
        if markers[-1] != "wa":
            raise ValueError("Hortatives require final inclusive wa")
        if directive.rapid_speech:
            if (
                directive.fused
                or markers != ("hè", "wa")
                or predicate.endswith("ů")
                or predicate[-1] not in ASAXI_VOWELS
            ):
                raise ValueError(
                    "Rapid-speech hortatives require vowel-final "
                    "root + hè + wa"
                )
            return predicate + "hwa"
        command = replace(
            directive,
            kind=DirectiveKind.COMMAND,
            markers=markers[:-1],
            rapid_speech=False,
            joint_participant=None,
        )
        return _realize_directive_predicate(
            predicate,
            command,
            source_attested_contraction=source_attested_contraction,
        ) + "wa"

    if kind is DirectiveKind.POLITE_HORTATIVE:
        if (
            placement is not DirectivePlacement.SUFFIX
            or markers != ("kă", "wa")
            or directive.fused
        ):
            raise ValueError(
                "Polite hortatives require the documented -kă-wa sequence"
            )
        return predicate + "kăwa"

    if kind is DirectiveKind.COMMAND:
        if placement is DirectivePlacement.PREFIX:
            if markers != ("hè",) or directive.fused:
                raise ValueError("Prefix commands require unfused hè-")
            return "hè" + predicate
        if placement is not DirectivePlacement.SUFFIX:
            raise ValueError("Commands use prefix or suffix placement")
        return _realize_imperative_suffix(
            predicate,
            markers=markers,
            fused=directive.fused,
        )

    suffixes = {
        DirectiveKind.PROHIBITION: ("ná", "hè"),
        DirectiveKind.ABSOLUTE_PROHIBITION: ("ná", "xă", "hè"),
    }
    if kind in suffixes:
        expected = suffixes[kind]
        if (
            placement is not DirectivePlacement.SUFFIX
            or markers != expected
            or directive.fused
        ):
            raise ValueError(
                f"{kind.value} requires the documented suffix markers"
            )
        return predicate + "".join(markers)

    flow_marker = {
        DirectiveKind.CESSATION: "nă",
        DirectiveKind.CONTINUATION: "sů",
    }.get(kind)
    if flow_marker is not None:
        if markers != (flow_marker,):
            raise ValueError(
                f"{kind.value} requires the documented {flow_marker} marker"
            )
        if placement is DirectivePlacement.PREFIX:
            if directive.fused:
                raise ValueError(
                    f"Prefix {kind.value} forms do not license fusion"
                )
            return flow_marker + predicate
        if placement is DirectivePlacement.SUFFIX:
            if directive.fused:
                if (
                    kind is not DirectiveKind.CESSATION
                    or not predicate.endswith("nů")
                    or not source_attested_contraction
                ):
                    raise ValueError(
                        "Only a source-attested derived -nů surface may use "
                        "cessation contraction"
                    )
                return predicate[:-1] + "ă"
            return predicate + flow_marker
        raise ValueError(f"{kind.value} has no circumfix form")

    if kind is DirectiveKind.SWITCH:
        if placement is not DirectivePlacement.CIRCUMFIX:
            raise ValueError("Switch directives require circumfix placement")
        if len(markers) != 2 or markers[0] != "nåhè":
            raise ValueError("Switch directives require nåhè- plus an imperative")
        suffix = _realize_imperative_suffix(
            predicate,
            markers=(markers[1],),
            fused=directive.fused,
        )
        return "nåhè" + suffix

    raise ValueError(f"Unsupported directive kind: {kind.value}")


def _realize_imperative_suffix(
    root: str,
    *,
    markers: tuple[str, ...],
    fused: bool,
) -> str:
    """Realize and validate the documented suffixal imperative allomorph."""

    if root.endswith("ů"):
        if fused:
            if markers != ("wë",):
                raise ValueError("Fused ů+hè commands require -wë")
            return root[:-1] + "wë"
        if markers != ("è",):
            raise ValueError("Unfused ů-final commands require -è")
        return root + "è"
    if fused:
        raise ValueError("Only ů-final roots license the -wë fusion")
    expected = ("hè",) if root[-1] in ASAXI_VOWELS else ("è",)
    if markers != expected:
        raise ValueError(
            "Imperative suffix does not match the root-final allomorph"
        )
    return root + expected[0]


def documented_directive_variants(
    root: str,
    kind: DirectiveKind,
    *,
    allow_cessation_fusion: bool = False,
) -> tuple[tuple[DirectivePlacement, tuple[str, ...], bool], ...]:
    """Return every target form licensed when English leaves focus unmarked."""

    predicate = root.strip().casefold()
    if not predicate or " " in predicate:
        return ()
    if kind is DirectiveKind.REQUEST:
        return ((DirectivePlacement.SUFFIX, ("kă",), False),)
    if kind is DirectiveKind.INSTRUCTION:
        return ((DirectivePlacement.SUFFIX, ("xă", "kă"), False),)
    if kind is DirectiveKind.POLITE_PROHIBITION:
        return ((DirectivePlacement.SUFFIX, ("ná", "xă", "kă"), False),)
    if kind is DirectiveKind.PROHIBITION:
        return ((DirectivePlacement.SUFFIX, ("ná", "hè"), False),)
    if kind is DirectiveKind.ABSOLUTE_PROHIBITION:
        return ((DirectivePlacement.SUFFIX, ("ná", "xă", "hè"), False),)
    if kind is DirectiveKind.CESSATION:
        variants = [
            (DirectivePlacement.SUFFIX, ("nă",), False),
            (DirectivePlacement.PREFIX, ("nă",), False),
        ]
        if allow_cessation_fusion and predicate.endswith("nů"):
            variants.insert(
                0,
                (DirectivePlacement.SUFFIX, ("nă",), True),
            )
        return tuple(variants)
    if kind is DirectiveKind.CONTINUATION:
        return (
            (DirectivePlacement.SUFFIX, ("sů",), False),
            (DirectivePlacement.PREFIX, ("sů",), False),
        )
    if kind is DirectiveKind.POLITE_HORTATIVE:
        return ((DirectivePlacement.SUFFIX, ("kă", "wa"), False),)

    suffixes: tuple[tuple[str, bool], ...]
    if predicate.endswith("ů"):
        suffixes = (("è", False), ("wë", True))
    elif predicate[-1] in ASAXI_VOWELS:
        suffixes = (("hè", False),)
    else:
        suffixes = (("è", False),)
    if kind is DirectiveKind.COMMAND:
        return tuple(
            (DirectivePlacement.SUFFIX, (marker,), fused)
            for marker, fused in suffixes
        )
    if kind is DirectiveKind.HORTATIVE:
        return tuple(
            (
                DirectivePlacement.SUFFIX,
                (marker, "wa"),
                fused,
            )
            for marker, fused in suffixes
        )
    if kind is DirectiveKind.SWITCH:
        return tuple(
            (
                DirectivePlacement.CIRCUMFIX,
                ("nåhè", marker),
                fused,
            )
            for marker, fused in suffixes
        )
    return ()


def realize_solicitative_predicate(
    root: str,
    directive: Directive,
) -> str:
    """Attach one documented kă-family directive to a lexical verb root."""

    return realize_solicitative_form(
        root,
        directive.kind,
        directive.placement,
    )


def realize_solicitative_form(
    root: str,
    kind: DirectiveKind,
    placement: DirectivePlacement,
) -> str:
    """Realize one kă-family form without requiring a complete clause."""

    predicate = root.strip().casefold()
    if not predicate or " " in predicate:
        raise ValueError("Solicitative realization requires one verb root")

    suffix = {
        DirectiveKind.REQUEST: "kă",
        DirectiveKind.INSTRUCTION: "xăkă",
        DirectiveKind.POLITE_PROHIBITION: "náxăkă",
    }.get(kind)
    if suffix is None:
        raise ValueError(
            f"{kind.value!r} is not a solicitative directive"
        )
    if placement is DirectivePlacement.SUFFIX:
        return predicate + suffix
    if placement is not DirectivePlacement.PREFIX:
        raise ValueError("Solicitatives do not have a circumfix realization")
    if kind is DirectiveKind.POLITE_PROHIBITION:
        raise ValueError(
            "The documented polite prohibition is suffixal"
        )
    prefix = "kă" if kind is DirectiveKind.REQUEST else "xăkă"
    bridge = "x" if predicate[0] in ASAXI_VOWELS else ""
    return prefix + bridge + predicate


def realize_predicate(
    root: str,
    *,
    tense: Tense = Tense.NONPAST,
    polarity: Polarity = Polarity.POSITIVE,
    modality: Modality = Modality.NONE,
) -> tuple[str, tuple[str, ...]]:
    """Realize the supported tense/polarity layer around one verb root.

    The grammar requires ``x`` between a vowel-final prefix and a
    vowel-initial root. The pure ``ů`` predicate uses the documented ``b``
    bridge in the past. Broader stative and subjective-tense behavior remains
    outside the first translation slice.
    """

    predicate = root.strip().casefold()
    if not predicate or " " in predicate:
        raise ValueError("Predicate realization requires one verb root")
    trace: list[str] = []
    if modality is not Modality.NONE:
        operator = {
            Modality.DESIDERATIVE: "jå",
            Modality.CONATIVE: "xè",
        }[modality]
        bridge = "x" if predicate[0] in ASAXI_VOWELS else ""
        predicate = operator + bridge + predicate
        trace.append(f"mood.{modality.value}")
        if bridge:
            trace.append("phonology.x-hiatus-bridge")
    if predicate == "xiŕa":
        surface = {
            (Tense.NONPAST, Polarity.POSITIVE): "xiŕa",
            (Tense.NONPAST, Polarity.NEGATIVE): "nèŕa",
            (Tense.PAST, Polarity.POSITIVE): "zèxiŕa",
            (Tense.PAST, Polarity.NEGATIVE): "zènèŕa",
            (Tense.FUTURE, Polarity.POSITIVE): "paxiŕa",
            (Tense.FUTURE, Polarity.NEGATIVE): "panèŕa",
        }[(tense, polarity)]
        return surface, (
            "copula.identity-irregular",
            f"tense.{tense.value}",
            f"polarity.{polarity.value}",
        )
    if tense is Tense.NONPAST:
        if polarity is Polarity.NEGATIVE:
            trace.append("negation.nonpast-suffix")
            return predicate + "ná", tuple(trace)
        return predicate, tuple(trace)

    prefix = {
        Tense.PAST: "zè",
        Tense.FUTURE: "pa",
    }[tense]
    trace.append(f"tense.{tense.value}-prefix")
    if polarity is Polarity.NEGATIVE:
        bridge = "x" if predicate[0] in ASAXI_VOWELS else ""
        if predicate == "ů" and tense is Tense.PAST:
            bridge = "b"
        trace.append("negation.tensed-infix")
        if bridge:
            trace.append(f"phonology.{bridge}-hiatus-bridge")
        return prefix + "ná" + bridge + predicate, tuple(trace)

    bridge = "x" if predicate[0] in ASAXI_VOWELS else ""
    if predicate == "ů" and tense is Tense.PAST:
        bridge = "b"
    if bridge:
        trace.append(f"phonology.{bridge}-hiatus-bridge")
    return prefix + bridge + predicate, tuple(trace)


def realize_validity_predicate(
    root: str,
    *,
    tense: Tense = Tense.NONPAST,
    polarity: Polarity = Polarity.POSITIVE,
) -> tuple[str, tuple[str, ...]]:
    """Realize the documented essential-validity tense/negation paradigm."""

    predicate = root.strip().casefold()
    if not predicate or " " in predicate:
        raise ValueError("Validity realization requires one predicate")
    if predicate == "xiŕa":
        return realize_predicate(
            predicate,
            tense=tense,
            polarity=polarity,
        )
    if not predicate.endswith("ŕa"):
        raise ValueError("Essential validity requires an overt -ŕa compound")
    if predicate.endswith("xiŕa"):
        if (
            predicate == "o-xiŕa"
            and tense is Tense.NONPAST
            and polarity is Polarity.NEGATIVE
        ):
            return "onèŕa", (
                "clause.validity-essential",
                "clause.deictic-location-predicate",
                "clause.validity-proximal-negation",
            )
        if tense is not Tense.NONPAST or polarity is not Polarity.POSITIVE:
            raise ValueError(
                "Inflected deictic -xiŕa compounds remain unresolved in the "
                "source grammar"
            )
        return predicate, ("clause.validity-essential",)
    if predicate[:-2] in {"va", "na", "xa", "pù", "pa", "hù", "ba", "ỏ"}:
        if polarity is Polarity.NEGATIVE:
            raise ValueError(
                "Negative topological validity is contradictory in the source "
                "documentation and must be selected explicitly"
            )
        if tense is not Tense.NONPAST:
            raise ValueError(
                "Tensed topological validity is not established by the source "
                "grammar and is not generated"
            )
    tense_prefix = {
        Tense.NONPAST: "",
        Tense.PAST: "zè",
        Tense.FUTURE: "pa",
    }[tense]
    polarity_prefix = "ná" if polarity is Polarity.NEGATIVE else ""
    trace = ["clause.validity-essential"]
    if tense_prefix:
        trace.append("clause.validity-tense-stack")
    if polarity_prefix:
        trace.append("clause.validity-relational-negation")
    return tense_prefix + polarity_prefix + predicate, tuple(trace)


def realize_circumstantial_predicate(
    root: str,
    *,
    tense: Tense = Tense.NONPAST,
    polarity: Polarity = Polarity.POSITIVE,
) -> tuple[str, tuple[str, ...]]:
    """Realize a bare relational particle without action-verb morphology.

    Note 21 directly attests the positive particle predicates and future
    negative ``panáni``. Other combinations remain parseable and explicit,
    but carry an unresolved-productivity trace instead of being presented as
    fully attested grammar.
    """

    predicate = root.strip().casefold()
    if predicate not in ASAXI_CIRCUMSTANTIAL_PREDICATES:
        raise ValueError(
            "Circumstantial realization requires an independent relational "
            "particle"
        )
    tense_prefix = {
        Tense.NONPAST: "",
        Tense.PAST: "zè",
        Tense.FUTURE: "pa",
    }[tense]
    polarity_prefix = "ná" if polarity is Polarity.NEGATIVE else ""
    trace = ["clause.validity-circumstantial"]
    if tense is not Tense.NONPAST:
        trace.append("clause.validity-tense-stack")
    if polarity is Polarity.NEGATIVE:
        trace.append("clause.validity-relational-negation")
    directly_attested = (
        tense is Tense.NONPAST
        and polarity is Polarity.POSITIVE
    ) or (
        predicate == "ni"
        and tense is Tense.FUTURE
        and polarity is Polarity.NEGATIVE
    )
    if not directly_attested:
        trace.append("clause.validity-productivity-unresolved")
    return tense_prefix + polarity_prefix + predicate, tuple(trace)


def realize_causative_predicate(
    root: str,
    *,
    tense: Tense,
    polarity: Polarity,
    modality: Modality,
    voice: CausativeVoice,
    derived_root: bool = False,
) -> tuple[str, tuple[str, ...]]:
    """Realize the documented causative agency prefix stack."""

    if modality is not Modality.NONE:
        raise ValueError(
            "Causative voice and action modality share one operator slot"
        )
    verb_voice: VerbVoice
    verb_polarity: VerbPolarity
    if voice is CausativeVoice.PERMISSIVE:
        verb_voice = VerbVoice.PERMISSIVE
        verb_polarity = (
            VerbPolarity.NEGATIVE
            if polarity is Polarity.NEGATIVE
            else VerbPolarity.POSITIVE
        )
    elif voice is CausativeVoice.COERCIVE:
        if polarity is Polarity.NEGATIVE:
            raise ValueError(
                "A negative coercive causative has no documented form"
            )
        verb_voice = VerbVoice.COERCIVE
        verb_polarity = VerbPolarity.POSITIVE
    else:
        if polarity is Polarity.NEGATIVE:
            raise ValueError(
                "Prohibitive causative already encodes negative force"
            )
        verb_voice = VerbVoice.PERMISSIVE
        verb_polarity = VerbPolarity.NEGATIVE_EMPHATIC

    realization = realize_verb_complex(
        VerbComplexSpec(
            root=root,
            tense={
                Tense.NONPAST: VerbTense.NONPAST,
                Tense.PAST: VerbTense.PAST,
                Tense.FUTURE: VerbTense.FUTURE,
            }[tense],
            polarity=verb_polarity,
            mood=VerbMood.NONE,
            aspect=VerbAspect.NONE,
            voice=verb_voice,
            root_kind=(
                VerbRootKind.DERIVED
                if derived_root
                else VerbRootKind.ROOT
            ),
        )
    )
    return realization.surface, (
        *realization.rule_trace,
        "clause.causative-prefix-stack",
        f"voice.{voice.value}",
    )
