"""Versioned runtime records shared by translator frontends."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from .models import GrammarModelReference, Severity
from .morphology import MorphologicalAnalysis
from .syntax import CanonicalClause


TRANSLATION_SCHEMA_VERSION = "0.5.0-provisional"
TRANSLATION_ENGINE_VERSION = "0.2.13"


class TranslationDirection(str, Enum):
    ASAXI_TO_ENGLISH = "asaxi-to-english"
    ENGLISH_TO_ASAXI = "english-to-asaxi"


class TranslationStatus(str, Enum):
    OK = "ok"
    AMBIGUOUS = "ambiguous"
    UNSUPPORTED = "unsupported"


@dataclass(frozen=True)
class TranslationDiagnostic:
    code: str
    severity: Severity
    message: str
    token_index: int | None = None
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "severity": self.severity.value,
            "message": self.message,
            "token_index": self.token_index,
            "details": dict(sorted(self.details.items())),
        }


@dataclass(frozen=True)
class TranslationAssumption:
    code: str
    message: str
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "message": self.message,
            "details": dict(sorted(self.details.items())),
        }


@dataclass(frozen=True)
class TranslationAmbiguity:
    code: str
    message: str
    choices: tuple[str, ...]
    selected: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "message": self.message,
            "choices": list(self.choices),
            "selected": self.selected,
        }


@dataclass(frozen=True)
class TranslationAnalysisRank:
    """Inspectable evidence used to order complete construction analyses."""

    source_token_count: int = 0
    resolved_token_count: int = 0
    unresolved_token_count: int = 0
    unresolved_topic: bool = False
    inference_cost: int = 0
    ambiguity_count: int = 0
    construction_families: tuple[str, ...] = ()

    @property
    def coverage(self) -> float:
        if self.source_token_count == 0:
            return 1.0
        return self.resolved_token_count / self.source_token_count

    @property
    def sort_key(self) -> tuple[int, int, int]:
        return (
            self.unresolved_token_count,
            int(self.unresolved_topic),
            self.inference_cost,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "source_token_count": self.source_token_count,
            "resolved_token_count": self.resolved_token_count,
            "unresolved_token_count": self.unresolved_token_count,
            "coverage": round(self.coverage, 6),
            "unresolved_topic": self.unresolved_topic,
            "inference_cost": self.inference_cost,
            "ambiguity_count": self.ambiguity_count,
            "construction_families": list(self.construction_families),
        }


@dataclass(frozen=True)
class AuthoredTranslationProvenance:
    """Inspectable provenance for a reviewed whole-phrase translation."""

    phrase_id: str
    canonical_source: str
    matched_source: str
    match_kind: str
    verified: bool
    revision: int
    reviewed_with_grammar_model: str | None = None
    reviewed_with_translation_engine_version: str | None = None
    reviewed_with_source_digest: str | None = None
    reviewed_by: str | None = None
    reviewed_at: str | None = None
    verification_source: str | None = None
    authorship: str = "human-authored"

    def to_dict(self) -> dict[str, Any]:
        return {
            "phrase_id": self.phrase_id,
            "canonical_source": self.canonical_source,
            "matched_source": self.matched_source,
            "match_kind": self.match_kind,
            "verified": self.verified,
            "revision": self.revision,
            "reviewed_with_grammar_model": (
                self.reviewed_with_grammar_model
            ),
            "reviewed_with_translation_engine_version": (
                self.reviewed_with_translation_engine_version
            ),
            "reviewed_with_source_digest": (
                self.reviewed_with_source_digest
            ),
            "reviewed_by": self.reviewed_by,
            "reviewed_at": self.reviewed_at,
            "verification_source": self.verification_source,
            "authorship": self.authorship,
        }


@dataclass(frozen=True)
class AuthoredTranslationMatch:
    """A reviewed output available alongside, not inside, grammar analyses."""

    identifier: str
    output_text: str
    provenance: AuthoredTranslationProvenance

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.identifier,
            "output_text": self.output_text,
            "provenance": self.provenance.to_dict(),
        }


@dataclass(frozen=True)
class TranslationToken:
    index: int
    surface: str
    normalized: str
    start: int
    end: int
    kind: str
    role: str | None = None
    morphology: tuple[MorphologicalAnalysis, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return {
            "index": self.index,
            "surface": self.surface,
            "normalized": self.normalized,
            "span": {"start": self.start, "end": self.end},
            "kind": self.kind,
            "role": self.role,
            "morphology": [
                analysis.to_dict() for analysis in self.morphology
            ],
        }


@dataclass(frozen=True)
class TranslationAlternative:
    identifier: str
    output_text: str
    canonical_clause: CanonicalClause | None
    tokens: tuple[TranslationToken, ...]
    assumptions: tuple[TranslationAssumption, ...] = ()
    ambiguities: tuple[TranslationAmbiguity, ...] = ()
    rule_trace: tuple[str, ...] = ()
    subject_text: str | None = None
    analysis_rank: TranslationAnalysisRank = field(
        default_factory=TranslationAnalysisRank
    )

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.identifier,
            "output_text": self.output_text,
            "canonical_clause": (
                self.canonical_clause.to_dict()
                if self.canonical_clause is not None
                else None
            ),
            "tokens": [token.to_dict() for token in self.tokens],
            "assumptions": [
                assumption.to_dict() for assumption in self.assumptions
            ],
            "ambiguities": [
                ambiguity.to_dict() for ambiguity in self.ambiguities
            ],
            "rule_trace": list(self.rule_trace),
            "subject_text": self.subject_text,
            "analysis_rank": self.analysis_rank.to_dict(),
        }


@dataclass(frozen=True)
class TranslationResult:
    direction: TranslationDirection
    input_text: str
    normalized_input: str
    status: TranslationStatus
    alternatives: tuple[TranslationAlternative, ...]
    grammar_model: GrammarModelReference
    fallback_output_text: str | None = None
    authored_matches: tuple[AuthoredTranslationMatch, ...] = ()
    diagnostics: tuple[TranslationDiagnostic, ...] = ()
    selected_alternative_id: str | None = None
    schema_version: str = TRANSLATION_SCHEMA_VERSION
    engine_version: str = TRANSLATION_ENGINE_VERSION

    @property
    def selected(self) -> TranslationAlternative | None:
        if self.selected_alternative_id is None:
            return None
        return next(
            (
                alternative
                for alternative in self.alternatives
                if alternative.identifier == self.selected_alternative_id
            ),
            None,
        )

    @property
    def preferred_output_text(self) -> str | None:
        """Return the default rendered output without changing grammar selection."""

        if self.authored_matches:
            return self.authored_matches[0].output_text
        selected = self.selected
        if selected is not None:
            return selected.output_text
        return self.fallback_output_text

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "engine_version": self.engine_version,
            "grammar_model": self.grammar_model.to_dict(),
            "direction": self.direction.value,
            "input_text": self.input_text,
            "normalized_input": self.normalized_input,
            "status": self.status.value,
            "selected_alternative_id": self.selected_alternative_id,
            "fallback_output_text": self.fallback_output_text,
            "authored_matches": [
                match.to_dict() for match in self.authored_matches
            ],
            "alternatives": [
                alternative.to_dict()
                for alternative in self.alternatives
            ],
            "diagnostics": [
                diagnostic.to_dict() for diagnostic in self.diagnostics
            ],
        }
