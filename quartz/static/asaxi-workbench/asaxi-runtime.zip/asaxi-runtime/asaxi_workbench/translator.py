"""Bounded canonical translation plus an explicitly noncanonical fallback.

The canonical parser intentionally accepts a small grammar and never widens a
parse through unlicensed heuristics. Unsupported English may additionally
receive a visibly labeled lexical fallback whose retained words stay uppercase.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
import itertools
import re
from typing import Iterable

from .clause_grammar import (
    CASE_ARGUMENT_ROLES,
    CASE_MARKERS,
    CONNECTOR_ENGLISH,
    CONNECTORS,
    ExpandedAsaxiClauseParser,
    lexeme_allowed_for_nominal_role,
    valency_allows_direct_object,
)
from .construction_lattice import rank_constructions
from .english_frontend import (
    ARTICLES,
    COPULA_TENSES,
    DO_AUXILIARIES,
    EnglishActionFrame,
    EnglishAspect,
    EnglishClauseFrame,
    EnglishDiscourseForce,
    EnglishEpistemicForce,
    EnglishDirectiveForce,
    EnglishDirectiveFrame,
    EnglishInputToken,
    EnglishLocativeKind,
    EnglishNominalFrame,
    EnglishNominalQuantifierKind,
    EnglishObliqueFrame,
    EnglishObliqueKind,
    EnglishPossessor,
    EnglishPreclausalForce,
    EnglishSpatialClauseFrame,
    EnglishSpatialRelation,
    EnglishStructuralFrame,
    EnglishStructuralFrontend,
    POSSESSIVE_DETERMINERS,
    UNIVERSAL_QUANTIFIERS,
)
from .models import LanguageDatabase, Lexeme, Severity, SpecificationStatus
from .morphology import (
    MorphologicalAnalysis,
    MorphologyEngine,
    pluralize_nominal,
)
from .numerals import fraction_denominator_form
from .phrase_memory import PhraseMemoryStore
from .productive_morphology import compose_ga_compound
from .spatial_semantics import (
    SPATIAL_ABSTRACT,
    SPATIAL_PHYSICAL,
    classify_spatial_landmark,
)
from .syntax import (
    CaseRelation,
    CausativeAgency,
    CausativeVoice,
    ClauseConnector,
    CanonicalClause,
    CanonicalGenerator,
    DeicticDistance,
    Directive,
    DirectiveKind,
    DirectivePlacement,
    DiscourseMarker,
    DiscourseMarkerKind,
    DiscourseState,
    DerivedTermAttestation,
    DistributiveModifier,
    DistributionScope,
    EventFrequency,
    EpistemicQualification,
    EpistemicStance,
    ASAXI_DISTRIBUTIVE_MARKERS,
    ASAXI_FREQUENCY_MARKERS,
    Nominal,
    NominalExtent,
    NominalExtentKind,
    NominalQuantifier,
    NominalQuantifierKind,
    Polarity,
    PreclausalMarker,
    PreclausalMarkerKind,
    PredicateKind,
    PronounAnimacy,
    PronounKind,
    PronounPerson,
    Register,
    RelationalPhrase,
    Tense,
    TteBinder,
    TteFunction,
    ValidityMode,
    VerbalDerivation,
    VerbalNominalization,
    VerbalizationMode,
    WhRole,
    documented_directive_variants,
    realize_predicate,
)
from .translation_lexicon import (
    EnglishGerundMatch,
    EnglishLexicalCandidate,
    EnglishVerbMatch,
    TranslationLexicon,
    past_tense,
    plural_noun,
    present_participle_phrase,
    present_third_person,
    split_english_gloss,
)
from .translation_models import (
    AuthoredTranslationMatch,
    AuthoredTranslationProvenance,
    TranslationAlternative,
    TranslationAnalysisRank,
    TranslationAmbiguity,
    TranslationAssumption,
    TranslationDiagnostic,
    TranslationDirection,
    TranslationResult,
    TranslationStatus,
    TranslationToken,
)
from .thesaurus import (
    ThesaurusCandidate,
    ThesaurusProvider,
    discover_thesaurus,
)
from .version import WORKBENCH_VERSION


TOKEN_RE = re.compile(
    r"[^\W\d_]+(?:(?:[.'\u2018\u2019\u02bc-])[^\W\d_]+)*"
    r"(?:['\u2018\u2019\u02bc])?"
    r"|\d+(?:[.,]\d+)?|[^\w\s]",
    re.UNICODE,
)
ENGLISH_CONTRACTION_AUXILIARIES = {
    "'m": "am",
    "'re": "are",
    "'ve": "have",
    "'ll": "will",
}
ENGLISH_NEGATIVE_CONTRACTION_AUXILIARIES = {
    "aren't": "are",
    "can't": "can",
    "couldn't": "could",
    "didn't": "did",
    "doesn't": "does",
    "don't": "do",
    "hadn't": "had",
    "hasn't": "has",
    "haven't": "have",
    "isn't": "is",
    "mustn't": "must",
    "needn't": "need",
    "mightn't": "might",
    "oughtn't": "ought",
    "daren't": "dare",
    "shan't": "shall",
    "shouldn't": "should",
    "wasn't": "was",
    "weren't": "were",
    "won't": "will",
    "wouldn't": "would",
}
ENGLISH_APOSTROPHE_TRANSLATION = str.maketrans(
    {"\u2018": "'", "\u2019": "'", "\u02bc": "'"}
)
ASAXI_SUBJECT_MARKERS = {
    "to": Register.OBJECTIVE,
    "ă": Register.SUBJECTIVE,
}
ASAXI_DETERMINERS = {
    "anő": "indefinite",
    "onă": "definite",
    "onýj": "definite",
    "ponă": "specific-indefinite",
    "ponýj": "specific-indefinite",
}
ENGLISH_ARTICLES = {"a", "an", "the"}
OBJECT_PRONOUNS = {
    "i": "me",
    "he": "him",
    "she": "her",
    "we": "us",
    "they": "them",
}
MAX_ENGLISH_NP_OPTIONS = 64
ENGLISH_COORDINATING_CONNECTORS = {
    "and": ClauseConnector.AND,
    "or": ClauseConnector.OR,
    "but": ClauseConnector.BUT,
    "so": ClauseConnector.SO,
    "then": ClauseConnector.THEN,
}
ENGLISH_SUBORDINATING_CONNECTORS = (
    (("by", "the", "time"), ClauseConnector.BY_THE_TIME),
    (("even", "if"), ClauseConnector.EVEN_IF),
    (("although",), ClauseConnector.EVEN_IF),
    (("because",), ClauseConnector.BECAUSE),
    (("unless",), ClauseConnector.UNLESS),
    (("while",), ClauseConnector.WHILE),
    (("when",), ClauseConnector.WHEN),
    (("if",), ClauseConnector.IF),
)
ENGLISH_PRECLAUSAL_TO_ASAXI = {
    EnglishPreclausalForce.REACTIVE_OBJECTION: (
        PreclausalMarkerKind.REACTIVE_OBJECTION
    ),
    EnglishPreclausalForce.REACTIVE_CONTINUATION: (
        PreclausalMarkerKind.REACTIVE_CONTINUATION
    ),
    EnglishPreclausalForce.AWE: PreclausalMarkerKind.AWE,
    EnglishPreclausalForce.EMOTIONAL_REALIZATION: (
        PreclausalMarkerKind.EMOTIONAL_REALIZATION
    ),
}
ENGLISH_DISCOURSE_TO_ASAXI = {
    EnglishDiscourseForce.AGREEMENT: DiscourseMarkerKind.AGREEMENT,
    EnglishDiscourseForce.ASSERTION: DiscourseMarkerKind.ASSERTION,
    EnglishDiscourseForce.CASUAL_EMPHASIS: (
        DiscourseMarkerKind.CASUAL_EMPHASIS
    ),
    EnglishDiscourseForce.SKEPTICISM: DiscourseMarkerKind.SKEPTICISM,
    EnglishDiscourseForce.RESIGNATION: DiscourseMarkerKind.RESIGNATION,
    EnglishDiscourseForce.CONTENTION: DiscourseMarkerKind.CONTENTION,
}
ENGLISH_EPISTEMIC_TO_ASAXI = {
    EnglishEpistemicForce.SURE: EpistemicStance.SURE,
    EnglishEpistemicForce.KNOWN: EpistemicStance.KNOWN,
    EnglishEpistemicForce.THINK: EpistemicStance.THINK,
    EnglishEpistemicForce.UNSURE: EpistemicStance.UNSURE,
    EnglishEpistemicForce.DOUBT: EpistemicStance.DOUBT,
    EnglishEpistemicForce.SUBJECTIVE_PAST: EpistemicStance.SUBJECTIVE_PAST,
    EnglishEpistemicForce.MEMORY_FACT: EpistemicStance.MEMORY_FACT,
    EnglishEpistemicForce.FUTURE_FACT: EpistemicStance.FUTURE_FACT,
}
MAX_ENGLISH_MODIFIER_SEGMENTS = 6
ASAXI_SPATIAL_PREDICATES = {
    EnglishSpatialRelation.INSIDE: "vanů",
    EnglishSpatialRelation.OUTSIDE: "pănů",
    EnglishSpatialRelation.ON: "nanů",
    EnglishSpatialRelation.BEHIND: "hùnů",
    EnglishSpatialRelation.BESIDE: "banů",
    EnglishSpatialRelation.IN_FRONT_OF: "panů",
    EnglishSpatialRelation.ABOVE: "xanů",
    EnglishSpatialRelation.BELOW: "pùnů",
    EnglishSpatialRelation.AMID: "ỏnů",
}
ASAXI_TOPOLOGICAL_PREDICATES = {
    EnglishSpatialRelation.INSIDE: "vaŕa",
    EnglishSpatialRelation.ON: "naŕa",
    EnglishSpatialRelation.BEHIND: "hùŕa",
    EnglishSpatialRelation.BESIDE: "baŕa",
    EnglishSpatialRelation.IN_FRONT_OF: "paŕa",
    EnglishSpatialRelation.ABOVE: "xaŕa",
    EnglishSpatialRelation.BELOW: "pùŕa",
    EnglishSpatialRelation.AMID: "ỏŕa",
}
ASAXI_CASE_MARKER_BY_RELATION = {
    relation: marker
    for marker, (relation, _function, _glosses) in CASE_MARKERS.items()
}
TRANSFER_ENGLISH_PREDICATES = frozenset(
    {
        "give",
        "hand",
        "lend",
        "offer",
        "pass",
        "send",
        "show",
        "tell",
    }
)
COPULA_DYNAMIC_PREFERRED_FIELDS = frozenset(
    {
        "circumstance",
        "emotion",
        "health & medicine",
        "professions & occupations",
        "shapes & dimensions",
        "weather & climate",
    }
)
COPULA_ESSENTIAL_PREFERRED_FIELDS = frozenset(
    {
        "animals",
        "colours",
        "family",
        "materials",
    }
)
COPULA_STRONGLY_ESSENTIAL_FIELDS = frozenset(
    {
        "behaviour",
        "colours",
        "materials",
    }
)
ENGLISH_NONPREDICATE_FUNCTION_WORDS = frozenset(
    {
        "about",
        "above",
        "across",
        "after",
        "against",
        "along",
        "among",
        "around",
        "at",
        "before",
        "behind",
        "below",
        "beside",
        "between",
        "by",
        "during",
        "for",
        "from",
        "in",
        "inside",
        "into",
        "near",
        "of",
        "off",
        "on",
        "onto",
        "outside",
        "over",
        "past",
        "through",
        "to",
        "toward",
        "under",
        "until",
        "with",
        "within",
        "without",
    }
)


@dataclass(frozen=True)
class _RawToken:
    index: int
    surface: str
    normalized: str
    start: int
    end: int
    kind: str


@dataclass(frozen=True)
class _PredicateCandidate:
    lexeme: Lexeme
    tense: Tense
    polarity: Polarity
    surface: str
    morphemes: tuple[str, ...]
    rule_trace: tuple[str, ...]


@dataclass(frozen=True)
class _NominalInterpretation:
    nominal: Nominal
    english_text: str
    assumptions: tuple[TranslationAssumption, ...] = ()
    ambiguities: tuple[TranslationAmbiguity, ...] = ()
    rule_trace: tuple[str, ...] = ()
    source_roles: tuple[tuple[int, str], ...] = ()


@dataclass(frozen=True)
class _EnglishModifierInterpretation:
    nominal: Nominal
    kind: str
    source_indexes: tuple[int, ...]
    constitution_root: str | None = None
    assumptions: tuple[TranslationAssumption, ...] = ()
    ambiguities: tuple[TranslationAmbiguity, ...] = ()
    rule_trace: tuple[str, ...] = ()


@dataclass(frozen=True)
class _EnglishPredicateInterpretation:
    lexeme: Lexeme
    base: str
    surface: str
    tense: Tense
    polarity: Polarity
    verbal_derivation: VerbalDerivation | None = None
    explicit_derived_term: bool = False
    assumptions: tuple[TranslationAssumption, ...] = ()
    ambiguities: tuple[TranslationAmbiguity, ...] = ()
    rule_trace: tuple[str, ...] = ()


@dataclass(frozen=True)
class _EnglishObliqueInterpretation:
    phrase: RelationalPhrase
    assumptions: tuple[TranslationAssumption, ...] = ()
    ambiguities: tuple[TranslationAmbiguity, ...] = ()
    rule_trace: tuple[str, ...] = ()
    source_roles: tuple[tuple[int, str], ...] = ()


@dataclass(frozen=True)
class _FallbackDecision:
    token_indexes: tuple[int, ...]
    source_text: str
    output_text: str
    state: str
    reason: str

    def to_dict(self) -> dict[str, object]:
        return {
            "token_indexes": list(self.token_indexes),
            "source_text": self.source_text,
            "output_text": self.output_text,
            "state": self.state,
            "reason": self.reason,
        }


def _tokenize(text: str) -> tuple[_RawToken, ...]:
    tokens: list[_RawToken] = []
    for index, match in enumerate(TOKEN_RE.finditer(text)):
        surface = match.group(0)
        if surface[0].isdigit():
            kind = "number"
        elif surface[0].isalpha():
            kind = "word"
        else:
            kind = "punctuation"
        tokens.append(
            _RawToken(
                index=index,
                surface=surface,
                normalized=surface.casefold(),
                start=match.start(),
                end=match.end(),
                kind=kind,
            )
        )
    return tuple(tokens)


def _english_contraction_expansion(value: str) -> tuple[str, str] | None:
    """Return an unambiguous two-word expansion for one English token.

    Ambiguous ``'s`` (``is``/``has``/possessive), ``'d``
    (``had``/``would``), and ``ain't`` deliberately remain lexical tokens.
    The structural parser must not silently guess their grammatical role.
    """

    normalized = value.translate(ENGLISH_APOSTROPHE_TRANSLATION).casefold()
    negative_auxiliary = ENGLISH_NEGATIVE_CONTRACTION_AUXILIARIES.get(
        normalized
    )
    if negative_auxiliary is not None:
        return negative_auxiliary, "not"
    for suffix, auxiliary in ENGLISH_CONTRACTION_AUXILIARIES.items():
        if not normalized.endswith(suffix):
            continue
        subject = normalized[: -len(suffix)]
        if subject and (suffix != "'m" or subject == "i"):
            return subject, auxiliary
    return None


def _tokenize_english(text: str) -> tuple[_RawToken, ...]:
    """Tokenize English and expose unambiguous contraction morphology.

    Expanded parts retain disjoint spans inside the original contraction so
    clause slicing and source provenance continue to reference the user's text.
    """

    expanded: list[_RawToken] = []
    for token in _tokenize(text):
        contraction = (
            _english_contraction_expansion(token.normalized)
            if token.kind == "word"
            else None
        )
        if contraction is None:
            expanded.append(replace(token, index=len(expanded)))
            continue
        normalized = token.normalized.translate(ENGLISH_APOSTROPHE_TRANSLATION)
        split_offset = (
            len(normalized) - 3
            if normalized.endswith("n't")
            else normalized.rfind("'")
        )
        if split_offset <= 0 or split_offset >= len(normalized):
            expanded.append(replace(token, index=len(expanded)))
            continue
        split = token.start + split_offset
        for part, start, end in (
            (
                (contraction[0], token.start, split),
                (contraction[1], split, token.end),
            )
        ):
            expanded.append(
                _RawToken(
                    index=len(expanded),
                    surface=text[start:end],
                    normalized=part,
                    start=start,
                    end=end,
                    kind="word",
                )
            )
    return tuple(expanded)


def _normalize_tokens(tokens: Iterable[_RawToken]) -> str:
    text = " ".join(token.normalized for token in tokens)
    return re.sub(r"\s+([.,!?;:])", r"\1", text).strip()


def _capitalize(text: str) -> str:
    return text[:1].upper() + text[1:] if text else text


def _render_fallback_pieces(pieces: Iterable[str]) -> str:
    text = " ".join(piece for piece in pieces if piece)
    text = re.sub(r"\s+([.,!?;:)\]}])", r"\1", text)
    text = re.sub(r"([(\[{])\s+", r"\1", text)
    return text.strip()


def _indefinite_article(noun: str) -> str:
    return "an" if noun[:1].casefold() in "aeiou" else "a"


def _is_plural_analysis(
    analyses: Iterable[MorphologicalAnalysis],
) -> bool:
    return any(
        dict(analysis.features).get("number") == "plural"
        for analysis in analyses
    )


def _morphemes_for_predicate(
    root: str,
    tense: Tense,
    polarity: Polarity,
    trace: tuple[str, ...],
) -> tuple[str, ...]:
    pieces: list[str] = []
    if tense is Tense.PAST:
        pieces.append("zè-")
    elif tense is Tense.FUTURE:
        pieces.append("pa-")
    if tense is not Tense.NONPAST and polarity is Polarity.NEGATIVE:
        pieces.append("ná-")
    if any("hiatus-bridge" in item for item in trace):
        bridge = next(
            item.split(".")[1].split("-")[0]
            for item in trace
            if "hiatus-bridge" in item
        )
        pieces.append(f"-{bridge}-")
    pieces.append(root)
    if tense is Tense.NONPAST and polarity is Polarity.NEGATIVE:
        pieces.append("-ná")
    return tuple(pieces)


class Translator:
    """Translate the explicitly supported canonical fragment."""

    def __init__(
        self,
        database: LanguageDatabase,
        *,
        thesaurus: ThesaurusProvider | None = None,
        phrase_memory: PhraseMemoryStore | None = None,
    ):
        self.database = database
        self.grammar_model = database.grammar_model.reference(
            runtime_workbench_version=WORKBENCH_VERSION,
        )
        self.lexicon = TranslationLexicon(database)
        self._lexeme_by_id = {
            lexeme.identifier: lexeme for lexeme in database.lexemes
        }
        self.morphology = MorphologyEngine(database)
        self.generator = CanonicalGenerator(
            derived_term_attestations=(
                DerivedTermAttestation(
                    identifier=term.identifier,
                    source_lexeme_id=lexeme.identifier,
                    surface=term.surface,
                )
                for lexeme in database.lexemes
                for term in lexeme.derived_terms
                if (
                    term.surface is not None
                    and term.category == "verb"
                    and term.status is SpecificationStatus.CONFIRMED
                )
            )
        )
        self.thesaurus = (
            discover_thesaurus()
            if thesaurus is None
            else thesaurus
        )
        self.phrase_memory = phrase_memory
        self.english_frontend = EnglishStructuralFrontend()
        self.expanded_clause_parser = ExpandedAsaxiClauseParser(
            database,
            self.lexicon,
            self.morphology,
        )
        predicate_work: dict[str, list[_PredicateCandidate]] = {}
        for lexeme in database.lexemes:
            if lexeme.category != "verb" or " " in lexeme.lemma:
                continue
            for tense in Tense:
                for polarity in Polarity:
                    surface, trace = realize_predicate(
                        lexeme.lemma,
                        tense=tense,
                        polarity=polarity,
                    )
                    candidate = _PredicateCandidate(
                        lexeme=lexeme,
                        tense=tense,
                        polarity=polarity,
                        surface=surface,
                        morphemes=_morphemes_for_predicate(
                            lexeme.lemma,
                            tense,
                            polarity,
                            trace,
                        ),
                        rule_trace=("lexicon.predicate",) + trace,
                    )
                    predicate_work.setdefault(surface, []).append(candidate)
        self._asaxi_predicates = {
            key: tuple(
                sorted(
                    values,
                    key=lambda item: (
                        item.lexeme.identifier,
                        item.tense.value,
                        item.polarity.value,
                    ),
                )
            )
            for key, values in predicate_work.items()
        }
        self._fallback_phrase_limit = max(
            (
                len(term.split())
                for _category, term in self.lexicon.by_english
            ),
            default=1,
        )

    def translate(
        self,
        text: str,
        direction: TranslationDirection | str,
        *,
        discourse_state: DiscourseState | None = None,
    ) -> TranslationResult:
        selected = TranslationDirection(direction)
        if selected is TranslationDirection.ASAXI_TO_ENGLISH:
            baseline = self.asaxi_to_english(
                text,
                discourse_state=discourse_state,
            )
        else:
            baseline = self.english_to_asaxi(text)
        return self._apply_authored_phrase(text, selected, baseline)

    def _apply_authored_phrase(
        self,
        text: str,
        direction: TranslationDirection,
        baseline: TranslationResult,
    ) -> TranslationResult:
        if self.phrase_memory is None:
            return baseline
        matches = self.phrase_memory.matches(text, direction)
        if not matches:
            return baseline
        return replace(
            baseline,
            authored_matches=tuple(
                AuthoredTranslationMatch(
                    identifier=f"authored-{match.phrase.identifier}",
                    output_text=match.phrase.target_text,
                    provenance=AuthoredTranslationProvenance(
                        phrase_id=match.phrase.identifier,
                        canonical_source=match.phrase.source_text,
                        matched_source=match.matched_text,
                        match_kind=match.match_kind,
                        verified=match.phrase.verified,
                        revision=match.phrase.revision,
                        reviewed_with_grammar_model=(
                            match.phrase.reviewed_with_grammar_model
                        ),
                        reviewed_with_translation_engine_version=(
                            match.phrase.reviewed_with_translation_engine_version
                        ),
                        reviewed_with_source_digest=(
                            match.phrase.reviewed_with_source_digest
                        ),
                        reviewed_by=match.phrase.reviewed_by,
                        reviewed_at=match.phrase.reviewed_at,
                        verification_source=(
                            match.phrase.verification_source
                        ),
                    ),
                )
                for match in matches
            ),
        )

    def asaxi_to_english(
        self,
        text: str,
        *,
        discourse_state: DiscourseState | None = None,
    ) -> TranslationResult:
        tokens = _tokenize(text)
        if self.expanded_clause_parser.should_preempt_legacy(tokens):
            typed = self.expanded_clause_parser.parse(
                text,
                tokens,
                discourse_state=discourse_state,
            )
            if typed.alternatives:
                return self._result(
                    TranslationDirection.ASAXI_TO_ENGLISH,
                    text,
                    _normalize_tokens(tokens),
                    list(typed.alternatives),
                )
            if typed.diagnostic is not None:
                return self._unsupported_from_diagnostic(
                    direction=TranslationDirection.ASAXI_TO_ENGLISH,
                    text=text,
                    normalized=_normalize_tokens(tokens),
                    diagnostic=typed.diagnostic,
                )
            return self._unsupported(
                TranslationDirection.ASAXI_TO_ENGLISH,
                text,
                _normalize_tokens(tokens),
                "CLAUSE_STRUCTURE_UNRESOLVED",
                (
                    "No complete documented analysis fits this clause shape. "
                    "A conservative word-level translation is shown without "
                    "inventing unresolved roles or attachments."
                ),
            )
        legacy = self._asaxi_to_english_legacy(text)
        if legacy.status is not TranslationStatus.UNSUPPORTED:
            return legacy
        outcome = self.expanded_clause_parser.parse(
            text,
            tokens,
            discourse_state=discourse_state,
        )
        if outcome.alternatives:
            return self._result(
                TranslationDirection.ASAXI_TO_ENGLISH,
                text,
                _normalize_tokens(tokens),
                list(outcome.alternatives),
            )
        if outcome.diagnostic is not None:
            return self._unsupported_from_diagnostic(
                direction=TranslationDirection.ASAXI_TO_ENGLISH,
                text=text,
                normalized=_normalize_tokens(tokens),
                diagnostic=outcome.diagnostic,
            )
        return legacy

    def _asaxi_to_english_legacy(self, text: str) -> TranslationResult:
        tokens = _tokenize(text)
        normalized = _normalize_tokens(tokens)
        if not tokens:
            return self._unsupported(
                TranslationDirection.ASAXI_TO_ENGLISH,
                text,
                normalized,
                "EMPTY_INPUT",
                "No Asaxi text was supplied.",
            )
        interior_punctuation = [
            token
            for token in tokens[:-1]
            if token.kind == "punctuation"
        ]
        if interior_punctuation:
            return self._unsupported(
                TranslationDirection.ASAXI_TO_ENGLISH,
                text,
                normalized,
                "MULTICLAUSE_NOT_SUPPORTED",
                "The first translation slice accepts one simple clause.",
                token_index=interior_punctuation[0].index,
            )

        words = [token for token in tokens if token.kind != "punctuation"]
        interrogative = any(
            token.surface == "?" for token in tokens
        )
        question_indices: set[int] = set()
        if words and words[0].normalized == "kè":
            interrogative = True
            question_indices.add(words[0].index)
            words = words[1:]
        if words and words[-1].normalized == "kè":
            interrogative = True
            question_indices.add(words[-1].index)
            words = words[:-1]
        if len(words) < 3:
            return self._unsupported(
                TranslationDirection.ASAXI_TO_ENGLISH,
                text,
                normalized,
                "CANONICAL_CLAUSE_INCOMPLETE",
                (
                    "The clause does not contain enough recognized material "
                    "for a documented marked, unmarked, or pro-drop parse."
                ),
            )

        marker = words[0]
        register = ASAXI_SUBJECT_MARKERS.get(marker.normalized)
        if register is None:
            return self._unsupported(
                TranslationDirection.ASAXI_TO_ENGLISH,
                text,
                normalized,
                "CLAUSE_SHAPE_NOT_SUPPORTED",
                (
                    "The clause did not match a documented strict-unmarked "
                    "SOV, explicit-subject, zero-copula, or pro-drop shape. "
                    "Subject markers 'to' and 'ă' are optional when strict "
                    "SOV order or explicit discourse state resolves roles."
                ),
                token_index=marker.index,
            )
        subject_token = words[1]
        predicate_token = words[-1]
        object_tokens = words[2:-1]
        if len(object_tokens) > 2 or (
            len(object_tokens) == 2
            and object_tokens[0].normalized not in ASAXI_DETERMINERS
        ):
            return self._unsupported(
                TranslationDirection.ASAXI_TO_ENGLISH,
                text,
                normalized,
                "NOUN_PHRASE_NOT_SUPPORTED",
                (
                    "Only a bare object or a determiner plus one object head "
                    "is supported in this milestone."
                ),
                token_index=object_tokens[0].index,
            )

        predicates = self._asaxi_predicates.get(
            predicate_token.normalized,
            (),
        )
        if not predicates:
            return self._unsupported(
                TranslationDirection.ASAXI_TO_ENGLISH,
                text,
                normalized,
                "PREDICATE_NOT_RECOGNIZED",
                (
                    f"No supported lexical predicate analysis was found for "
                    f"{predicate_token.surface!r}."
                ),
                token_index=predicate_token.index,
            )
        if object_tokens:
            predicates = tuple(
                predicate
                for predicate in predicates
                if (
                    not predicate.lexeme.valency.is_present
                    or valency_allows_direct_object(
                        str(predicate.lexeme.valency.value)
                    )
                )
            )
            if not predicates:
                return self._unsupported(
                    TranslationDirection.ASAXI_TO_ENGLISH,
                    text,
                    normalized,
                    "OBJECT_NOT_LICENSED_BY_PREDICATE",
                    (
                        f"The compiled valency for "
                        f"{predicate_token.surface!r} does not license a "
                        "direct object."
                    ),
                    token_index=predicate_token.index,
                )

        subject_options = self._asaxi_subject_options(subject_token)
        object_options = self._asaxi_object_options(object_tokens)
        if object_tokens and not object_options:
            return self._unsupported(
                TranslationDirection.ASAXI_TO_ENGLISH,
                text,
                normalized,
                "OBJECT_NOT_RECOGNIZED",
                (
                    f"No noun or pronoun analysis was found for "
                    f"{object_tokens[-1].surface!r}."
                ),
                token_index=object_tokens[-1].index,
            )

        role_by_index = {
            marker.index: "subject-marker",
            subject_token.index: "subject",
            predicate_token.index: "predicate",
            **{index: "question" for index in question_indices},
        }
        if object_tokens:
            role_by_index[object_tokens[-1].index] = "object"
            if len(object_tokens) == 2:
                role_by_index[object_tokens[0].index] = "determiner"
        for token in tokens:
            if token.kind == "punctuation":
                role_by_index[token.index] = "punctuation"

        alternatives: list[TranslationAlternative] = []
        combinations = itertools.product(
            subject_options,
            object_options or (None,),
            predicates,
        )
        for subject, object_option, predicate in combinations:
            glosses = split_english_gloss(predicate.lexeme)
            if not glosses:
                continue
            lexical_ambiguity = self._gloss_ambiguity(
                predicate.lexeme,
                glosses,
            )
            for gloss in glosses:
                clause = CanonicalClause(
                    predicate=predicate.lexeme.lemma,
                    subject=subject.nominal,
                    object=(
                        object_option.nominal
                        if object_option is not None
                        else None
                    ),
                    tense=predicate.tense,
                    polarity=predicate.polarity,
                    register=register,
                    interrogative=interrogative,
                    verbal_derivation=(
                        self.expanded_clause_parser
                        .lexical_verbal_derivation(predicate.lexeme)
                    ),
                )
                assumptions = list(subject.assumptions)
                ambiguities = list(subject.ambiguities)
                trace = [
                    "translation.asaxi-canonical-clause",
                    f"register.{register.value}",
                    *subject.rule_trace,
                    *predicate.rule_trace,
                ]
                if object_option is not None:
                    assumptions.extend(object_option.assumptions)
                    ambiguities.extend(object_option.ambiguities)
                    trace.extend(object_option.rule_trace)
                if lexical_ambiguity is not None:
                    ambiguities.append(
                        replace(lexical_ambiguity, selected=gloss)
                    )
                if (
                    register is Register.SUBJECTIVE
                    and predicate.tense is not Tense.NONPAST
                ):
                    assumptions.append(
                        TranslationAssumption(
                            code="SUBJECTIVE_TENSE_NOT_EXPANDED",
                            message=(
                                "The subject is subjective, but this slice "
                                "retains the parsed tense form without "
                                "inferring a subjective tense replacement."
                            ),
                        )
                    )
                output = self._render_english(
                    subject.english_text,
                    gloss,
                    (
                        object_option.english_text
                        if object_option is not None
                        else None
                    ),
                    tense=predicate.tense,
                    polarity=predicate.polarity,
                    interrogative=interrogative,
                )
                rendered_tokens = self._render_tokens(
                    tokens,
                    role_by_index,
                    source_direction=TranslationDirection.ASAXI_TO_ENGLISH,
                    predicate=predicate,
                )
                alternatives.append(
                    TranslationAlternative(
                        identifier="",
                        output_text=output,
                        canonical_clause=clause,
                        tokens=rendered_tokens,
                        assumptions=tuple(assumptions),
                        ambiguities=tuple(ambiguities),
                        rule_trace=tuple(trace),
                        subject_text=subject.english_text,
                    )
                )
        return self._result(
            TranslationDirection.ASAXI_TO_ENGLISH,
            text,
            normalized,
            alternatives,
        )

    def english_to_asaxi(self, text: str) -> TranslationResult:
        tokens = _tokenize_english(text)
        normalized = _normalize_tokens(tokens)
        if not tokens:
            return self._unsupported(
                TranslationDirection.ENGLISH_TO_ASAXI,
                text,
                normalized,
                "EMPTY_INPUT",
                "No English text was supplied.",
            )
        epistemic = self._translate_english_epistemic_wrapper(
            text=text,
            normalized=normalized,
            tokens=tokens,
        )
        if epistemic is not None:
            return epistemic
        linked = self._translate_english_linked_clauses(
            text=text,
            normalized=normalized,
            tokens=tokens,
        )
        if linked is not None:
            return linked
        interior_punctuation = [
            token
            for token in tokens[:-1]
            if token.kind == "punctuation"
        ]
        words = [token for token in tokens if token.kind != "punctuation"]
        punctuation_question = any(
            token.surface == "?" for token in tokens
        )
        punctuation_directive = any(
            token.surface == "!" for token in tokens
        )
        if not words or (len(words) < 2 and not punctuation_directive):
            return self._unsupported(
                TranslationDirection.ENGLISH_TO_ASAXI,
                text,
                normalized,
                "CONTROLLED_CLAUSE_INCOMPLETE",
                "Expected a subject and a predicate.",
            )
        comma_indexes = {
            token.index for token in tokens if token.surface == ","
        }
        frontend_words = tuple(
            EnglishInputToken(
                index=word.index,
                surface=word.surface,
                normalized=word.normalized,
                preceded_by_comma=(word.index - 1 in comma_indexes),
                followed_by_comma=(word.index + 1 in comma_indexes),
            )
            for word in words
        )
        structural_frames = self.english_frontend.parse(
            frontend_words,
            directive_hint=punctuation_directive,
        )
        if (
            structural_frames
            and all(
                isinstance(frame, EnglishDirectiveFrame)
                and frame.force is EnglishDirectiveForce.COMMAND
                for frame in structural_frames
            )
            and not any(
                self._english_predicate_options(
                    frame.predicate,
                    forced_tense=Tense.NONPAST,
                    polarity=Polarity.POSITIVE,
                )
                for frame in structural_frames
            )
        ):
            # Exclamation is only a command hint.  A finite declarative such
            # as "John reads!" must win when no proposed imperative predicate
            # exists in the compiled target lexicon.
            declarative_frames = self.english_frontend.parse(frontend_words)
            if declarative_frames:
                structural_frames = declarative_frames
        if (
            structural_frames
            and isinstance(structural_frames[0], EnglishActionFrame)
            and all(
                "english.frontend.declarative-action" in frame.rule_trace
                for frame in structural_frames
            )
        ):
            # The source-only frontend enumerates every legal split.  Keep
            # only splits with a compiled (or explicitly widened) predicate;
            # otherwise preserve the established controlled-English path.
            structural_frames = tuple(
                frame
                for frame in structural_frames
                if self._english_predicate_options(
                    frame.predicate,
                    forced_tense=frame.tense,
                    polarity=frame.polarity,
                )
            )
        if interior_punctuation:
            pragmatic_word_indexes = {
                index
                for frame in structural_frames
                for index, role in frame.role_by_index
                if role in {"preclausal-marker", "discourse-marker"}
            }
            time_word_indexes = {
                index
                for frame in structural_frames
                if isinstance(frame, EnglishActionFrame)
                and frame.time is not None
                for index in frame.time.source_indexes
            }
            unconsumed = [
                token
                for token in interior_punctuation
                if token.surface != ","
                or not (
                    token.index - 1 in pragmatic_word_indexes
                    or token.index + 1 in pragmatic_word_indexes
                    or token.index - 1 in time_word_indexes
                    or token.index + 1 in time_word_indexes
                )
            ]
            if unconsumed:
                return self._unsupported(
                    TranslationDirection.ENGLISH_TO_ASAXI,
                    text,
                    normalized,
                    "MULTICLAUSE_NOT_SUPPORTED",
                    "Controlled English currently accepts one simple clause.",
                    token_index=unconsumed[0].index,
                )
        if structural_frames:
            if isinstance(structural_frames[0], EnglishDirectiveFrame):
                return self._translate_english_directive_frames(
                    text=text,
                    normalized=normalized,
                    tokens=tokens,
                    frames=tuple(
                        frame
                        for frame in structural_frames
                        if isinstance(frame, EnglishDirectiveFrame)
                    ),
                    punctuation_question=punctuation_question,
                )
            if isinstance(structural_frames[0], EnglishActionFrame):
                return self._translate_english_action_frames(
                    text=text,
                    normalized=normalized,
                    tokens=tokens,
                    frames=tuple(
                        frame
                        for frame in structural_frames
                        if isinstance(frame, EnglishActionFrame)
                    ),
                    punctuation_question=punctuation_question,
                )
            if isinstance(
                structural_frames[0],
                EnglishSpatialClauseFrame,
            ):
                return self._translate_english_spatial_frames(
                    text=text,
                    normalized=normalized,
                    tokens=tokens,
                    frames=tuple(
                        frame
                        for frame in structural_frames
                        if isinstance(
                            frame,
                            EnglishSpatialClauseFrame,
                        )
                    ),
                    punctuation_question=punctuation_question,
                )
            return self._translate_english_structural_frames(
                text=text,
                normalized=normalized,
                tokens=tokens,
                frames=structural_frames,
                punctuation_question=punctuation_question,
            )
        parsed = self._parse_controlled_english(words)
        if isinstance(parsed, TranslationDiagnostic):
            return self._unsupported_from_diagnostic(
                direction=TranslationDirection.ENGLISH_TO_ASAXI,
                text=text,
                normalized=normalized,
                diagnostic=parsed,
            )
        (
            subject_token,
            predicate_options,
            object_tokens,
            interrogative,
            role_by_index,
        ) = parsed
        interrogative = interrogative or punctuation_question
        for token in tokens:
            if token.kind == "punctuation":
                role_by_index[token.index] = "punctuation"

        subject_options = self._english_subject_options(subject_token)
        if not subject_options:
            return self._unsupported(
                TranslationDirection.ENGLISH_TO_ASAXI,
                text,
                normalized,
                "SUBJECT_NOT_RECOGNIZED",
                (
                    "The subject must be a documented pronoun or a "
                    "capitalized one-word proper name."
                ),
                token_index=subject_token.index,
            )
        object_options = self._english_object_options(object_tokens)
        if object_tokens and not object_options:
            return self._unsupported(
                TranslationDirection.ENGLISH_TO_ASAXI,
                text,
                normalized,
                "OBJECT_NOT_RECOGNIZED",
                (
                    "The object must be a documented one-word noun or "
                    "pronoun, optionally preceded by an article."
                ),
                token_index=object_tokens[-1].index,
            )
        if object_tokens:
            predicate_options = tuple(
                predicate
                for predicate in predicate_options
                if (
                    not predicate.lexeme.valency.is_present
                    or valency_allows_direct_object(
                        str(predicate.lexeme.valency.value)
                    )
                )
            )
            if not predicate_options:
                return self._unsupported(
                    TranslationDirection.ENGLISH_TO_ASAXI,
                    text,
                    normalized,
                    "OBJECT_NOT_LICENSED_BY_PREDICATE",
                    (
                        f"The compiled valency for "
                        f"{words[-len(object_tokens) - 1].surface!r} does "
                        "not license a direct object."
                    ),
                    token_index=words[-len(object_tokens) - 1].index,
                )

        alternatives: list[TranslationAlternative] = []
        for subject, object_option, predicate in itertools.product(
            subject_options,
            object_options or (None,),
            predicate_options,
        ):
            clause = CanonicalClause(
                predicate=predicate.surface,
                subject=subject.nominal,
                object=(
                    object_option.nominal
                    if object_option is not None
                    else None
                ),
                tense=predicate.tense,
                polarity=predicate.polarity,
                register=Register.OBJECTIVE,
                interrogative=interrogative,
                verbal_derivation=predicate.verbal_derivation,
            )
            realization = self.generator.realize(clause)
            assumptions = [
                TranslationAssumption(
                    code="OBJECTIVE_REGISTER_DEFAULT",
                    message=(
                        "Controlled English does not encode Asaxi's "
                        "objective/subjective contrast; objective register "
                        "was selected."
                    ),
                ),
                *subject.assumptions,
                *predicate.assumptions,
            ]
            ambiguities = [
                *subject.ambiguities,
                *predicate.ambiguities,
            ]
            trace = [
                "translation.controlled-english-clause",
                "syntax.explicit-objective-subject",
                *subject.rule_trace,
                *predicate.rule_trace,
                *realization.rule_trace,
            ]
            if object_option is not None:
                assumptions.extend(object_option.assumptions)
                ambiguities.extend(object_option.ambiguities)
                trace.extend(object_option.rule_trace)
            rendered_tokens = self._render_tokens(
                tokens,
                role_by_index,
                source_direction=TranslationDirection.ENGLISH_TO_ASAXI,
            )
            alternatives.append(
                TranslationAlternative(
                    identifier="",
                    output_text=realization.text,
                    canonical_clause=clause,
                    tokens=rendered_tokens,
                    assumptions=tuple(assumptions),
                    ambiguities=tuple(ambiguities),
                    rule_trace=tuple(trace),
                )
            )
        return self._result(
            TranslationDirection.ENGLISH_TO_ASAXI,
            text,
            normalized,
            alternatives,
        )

    def _translate_english_epistemic_wrapper(
        self,
        *,
        text: str,
        normalized: str,
        tokens: tuple[_RawToken, ...],
    ) -> TranslationResult | None:
        """Give an epistemic wrapper scope over its complete proposition.

        This runs before linked-clause splitting, so ``I know that A and B``
        qualifies the coordinated proposition rather than only clause A.
        """

        words = tuple(
            EnglishInputToken(
                index=token.index,
                surface=token.surface,
                normalized=token.normalized,
            )
            for token in tokens
            if token.kind != "punctuation"
        )
        extracted = self.english_frontend.extract_epistemic(words)
        if extracted is None:
            return None
        _proposition_words, force, wrapper_indexes = extracted
        wrapper_index_set = set(wrapper_indexes)
        wrapper_tokens = [
            token for token in tokens if token.index in wrapper_index_set
        ]
        if not wrapper_tokens:
            return None
        proposition_start = max(token.end for token in wrapper_tokens)
        proposition_text = text[proposition_start:].strip()
        if not proposition_text:
            return self._unsupported(
                TranslationDirection.ENGLISH_TO_ASAXI,
                text,
                normalized,
                "EPISTEMIC_PROPOSITION_INCOMPLETE",
                "An epistemic wrapper requires a complete proposition after 'that'.",
            )
        proposition = self.english_to_asaxi(proposition_text)
        if not proposition.alternatives:
            return self._unsupported(
                TranslationDirection.ENGLISH_TO_ASAXI,
                text,
                normalized,
                "EPISTEMIC_PROPOSITION_NOT_SUPPORTED",
                (
                    "The certainty wrapper was recognized, but its proposition "
                    "could not be translated by the documented grammar."
                ),
            )

        roles = {
            token.index: (
                "epistemic-marker"
                if token.index in wrapper_index_set
                else "punctuation"
                if token.kind == "punctuation"
                else "epistemic-proposition"
            )
            for token in tokens
        }
        rendered_tokens = self._render_tokens(
            tokens,
            roles,
            source_direction=TranslationDirection.ENGLISH_TO_ASAXI,
        )
        alternatives: list[TranslationAlternative] = []
        binder = TteBinder(
            function=TteFunction.EPISTEMIC,
            qualification=EpistemicQualification(
                ENGLISH_EPISTEMIC_TO_ASAXI[force]
            ),
            cognizer=Nominal("wo"),
            cognizer_omitted=False,
        )
        for item in proposition.alternatives:
            if item.canonical_clause.interrogative:
                continue
            clause = replace(
                item.canonical_clause,
                tte_binder=binder,
            )
            realization = self.generator.realize(clause)
            alternatives.append(
                TranslationAlternative(
                    identifier="",
                    output_text=realization.text,
                    canonical_clause=clause,
                    tokens=rendered_tokens,
                    assumptions=item.assumptions,
                    ambiguities=item.ambiguities,
                    rule_trace=(
                        "translation.typed-english-epistemic-wrapper",
                        *item.rule_trace,
                        *realization.rule_trace,
                    ),
                )
            )
        if not alternatives:
            return self._unsupported(
                TranslationDirection.ENGLISH_TO_ASAXI,
                text,
                normalized,
                "EPISTEMIC_PROPOSITION_MUST_BE_STATEMENT",
                "The documented tte construction qualifies statements.",
            )
        return self._result(
            TranslationDirection.ENGLISH_TO_ASAXI,
            text,
            normalized,
            alternatives,
        )

    def _translate_english_linked_clauses(
        self,
        *,
        text: str,
        normalized: str,
        tokens: tuple[_RawToken, ...],
    ) -> TranslationResult | None:
        """Transfer complete linked clauses into Asaxi's tail-link order.

        English subordinate linkers may precede or follow their context clause;
        Asaxi always places the linker after that clause. Coordinators remain in
        source order. Every candidate side must independently produce a typed
        canonical clause, which prevents nominal ``John and Tom`` from being
        reinterpreted as clause coordination.
        """

        subordinate = self._split_english_subordinate_link(
            text=text,
            tokens=tokens,
        )
        if subordinate is not None:
            (
                connector,
                context_text,
                matrix_text,
                connector_indexes,
                context_span,
                matrix_span,
            ) = subordinate
            result = self._translate_english_clause_pair(
                text=text,
                normalized=normalized,
                tokens=tokens,
                first_text=context_text,
                second_text=matrix_text,
                connector=connector,
                connector_indexes=connector_indexes,
                first_source_span=context_span,
                second_source_span=matrix_span,
                source_rule="english.subordinate-linker",
            )
            if result is not None:
                return result

        for connector_position, connector_token in enumerate(tokens):
            connector = ENGLISH_COORDINATING_CONNECTORS.get(
                connector_token.normalized
            )
            if connector is None:
                continue
            if self._is_parallel_english_gerund_coordination(
                tokens,
                connector_position,
            ):
                continue
            left_text = text[:connector_token.start].rstrip(" \t\r\n,")
            right_text = text[connector_token.end:].lstrip(" \t\r\n,")
            if not left_text or not right_text:
                continue
            left_words = [
                token
                for token in _tokenize_english(left_text)
                if token.kind != "punctuation"
            ]
            right_words = [
                token
                for token in _tokenize_english(right_text)
                if token.kind != "punctuation"
            ]
            if len(left_words) < 2 or len(right_words) < 2:
                continue
            result = self._translate_english_clause_pair(
                text=text,
                normalized=normalized,
                tokens=tokens,
                first_text=left_text,
                second_text=right_text,
                connector=connector,
                connector_indexes=(connector_token.index,),
                first_source_span=(0, connector_token.start),
                second_source_span=(connector_token.end, len(text)),
                source_rule="english.coordinating-linker",
            )
            if result is not None:
                return result
        return None

    def _is_parallel_english_gerund_coordination(
        self,
        tokens: tuple[_RawToken, ...],
        connector_position: int,
    ) -> bool:
        """Keep adjacent lexical gerunds inside one nominal coordination.

        A surface coordinator alone is not evidence for two finite clauses.
        In ``reading and taking notes``, both words adjacent to ``and`` are
        independently licensed gerunds, so the nominal parser must receive the
        complete sequence.  Full clauses such as ``John reads and Tom writes``
        do not satisfy this structural test.
        """

        left = next(
            (
                token
                for token in reversed(tokens[:connector_position])
                if token.kind != "punctuation"
            ),
            None,
        )
        right = next(
            (
                token
                for token in tokens[connector_position + 1 :]
                if token.kind != "punctuation"
            ),
            None,
        )
        if left is None or right is None:
            return False
        return bool(
            self.lexicon.english_gerund_matches(left.normalized)
            and self.lexicon.english_gerund_matches(right.normalized)
        )

    def _has_transferable_english_clause(self, text: str) -> bool:
        """Require a typed source clause independently of recursive transfer."""

        tokens = _tokenize_english(text)
        words = tuple(
            token for token in tokens if token.kind != "punctuation"
        )
        if len(words) < 2:
            return False
        comma_indexes = {
            token.index for token in tokens if token.surface == ","
        }
        frontend_words = tuple(
            EnglishInputToken(
                index=word.index,
                surface=word.surface,
                normalized=word.normalized,
                preceded_by_comma=(word.index - 1 in comma_indexes),
                followed_by_comma=(word.index + 1 in comma_indexes),
            )
            for word in words
        )
        for frame in self.english_frontend.parse(frontend_words):
            if isinstance(frame, (EnglishClauseFrame, EnglishSpatialClauseFrame)):
                return True
            if isinstance(frame, EnglishActionFrame) and (
                self._english_predicate_options(
                    frame.predicate,
                    forced_tense=frame.tense,
                    polarity=frame.polarity,
                )
            ):
                return True
        return False

    @staticmethod
    def _split_english_subordinate_link(
        *,
        text: str,
        tokens: tuple[_RawToken, ...],
    ) -> tuple[
        ClauseConnector,
        str,
        str,
        tuple[int, ...],
        tuple[int, int],
        tuple[int, int],
    ] | None:
        """Return context then matrix clause, regardless of English order."""

        for pattern, connector in ENGLISH_SUBORDINATING_CONNECTORS:
            width = len(pattern)
            for start in range(0, len(tokens) - width + 1):
                matched = tokens[start:start + width]
                if tuple(token.normalized for token in matched) != pattern:
                    continue
                if any(token.kind != "word" for token in matched):
                    continue
                first_token = matched[0]
                last_token = matched[-1]
                connector_indexes = tuple(token.index for token in matched)
                if start == 0:
                    comma = next(
                        (
                            token
                            for token in tokens[start + width:]
                            if token.surface == ","
                        ),
                        None,
                    )
                    if comma is None:
                        continue
                    context_text = text[last_token.end:comma.start].strip()
                    matrix_text = text[comma.end:].strip()
                    context_span = (last_token.end, comma.start)
                    matrix_span = (comma.end, len(text))
                else:
                    context_text = text[last_token.end:].lstrip(" \t\r\n,")
                    matrix_text = text[:first_token.start].rstrip(" \t\r\n,")
                    context_start = len(text) - len(context_text)
                    context_span = (context_start, len(text))
                    matrix_span = (0, first_token.start)
                if context_text and matrix_text:
                    return (
                        connector,
                        context_text,
                        matrix_text,
                        connector_indexes,
                        context_span,
                        matrix_span,
                    )
        return None

    def _translate_english_clause_pair(
        self,
        *,
        text: str,
        normalized: str,
        tokens: tuple[_RawToken, ...],
        first_text: str,
        second_text: str,
        connector: ClauseConnector,
        connector_indexes: tuple[int, ...],
        first_source_span: tuple[int, int],
        second_source_span: tuple[int, int],
        source_rule: str,
    ) -> TranslationResult | None:
        if not (
            self._has_transferable_english_clause(first_text)
            and self._has_transferable_english_clause(second_text)
        ):
            return None
        first_result = self.english_to_asaxi(first_text)
        second_result = self.english_to_asaxi(second_text)
        if not first_result.alternatives or not second_result.alternatives:
            return None

        roles: dict[int, str] = {}
        connector_index_set = set(connector_indexes)
        for token in tokens:
            if token.index in connector_index_set:
                roles[token.index] = "clause-connector"
            elif token.kind == "punctuation":
                roles[token.index] = "punctuation"
            elif first_source_span[0] <= token.start < first_source_span[1]:
                roles[token.index] = "linked-context-clause"
            elif second_source_span[0] <= token.start < second_source_span[1]:
                roles[token.index] = "linked-matrix-clause"
            else:
                roles[token.index] = "clause-boundary"
        rendered_tokens = self._render_tokens(
            tokens,
            roles,
            source_direction=TranslationDirection.ENGLISH_TO_ASAXI,
        )
        alternatives: list[TranslationAlternative] = []
        for first, second in itertools.islice(
            itertools.product(
                first_result.alternatives,
                second_result.alternatives,
            ),
            MAX_ENGLISH_NP_OPTIONS,
        ):
            clause = replace(
                first.canonical_clause,
                connector=connector,
                coordinated_clause=second.canonical_clause,
            )
            realization = self.generator.realize(clause)
            alternatives.append(
                TranslationAlternative(
                    identifier="",
                    output_text=realization.text,
                    canonical_clause=clause,
                    tokens=rendered_tokens,
                    assumptions=(
                        *first.assumptions,
                        *second.assumptions,
                    ),
                    ambiguities=(
                        *first.ambiguities,
                        *second.ambiguities,
                    ),
                    rule_trace=(
                        "translation.typed-english-clause-linking",
                        source_rule,
                        *first.rule_trace,
                        f"english.connector.{connector.value}",
                        *second.rule_trace,
                        *realization.rule_trace,
                    ),
                )
            )
        return self._result(
            TranslationDirection.ENGLISH_TO_ASAXI,
            text,
            normalized,
            alternatives,
        )

    @staticmethod
    def _english_clause_envelope_fields(
        frame: EnglishStructuralFrame,
    ) -> dict[
        str,
        PreclausalMarker
        | DiscourseMarker
        | TteBinder
        | None,
    ]:
        return {
            "preclausal_marker": (
                PreclausalMarker(
                    ENGLISH_PRECLAUSAL_TO_ASAXI[frame.preclausal_force]
                )
                if frame.preclausal_force is not None
                else None
            ),
            "discourse_marker": (
                DiscourseMarker(
                    ENGLISH_DISCOURSE_TO_ASAXI[frame.discourse_force]
                )
                if frame.discourse_force is not None
                else None
            ),
            "tte_binder": (
                TteBinder(
                    function=TteFunction.EPISTEMIC,
                    qualification=EpistemicQualification(
                        ENGLISH_EPISTEMIC_TO_ASAXI[
                            frame.epistemic_force
                        ]
                    ),
                    cognizer=Nominal("wo"),
                    cognizer_omitted=False,
                )
                if frame.epistemic_force is not None
                else None
            ),
        }

    @staticmethod
    def _english_clause_is_interrogative(
        frame: EnglishStructuralFrame,
        punctuation_question: bool,
    ) -> bool:
        """Keep an outer English tag distinct from proposition inquiry."""

        if frame.interrogative:
            return True
        if (
            punctuation_question
            and frame.discourse_force
            in {
                EnglishDiscourseForce.AGREEMENT,
                EnglishDiscourseForce.SKEPTICISM,
            }
        ):
            return False
        return punctuation_question

    def _translate_english_directive_frames(
        self,
        *,
        text: str,
        normalized: str,
        tokens: tuple[_RawToken, ...],
        frames: tuple[EnglishDirectiveFrame, ...],
        punctuation_question: bool,
    ) -> TranslationResult:
        """Transfer finite English command forms through typed semantics."""

        if punctuation_question and not all(
            frame.force is EnglishDirectiveForce.POLITE_HORTATIVE
            for frame in frames
        ):
            return self._unsupported(
                TranslationDirection.ENGLISH_TO_ASAXI,
                text,
                normalized,
                "INTERROGATIVE_DIRECTIVE_NOT_SUPPORTED",
                (
                    "The bounded directive frontend accepts command force, "
                    "not question-marked request syntax."
                ),
            )

        kind_by_force = {
            EnglishDirectiveForce.COMMAND: DirectiveKind.COMMAND,
            EnglishDirectiveForce.PROHIBITION: DirectiveKind.PROHIBITION,
            EnglishDirectiveForce.ABSOLUTE_PROHIBITION: (
                DirectiveKind.ABSOLUTE_PROHIBITION
            ),
            EnglishDirectiveForce.REQUEST: DirectiveKind.REQUEST,
            EnglishDirectiveForce.INSTRUCTION: DirectiveKind.INSTRUCTION,
            EnglishDirectiveForce.POLITE_PROHIBITION: (
                DirectiveKind.POLITE_PROHIBITION
            ),
            EnglishDirectiveForce.CESSATION: DirectiveKind.CESSATION,
            EnglishDirectiveForce.CONTINUATION: DirectiveKind.CONTINUATION,
            EnglishDirectiveForce.SWITCH: DirectiveKind.SWITCH,
            EnglishDirectiveForce.HORTATIVE: DirectiveKind.HORTATIVE,
            EnglishDirectiveForce.POLITE_HORTATIVE: (
                DirectiveKind.POLITE_HORTATIVE
            ),
        }
        addressee = Nominal(
            surface="na",
            person=PronounPerson.SECOND,
            animacy=PronounAnimacy.ANIMATE,
            pronoun_kind=PronounKind.PERSONAL,
            pronoun_base="na",
        )
        inclusive = Nominal(
            surface="wa",
            person=PronounPerson.FIRST,
            animacy=PronounAnimacy.ANIMATE,
            pronoun_kind=PronounKind.PERSONAL,
            pronoun_base="wa",
        )
        alternatives: list[TranslationAlternative] = []
        unresolved_objects: list[EnglishNominalFrame] = []
        unresolved_predicates: list[EnglishDirectiveFrame] = []
        object_not_licensed: list[EnglishDirectiveFrame] = []

        for frame in frames:
            object_options = (
                self._english_frame_nominal_options(
                    frame.object,
                    tokens,
                    role="object",
                )
                if frame.object is not None
                else (None,)
            )
            predicate_options = self._english_predicate_options(
                frame.predicate,
                forced_tense=Tense.NONPAST,
                polarity=Polarity.POSITIVE,
            )
            if frame.object is not None and not object_options:
                unresolved_objects.append(frame.object)
                continue
            if not predicate_options:
                unresolved_predicates.append(frame)
                continue
            if frame.object is not None:
                predicate_options = tuple(
                    predicate
                    for predicate in predicate_options
                    if (
                        not predicate.lexeme.valency.is_present
                        or valency_allows_direct_object(
                            str(predicate.lexeme.valency.value)
                        )
                    )
                )
                if not predicate_options:
                    object_not_licensed.append(frame)
                    continue

            kind = kind_by_force[frame.force]
            polarity = (
                Polarity.NEGATIVE
                if kind
                in {
                    DirectiveKind.PROHIBITION,
                    DirectiveKind.ABSOLUTE_PROHIBITION,
                    DirectiveKind.POLITE_PROHIBITION,
                }
                else Polarity.POSITIVE
            )
            for object_option, predicate in itertools.product(
                object_options,
                predicate_options,
            ):
                variants = documented_directive_variants(
                    predicate.surface,
                    kind,
                    allow_cessation_fusion=(
                        self.generator.has_derived_attestation(
                            predicate.verbal_derivation,
                            predicate.surface,
                        )
                    ),
                )
                for placement, markers, fused in variants:
                    directive = Directive(
                        kind=kind,
                        placement=placement,
                        markers=markers,
                        addressee=addressee,
                        implicit_addressee=True,
                        fused=fused,
                        joint_participant=(
                            inclusive
                            if kind
                            in {
                                DirectiveKind.HORTATIVE,
                                DirectiveKind.POLITE_HORTATIVE,
                            }
                            else None
                        ),
                    )
                    clause = CanonicalClause(
                        predicate=predicate.surface,
                        subject=addressee,
                        object=(
                            object_option.nominal
                            if object_option is not None
                            else None
                        ),
                        polarity=polarity,
                        predicate_kind=PredicateKind.ACTION,
                        directive=directive,
                        omitted_subject=True,
                        verbal_derivation=predicate.verbal_derivation,
                        **self._english_clause_envelope_fields(frame),
                    )
                    realization = self.generator.realize(clause)
                    roles = dict(frame.role_by_index)
                    if object_option is not None:
                        roles.update(object_option.source_roles)
                    for token in tokens:
                        if token.kind == "punctuation":
                            roles[token.index] = "punctuation"
                    assumptions = [
                        *predicate.assumptions,
                        *(
                            object_option.assumptions
                            if object_option is not None
                            else ()
                        ),
                    ]
                    ambiguities = [
                        *predicate.ambiguities,
                        *(
                            object_option.ambiguities
                            if object_option is not None
                            else ()
                        ),
                    ]
                    if len(variants) > 1:
                        ambiguities.append(
                            TranslationAmbiguity(
                                code="DIRECTIVE_FORM_UNDERSPECIFIED",
                                message=(
                                    "English does not distinguish the "
                                    "documented Asaxi directive placement or "
                                    "ů+hè fusion variants."
                                ),
                                choices=tuple(
                                    (
                                        f"{candidate_placement.value}:"
                                        f"{'-'.join(candidate_markers)}:"
                                        f"fused={candidate_fused}"
                                    )
                                    for (
                                        candidate_placement,
                                        candidate_markers,
                                        candidate_fused,
                                    ) in variants
                                ),
                                selected=(
                                    f"{placement.value}:{'-'.join(markers)}:"
                                    f"fused={fused}"
                                ),
                            )
                        )
                    trace = [
                        "translation.typed-english-directive-transfer",
                        *frame.rule_trace,
                        "clause.implicit-second-person-addressee",
                        *predicate.rule_trace,
                        *(
                            object_option.rule_trace
                            if object_option is not None
                            else ()
                        ),
                        *realization.rule_trace,
                    ]
                    alternatives.append(
                        TranslationAlternative(
                            identifier="",
                            output_text=realization.text,
                            canonical_clause=clause,
                            tokens=self._render_tokens(
                                tokens,
                                roles,
                                source_direction=(
                                    TranslationDirection.ENGLISH_TO_ASAXI
                                ),
                            ),
                            assumptions=tuple(assumptions),
                            ambiguities=tuple(ambiguities),
                            rule_trace=tuple(trace),
                        )
                    )

        if alternatives:
            return self._result(
                TranslationDirection.ENGLISH_TO_ASAXI,
                text,
                normalized,
                alternatives,
            )
        if unresolved_objects:
            nominal = unresolved_objects[0]
            return self._unsupported_from_diagnostic(
                direction=TranslationDirection.ENGLISH_TO_ASAXI,
                text=text,
                normalized=normalized,
                diagnostic=TranslationDiagnostic(
                    code="ENGLISH_DIRECTIVE_OBJECT_NOT_RECOGNIZED",
                    severity=Severity.ERROR,
                    message=(
                        f"No documented Asaxi object matches "
                        f"{nominal.head!r}, directly or through an available "
                        "same-part-of-speech synonym."
                    ),
                    token_index=nominal.head_indexes[0],
                    details={
                        "head": nominal.head,
                        "thesaurus_available": self.thesaurus.available,
                        "thesaurus_provider": self.thesaurus.name,
                    },
                ),
            )
        if object_not_licensed:
            frame = object_not_licensed[0]
            return self._unsupported(
                TranslationDirection.ENGLISH_TO_ASAXI,
                text,
                normalized,
                "OBJECT_NOT_LICENSED_BY_PREDICATE",
                (
                    f"The compiled valency for {frame.predicate!r} does not "
                    "license a direct object."
                ),
                token_index=frame.predicate_indexes[0],
            )
        frame = unresolved_predicates[0]
        return self._unsupported(
            TranslationDirection.ENGLISH_TO_ASAXI,
            text,
            normalized,
            "ENGLISH_DIRECTIVE_PREDICATE_NOT_RECOGNIZED",
            (
                f"No documented Asaxi verb matches {frame.predicate!r}, "
                "directly or through an available same-part-of-speech "
                "synonym."
            ),
            token_index=frame.predicate_indexes[0],
        )

    def _translate_english_action_frames(
        self,
        *,
        text: str,
        normalized: str,
        tokens: tuple[_RawToken, ...],
        frames: tuple[EnglishActionFrame, ...],
        punctuation_question: bool,
    ) -> TranslationResult:
        """Transfer typed English action questions without word substitution."""

        alternatives: list[TranslationAlternative] = []
        unresolved_nominals: list[tuple[EnglishNominalFrame, str]] = []
        unresolved_predicates: list[EnglishActionFrame] = []
        object_not_licensed: list[EnglishActionFrame] = []
        invalid_causatives: list[tuple[EnglishActionFrame, str, str]] = []
        ranked_frames = self._rank_declarative_action_frames(frames, tokens)
        for frame in ranked_frames:
            if (frame.causer is None) != (frame.causative_voice is None):
                invalid_causatives.append(
                    (
                        frame,
                        "INCOMPLETE_CAUSATIVE_FRAME",
                        "The typed causative analysis is missing either its "
                        "causer or its causative force.",
                    )
                )
                continue
            if frame.causative_voice is not None:
                if frame.modality.value != "none":
                    invalid_causatives.append(
                        (
                            frame,
                            "CAUSATIVE_MODALITY_STACK_UNDOCUMENTED",
                            "The documented Asaxi causative and action-modality "
                            "prefixes occupy the same operator slot, so this "
                            "combination cannot be generated canonically.",
                        )
                    )
                    continue
                if (
                    frame.polarity is Polarity.NEGATIVE
                    and frame.causative_voice.value == "coercive"
                ):
                    invalid_causatives.append(
                        (
                            frame,
                            "NEGATIVE_COERCIVE_CAUSATIVE_UNDOCUMENTED",
                            "The grammar documents coercion and prohibition as "
                            "different causative forces; it does not license a "
                            "plain negated coercive form.",
                        )
                    )
                    continue
                if (
                    frame.polarity is Polarity.NEGATIVE
                    and frame.causative_voice.value == "prohibitive"
                ):
                    invalid_causatives.append(
                        (
                            frame,
                            "DOUBLE_NEGATIVE_PROHIBITIVE_CAUSATIVE",
                            "The prohibitive causative already encodes negative "
                            "force and cannot take a second clause negation.",
                        )
                    )
                    continue
            subject_options = self._english_frame_nominal_options(
                frame.subject,
                tokens,
                role="subject",
            )
            causer_options = (
                self._english_frame_nominal_options(
                    frame.causer,
                    tokens,
                    role="causer",
                )
                if frame.causer is not None
                else (None,)
            )
            object_options = (
                self._english_frame_nominal_options(
                    frame.object,
                    tokens,
                    role="object",
                )
                if frame.object is not None
                else (None,)
            )
            adjunct_options = (
                self._english_frame_nominal_options(
                    frame.adjunct,
                    tokens,
                    role="location",
                )
                if frame.adjunct is not None
                else (None,)
            )
            time_options = (
                self._english_frame_nominal_options(
                    frame.time,
                    tokens,
                    role="time",
                )
                if frame.time is not None
                else (None,)
            )
            predicate_options = self._english_predicate_options(
                frame.predicate,
                forced_tense=frame.tense,
                polarity=frame.polarity,
            )
            if not subject_options:
                unresolved_nominals.append((frame.subject, "subject"))
                continue
            if frame.causer is not None and not causer_options:
                unresolved_nominals.append((frame.causer, "causer"))
                continue
            if frame.object is not None and not object_options:
                unresolved_nominals.append((frame.object, "object"))
                continue
            if frame.adjunct is not None and not adjunct_options:
                unresolved_nominals.append((frame.adjunct, "adjunct"))
                continue
            if frame.time is not None and not time_options:
                unresolved_nominals.append((frame.time, "time"))
                continue
            unresolved_oblique = next(
                (
                    oblique
                    for oblique in frame.obliques
                    if not self._english_frame_nominal_options(
                        oblique.nominal,
                        tokens,
                        role="oblique",
                    )
                ),
                None,
            )
            if unresolved_oblique is not None:
                unresolved_nominals.append(
                    (unresolved_oblique.nominal, "oblique")
                )
                continue
            if not predicate_options:
                unresolved_predicates.append(frame)
                continue

            if frame.object is not None:
                predicate_options = tuple(
                    predicate
                    for predicate in predicate_options
                    if (
                        not predicate.lexeme.valency.is_present
                        or valency_allows_direct_object(
                            str(predicate.lexeme.valency.value)
                        )
                    )
                )
                if not predicate_options:
                    object_not_licensed.append(frame)
                    continue

            for predicate in predicate_options:
                predicate_derivation = predicate.verbal_derivation
                weather_subject = self._english_weather_subject_option(
                    frame,
                    predicate,
                )
                effective_subject_options = (
                    (weather_subject,)
                    if weather_subject is not None
                    else subject_options
                )
                oblique_combinations = (
                    self._english_oblique_combinations(
                        frame.obliques,
                        predicate,
                        tokens,
                    )
                )
                for (
                    subject,
                    causer_option,
                    object_option,
                    adjunct_option,
                    time_option,
                    oblique_options,
                ) in itertools.product(
                    effective_subject_options,
                    causer_options,
                    object_options,
                    adjunct_options,
                    time_options,
                    oblique_combinations,
                ):
                    subject_nominal = subject.nominal
                    object_nominal = (
                        object_option.nominal
                        if object_option is not None
                        else None
                    )
                    directed_feeling_target = (
                        object_nominal is not None
                        and predicate_derivation is not None
                        and predicate_derivation.mode
                        is VerbalizationMode.INTERACTION
                    )
                    generated_obliques = tuple(
                        option.phrase for option in oblique_options
                    )
                    if directed_feeling_target:
                        generated_obliques = (
                            RelationalPhrase(
                                marker="ni",
                                relation=CaseRelation.ALLATIVE,
                                nominal=object_nominal,
                                function="goal",
                            ),
                            *generated_obliques,
                        )
                        object_nominal = None
                    location_nominal = (
                        adjunct_option.nominal
                        if adjunct_option is not None
                        else None
                    )
                    event_distribution = None
                    if frame.distribution_kind is not None:
                        distribution = DistributiveModifier(
                            marker=ASAXI_DISTRIBUTIVE_MARKERS[
                                frame.distribution_kind
                            ],
                            kind=frame.distribution_kind,
                            scope=(
                                frame.distribution_scope
                                or DistributionScope.EVENT
                            ),
                            target_role=frame.distribution_target_role,
                        )
                        if (
                            distribution.scope
                            is DistributionScope.EVENT
                        ):
                            event_distribution = distribution
                        elif distribution.target_role == "subject":
                            subject_nominal = replace(
                                subject_nominal,
                                distribution=distribution,
                            )
                        elif distribution.target_role == "object":
                            if object_nominal is None:
                                raise ValueError(
                                    "Object distribution has no object"
                                )
                            object_nominal = replace(
                                object_nominal,
                                distribution=distribution,
                            )
                        elif distribution.target_role == "location":
                            if location_nominal is None:
                                raise ValueError(
                                    "Location distribution has no location"
                                )
                            location_nominal = replace(
                                location_nominal,
                                distribution=distribution,
                            )
                        else:
                            raise ValueError(
                                "Unsupported English distributive target: "
                                f"{distribution.target_role!r}"
                            )
                    clause = CanonicalClause(
                        predicate=predicate.surface,
                        subject=subject_nominal,
                        object=object_nominal,
                        location=location_nominal,
                        time=(
                            time_option.nominal
                            if time_option is not None
                            else None
                        ),
                        tense=predicate.tense,
                        polarity=predicate.polarity,
                        register=Register.OBJECTIVE,
                        interrogative=self._english_clause_is_interrogative(
                            frame,
                            punctuation_question,
                        ),
                        wh_role=frame.wh_role,
                        modality=frame.modality,
                        temporal_aspect=frame.temporal_aspect,
                        frequency=(
                            EventFrequency(
                                marker=ASAXI_FREQUENCY_MARKERS[
                                    frame.frequency_kind
                                ],
                                kind=frame.frequency_kind,
                            )
                            if frame.frequency_kind is not None
                            else None
                        ),
                        distribution=event_distribution,
                        causative_agency=(
                            CausativeAgency(
                                voice=frame.causative_voice,
                                causer=causer_option.nominal,
                            )
                            if (
                                frame.causative_voice is not None
                                and causer_option is not None
                            )
                            else None
                        ),
                        obliques=generated_obliques,
                        subject_marked=weather_subject is None,
                        verbal_derivation=predicate_derivation,
                        **self._english_clause_envelope_fields(frame),
                    )
                    realization = self.generator.realize(clause)
                    roles = dict(frame.role_by_index)
                    roles.update(subject.source_roles)
                    if causer_option is not None:
                        roles.update(causer_option.source_roles)
                    if object_option is not None:
                        roles.update(object_option.source_roles)
                    if adjunct_option is not None:
                        roles.update(adjunct_option.source_roles)
                    if time_option is not None:
                        roles.update(time_option.source_roles)
                    for option in oblique_options:
                        roles.update(option.source_roles)
                    for token in tokens:
                        if token.kind == "punctuation":
                            roles[token.index] = "punctuation"
                    assumptions = [
                        TranslationAssumption(
                            code="OBJECTIVE_REGISTER_DEFAULT",
                            message=(
                                "English does not encode Asaxi's "
                                "objective/subjective contrast; objective "
                                "register was selected."
                            ),
                        ),
                        *subject.assumptions,
                        *predicate.assumptions,
                    ]
                    if causer_option is not None:
                        assumptions.extend(causer_option.assumptions)
                    if frame.aspect is EnglishAspect.PROGRESSIVE:
                        assumptions.append(
                            TranslationAssumption(
                                code=(
                                    "ENGLISH_PROGRESSIVE_ASAXI_SIMPLE_TENSE"
                                ),
                                message=(
                                    "English marks this event as progressive. "
                                    "Asaxi's basic tense form can cover an "
                                    "ongoing reading without a mandatory "
                                    "separate progressive marker, so the "
                                    "target keeps the documented simple "
                                    "tense form."
                                ),
                                details={
                                    "source_aspect": "progressive",
                                    "target_tense": predicate.tense.value,
                                    "overt_target_aspect": "none",
                                },
                            )
                        )
                    ambiguities = [
                        *subject.ambiguities,
                        *predicate.ambiguities,
                    ]
                    if causer_option is not None:
                        ambiguities.extend(causer_option.ambiguities)
                    trace = [
                        "translation.typed-english-action-transfer",
                        *frame.rule_trace,
                        *subject.rule_trace,
                        *predicate.rule_trace,
                    ]
                    if causer_option is not None:
                        trace.extend(causer_option.rule_trace)
                        trace.append(
                            "translation.english-causer-to-asaxi-ba-agency"
                        )
                    if weather_subject is not None:
                        trace.append(
                            "translation.english-weather-expletive-to-"
                            "event-subject"
                        )
                    if frame.aspect is EnglishAspect.PROGRESSIVE:
                        trace.append(
                            "english.aspect."
                            "progressive-to-asaxi-simple-tense"
                        )
                    if object_option is not None:
                        assumptions.extend(object_option.assumptions)
                        if directed_feeling_target:
                            assumptions.append(
                                TranslationAssumption(
                                    code=(
                                        "ENGLISH_DIRECTED_FEELING_TO_ALLATIVE"
                                    ),
                                    message=(
                                        "The English complement of a "
                                        "documented directed-feeling verb "
                                        "was marked with Asaxi allative ni."
                                    ),
                                )
                            )
                        ambiguities.extend(object_option.ambiguities)
                        trace.extend(object_option.rule_trace)
                        if directed_feeling_target:
                            trace.append(
                                "translation.english-directed-feeling-"
                                "object-to-allative"
                            )
                    if adjunct_option is not None:
                        assumptions.extend(adjunct_option.assumptions)
                        ambiguities.extend(adjunct_option.ambiguities)
                        trace.extend(adjunct_option.rule_trace)
                    if time_option is not None:
                        assumptions.extend(time_option.assumptions)
                        ambiguities.extend(time_option.ambiguities)
                        trace.extend(time_option.rule_trace)
                        trace.append("translation.english-time-to-asaxi-fronted")
                    for option in oblique_options:
                        assumptions.extend(option.assumptions)
                        ambiguities.extend(option.ambiguities)
                        trace.extend(option.rule_trace)
                    trace.extend(realization.rule_trace)
                    alternatives.append(
                        TranslationAlternative(
                            identifier="",
                            output_text=realization.text,
                            canonical_clause=clause,
                            tokens=self._render_tokens(
                                tokens,
                                roles,
                                source_direction=(
                                    TranslationDirection.ENGLISH_TO_ASAXI
                                ),
                            ),
                            assumptions=tuple(assumptions),
                            ambiguities=tuple(ambiguities),
                            rule_trace=tuple(trace),
                        )
                    )

        if alternatives:
            return self._result(
                TranslationDirection.ENGLISH_TO_ASAXI,
                text,
                normalized,
                alternatives,
            )
        if invalid_causatives:
            frame, code, message = invalid_causatives[0]
            return self._unsupported(
                TranslationDirection.ENGLISH_TO_ASAXI,
                text,
                normalized,
                code,
                message,
                token_index=(
                    frame.causative_indexes[0]
                    if frame.causative_indexes
                    else frame.predicate_indexes[0]
                ),
            )
        if unresolved_nominals:
            nominal, role = unresolved_nominals[0]
            if (
                role == "subject"
                and len(nominal.head_indexes) == 1
                and not nominal.proper_name
            ):
                return self._unsupported(
                    TranslationDirection.ENGLISH_TO_ASAXI,
                    text,
                    normalized,
                    "SUBJECT_NOT_RECOGNIZED",
                    (
                        "The subject must be a documented nominal or a "
                        "capitalized proper name."
                    ),
                    token_index=nominal.head_indexes[0],
                )
            if role == "object" and len(nominal.head_indexes) > 1:
                return self._unsupported(
                    TranslationDirection.ENGLISH_TO_ASAXI,
                    text,
                    normalized,
                    "ENGLISH_NOUN_PHRASE_NOT_SUPPORTED",
                    (
                        "The object noun phrase has no complete documented "
                        "head-and-modifier analysis."
                    ),
                    token_index=nominal.head_indexes[0],
                )
            return self._unsupported_from_diagnostic(
                direction=TranslationDirection.ENGLISH_TO_ASAXI,
                text=text,
                normalized=normalized,
                diagnostic=TranslationDiagnostic(
                    code="ENGLISH_ACTION_NOMINAL_NOT_RECOGNIZED",
                    severity=Severity.ERROR,
                    message=(
                        f"No documented Asaxi {role} matches "
                        f"{nominal.head!r}, directly or through an "
                        "available same-part-of-speech synonym."
                    ),
                    token_index=nominal.head_indexes[0],
                    details={
                        "head": nominal.head,
                        "role": role,
                        "thesaurus_available": self.thesaurus.available,
                        "thesaurus_provider": self.thesaurus.name,
                    },
                ),
            )
        if object_not_licensed:
            frame = object_not_licensed[0]
            return self._unsupported(
                TranslationDirection.ENGLISH_TO_ASAXI,
                text,
                normalized,
                "OBJECT_NOT_LICENSED_BY_PREDICATE",
                (
                    f"The compiled valency for {frame.predicate!r} does "
                    "not license a direct object."
                ),
                token_index=frame.predicate_indexes[0],
            )
        frame = unresolved_predicates[0]
        return self._unsupported(
            TranslationDirection.ENGLISH_TO_ASAXI,
            text,
            normalized,
            "ENGLISH_PREDICATE_NOT_RECOGNIZED",
            (
                f"No documented Asaxi verb matches "
                f"{frame.predicate!r}, directly or through an available "
                "same-part-of-speech synonym."
            ),
            token_index=frame.predicate_indexes[0],
        )

    def _english_weather_subject_option(
        self,
        frame: EnglishActionFrame,
        predicate: _EnglishPredicateInterpretation,
    ) -> _NominalInterpretation | None:
        """Recover an Asaxi weather-event noun from English expletive it."""

        if frame.subject.head != "it":
            return None
        fields = {
            field.removeprefix("Smntc_Field ").strip().casefold()
            for field in predicate.lexeme.semantic_fields
        }
        if "weather & climate" not in fields:
            return None
        root_names = {
            root.split(" (", 1)[0].strip().casefold()
            for root in predicate.lexeme.root_links
        }
        candidates = sorted(
            (
                lexeme
                for lexeme in self.database.lexemes
                if lexeme.category == "noun"
                and lexeme.lemma.casefold() in root_names
                and "weather & climate"
                in {
                    field.removeprefix("Smntc_Field ")
                    .strip()
                    .casefold()
                    for field in lexeme.semantic_fields
                }
            ),
            key=lambda lexeme: (lexeme.lemma.casefold(), lexeme.identifier),
        )
        if not candidates:
            return None
        source = candidates[0]
        return _NominalInterpretation(
            nominal=Nominal(
                surface=source.surface_form,
                lexeme_id=source.identifier,
                noun_class=(
                    str(source.noun_class.value)
                    if source.noun_class.is_present
                    else None
                ),
                number="singular",
            ),
            english_text="it",
            assumptions=(
                TranslationAssumption(
                    code="ENGLISH_WEATHER_EXPLETIVE",
                    message=(
                        "English expletive 'it' was transferred as the "
                        "documented Asaxi weather-event noun from the "
                        "predicate's derivational source."
                    ),
                ),
            ),
            rule_trace=(
                "english.weather-expletive",
                "lexicon.weather-event-root",
            ),
            source_roles=tuple(
                (index, "subject-weather-expletive")
                for index in frame.subject.source_indexes
            ),
        )

    def _english_oblique_combinations(
        self,
        frames: tuple[EnglishObliqueFrame, ...],
        predicate: _EnglishPredicateInterpretation,
        tokens: tuple[_RawToken, ...],
    ) -> tuple[tuple[_EnglishObliqueInterpretation, ...], ...]:
        if not frames:
            return ((),)
        groups: list[tuple[_EnglishObliqueInterpretation, ...]] = []
        for frame in frames:
            nominals = self._english_frame_nominal_options(
                frame.nominal,
                tokens,
                role="oblique",
            )
            options: list[_EnglishObliqueInterpretation] = []
            for nominal in nominals:
                relations = self._english_oblique_relations(
                    frame,
                    predicate,
                    nominal.nominal,
                )
                choices = tuple(
                    f"{relation.value} -> "
                    f"{ASAXI_CASE_MARKER_BY_RELATION[relation]}"
                    for relation in relations
                )
                for relation in relations:
                    marker = ASAXI_CASE_MARKER_BY_RELATION[relation]
                    ambiguities = list(nominal.ambiguities)
                    if len(relations) > 1:
                        ambiguities.append(
                            TranslationAmbiguity(
                                code=(
                                    "ENGLISH_WITH_RELATION_AMBIGUOUS"
                                ),
                                message=(
                                    "English 'with' can mark either a "
                                    "co-participant or an instrument. Both "
                                    "documented Asaxi case relations remain "
                                    "available."
                                ),
                                choices=choices,
                                selected=(
                                    f"{relation.value} -> {marker}"
                                ),
                            )
                        )
                    assumptions = list(nominal.assumptions)
                    if (
                        frame.kind is EnglishObliqueKind.TO
                        and relation
                        is CaseRelation.TRANSFER_DATIVE
                    ):
                        assumptions.append(
                            TranslationAssumption(
                                code=(
                                    "ENGLISH_TO_TRANSFER_RECIPIENT"
                                ),
                                message=(
                                    "The English goal marker 'to' was "
                                    "realized as Asaxi transfer-recipient "
                                    "dåni because the predicate belongs to "
                                    "the transfer class."
                                ),
                                details={
                                    "predicate": predicate.base,
                                    "relation": relation.value,
                                },
                            )
                        )
                    roles = dict(nominal.source_roles)
                    for index in frame.marker_indexes:
                        roles[index] = (
                            f"oblique-{relation.value}-marker"
                        )
                    options.append(
                        _EnglishObliqueInterpretation(
                            phrase=RelationalPhrase(
                                marker=marker,
                                relation=relation,
                                nominal=nominal.nominal,
                                function=CASE_ARGUMENT_ROLES[relation],
                            ),
                            assumptions=tuple(assumptions),
                            ambiguities=tuple(ambiguities),
                            rule_trace=(
                                *nominal.rule_trace,
                                "english.oblique.structural-transfer",
                                f"english.oblique.{relation.value}",
                            ),
                            source_roles=tuple(sorted(roles.items())),
                        )
                    )
            groups.append(tuple(options))
        return tuple(
            tuple(combination)
            for combination in itertools.product(*groups)
        )

    @staticmethod
    def _english_oblique_relations(
        frame: EnglishObliqueFrame,
        predicate: _EnglishPredicateInterpretation,
        nominal: Nominal,
    ) -> tuple[CaseRelation, ...]:
        if frame.kind is EnglishObliqueKind.TO:
            if predicate.base in TRANSFER_ENGLISH_PREDICATES:
                return (CaseRelation.TRANSFER_DATIVE,)
            return (CaseRelation.ALLATIVE,)
        if frame.kind is EnglishObliqueKind.FROM:
            return (CaseRelation.ABLATIVE,)
        if frame.kind is EnglishObliqueKind.FOR:
            return (CaseRelation.DATIVE,)
        if frame.kind is EnglishObliqueKind.UNTIL:
            return (CaseRelation.TERMINATIVE,)
        if frame.kind is EnglishObliqueKind.ABOUT:
            return (CaseRelation.TOPICAL,)
        if frame.kind is EnglishObliqueKind.BY:
            return (CaseRelation.INSTRUMENTAL,)
        if frame.kind is EnglishObliqueKind.WITH:
            if nominal.noun_class == "cold":
                return (
                    CaseRelation.INSTRUMENTAL,
                    CaseRelation.COMITATIVE,
                )
            return (
                CaseRelation.COMITATIVE,
                CaseRelation.INSTRUMENTAL,
            )
        raise ValueError(f"Unsupported English oblique: {frame.kind}")

    def _rank_declarative_action_frames(
        self,
        frames: tuple[EnglishActionFrame, ...],
        tokens: tuple[_RawToken, ...],
    ) -> tuple[EnglishActionFrame, ...]:
        """Prefer finite predicates that agree with their proposed subject.

        The structural frontend deliberately enumerates every possible
        subject/predicate split. English agreement supplies a general ranking
        signal for ambiguous homonyms without deleting the losing analyses.
        """

        decorated: list[
            tuple[int, int, int, EnglishActionFrame]
        ] = []
        for index, frame in enumerate(frames):
            agreement_rank = self._declarative_agreement_rank(
                frame,
                tokens,
            )
            # Agreement alone cannot distinguish "the red records change"
            # from "the book records change". Demote a short subject only
            # when its final head is documented solely as an attributive
            # source. Ordinary noun heads remain a genuine structural tie.
            attributive_head_rank = (
                1
                if agreement_rank == 0
                and self._english_subject_head_is_attributive(
                    frame.subject,
                    tokens,
                )
                else 0
            )
            decorated.append(
                (
                    agreement_rank,
                    attributive_head_rank,
                    index,
                    frame,
                )
            )

        has_attributive_tie = any(
            agreement_rank == 0 and attributive_head_rank == 1
            for (
                agreement_rank,
                attributive_head_rank,
                _,
                _,
            ) in decorated
        )
        ranked: list[tuple[int, int, int, EnglishActionFrame]] = []
        for (
            agreement_rank,
            attributive_head_rank,
            index,
            frame,
        ) in decorated:
            traces: list[str] = []
            if agreement_rank == 0:
                traces.append(
                    "english.frontend.subject-verb-agreement-ranked"
                )
            if (
                has_attributive_tie
                and agreement_rank == 0
                and attributive_head_rank == 0
            ):
                traces.append(
                    "english.frontend."
                    "independent-nominal-head-ranked"
                )
            if traces:
                frame = replace(
                    frame,
                    rule_trace=(*frame.rule_trace, *traces),
                )
            ranked.append(
                (
                    agreement_rank,
                    attributive_head_rank,
                    index,
                    frame,
                )
            )
        ranked.sort(key=lambda item: item[:3])
        return tuple(frame for _, _, _, frame in ranked)

    def _english_subject_head_is_attributive(
        self,
        subject: EnglishNominalFrame,
        tokens: tuple[_RawToken, ...],
    ) -> bool:
        """Return whether the proposed English head is modifier-only.

        Asaxi lexical categories are the source of truth. Ordinary nouns can
        head an English NP, while documented adjectives and ``ga``-nouns are
        preferentially attributive when another noun follows.
        """

        if (
            subject.wh_word is not None
            or subject.proper_name
            or not subject.head_indexes
        ):
            return False
        by_index = {token.index: token for token in tokens}
        head_token = by_index.get(subject.head_indexes[-1])
        if head_token is None:
            return False
        term = head_token.normalized
        exact = (
            *self.lexicon.english_matches(term, "noun"),
            *self.lexicon.english_matches(term, "adjective"),
        )
        if not exact:
            return False
        ordinary_nouns = tuple(
            lexeme
            for lexeme in exact
            if lexeme.category == "noun"
            and "ga-noun" not in lexeme.tags
        )
        attributive_sources = tuple(
            lexeme
            for lexeme in exact
            if lexeme.category == "adjective"
            or "ga-noun" in lexeme.tags
        )
        return bool(attributive_sources) and not ordinary_nouns

    def _declarative_agreement_rank(
        self,
        frame: EnglishActionFrame,
        tokens: tuple[_RawToken, ...],
    ) -> int:
        if (
            frame.interrogative
            or "english.frontend.declarative-action"
            not in frame.rule_trace
        ):
            return 1
        number = self._english_subject_agreement_number(
            frame.subject,
            tokens,
        )
        if number is None:
            return 1

        matches = self.lexicon.english_verb_matches(
            frame.predicate,
            thesaurus=self.thesaurus,
        )
        nonpast = tuple(
            match for match in matches if match.tense_hint == "nonpast"
        )
        if not nonpast:
            return 1
        source = frame.predicate.casefold()
        for match in nonpast:
            source_base = (
                match.thesaurus_candidate.query_lemma
                if match.thesaurus_candidate is not None
                else match.base
            )
            expected = (
                present_third_person(source_base)
                if number == "third-singular"
                else source_base.casefold()
            )
            if source == expected:
                return 0
        return 2

    def _english_subject_agreement_number(
        self,
        subject: EnglishNominalFrame,
        tokens: tuple[_RawToken, ...],
    ) -> str | None:
        if subject.wh_word is not None:
            return None
        by_index = {token.index: token for token in tokens}
        head_tokens = tuple(
            by_index[index]
            for index in subject.head_indexes
            if index in by_index
        )
        if not head_tokens:
            return None
        head = head_tokens[-1].normalized
        if head in {"i", "you", "we", "they"}:
            return "non-third-singular"
        if head in {"he", "she", "it", "this", "that"}:
            return "third-singular"
        if subject.proper_name or subject.determiner in {"a", "an"}:
            return "third-singular"

        # Productive plural evidence must be checked before an exact plural
        # gloss such as "figures"; both lexical readings remain available.
        if self._has_documented_english_plural_base(head):
            return "non-third-singular"
        if self.lexicon.english_matches(head, "noun"):
            return "third-singular"
        if head in {
            "children",
            "feet",
            "geese",
            "men",
            "mice",
            "people",
            "teeth",
            "women",
        }:
            return "non-third-singular"
        if head.endswith("s") and not head.endswith(("ss", "us", "is")):
            return "non-third-singular"
        return "third-singular"

    def _has_documented_english_plural_base(self, surface: str) -> bool:
        return any(
            category == "noun"
            and term != surface
            and plural_noun(term) == surface
            for category, term in self.lexicon.by_english
        )

    def _translate_english_spatial_frames(
        self,
        *,
        text: str,
        normalized: str,
        tokens: tuple[_RawToken, ...],
        frames: tuple[EnglishSpatialClauseFrame, ...],
        punctuation_question: bool,
    ) -> TranslationResult:
        """Transfer physical copular prepositions to Asaxi spatial verbs."""

        alternatives: list[TranslationAlternative] = []
        unresolved: list[tuple[EnglishNominalFrame, str]] = []
        rejected_landmarks: list[
            tuple[
                EnglishSpatialClauseFrame,
                _NominalInterpretation,
                str,
            ]
        ] = []
        for frame in frames:
            subject_options = self._english_frame_nominal_options(
                frame.subject,
                tokens,
                role="subject",
            )
            location_options = self._english_frame_nominal_options(
                frame.location,
                tokens,
                role="object",
            )
            if not subject_options:
                unresolved.append((frame.subject, "subject"))
                continue
            if not location_options:
                unresolved.append((frame.location, "location"))
                continue
            active_predicate = ASAXI_SPATIAL_PREDICATES[frame.relation]
            for subject, location in itertools.product(
                subject_options,
                location_options,
            ):
                physicality = self._spatial_landmark_physicality(
                    frame.location,
                    location,
                )
                if physicality != SPATIAL_PHYSICAL:
                    rejected_landmarks.append(
                        (frame, location, physicality)
                    )
                    continue
                predicate_options = [
                    (
                        active_predicate,
                        ValidityMode.DYNAMIC,
                        "mutable/current spatial occupation",
                        "clause.english-spatial-active-reading",
                    )
                ]
                topological_predicate = ASAXI_TOPOLOGICAL_PREDICATES.get(
                    frame.relation
                )
                if (
                    topological_predicate is not None
                    and frame.tense is Tense.NONPAST
                    and frame.polarity is Polarity.POSITIVE
                ):
                    predicate_options.append(
                        (
                            topological_predicate,
                            ValidityMode.ESSENTIAL,
                            "immutable/defining topological state",
                            "clause.english-spatial-essential-reading",
                        )
                    )
                for (
                    predicate,
                    validity_mode,
                    validity_label,
                    validity_trace,
                ) in predicate_options:
                    subject_marked = subject.nominal.quantifier is None
                    clause = CanonicalClause(
                        predicate=predicate,
                        subject=subject.nominal,
                        object=location.nominal,
                        tense=frame.tense,
                        polarity=frame.polarity,
                        register=Register.OBJECTIVE,
                        interrogative=self._english_clause_is_interrogative(
                            frame,
                            punctuation_question,
                        ),
                        predicate_kind=PredicateKind.LOCATION,
                        validity_mode=validity_mode,
                        subject_marked=subject_marked,
                        **self._english_clause_envelope_fields(frame),
                    )
                    realization = self.generator.realize(clause)
                    roles = dict(frame.role_by_index)
                    roles.update(subject.source_roles)
                    roles.update(location.source_roles)
                    for token in tokens:
                        if token.kind == "punctuation":
                            roles[token.index] = "punctuation"
                    alternatives.append(
                        TranslationAlternative(
                            identifier="",
                            output_text=realization.text,
                            canonical_clause=clause,
                            tokens=self._render_tokens(
                                tokens,
                                roles,
                                source_direction=(
                                    TranslationDirection.ENGLISH_TO_ASAXI
                                ),
                            ),
                            assumptions=(
                                TranslationAssumption(
                                    code="PHYSICAL_SPATIAL_READING_SELECTED",
                                    message=(
                                        "The English copular preposition was "
                                        "interpreted as a physical location. "
                                        "Asaxi spatial predicates are not "
                                        "licensed for abstract membership or "
                                        "metaphorical containment."
                                    ),
                                    details={
                                        "relation": frame.relation.value,
                                        "target_predicate": predicate,
                                    },
                                ),
                                *subject.assumptions,
                                *location.assumptions,
                            ),
                            ambiguities=(
                                *(
                                    (
                                        TranslationAmbiguity(
                                            code=(
                                                "ENGLISH_SPATIAL_VALIDITY_SPLIT"
                                            ),
                                            message=(
                                                "English spatial 'be' does not "
                                                "state whether the location is "
                                                "temporary or an immutable "
                                                "defining relation; Asaxi "
                                                "distinguishes them."
                                            ),
                                            choices=tuple(
                                                option[2]
                                                for option in predicate_options
                                            ),
                                            selected=validity_label,
                                        ),
                                    )
                                    if len(predicate_options) > 1
                                    else ()
                                ),
                                *subject.ambiguities,
                                *location.ambiguities,
                            ),
                            rule_trace=(
                                "translation.typed-english-spatial-transfer",
                                *frame.rule_trace,
                                "clause.english-copular-preposition-to-"
                                "asaxi-spatial-verb",
                                "clause.english-copular-preposition-to-"
                                "asaxi-spatial-predicate",
                                validity_trace,
                                *subject.rule_trace,
                                *location.rule_trace,
                                *realization.rule_trace,
                            ),
                        )
                    )
        if alternatives:
            return self._result(
                TranslationDirection.ENGLISH_TO_ASAXI,
                text,
                normalized,
                alternatives,
            )
        if rejected_landmarks:
            frame, location, physicality = rejected_landmarks[0]
            known_abstract = physicality == SPATIAL_ABSTRACT
            return self._unsupported_from_diagnostic(
                direction=TranslationDirection.ENGLISH_TO_ASAXI,
                text=text,
                normalized=normalized,
                diagnostic=TranslationDiagnostic(
                    code=(
                        "ENGLISH_ABSTRACT_SPATIAL_REQUIRES_NPCP"
                        if known_abstract
                        else "ENGLISH_SPATIAL_PHYSICALITY_UNRESOLVED"
                    ),
                    severity=Severity.ERROR,
                    message=(
                        (
                            "The English landmark denotes abstract membership "
                            "or metaphorical containment. Documented Asaxi "
                            "physical spatial verbs are forbidden here; an "
                            "appropriate NPCP relation must be selected "
                            "instead."
                        )
                        if known_abstract
                        else (
                            "The English landmark is not positively identified "
                            "as a physical location. Asaxi spatial verbs are "
                            "physical-only, so the relation remains explicit "
                            "and reviewable rather than being guessed."
                        )
                    ),
                    token_index=frame.location.head_indexes[0],
                    details={
                        "head": frame.location.head,
                        "relation": frame.relation.value,
                        "target_lexeme_id": (
                            location.nominal.lexeme_id
                        ),
                        "physical_predicate_rejected": (
                            ASAXI_SPATIAL_PREDICATES[frame.relation]
                        ),
                        "physicality": physicality,
                    },
                ),
            )
        nominal, role = unresolved[0]
        return self._unsupported_from_diagnostic(
            direction=TranslationDirection.ENGLISH_TO_ASAXI,
            text=text,
            normalized=normalized,
            diagnostic=TranslationDiagnostic(
                code="ENGLISH_SPATIAL_NOMINAL_NOT_RECOGNIZED",
                severity=Severity.ERROR,
                message=(
                    f"No documented Asaxi {role} matches "
                    f"{nominal.head!r}, directly or through an available "
                    "same-part-of-speech synonym."
                ),
                token_index=nominal.head_indexes[0],
                details={
                    "head": nominal.head,
                    "role": role,
                    "thesaurus_available": self.thesaurus.available,
                    "thesaurus_provider": self.thesaurus.name,
                },
            ),
        )

    def _spatial_landmark_physicality(
        self,
        frame: EnglishNominalFrame,
        interpretation: _NominalInterpretation | None = None,
    ) -> str:
        """Classify landmark physicality without turning uncertainty into fact."""

        head = frame.head.casefold()
        candidates: list[Lexeme] = []
        if interpretation is not None:
            lexeme_id = interpretation.nominal.lexeme_id
            lexeme = (
                self._lexeme_by_id.get(lexeme_id)
                if lexeme_id is not None
                else None
            )
            if lexeme is not None:
                candidates.append(lexeme)
        if not candidates:
            candidates.extend(
                self.lexicon.english_matches(frame.head, "noun")
            )
        return classify_spatial_landmark(head, candidates)

    def _translate_english_structural_frames(
        self,
        *,
        text: str,
        normalized: str,
        tokens: tuple[_RawToken, ...],
        frames: tuple[EnglishClauseFrame, ...],
        punctuation_question: bool,
    ) -> TranslationResult:
        """Transfer typed English frames into canonical Asaxi structures."""

        alternatives: list[TranslationAlternative] = []
        unresolved: list[tuple[EnglishNominalFrame, str]] = []
        unsupported_deictics: list[EnglishClauseFrame] = []
        for frame in frames:
            locative_complement = frame.complement.locative is not None
            subject_options = self._english_frame_nominal_options(
                frame.subject,
                tokens,
                role="subject",
            )
            complement_options = self._english_frame_nominal_options(
                frame.complement,
                tokens,
                role=(
                    "location"
                    if locative_complement
                    else "complement"
                ),
            )
            if not subject_options:
                unresolved.append((frame.subject, "subject"))
                continue
            if not complement_options:
                unresolved.append((frame.complement, "complement"))
                continue

            for subject, complement in itertools.product(
                subject_options,
                complement_options,
            ):
                subject_marked = (
                    subject.nominal.quantifier is None
                )
                wh_role = (
                    WhRole.SUBJECT
                    if subject.nominal.wh_word
                    else WhRole.LOCATION
                    if (
                        locative_complement
                        and complement.nominal.wh_word
                    )
                    else WhRole.COMPLEMENT
                    if complement.nominal.wh_word
                    else None
                )
                copula_options = (
                    self._english_deictic_predicate_options(
                        frame,
                        subject,
                        complement,
                    )
                    if locative_complement
                    else self._copula_options_for_complement(
                        complement,
                        subject=subject,
                    )
                )
                if not copula_options:
                    unsupported_deictics.append(frame)
                    continue
                for (
                    predicate,
                    predicate_kind,
                    validity_mode,
                    copula_label,
                    copula_trace,
                ) in copula_options:
                    predicate_is_deictic = (
                        locative_complement
                        and complement.nominal.surface
                        in {"o", "no", "ko", "gă"}
                    )
                    clause = CanonicalClause(
                        predicate=predicate,
                        subject=subject.nominal,
                        complement=(
                            None
                            if locative_complement
                            else complement.nominal
                        ),
                        location=(
                            complement.nominal
                            if (
                                locative_complement
                                and not predicate_is_deictic
                            )
                            else None
                        ),
                        tense=frame.tense,
                        polarity=frame.polarity,
                        register=Register.OBJECTIVE,
                        interrogative=self._english_clause_is_interrogative(
                            frame,
                            punctuation_question,
                        ),
                        predicate_kind=predicate_kind,
                        validity_mode=validity_mode,
                        wh_role=wh_role,
                        subject_marked=subject_marked,
                        **self._english_clause_envelope_fields(frame),
                    )
                    realization = self.generator.realize(clause)
                    roles = dict(frame.role_by_index)
                    roles.update(subject.source_roles)
                    roles.update(complement.source_roles)
                    for token in tokens:
                        if token.kind == "punctuation":
                            roles[token.index] = "punctuation"
                    copula_ambiguity = (
                        (
                            TranslationAmbiguity(
                                code=(
                                    "ENGLISH_DEICTIC_VALIDITY_SPLIT"
                                    if predicate_is_deictic
                                    else "ENGLISH_COPULA_ASAXI_SPLIT"
                                ),
                                message=(
                                    "English deictic 'be' does not always "
                                    "distinguish a circumstantial point from "
                                    "a stable proximal state."
                                    if predicate_is_deictic
                                    else (
                                        "English 'be' does not always say "
                                        "whether the predication is current "
                                        "and changeable or an essential "
                                        "defining fact; Asaxi requires that "
                                        "distinction."
                                    )
                                ),
                                choices=tuple(
                                    option[3]
                                    for option in copula_options
                                ),
                                selected=copula_label,
                            ),
                        )
                        if len(copula_options) > 1
                        else ()
                    )
                    register_assumption = (
                        TranslationAssumption(
                            code="UNMARKED_SUBJECT_CANONICAL_ORDER",
                            message=(
                                "The universally quantified subject was "
                                "left unmarked in the attested canonical "
                                "order, as in 'mămă apo gapo xiŕa'."
                            ),
                        )
                        if not subject_marked
                        else TranslationAssumption(
                            code="OBJECTIVE_REGISTER_DEFAULT",
                            message=(
                                "English does not encode Asaxi's "
                                "objective/subjective contrast; objective "
                                "register was selected."
                            ),
                        )
                    )
                    alternatives.append(
                        TranslationAlternative(
                            identifier="",
                            output_text=realization.text,
                            canonical_clause=clause,
                            tokens=self._render_tokens(
                                tokens,
                                roles,
                                source_direction=(
                                    TranslationDirection.ENGLISH_TO_ASAXI
                                ),
                            ),
                            assumptions=(
                                register_assumption,
                                *subject.assumptions,
                                *complement.assumptions,
                            ),
                            ambiguities=(
                                *copula_ambiguity,
                                *subject.ambiguities,
                                *complement.ambiguities,
                            ),
                            rule_trace=(
                                "translation.typed-english-structural-transfer",
                                copula_trace,
                                *frame.rule_trace,
                                *subject.rule_trace,
                                *complement.rule_trace,
                                *realization.rule_trace,
                            ),
                        ),
                    )

        if alternatives:
            return self._result(
                TranslationDirection.ENGLISH_TO_ASAXI,
                text,
                normalized,
                alternatives,
            )

        if unsupported_deictics:
            frame = unsupported_deictics[0]
            return self._unsupported_from_diagnostic(
                direction=TranslationDirection.ENGLISH_TO_ASAXI,
                text=text,
                normalized=normalized,
                diagnostic=TranslationDiagnostic(
                    code="ENGLISH_DEICTIC_INFLECTION_UNRESOLVED",
                    severity=Severity.ERROR,
                    message=(
                        "The notes distinguish point deixis from vicinity, "
                        "but do not establish this tense/polarity form for "
                        "the requested deictic predicate. The Workshop will "
                        "not substitute an o-gă/no-gă/ko-gă vicinity noun."
                    ),
                    token_index=frame.complement.head_indexes[0],
                ),
            )

        nominal, role = unresolved[0]
        return self._unsupported_from_diagnostic(
            direction=TranslationDirection.ENGLISH_TO_ASAXI,
            text=text,
            normalized=normalized,
            diagnostic=TranslationDiagnostic(
                code="ENGLISH_IDENTITY_NOMINAL_NOT_RECOGNIZED",
                severity=Severity.ERROR,
                message=(
                    f"No documented Asaxi {role} matches "
                    f"{nominal.head!r}, directly or through an available "
                    "same-part-of-speech synonym."
                ),
                token_index=nominal.head_indexes[0],
                details={
                    "head": nominal.head,
                    "role": role,
                    "thesaurus_available": self.thesaurus.available,
                    "thesaurus_provider": self.thesaurus.name,
                },
            ),
        )

    @staticmethod
    def _english_deictic_predicate_options(
        frame: EnglishClauseFrame,
        subject: _NominalInterpretation,
        location: _NominalInterpretation,
    ) -> tuple[
        tuple[str, PredicateKind, ValidityMode, str, str],
        ...,
    ]:
        """Keep point deixis distinct from compound vicinity nouns."""

        point = location.nominal.surface
        if point not in {"o", "no", "ko", "gă"}:
            return ()
        if frame.tense is not Tense.NONPAST:
            return ()
        if frame.polarity is Polarity.NEGATIVE:
            if point != "o":
                return ()
            return (
                (
                    "o-xiŕa",
                    PredicateKind.LOCATION,
                    ValidityMode.ESSENTIAL,
                    "documented proximal negative onèŕa",
                    "clause.deictic-location-essential",
                ),
            )
        circumstantial = (
            point,
            PredicateKind.LOCATION,
            ValidityMode.CIRCUMSTANTIAL,
            "circumstantial deictic point",
            "clause.deictic-location-circumstantial",
        )
        if point == "gă":
            return (circumstantial,)
        essential = (
            f"{point}-xiŕa",
            PredicateKind.LOCATION,
            ValidityMode.ESSENTIAL,
            "essential deictic state",
            "clause.deictic-location-essential",
        )
        subject_is_nonspecific = (
            subject.nominal.determiner in {"a", "an", "indefinite"}
            or subject.nominal.quantifier is not None
        )
        return (
            (circumstantial,)
            if subject_is_nonspecific
            else (essential, circumstantial)
        )

    def _copula_options_for_complement(
        self,
        complement: _NominalInterpretation,
        *,
        subject: _NominalInterpretation | None = None,
    ) -> tuple[
        tuple[
            str,
            PredicateKind,
            ValidityMode,
            str,
            str,
        ],
        ...,
    ]:
        """Rank documented active/essential readings by complement evidence.

        English ``be`` does not encode Asaxi's validity contrast.  Semantic
        fields can make one reading likelier, but the grammar-book stone and
        mother minimal pairs prove that a lexical complement cannot prohibit
        the other reading.
        """

        dynamic = (
            "ů",
            PredicateKind.PERFORMANCE,
            ValidityMode.DYNAMIC,
            "active/current ů",
            "copula.split.dynamic-active",
        )
        essential = (
            "xiŕa",
            PredicateKind.IDENTITY,
            ValidityMode.ESSENTIAL,
            "essential/definitional xiŕa",
            "copula.split.essential-identity",
        )
        if complement.nominal.wh_word is not None:
            return (essential,)
        if (
            subject is not None
            and subject.nominal.extent is not None
        ):
            # Note 52's extent predication uses xiŕa: the statement applies
            # to the referent taken as a complete unit, not merely to its
            # current activity. Retain the dynamic reading for review.
            return (essential, dynamic)
        if (
            subject is not None
            and (
                subject.nominal.verbal_nominalization is not None
                or (
                    subject.nominal.coordinated
                    and all(
                        item.verbal_nominalization is not None
                        for item in subject.nominal.coordinated
                    )
                )
            )
        ):
            # The nominalization chapter's evaluative examples use xiŕa for
            # the event concept. English still leaves the active reading
            # possible, so retain it as the reviewable second alternative.
            return (essential, dynamic)
        lexeme_id = complement.nominal.lexeme_id
        if lexeme_id is None:
            if complement.nominal.surface.isupper():
                return (essential, dynamic)
            return (dynamic, essential)
        lexeme = self._lexeme_by_id.get(lexeme_id)
        if lexeme is None:
            return (dynamic, essential)
        semantic_fields = {
            field.removeprefix("Smntc_Field ").strip().casefold()
            for field in lexeme.semantic_fields
        }
        if semantic_fields & COPULA_STRONGLY_ESSENTIAL_FIELDS:
            return (essential, dynamic)
        if (
            lexeme.category == "noun"
            and semantic_fields & COPULA_ESSENTIAL_PREFERRED_FIELDS
        ):
            return (essential, dynamic)
        if semantic_fields & COPULA_DYNAMIC_PREFERRED_FIELDS:
            return (dynamic, essential)
        # Adjectival predication describes a state by default. Lexical field
        # metadata can be broader than the particular English sense (the
        # attested ``dănă`` "big" entry, for example, is filed under Animals),
        # so adjective status outranks weaker identity-field hints.
        if lexeme.category == "adjective":
            return (dynamic, essential)
        return (essential, dynamic)

    def _english_frame_nominal_options(
        self,
        frame: EnglishNominalFrame,
        tokens: tuple[_RawToken, ...],
        *,
        role: str,
    ) -> tuple[_NominalInterpretation, ...]:
        source_tokens = {
            token.index: token
            for token in tokens
        }
        english_text = " ".join(
            source_tokens[index].surface
            for index in frame.source_indexes
            if index in source_tokens
        )
        if frame.locative is not None:
            return self._english_deictic_location_options(
                frame,
                english_text,
                role=role,
            )
        if frame.wh_word is not None:
            wh_surface = {
                "who": "kshá",
                "what": "kjo",
                "where": "ksi",
                "when": "kvå",
                "why": "ksè",
                "how": "ksá",
            }.get(frame.wh_word)
            if wh_surface is None:
                return ()
            return (
                _NominalInterpretation(
                    nominal=Nominal(
                        wh_surface,
                        wh_word=frame.wh_word,
                    ),
                    english_text=english_text,
                    rule_trace=(
                        "english.wh-to-asaxi-in-situ",
                        f"english.wh-word.{frame.wh_word}",
                    ),
                ),
            )

        excluded_indexes = {
            *(
                frame.possessor.source_indexes
                if frame.possessor is not None
                else ()
            ),
            *(
                frame.quantifier.source_indexes
                if frame.quantifier is not None
                else ()
            ),
            *(
                frame.extent.source_indexes
                if frame.extent is not None
                else ()
            ),
        }
        head_frame = replace(
            frame,
            source_indexes=tuple(
                index
                for index in frame.source_indexes
                if index not in excluded_indexes
            ),
            possessor=None,
            quantifier=None,
            extent=None,
            determiner=(None if frame.extent is not None else frame.determiner),
        )
        head_options = self._english_unpossessed_nominal_options(
            head_frame,
            source_tokens,
            english_text,
            role=role,
        )
        if not head_options:
            return ()

        options = list(head_options)
        if frame.possessor is not None:
            possessor_options = self._english_possessor_options(
                frame.possessor,
                tokens,
            )
            options = [
                _NominalInterpretation(
                    nominal=replace(
                        head.nominal,
                        surface=(
                            f"sè {possessor.nominal.surface} "
                            f"{head.nominal.surface}"
                        ),
                        possessor=possessor.nominal,
                    ),
                    english_text=english_text,
                    assumptions=(
                        *head.assumptions,
                        *possessor.assumptions,
                    ),
                    ambiguities=(
                        *head.ambiguities,
                        *possessor.ambiguities,
                    ),
                    rule_trace=(
                        "noun.genitive-possession",
                        *possessor.rule_trace,
                        *head.rule_trace,
                    ),
                    source_roles=(
                        *head.source_roles,
                        *possessor.source_roles,
                    ),
                )
                for head, possessor in itertools.product(
                    options,
                    possessor_options,
                )
            ]

        if frame.quantifier is not None:
            options = [
                self._apply_english_nominal_quantifier(
                    option,
                    frame,
                    role=role,
                )
                for option in options
            ]
        if frame.extent is not None:
            options = [
                self._apply_english_nominal_extent(
                    option,
                    frame,
                    role=role,
                )
                for option in options
            ]
        return tuple(options)

    @staticmethod
    def _apply_english_nominal_extent(
        option: _NominalInterpretation,
        frame: EnglishNominalFrame,
        *,
        role: str,
    ) -> _NominalInterpretation:
        extent = frame.extent
        if extent is None:
            return option
        if extent.kind is NominalExtentKind.COMPLETE:
            marker = "săsă" if extent.emphasized else "să"
            target = NominalExtent(
                marker=marker,
                kind=NominalExtentKind.COMPLETE,
                emphasized=extent.emphasized,
                source_form=extent.source_form,
            )
            surface = marker + option.nominal.surface
            message = (
                f"English {extent.source_form!r} was transferred as the "
                f"documented {'emphasized ' if extent.emphasized else ''}"
                f"completeness prefix {marker}-."
            )
        else:
            denominator = fraction_denominator_form(
                extent.denominator_value or 0
            )
            if denominator is None:
                return option
            target = NominalExtent(
                marker="pù",
                kind=NominalExtentKind.FRACTIONAL,
                denominator=denominator,
                denominator_value=extent.denominator_value,
                source_form=extent.source_form,
            )
            surface = f"pù{denominator}-{option.nominal.surface}"
            message = (
                f"English {extent.source_form!r} was transferred through "
                f"the documented pù- denominator construction ({denominator})."
            )
        return replace(
            option,
            nominal=replace(
                option.nominal,
                surface=surface,
                determiner=None,
                extent=target,
            ),
            assumptions=(
                *option.assumptions,
                TranslationAssumption(
                    code="ENGLISH_NOMINAL_EXTENT",
                    message=message,
                ),
            ),
            rule_trace=(
                "noun.extent.number-prefix",
                (
                    "noun.extent.complete"
                    if extent.kind is NominalExtentKind.COMPLETE
                    else "noun.extent.fractional"
                ),
                *option.rule_trace,
            ),
            source_roles=(
                *option.source_roles,
                *tuple(
                    (index, f"{role}-extent")
                    for index in extent.source_indexes
                ),
            ),
        )

    @staticmethod
    def _english_deictic_location_options(
        frame: EnglishNominalFrame,
        english_text: str,
        *,
        role: str,
    ) -> tuple[_NominalInterpretation, ...]:
        if frame.locative is None:
            return ()
        surface, distance = {
            EnglishLocativeKind.PROXIMAL: (
                "o",
                DeicticDistance.PROXIMAL,
            ),
            EnglishLocativeKind.MEDIAL: (
                "no",
                DeicticDistance.MEDIAL,
            ),
            EnglishLocativeKind.DISTAL: (
                "ko",
                DeicticDistance.DISTAL,
            ),
            EnglishLocativeKind.INDEFINITE: (
                "gă",
                DeicticDistance.INDEFINITE,
            ),
        }[frame.locative]
        return (
            _NominalInterpretation(
                nominal=Nominal(
                    surface=surface,
                    deixis=distance,
                ),
                english_text=english_text,
                assumptions=(
                    TranslationAssumption(
                        code="ENGLISH_DEICTIC_LOCATION_TO_POINT",
                        message=(
                            f"English {frame.head!r} was transferred as "
                            f"the documented Asaxi {surface!r} deictic "
                            "point. Compound vicinity nouns such as o-gă "
                            "remain a separate construction."
                        ),
                    ),
                ),
                rule_trace=(
                    "english.deictic-location",
                    f"noun.deixis.{distance.value}",
                ),
                source_roles=tuple(
                    (index, f"{role}-deictic")
                    for index in frame.source_indexes
                ),
            ),
        )

    @staticmethod
    def _apply_english_nominal_quantifier(
        option: _NominalInterpretation,
        frame: EnglishNominalFrame,
        *,
        role: str,
    ) -> _NominalInterpretation:
        quantifier = frame.quantifier
        if (
            quantifier is None
            or quantifier.kind
            is not EnglishNominalQuantifierKind.UNIVERSAL
        ):
            return option
        bare_surface = option.nominal.surface
        if option.nominal.determiner is not None and " " in bare_surface:
            bare_surface = bare_surface.split(" ", 1)[1]
        if (
            quantifier.source_form == "all"
            and option.nominal.number != "plural"
        ):
            extent = NominalExtent(
                marker="să",
                kind=NominalExtentKind.COMPLETE,
                emphasized=False,
                source_form=quantifier.source_form,
            )
            return replace(
                option,
                nominal=replace(
                    option.nominal,
                    surface=f"să{bare_surface}",
                    determiner=None,
                    quantifier=None,
                    extent=extent,
                ),
                assumptions=(
                    *option.assumptions,
                    TranslationAssumption(
                        code="ENGLISH_ALL_AS_NOMINAL_EXTENT",
                        message=(
                            "Singular English 'all' was transferred as the "
                            "documented să- complete-extent prefix rather "
                            "than the mămă individual-set quantifier."
                        ),
                    ),
                ),
                rule_trace=(
                    "noun.extent.number-prefix",
                    "noun.extent.complete",
                    *option.rule_trace,
                ),
                source_roles=(
                    *option.source_roles,
                    *tuple(
                        (index, f"{role}-extent")
                        for index in quantifier.source_indexes
                    ),
                ),
            )
        target = NominalQuantifier(
            marker="mămă",
            kind=NominalQuantifierKind.UNIVERSAL,
            source_form=quantifier.source_form,
        )
        return replace(
            option,
            nominal=replace(
                option.nominal,
                surface=f"mămă {bare_surface}",
                determiner=None,
                quantifier=target,
            ),
            assumptions=(
                *option.assumptions,
                TranslationAssumption(
                    code="ENGLISH_UNIVERSAL_QUANTIFIER",
                    message=(
                        f"English {quantifier.source_form!r} was "
                        "transferred as mămă, the documented exhaustive "
                        "individual-set quantifier."
                    ),
                ),
            ),
            rule_trace=(
                "noun.quantifier.mămă-universal",
                *option.rule_trace,
            ),
            source_roles=(
                *option.source_roles,
                *tuple(
                    (index, f"{role}-quantifier")
                    for index in quantifier.source_indexes
                ),
            ),
        )

    def _english_unpossessed_nominal_options(
        self,
        frame: EnglishNominalFrame,
        source_tokens: dict[int, _RawToken],
        english_text: str,
        *,
        role: str,
    ) -> tuple[_NominalInterpretation, ...]:
        """Resolve an exact lexical head before attempting NP decomposition."""

        verbal = self._english_verbal_nominal_options(
            frame,
            source_tokens,
            english_text,
            role=role,
        )
        direct = self._english_frame_head_options(
            frame,
            english_text,
            role=role,
            allow_thesaurus=False,
        )
        if direct or verbal:
            options = (*direct, *verbal)
            if direct and verbal:
                choices = tuple(
                    dict.fromkeys(
                        (
                            "documented lexical nominal"
                            if option.nominal.verbal_nominalization is None
                            else "documented verbal nominalization"
                        )
                        for option in options
                    )
                )
                options = tuple(
                    replace(
                        option,
                        ambiguities=(
                            *option.ambiguities,
                            TranslationAmbiguity(
                                code="ENGLISH_NOMINALIZATION_AMBIGUOUS",
                                message=(
                                    "The English form licenses both a "
                                    "lexical noun and a documented verbal "
                                    "nominalization."
                                ),
                                choices=choices,
                                selected=(
                                    "documented lexical nominal"
                                    if option.nominal.verbal_nominalization
                                    is None
                                    else "documented verbal nominalization"
                                ),
                            ),
                        ),
                    )
                    for option in options
                )
            return tuple(
                replace(
                    option,
                    source_roles=(
                        option.source_roles
                        or self._english_nominal_source_roles(
                            frame,
                            role=role,
                        )
                    ),
                )
                for option in options
            )

        content = tuple(
            source_tokens[index]
            for index in frame.head_indexes
            if index in source_tokens
        )
        if len(content) > 1:
            exact_structural = self._english_modified_nominal_options(
                frame,
                content,
                english_text,
                role=role,
                allow_thesaurus=False,
            )
            if exact_structural:
                return exact_structural
            return self._english_modified_nominal_options(
                frame,
                content,
                english_text,
                role=role,
                allow_thesaurus=True,
            )

        widened = self._english_frame_head_options(
            frame,
            english_text,
            role=role,
            allow_thesaurus=True,
        )
        return tuple(
            replace(
                option,
                source_roles=self._english_nominal_source_roles(
                    frame,
                    role=role,
                ),
            )
            for option in widened
        )

    @staticmethod
    def _target_verbal_nominal(
        match: EnglishGerundMatch,
        *,
        specific: bool,
    ) -> Nominal:
        predicate = match.lexeme.lemma
        predicate_surface = f"o-{predicate}" if specific else predicate
        return Nominal(
            surface=f"anő {predicate_surface}",
            noun_class="cold",
            determiner="indefinite",
            relation="verbal-nominalization",
            deixis=(DeicticDistance.PROXIMAL if specific else None),
            verbal_nominalization=VerbalNominalization(
                predicate=predicate,
                predicate_lexeme_id=match.lexeme.identifier,
                specific=specific,
                proximal_marker="o" if specific else None,
            ),
        )

    def _english_verbal_nominal_options(
        self,
        frame: EnglishNominalFrame,
        source_tokens: dict[int, _RawToken],
        english_text: str,
        *,
        role: str,
    ) -> tuple[_NominalInterpretation, ...]:
        """Map exact lexical gerunds to ``anő`` without suffix guessing."""

        if frame.determiner not in {None, "a", "an", "the"}:
            return ()
        matches = self.lexicon.english_gerund_matches(frame.head)
        if matches:
            specific = frame.determiner == "the"
            options = tuple(
                _NominalInterpretation(
                    nominal=self._target_verbal_nominal(
                        match,
                        specific=specific,
                    ),
                    english_text=english_text,
                    assumptions=(
                        (
                            TranslationAssumption(
                                code=(
                                    "ENGLISH_DEFINITE_GERUND_TO_PROXIMAL"
                                ),
                                message=(
                                    "English definite gerund specificity "
                                    "was transferred with the documented "
                                    "proximal o- prefix under anő."
                                ),
                            ),
                        )
                        if specific
                        else ()
                    ),
                    rule_trace=(
                        "noun.verbal-nominalization-anő",
                        "noun.verbal-nominalization-cold-class",
                        "english.exact-lexical-gerund",
                        *(
                            (
                                "noun.verbal-nominalization-proximal-specific",
                            )
                            if specific
                            else ()
                        ),
                    ),
                    source_roles=self._english_nominal_source_roles(
                        frame,
                        role=role,
                    ),
                )
                for match in matches
            )
            return self._mark_english_gerund_ambiguity(options)

        if frame.determiner is not None:
            return ()
        content = tuple(
            source_tokens[index]
            for index in frame.head_indexes
            if index in source_tokens
        )
        and_positions = tuple(
            index
            for index, token in enumerate(content)
            if token.normalized == "and"
        )
        if len(and_positions) != 1:
            return ()
        position = and_positions[0]
        groups = (content[:position], content[position + 1:])
        if any(not group for group in groups):
            return ()
        group_matches = tuple(
            self.lexicon.english_gerund_matches(
                " ".join(token.normalized for token in group)
            )
            for group in groups
        )
        if any(not matches for matches in group_matches):
            return ()

        options: list[_NominalInterpretation] = []
        for combination in itertools.product(*group_matches):
            children = tuple(
                replace(
                    self._target_verbal_nominal(match, specific=False),
                    surface=match.lexeme.lemma,
                    determiner=None,
                )
                for match in combination
            )
            roles = {
                token.index: f"{role}-nominalized-predicate"
                for group in groups
                for token in group
            }
            roles[content[position].index] = f"{role}-connector"
            options.append(
                _NominalInterpretation(
                    nominal=Nominal(
                        surface=(
                            "anő "
                            + " ja ".join(
                                match.lexeme.lemma
                                for match in combination
                            )
                        ),
                        noun_class="cold",
                        determiner="indefinite",
                        number="plural",
                        coordinated=children,
                        relation="coordinated-verbal-nominalization",
                    ),
                    english_text=english_text,
                    rule_trace=(
                        "noun.verbal-nominalization-anő",
                        "noun.verbal-nominalization-cold-class",
                        "noun.gerund-list-single-anchor",
                        "noun.coordination-ja",
                        "english.exact-lexical-gerund-list",
                    ),
                    source_roles=tuple(sorted(roles.items())),
                )
            )
        return self._mark_english_gerund_ambiguity(tuple(options))

    @staticmethod
    def _mark_english_gerund_ambiguity(
        options: tuple[_NominalInterpretation, ...],
    ) -> tuple[_NominalInterpretation, ...]:
        choices = tuple(
            dict.fromkeys(option.nominal.surface for option in options)
        )
        if len(choices) < 2:
            return options
        return tuple(
            replace(
                option,
                ambiguities=(
                    *option.ambiguities,
                    TranslationAmbiguity(
                        code="ENGLISH_GERUND_LEXICAL_AMBIGUITY",
                        message=(
                            "The English gerund has multiple documented "
                            "Asaxi verb analyses."
                        ),
                        choices=choices,
                        selected=option.nominal.surface,
                    ),
                ),
            )
            for option in options
        )

    @staticmethod
    def _english_nominal_source_roles(
        frame: EnglishNominalFrame,
        *,
        role: str,
        modifier_indexes: tuple[int, ...] = (),
        head_indexes: tuple[int, ...] | None = None,
    ) -> tuple[tuple[int, str], ...]:
        heads = (
            frame.head_indexes
            if head_indexes is None
            else head_indexes
        )
        roles = {index: f"{role}-head" for index in heads}
        roles.update(
            {
                index: f"{role}-modifier"
                for index in modifier_indexes
            }
        )
        if frame.determiner is not None:
            for index in (
                set(frame.source_indexes)
                - set(frame.head_indexes)
            ):
                roles[index] = f"{role}-determiner"
        return tuple(sorted(roles.items()))

    def _english_modified_nominal_options(
        self,
        frame: EnglishNominalFrame,
        content: tuple[_RawToken, ...],
        english_text: str,
        *,
        role: str,
        allow_thesaurus: bool,
    ) -> tuple[_NominalInterpretation, ...]:
        """Resolve left modifiers plus the longest available lexical head."""

        options: list[_NominalInterpretation] = []
        # Earlier split points leave a longer suffix as the lexical head.
        for split in range(1, len(content)):
            head_words = content[split:]
            head_frame = replace(
                frame,
                head=" ".join(word.normalized for word in head_words),
                head_indexes=tuple(word.index for word in head_words),
            )
            head_options = self._english_frame_head_options(
                head_frame,
                english_text,
                role=role,
                allow_thesaurus=allow_thesaurus,
            )
            if not head_options:
                continue
            modifier_sequences = self._english_modifier_sequences(
                content[:split],
                allow_thesaurus=allow_thesaurus,
            )
            if not modifier_sequences:
                continue
            for head, modifiers in itertools.product(
                head_options,
                modifier_sequences,
            ):
                composed = self._compose_english_modified_nominal(
                    frame,
                    head,
                    modifiers,
                    english_text,
                    role=role,
                    head_indexes=head_frame.head_indexes,
                )
                if composed is not None:
                    if len(options) < MAX_ENGLISH_NP_OPTIONS:
                        options.append(composed)
                    else:
                        return self._mark_nominal_analysis_limit(
                            options,
                            scope="modified-nominal-options",
                        )
        return tuple(options)

    def _english_modifier_sequences(
        self,
        words: tuple[_RawToken, ...],
        *,
        allow_thesaurus: bool,
    ) -> tuple[tuple[_EnglishModifierInterpretation, ...], ...]:
        """Segment a modifier span by documented lexical entries."""

        memo: dict[
            tuple[int, int],
            tuple[tuple[_EnglishModifierInterpretation, ...], ...],
        ] = {}

        def visit(
            position: int,
            remaining: int,
        ) -> tuple[tuple[_EnglishModifierInterpretation, ...], ...]:
            key = (position, remaining)
            if key in memo:
                return memo[key]
            if position == len(words):
                return ((),)
            if remaining == 0:
                return ()

            sequences: list[
                tuple[_EnglishModifierInterpretation, ...]
            ] = []
            # Prefer the longest documented modifier term at each point.
            for end in range(len(words), position, -1):
                selected = words[position:end]
                term = " ".join(word.normalized for word in selected)
                interpretations = self._english_modifier_term_options(
                    term,
                    tuple(word.index for word in selected),
                    allow_thesaurus=allow_thesaurus,
                )
                for interpretation in interpretations:
                    for tail in visit(end, remaining - 1):
                        sequence = (interpretation, *tail)
                        if len(sequences) < MAX_ENGLISH_NP_OPTIONS:
                            sequences.append(sequence)
                        else:
                            memo[key] = (
                                self._mark_modifier_analysis_limit(
                                    sequences,
                                    scope="modifier-segmentation",
                                )
                            )
                            return memo[key]
            memo[key] = tuple(sequences)
            return memo[key]

        return visit(0, MAX_ENGLISH_MODIFIER_SEGMENTS)

    @staticmethod
    def _analysis_limit_assumption(
        *,
        scope: str,
    ) -> TranslationAssumption:
        return TranslationAssumption(
            code="ANALYSIS_LIMIT_REACHED",
            message=(
                "The bounded English lexical analyzer retained its first "
                f"{MAX_ENGLISH_NP_OPTIONS} deterministic analyses and "
                "left additional analyses unmaterialized."
            ),
            details={
                "scope": scope,
                "retained": MAX_ENGLISH_NP_OPTIONS,
                "available_at_least": MAX_ENGLISH_NP_OPTIONS + 1,
            },
        )

    def _mark_nominal_analysis_limit(
        self,
        options: list[_NominalInterpretation],
        *,
        scope: str,
    ) -> tuple[_NominalInterpretation, ...]:
        assumption = self._analysis_limit_assumption(scope=scope)
        return tuple(
            replace(
                option,
                assumptions=(*option.assumptions, assumption),
            )
            for option in options
        )

    def _mark_modifier_analysis_limit(
        self,
        sequences: list[
            tuple[_EnglishModifierInterpretation, ...]
        ],
        *,
        scope: str,
    ) -> tuple[tuple[_EnglishModifierInterpretation, ...], ...]:
        assumption = self._analysis_limit_assumption(scope=scope)
        marked: list[tuple[_EnglishModifierInterpretation, ...]] = []
        for sequence in sequences:
            if not sequence:
                marked.append(sequence)
                continue
            first, *rest = sequence
            marked.append(
                (
                    replace(
                        first,
                        assumptions=(*first.assumptions, assumption),
                    ),
                    *rest,
                )
            )
        return tuple(marked)

    def _mark_predicate_analysis_limit(
        self,
        options: list[_EnglishPredicateInterpretation],
        *,
        scope: str,
    ) -> tuple[_EnglishPredicateInterpretation, ...]:
        assumption = self._analysis_limit_assumption(scope=scope)
        return tuple(
            replace(
                option,
                assumptions=(*option.assumptions, assumption),
            )
            for option in options
        )

    def _english_modifier_term_options(
        self,
        term: str,
        source_indexes: tuple[int, ...],
        *,
        allow_thesaurus: bool,
    ) -> tuple[_EnglishModifierInterpretation, ...]:
        adjective_candidates = self.lexicon.english_candidates(
            term,
            "adjective",
        )
        constitution_candidates = self.lexicon.english_candidates(
            term,
            "noun",
        )
        if (
            not adjective_candidates
            and not constitution_candidates
            and allow_thesaurus
        ):
            adjective_candidates = self.lexicon.english_candidates(
                term,
                "adjective",
                thesaurus=self.thesaurus,
            )
            constitution_candidates = self.lexicon.english_candidates(
                term,
                "noun",
                thesaurus=self.thesaurus,
            )

        options: list[_EnglishModifierInterpretation] = []
        for kind, candidates in (
            ("qualitative", adjective_candidates),
            ("constitution", constitution_candidates),
        ):
            for candidate in candidates:
                lexeme = candidate.lexeme
                thesaurus = candidate.thesaurus_candidate
                assumptions = (
                    (
                        self._thesaurus_assumption(
                            source_term=term,
                            matched_term=candidate.matched_term,
                            candidate=thesaurus,
                            part_of_speech=candidate.category,
                        ),
                    )
                    if thesaurus is not None
                    else ()
                )
                roots = (
                    self._constitution_roots(lexeme)
                    if kind == "constitution"
                    else (None,)
                )
                for root in roots:
                    options.append(
                        _EnglishModifierInterpretation(
                            nominal=Nominal(
                                surface=lexeme.surface_form,
                                lexeme_id=lexeme.identifier,
                                noun_class=(
                                    str(lexeme.noun_class.value)
                                    if lexeme.noun_class.is_present
                                    else None
                                ),
                            ),
                            kind=kind,
                            source_indexes=source_indexes,
                            constitution_root=root,
                            assumptions=assumptions,
                            rule_trace=(
                                (
                                    "noun.modifier.qualitative-adjective"
                                    if kind == "qualitative"
                                    else "noun.modifier.ga-constitution"
                                ),
                                *(
                                    (
                                        "noun.ga-lexical-modifier-unwrapped",
                                        (
                                            "noun.ga-payload-from-compiled-"
                                            "derivation"
                                        ),
                                    )
                                    if (
                                        kind == "constitution"
                                        and root != lexeme.surface_form
                                    )
                                    else ()
                                ),
                                *(
                                    (
                                        "lexicon.same-pos-thesaurus-fallback",
                                    )
                                    if thesaurus is not None
                                    else ()
                                ),
                            ),
                        )
                    )
        return tuple(options)

    def _constitution_roots(self, lexeme: Lexeme) -> tuple[str, ...]:
        """Return lexical roots licensed for a constitutional modifier."""

        surface = lexeme.surface_form
        if "ga-noun" not in lexeme.tags:
            return (surface,)

        payloads: tuple[str, ...]
        if surface.startswith("gă") and len(surface) > 2:
            payloads = ("i" + surface[2:],)
        elif surface.startswith("ga") and len(surface) > 2:
            # ``ga`` + initial ``a`` coalesces to one ``a``. Both inverses
            # are possible from spelling alone; compiled etymology decides.
            payloads = (surface[1:], surface[2:])
        else:
            return (surface,)

        linked_roots = tuple(
            self._derivational_link_lemma(link)
            for link in lexeme.root_links
            if self._derivational_link_lemma(link) not in {"ga", "gă"}
        )
        exact = tuple(
            payload
            for payload in payloads
            if payload in linked_roots
        )
        if exact:
            return exact
        prefix_evidenced = tuple(
            payload
            for payload in payloads
            if any(root.startswith(payload) for root in linked_roots)
        )
        if prefix_evidenced:
            return prefix_evidenced
        # Old notes may have the ga-noun tag without parsed etymology. The
        # tag still licenses a single-prefix inverse; unrelated standalone
        # noun entries never decide the payload.
        return (payloads[-1],)

    @staticmethod
    def _derivational_link_lemma(link: str) -> str:
        leaf = link.rsplit("/", 1)[-1].strip()
        return re.sub(r"\s+\([^)]*\)\s*$", "", leaf).casefold()

    def _compose_english_modified_nominal(
        self,
        frame: EnglishNominalFrame,
        head: _NominalInterpretation,
        modifiers: tuple[_EnglishModifierInterpretation, ...],
        english_text: str,
        *,
        role: str,
        head_indexes: tuple[int, ...],
    ) -> _NominalInterpretation | None:
        head_id = head.nominal.lexeme_id
        head_lexeme = (
            self._lexeme_by_id.get(head_id)
            if head_id is not None
            else None
        )
        if head_lexeme is None or head_lexeme.category != "noun":
            return None

        qualitative = tuple(
            modifier
            for modifier in modifiers
            if modifier.kind == "qualitative"
        )
        constitution = tuple(
            modifier
            for modifier in modifiers
            if modifier.kind == "constitution"
        )
        trace = [
            "english.noun-phrase.longest-lexical-head",
            *head.rule_trace,
        ]
        assumptions = list(head.assumptions)
        ambiguities = list(head.ambiguities)

        base = head_lexeme.surface_form
        if constitution:
            roots: list[str] = []
            for modifier in constitution:
                modifier_id = modifier.nominal.lexeme_id
                modifier_lexeme = (
                    self._lexeme_by_id.get(modifier_id)
                    if modifier_id is not None
                    else None
                )
                if (
                    modifier_lexeme is None
                    or modifier_lexeme.category != "noun"
                ):
                    return None
                roots.append(
                    modifier.constitution_root
                    or modifier_lexeme.surface_form
                )
            generated = compose_ga_compound(tuple(roots), base)
            base = generated.surface
            trace.extend(generated.rule_trace)
            trace.append("noun.ga-compound-from-english-constitution")
            assumptions.append(
                TranslationAssumption(
                    code="GA_COMPOUND_CLASS_FROM_HEAD",
                    message=(
                        "The productive ga compound inherited its provisional "
                        "noun class from the lexical head. Asaxi assigns the "
                        "resulting concept's class semantically, so an "
                        "unattested compound may require review."
                    ),
                )
            )

        if head.nominal.number == "plural":
            try:
                base = pluralize_nominal(base).surface
            except ValueError:
                return None

        adjective_nominals: list[Nominal] = []
        adjective_surfaces: list[str] = []
        for index, modifier in enumerate(qualitative):
            surface = self._english_adjective_chain_surface(
                modifier.nominal.surface,
                final=index == len(qualitative) - 1,
            )
            if surface is None:
                return None
            adjective_surfaces.append(surface)
            adjective_nominals.append(
                replace(modifier.nominal, surface=surface)
            )
        if qualitative:
            trace.append("adjective-chain.before-head")
            if len(qualitative) > 1:
                trace.append("adjective.nonfinal-chain-reduction")

        determiner: str | None = None
        if frame.determiner in {"a", "an"}:
            determiner = "anő"
        elif frame.determiner == "the":
            noun_class = head.nominal.noun_class
            if noun_class not in {"warm", "cold"}:
                return None
            determiner = "onă" if noun_class == "warm" else "onýj"
            if constitution:
                ambiguities.append(
                    TranslationAmbiguity(
                        code="GA_COMPOUND_CLASS_REQUIRES_REVIEW",
                        message=(
                            "The definite determiner uses the lexical head's "
                            "class provisionally; an established compound "
                            "entry may assign another semantic class."
                        ),
                        choices=("warm", "cold"),
                        selected=noun_class,
                    )
                )

        surface = " ".join(
            (
                *((determiner,) if determiner else ()),
                *adjective_surfaces,
                base,
            )
        )
        for modifier in modifiers:
            assumptions.extend(modifier.assumptions)
            ambiguities.extend(modifier.ambiguities)
            trace.extend(modifier.rule_trace)

        modifier_indexes = tuple(
            index
            for modifier in modifiers
            for index in modifier.source_indexes
        )
        return _NominalInterpretation(
            nominal=Nominal(
                surface=surface,
                lexeme_id=head_lexeme.identifier,
                noun_class=head.nominal.noun_class,
                determiner=frame.determiner,
                number=head.nominal.number,
                modifiers=(
                    *adjective_nominals,
                    *(
                        modifier.nominal
                        for modifier in constitution
                    ),
                ),
            ),
            english_text=english_text,
            assumptions=tuple(assumptions),
            ambiguities=tuple(ambiguities),
            rule_trace=tuple(trace),
            source_roles=self._english_nominal_source_roles(
                frame,
                role=role,
                modifier_indexes=modifier_indexes,
                head_indexes=head_indexes,
            ),
        )

    @staticmethod
    def _english_adjective_chain_surface(
        surface: str,
        *,
        final: bool,
    ) -> str | None:
        if final:
            return surface
        if surface.endswith("nă"):
            return surface[:-2] + "na"
        if surface.endswith("nýj"):
            return surface[:-3] + "ný"
        return None

    def _english_possessor_options(
        self,
        possessor: EnglishPossessor,
        tokens: tuple[_RawToken, ...],
    ) -> tuple[_NominalInterpretation, ...]:
        frame = EnglishNominalFrame(
            source_indexes=possessor.source_indexes,
            head=possessor.term.casefold(),
            head_indexes=possessor.source_indexes,
            proper_name=possessor.proper_name,
        )
        english_text = " ".join(
            token.surface
            for token in tokens
            if token.index in possessor.source_indexes
        )
        return self._english_frame_head_options(
            frame,
            english_text,
            role="possessor",
        )

    def _english_frame_head_options(
        self,
        frame: EnglishNominalFrame,
        english_text: str,
        *,
        role: str,
        allow_thesaurus: bool = True,
    ) -> tuple[_NominalInterpretation, ...]:
        forced_proper_name = (
            frame.proper_name
            and english_text.isupper()
            and len(english_text) > 1
        )
        if forced_proper_name:
            return (
                _NominalInterpretation(
                    nominal=Nominal(frame.head.upper()),
                    english_text=english_text,
                    assumptions=(
                        TranslationAssumption(
                            code="PROPER_NAME_RETAINED_UPPERCASE",
                            message=(
                                "The proper name was retained in capitals "
                                "under Asaxi orthographic convention."
                            ),
                        ),
                    ),
                    rule_trace=("nominal.controlled-proper-name",),
                ),
            )

        categories = (
            (
                ("noun", "particle", "pronoun", "adjective")
                if frame.determiner is not None
                else ("adjective", "noun", "particle", "pronoun")
            )
            if role == "complement"
            else ("noun", "particle", "pronoun")
        )
        candidates = self.lexicon.english_candidates(
            frame.head,
            *categories,
        )
        plural_candidates: list[EnglishLexicalCandidate] = []
        for lexeme in self.database.lexemes:
            if lexeme.category != "noun":
                continue
            for term in split_english_gloss(lexeme):
                if (
                    term.casefold() == frame.head
                    or plural_noun(term) != frame.head
                ):
                    continue
                plural_candidates.append(
                    EnglishLexicalCandidate(
                        lexeme=lexeme,
                        source_term=frame.head,
                        matched_term=term.casefold(),
                        category="noun",
                    )
                )
        if (
            not candidates
            and not plural_candidates
            and frame.proper_name
        ):
            initial_titlecase = (
                min(frame.head_indexes, default=-1) == 0
                and not english_text.isupper()
            )
            return (
                _NominalInterpretation(
                    nominal=Nominal(frame.head.upper()),
                    english_text=english_text,
                    assumptions=(
                        TranslationAssumption(
                            code=(
                                "SENTENCE_INITIAL_TITLECASE_NAME_DEFAULT"
                                if initial_titlecase
                                else "PROPER_NAME_RETAINED_UPPERCASE"
                            ),
                            message=(
                                (
                                    "Sentence-initial title case alone does "
                                    "not prove that this is a proper name. "
                                    "The token was provisionally retained "
                                    "as a capitalized name and remains "
                                    "reviewable."
                                )
                                if initial_titlecase
                                else (
                                    "The proper name was retained in "
                                    "capitals under Asaxi orthographic "
                                    "convention."
                                )
                            ),
                            details=(
                                {
                                    "source_evidence": (
                                        "sentence-initial-titlecase"
                                    ),
                                    "selected_reading": "proper-name",
                                    "other_possible_reading": (
                                        "unresolved-common-noun"
                                    ),
                                }
                                if initial_titlecase
                                else {}
                            ),
                        ),
                    ),
                    rule_trace=(
                        (
                            "nominal.provisional-initial-titlecase-name",
                        )
                        if initial_titlecase
                        else ("nominal.controlled-proper-name",)
                    ),
                ),
            )
        if (
            not candidates
            and not plural_candidates
            and allow_thesaurus
        ):
            candidates = self.lexicon.english_candidates(
                frame.head,
                *categories,
                thesaurus=self.thesaurus,
            )

        records: list[
            tuple[EnglishLexicalCandidate, bool]
        ] = [
            (candidate, True)
            for candidate in plural_candidates
        ]
        records.extend(
            (candidate, False)
            for candidate in candidates
        )
        options: list[_NominalInterpretation] = []
        for candidate, plural in records:
            lexeme = candidate.lexeme
            if not lexeme_allowed_for_nominal_role(lexeme, role):
                continue
            thesaurus = candidate.thesaurus_candidate
            if (
                not plural
                and thesaurus is not None
                and thesaurus.query_lemma is not None
                and plural_noun(thesaurus.query_lemma) == frame.head
            ):
                plural = True
            surface = lexeme.surface_form
            if plural:
                try:
                    surface = pluralize_nominal(lexeme.lemma).surface
                except ValueError:
                    continue
            if frame.determiner in {"a", "an"}:
                if lexeme.category != "noun" or plural:
                    continue
                surface = f"anő {surface}"
            elif frame.determiner == "the":
                if not lexeme.noun_class.is_present:
                    continue
                determiner = (
                    "onă"
                    if lexeme.noun_class.value == "warm"
                    else "onýj"
                )
                surface = f"{determiner} {surface}"

            assumptions: list[TranslationAssumption] = []
            if plural:
                assumptions.append(
                    TranslationAssumption(
                        code="ENGLISH_PLURAL_MORPHOLOGY",
                        message=(
                            f"{frame.head!r} was analyzed as a plural noun "
                            "before lexical fallback."
                        ),
                    )
                )
            if thesaurus is not None:
                assumptions.append(
                    self._thesaurus_assumption(
                        source_term=frame.head,
                        matched_term=candidate.matched_term,
                        candidate=thesaurus,
                        part_of_speech=candidate.category,
                    )
                )
            options.append(
                _NominalInterpretation(
                    nominal=Nominal(
                        surface=surface,
                        lexeme_id=lexeme.identifier,
                        noun_class=(
                            lexeme.noun_class.value
                            if lexeme.noun_class.is_present
                            else None
                        ),
                        determiner=frame.determiner,
                        number="plural" if plural else "singular",
                    ),
                    english_text=english_text,
                    assumptions=tuple(assumptions),
                    rule_trace=(
                        "lexicon.english-nominal",
                        *(
                            ("lexicon.same-pos-thesaurus-fallback",)
                            if thesaurus is not None
                            else ()
                        ),
                    ),
                )
            )
            if len(options) > MAX_ENGLISH_NP_OPTIONS:
                break

        if len(options) > MAX_ENGLISH_NP_OPTIONS:
            options = list(
                self._mark_nominal_analysis_limit(
                    options[:MAX_ENGLISH_NP_OPTIONS],
                    scope="nominal-head-options",
                )
            )

        if len(options) < 2:
            return tuple(options)
        choices = tuple(
            f"{option.nominal.surface} "
            f"[{option.nominal.lexeme_id or 'retained'}]"
            for option in options
        )
        return tuple(
            replace(
                option,
                ambiguities=(
                    *option.ambiguities,
                    TranslationAmbiguity(
                        code="ENGLISH_NOMINAL_AMBIGUOUS",
                        message=(
                            "The English nominal has multiple documented "
                            "Asaxi lexical analyses."
                        ),
                        choices=choices,
                        selected=choices[index],
                    ),
                ),
            )
            for index, option in enumerate(options)
        )

    def _english_predicate_options(
        self,
        source_term: str,
        *,
        forced_tense: Tense | None,
        polarity: Polarity,
    ) -> tuple[_EnglishPredicateInterpretation, ...]:
        """Resolve one English predicate with inspectable lexical provenance."""

        verb_matches = self.lexicon.english_verb_matches(
            source_term,
            thesaurus=self.thesaurus,
        )
        if not verb_matches:
            return ()

        resolved_matches: list[
            tuple[EnglishVerbMatch, VerbalDerivation | None]
        ] = []
        for match in verb_matches:
            if match.explicit_derived_term:
                derivation = (
                    self.expanded_clause_parser
                    .explicit_derived_verbal_derivation(
                        match.lexeme,
                        match.asaxi_surface,
                    )
                )
                if derivation is None:
                    continue
            else:
                derivation = (
                    self.expanded_clause_parser.lexical_verbal_derivation(
                        match.lexeme
                    )
                )
            resolved_matches.append((match, derivation))
        if not resolved_matches:
            return ()

        lexical_choices = tuple(
            sorted(
                {
                    f"{match.base} -> {match.asaxi_surface}"
                    for match, _derivation in resolved_matches
                }
            )
        )
        options: list[_EnglishPredicateInterpretation] = []
        for match, derivation in resolved_matches:
            ambiguity: tuple[TranslationAmbiguity, ...] = ()
            if len(lexical_choices) > 1:
                ambiguity = (
                    TranslationAmbiguity(
                        code="ENGLISH_VERB_AMBIGUOUS",
                        message=(
                            "The English verb form has multiple documented "
                            "lexical or tense analyses."
                        ),
                        choices=lexical_choices,
                        selected=(
                            f"{match.base} -> {match.asaxi_surface}"
                        ),
                    ),
                )
            assumptions: tuple[TranslationAssumption, ...] = ()
            if match.thesaurus_candidate is not None:
                assumptions = (
                    self._thesaurus_assumption(
                        source_term=source_term,
                        matched_term=match.base,
                        candidate=match.thesaurus_candidate,
                        part_of_speech="verb",
                    ),
                )
            options.append(
                _EnglishPredicateInterpretation(
                    lexeme=match.lexeme,
                    base=match.base,
                    surface=match.asaxi_surface,
                    tense=(
                        forced_tense
                        if forced_tense is not None
                        else Tense(match.tense_hint)
                    ),
                    polarity=polarity,
                    verbal_derivation=derivation,
                    explicit_derived_term=match.explicit_derived_term,
                    assumptions=assumptions,
                    ambiguities=ambiguity,
                    rule_trace=(
                        (
                            "english.controlled-auxiliary"
                            if forced_tense is not None
                            else "english.inflected-verb-form"
                        ),
                        *(
                            ("lexicon.same-pos-thesaurus-fallback",)
                            if match.thesaurus_candidate is not None
                            else ()
                        ),
                        *(
                            (
                                "clause.explicit-derived-term",
                                "lexicon.explicit-derived-term-gloss",
                            )
                            if match.explicit_derived_term
                            else ()
                        ),
                    ),
                )
            )

        unique: list[_EnglishPredicateInterpretation] = []
        seen: set[tuple[object, ...]] = set()
        for item in options:
            provenance = tuple(
                repr(assumption.to_dict())
                for assumption in item.assumptions
            )
            key = (
                item.lexeme.identifier,
                item.base,
                item.surface,
                item.tense,
                item.polarity,
                item.explicit_derived_term,
                provenance,
            )
            if key in seen:
                continue
            seen.add(key)
            unique.append(item)
        if len(unique) > MAX_ENGLISH_NP_OPTIONS:
            unique = list(
                self._mark_predicate_analysis_limit(
                    unique[:MAX_ENGLISH_NP_OPTIONS],
                    scope="predicate-options",
                )
            )
        return tuple(unique)

    def _thesaurus_assumption(
        self,
        *,
        source_term: str,
        matched_term: str,
        candidate: ThesaurusCandidate,
        part_of_speech: str,
    ) -> TranslationAssumption:
        return TranslationAssumption(
            code="THESAURUS_SYNONYM_FALLBACK",
            message=(
                f"No direct documented Asaxi gloss matched {source_term!r}; "
                f"{matched_term!r} was used as a same-{part_of_speech} "
                f"synonym from {candidate.provider}."
            ),
            details={
                "source_term": source_term,
                "matched_term": matched_term,
                "part_of_speech": part_of_speech,
                "provider": candidate.provider,
                "provider_version": candidate.provider_version,
                "relation": candidate.relation,
                "sense_id": candidate.sense_id,
                "query_lemma": candidate.query_lemma,
            },
        )

    @staticmethod
    def _remove_english_article(text: str) -> str:
        lowered = text.casefold()
        for article in ("a ", "an ", "the ", "this ", "that "):
            if lowered.startswith(article):
                return text[len(article):]
        return text

    def _fallback_asaxi_predicate_text(
        self,
        reading: object,
        subject_hint: str | None,
        *,
        diagnostic_code: str | None = None,
    ) -> tuple[str, tuple[str, ...]]:
        """Render one independently recognized predicate without attachment.

        The fallback only commits to morphology encoded in the predicate form.
        It does not decide which surrounding nominal is an argument.
        """

        glosses = tuple(dict.fromkeys(reading.english_glosses))
        base = glosses[0] if glosses else reading.surface
        subject = subject_hint or "they"
        directive = reading.directive_form
        if directive is not None:
            gerund = present_participle_phrase(base)
            phrase = {
                DirectiveKind.COMMAND: f"must {base}",
                DirectiveKind.PROHIBITION: f"must not {base}",
                DirectiveKind.ABSOLUTE_PROHIBITION: (
                    f"must never {base}"
                ),
                DirectiveKind.REQUEST: f"is requested to {base}",
                DirectiveKind.INSTRUCTION: f"is instructed to {base}",
                DirectiveKind.POLITE_PROHIBITION: (
                    f"is requested not to {base}"
                ),
                DirectiveKind.CESSATION: f"must stop {gerund}",
                DirectiveKind.CONTINUATION: f"must continue {gerund}",
                DirectiveKind.SWITCH: f"must {base} now",
                DirectiveKind.HORTATIVE: f"should {base} with us",
                DirectiveKind.POLITE_HORTATIVE: (
                    f"is invited to {base} with us"
                ),
            }[directive.kind]
            return phrase, glosses

        missing_suffix = ""
        if reading.causative_voice is not None:
            if reading.causative_voice is CausativeVoice.PERMISSIVE:
                base = f"be allowed to {base}"
            elif reading.causative_voice is CausativeVoice.COERCIVE:
                base = f"be forced to {base}"
            else:
                base = (
                    "be prohibited from "
                    + present_participle_phrase(base)
                )
            if diagnostic_code == "CAUSATIVE_CAUSER_REQUIRED":
                missing_suffix = " [missing causer]"
        elif diagnostic_code == "PREDICATE_COMPLEMENT_REQUIRED":
            missing_suffix = " [missing complement]"

        if reading.kind in {
            PredicateKind.IDENTITY,
            PredicateKind.PERFORMANCE,
            PredicateKind.CONSTITUTION,
            PredicateKind.LOCATION,
        } and not base.startswith("be"):
            base = "be " + base

        if base == "be" or base.startswith("be "):
            complement = base[2:].strip()
            if reading.tense is Tense.FUTURE:
                finite = "will "
                if reading.polarity is Polarity.NEGATIVE:
                    finite += "not "
                finite += "be"
            elif reading.tense is Tense.PAST:
                normalized = subject.casefold()
                finite = (
                    "were"
                    if normalized in {"you", "we", "they"}
                    or " and " in normalized
                    else "was"
                )
                if reading.polarity is Polarity.NEGATIVE:
                    finite += " not"
            else:
                finite = self.expanded_clause_parser._present_be(subject)
                if reading.polarity is Polarity.NEGATIVE:
                    finite += " not"
            return (
                f"{finite} {complement}{missing_suffix}".strip(),
                glosses,
            )

        finite = self.expanded_clause_parser._finite_predicate(
            base,
            reading,
            subject,
        )
        return finite + missing_suffix, glosses

    def _best_effort_asaxi_to_english(
        self,
        text: str,
        *,
        blocked_token_indices: frozenset[int] = frozenset(),
        primary_diagnostic_code: str | None = None,
    ) -> tuple[str, TranslationDiagnostic]:
        """Gloss every recoverable Asaxi form when full syntax is unresolved.

        Source order is deliberately retained. Reordering fragments into an
        English clause would amount to choosing roles and attachments that the
        documented parser could not establish. Unknown forms are uppercased so
        translated and retained material cannot be mistaken for one another.
        """

        tokens = _tokenize(text)
        word_tokens = tuple(token for token in tokens if token.kind == "word")
        last_word_index = word_tokens[-1].index if word_tokens else None
        nominal_chunks = self._fallback_nominal_chunks(
            tokens,
            last_word_index=last_word_index,
        )
        skipped_chunk_indices: set[int] = set()
        subject_pending = False
        subject_hint: str | None = None
        pending_determiner = False
        translated_indices: list[int] = []
        retained_indices: list[int] = []
        punctuation_indices: list[int] = []
        decisions: list[dict[str, object]] = []
        pieces: list[str] = []
        has_question_punctuation = any(
            token.surface == "?" for token in tokens
        )
        question_marker = False

        for token in tokens:
            if token.index in skipped_chunk_indices:
                continue
            if token.kind == "punctuation":
                pieces.append(token.surface)
                punctuation_indices.append(token.index)
                decisions.append(
                    {
                        "token_index": token.index,
                        "source": token.surface,
                        "role": "punctuation",
                        "output": token.surface,
                    }
                )
                continue
            if token.index in blocked_token_indices:
                output = token.surface.upper()
                pieces.append(output)
                retained_indices.append(token.index)
                decisions.append(
                    {
                        "token_index": token.index,
                        "source": token.surface,
                        "role": "blocked-by-diagnostic",
                        "output": output,
                        "diagnostic_code": primary_diagnostic_code,
                    }
                )
                if subject_pending:
                    subject_hint = output
                    subject_pending = False
                pending_determiner = False
                continue
            normalized = token.normalized
            if normalized in ASAXI_SUBJECT_MARKERS:
                decisions.append(
                    {
                        "token_index": token.index,
                        "source": token.surface,
                        "role": "subject-marker",
                        "output": "",
                    }
                )
                translated_indices.append(token.index)
                subject_pending = True
                continue
            if normalized == "kè":
                question_marker = True
                translated_indices.append(token.index)
                decisions.append(
                    {
                        "token_index": token.index,
                        "source": token.surface,
                        "role": "interrogative-marker",
                        "output": "?",
                    }
                )
                continue

            chunk = nominal_chunks.get(token.index)
            if chunk is not None:
                reading, chunk_tokens = chunk
                chunk_indices = tuple(item.index for item in chunk_tokens)
                skipped_chunk_indices.update(chunk_indices[1:])
                role = "subject" if subject_pending else "nominal"
                output = reading.english_text
                pieces.append(output)
                translated_indices.extend(chunk_indices)
                for position, item in enumerate(chunk_tokens):
                    decisions.append(
                        {
                            "token_index": item.index,
                            "source": item.surface,
                            "role": f"{role}-construction",
                            "output": output if position == 0 else "",
                            "construction_span": list(chunk_indices),
                            "construction_rules": list(reading.rule_trace),
                        }
                    )
                if subject_pending or subject_hint is None:
                    subject_hint = output
                subject_pending = False
                pending_determiner = False
                continue

            determiner = ASAXI_DETERMINERS.get(normalized)
            if determiner is not None:
                output = {
                    "indefinite": "a",
                    "definite": "the",
                    "specific-indefinite": "a specific",
                }[determiner]
                pieces.append(output)
                pending_determiner = True
                translated_indices.append(token.index)
                decisions.append(
                    {
                        "token_index": token.index,
                        "source": token.surface,
                        "role": "determiner",
                        "output": output,
                    }
                )
                continue

            predicate_readings = (
                self.expanded_clause_parser._all_predicate_readings(normalized)
                if token.index == last_word_index
                else ()
            )
            if predicate_readings:
                output, choices = self._fallback_asaxi_predicate_text(
                    predicate_readings[0],
                    subject_hint,
                    diagnostic_code=primary_diagnostic_code,
                )
                pieces.append(output)
                translated_indices.append(token.index)
                decisions.append(
                    {
                        "token_index": token.index,
                        "source": token.surface,
                        "role": "predicate",
                        "output": output,
                        "choices": list(choices),
                    }
                )
                continue

            connector = CONNECTORS.get(normalized)
            if connector is not None:
                output = CONNECTOR_ENGLISH[connector]
                pieces.append(output)
                translated_indices.append(token.index)
                decisions.append(
                    {
                        "token_index": token.index,
                        "source": token.surface,
                        "role": "clause-connector",
                        "output": output,
                    }
                )
                continue

            case_marker = CASE_MARKERS.get(normalized)
            if case_marker is not None:
                output = case_marker[2][0]
                pieces.append(output)
                translated_indices.append(token.index)
                decisions.append(
                    {
                        "token_index": token.index,
                        "source": token.surface,
                        "role": "case-marker",
                        "output": output,
                        "choices": list(case_marker[2]),
                    }
                )
                continue

            role = "subject" if subject_pending else "nominal"
            parse_role = "subject" if subject_pending else "object"
            nominal_readings = self.expanded_clause_parser._parse_nominal_atom(
                token,
                role=parse_role,
            )
            if not nominal_readings and role == "subject":
                # A dependent pronoun can still be glossed even when its
                # illegal subject position is reported by the primary
                # diagnostic.
                nominal_readings = (
                    self.expanded_clause_parser._parse_nominal_atom(
                        token,
                        role="object",
                    )
                )
            if nominal_readings:
                choices = tuple(
                    dict.fromkeys(
                        reading.english_text for reading in nominal_readings
                    )
                )
                output = choices[0]
                if pending_determiner:
                    output = self._remove_english_article(output)
                pieces.append(output)
                translated_indices.append(token.index)
                decisions.append(
                    {
                        "token_index": token.index,
                        "source": token.surface,
                        "role": role,
                        "output": output,
                        "choices": list(choices),
                    }
                )
                if subject_pending or subject_hint is None:
                    subject_hint = output
                if subject_pending:
                    subject_pending = False
                pending_determiner = False
                continue

            analyses = self.morphology.analyze(normalized)
            lexemes: dict[str, Lexeme] = {
                lexeme.identifier: lexeme
                for lexeme in self.lexicon.by_surface.get(normalized, ())
            }
            for analysis in analyses:
                if analysis.lexeme_id is None:
                    continue
                lexeme = self._lexeme_by_id.get(analysis.lexeme_id)
                if lexeme is not None:
                    lexemes.setdefault(lexeme.identifier, lexeme)
            lexical_choices = tuple(
                dict.fromkeys(
                    gloss
                    for lexeme in lexemes.values()
                    for gloss in split_english_gloss(lexeme)
                )
            )
            if lexical_choices:
                output = lexical_choices[0]
                if _is_plural_analysis(analyses):
                    output = plural_noun(output)
                if pending_determiner:
                    output = self._remove_english_article(output)
                pieces.append(output)
                translated_indices.append(token.index)
                decisions.append(
                    {
                        "token_index": token.index,
                        "source": token.surface,
                        "role": role,
                        "output": output,
                        "choices": list(lexical_choices),
                    }
                )
                if subject_pending or subject_hint is None:
                    subject_hint = output
                if subject_pending:
                    subject_pending = False
                pending_determiner = False
                continue

            output = (
                token.surface[:1].upper() + token.surface[1:].lower()
                if token.surface.isupper()
                else token.surface.upper()
            )
            pieces.append(output)
            retained_indices.append(token.index)
            decisions.append(
                {
                    "token_index": token.index,
                    "source": token.surface,
                    "role": "unresolved",
                    "output": output,
                }
            )
            if subject_pending or subject_hint is None:
                subject_hint = output
            if subject_pending:
                subject_pending = False
            pending_determiner = False

        fallback = _render_fallback_pieces(pieces)
        if question_marker and not has_question_punctuation:
            fallback += "?"
        fallback = _capitalize(fallback) if fallback else text
        return fallback, TranslationDiagnostic(
            code="BEST_EFFORT_ASAXI_GLOSS",
            severity=Severity.WARNING,
            message=(
                "A complete documented clause analysis was unavailable. "
                "Recognized anchored constituents, words, and morphology "
                "were translated in source order; untranslated forms remain "
                "visibly capitalized, and no unresolved attachment was "
                "silently selected."
            ),
            details={
                "strategy": (
                    "source-order-anchored-construction-and-lexical-gloss"
                ),
                "translated_token_indices": translated_indices,
                "retained_token_indices": retained_indices,
                "punctuation_token_indices": punctuation_indices,
                "covered_token_indices": sorted(
                    (
                        *translated_indices,
                        *retained_indices,
                        *punctuation_indices,
                    )
                ),
                "decisions": decisions,
            },
        )

    def _fallback_nominal_chunks(
        self,
        tokens: tuple[_RawToken, ...],
        *,
        last_word_index: int | None,
    ) -> dict[int, tuple[object, tuple[_RawToken, ...]]]:
        """Find maximal source-grounded NPs for conservative partial transfer.

        Free head-final adjacency is intentionally excluded here: in a failed
        clause it could swallow a subject and object into one guessed NP.
        Only constructions carrying an overt anchor (determiner, genitive,
        coordination, relative clause, extent, or productive nominal prefix)
        may replace token-by-token glossing.
        """

        anchored_rules = (
            "noun.determiner-anchor",
            "noun.genitive-possession",
            "noun.coordination-ja",
            "noun.relative-clause-prenominal",
            "noun.extent.",
            "noun.attainable-ono-prefix",
        )
        words = tuple(
            token
            for token in tokens
            if token.kind in {"word", "number"}
            and token.index != last_word_index
        )
        chunks: dict[int, tuple[object, tuple[_RawToken, ...]]] = {}
        for start in range(len(words)):
            # Punctuation creates a hard boundary. Eight tokens is generous
            # for the documented anchored NPs while keeping fallback latency
            # bounded on large documents.
            maximum = min(len(words), start + 8)
            for end in range(maximum, start + 1, -1):
                span = words[start:end]
                if any(
                    right.index != left.index + 1
                    for left, right in zip(span, span[1:])
                ):
                    continue
                readings = self.expanded_clause_parser._parse_nominal_span(
                    span,
                    role="object",
                )
                anchored = tuple(
                    reading
                    for reading in readings
                    if any(
                        trace == anchor or trace.startswith(anchor)
                        for trace in reading.rule_trace
                        for anchor in anchored_rules
                    )
                )
                if not anchored:
                    continue
                selected = min(
                    anchored,
                    key=lambda reading: (
                        reading.structural_cost,
                        reading.english_text.casefold(),
                    ),
                )
                chunks[span[0].index] = (selected, span)
                break
        return chunks

    def _best_effort_english_to_asaxi(
        self,
        text: str,
    ) -> tuple[str, TranslationDiagnostic]:
        """Translate known lexical material while visibly retaining gaps.

        This is deliberately separate from the canonical parser. Recognized
        source syntax is transferred first; only wholly unparsed input retains
        English order. In either mode, unresolved lexical material stays
        uppercase and the diagnostic makes the limitation explicit.
        """

        tokens = _tokenize_english(text)
        words = tuple(
            EnglishInputToken(
                index=token.index,
                surface=token.surface,
                normalized=token.normalized,
            )
            for token in tokens
            if token.kind != "punctuation"
        )
        structural = self._best_effort_structural_english_to_asaxi(
            tokens,
            self.english_frontend.parse(
                words,
                directive_hint=any(
                    token.surface == "!" for token in tokens
                ),
            ),
        )
        if structural is not None:
            return structural

        decisions: list[_FallbackDecision] = []
        position = 0
        while position < len(tokens):
            token = tokens[position]
            if token.kind == "punctuation":
                decisions.append(
                    _FallbackDecision(
                        token_indexes=(token.index,),
                        source_text=token.surface,
                        output_text=token.surface,
                        state="retained",
                        reason="punctuation",
                    )
                )
                position += 1
                continue
            if token.kind == "number":
                decisions.append(
                    _FallbackDecision(
                        token_indexes=(token.index,),
                        source_text=token.surface,
                        output_text=token.surface,
                        state="retained",
                        reason="number",
                    )
                )
                position += 1
                continue

            auxiliary = self._fallback_auxiliary_predicate(
                tokens,
                position,
            )
            if auxiliary is not None:
                decision, position = auxiliary
                decisions.append(decision)
                continue

            possessor_term = POSSESSIVE_DETERMINERS.get(
                token.normalized
            )
            if possessor_term is not None:
                options = self._english_possessor_options(
                    EnglishPossessor(
                        source_indexes=(token.index,),
                        term=possessor_term,
                    ),
                    tokens,
                )
                if options:
                    decisions.append(
                        _FallbackDecision(
                            token_indexes=(token.index,),
                            source_text=token.surface,
                            output_text=(
                                f"sè {options[0].nominal.surface}"
                            ),
                            state="translated",
                            reason="documented-genitive-possessor",
                        )
                    )
                else:
                    decisions.append(
                        _FallbackDecision(
                            token_indexes=(token.index,),
                            source_text=token.surface,
                            output_text=token.surface.upper(),
                            state="untranslated",
                            reason="possessive-determiner-unresolved",
                        )
                    )
                position += 1
                continue

            if token.normalized in {"a", "an"}:
                decisions.append(
                    _FallbackDecision(
                        token_indexes=(token.index,),
                        source_text=token.surface,
                        output_text="anő",
                        state="translated",
                        reason="indefinite-article",
                    )
                )
                position += 1
                continue
            if token.normalized == "the":
                determiner = self._fallback_definite_determiner(
                    tokens,
                    position + 1,
                )
                if determiner is not None:
                    decisions.append(
                        _FallbackDecision(
                            token_indexes=(token.index,),
                            source_text=token.surface,
                            output_text=determiner,
                            state="translated",
                            reason="noun-class-determined-article",
                        )
                    )
                else:
                    decisions.append(
                        _FallbackDecision(
                            token_indexes=(token.index,),
                            source_text=token.surface,
                            output_text=token.surface.upper(),
                            state="untranslated",
                            reason="noun-class-not-determined",
                        )
                    )
                position += 1
                continue

            phrase = self._fallback_lexical_phrase(tokens, position)
            if phrase is not None:
                decision, position = phrase
                decisions.append(decision)
                continue

            plural = self._fallback_plural_nominal(token)
            if plural is not None:
                decisions.append(
                    _FallbackDecision(
                        token_indexes=(token.index,),
                        source_text=token.surface,
                        output_text=plural,
                        state="translated",
                        reason="documented-plural-nominal",
                    )
                )
                position += 1
                continue

            verb_matches = self.lexicon.english_verb_forms.get(
                token.normalized,
                (),
            )
            if verb_matches:
                match = verb_matches[0]
                surface, _trace = realize_predicate(
                    match.asaxi_surface,
                    tense=Tense(match.tense_hint),
                    polarity=Polarity.POSITIVE,
                )
                decisions.append(
                    _FallbackDecision(
                        token_indexes=(token.index,),
                        source_text=token.surface,
                        output_text=surface,
                        state="translated",
                        reason="documented-inflected-verb",
                    )
                )
                position += 1
                continue

            if token.surface[:1].isupper():
                decisions.append(
                    _FallbackDecision(
                        token_indexes=(token.index,),
                        source_text=token.surface,
                        output_text=token.surface.upper(),
                        state="retained",
                        reason="proper-name-convention",
                    )
                )
            else:
                decisions.append(
                    _FallbackDecision(
                        token_indexes=(token.index,),
                        source_text=token.surface,
                        output_text=token.surface.upper(),
                        state="untranslated",
                        reason="no-documented-lexical-match",
                    )
                )
            position += 1

        output = _render_fallback_pieces(
            decision.output_text for decision in decisions
        )
        untranslated = [
            index
            for decision in decisions
            if decision.state == "untranslated"
            for index in decision.token_indexes
        ]
        translated = [
            index
            for decision in decisions
            if decision.state == "translated"
            for index in decision.token_indexes
        ]
        diagnostic = TranslationDiagnostic(
            code="BEST_EFFORT_LEXICAL_FALLBACK",
            severity=Severity.WARNING,
            message=(
                "A conservative word-by-word fallback was produced. "
                "CAPITALIZED material was retained rather than translated "
                "(proper names are uppercase by convention); review the "
                "result because English word order was retained."
            ),
            details={
                "mode": "lexical-token-substitution",
                "translated_token_indexes": translated,
                "untranslated_token_indexes": untranslated,
                "decisions": [
                    decision.to_dict() for decision in decisions
                ],
            },
        )
        return output, diagnostic

    def _best_effort_structural_english_to_asaxi(
        self,
        tokens: tuple[_RawToken, ...],
        frames: tuple[EnglishStructuralFrame, ...],
    ) -> tuple[str, TranslationDiagnostic] | None:
        """Retain lexical gaps while preserving recognized target syntax."""

        if not frames:
            return None
        frame: EnglishStructuralFrame
        if isinstance(frames[0], EnglishActionFrame):
            action_frames = tuple(
                candidate
                for candidate in frames
                if isinstance(candidate, EnglishActionFrame)
            )
            recognized = tuple(
                candidate
                for candidate in action_frames
                if self._english_predicate_options(
                    candidate.predicate,
                    forced_tense=candidate.tense,
                    polarity=candidate.polarity,
                )
            )
            ranked = (
                self._rank_declarative_action_frames(recognized, tokens)
                if recognized
                else self._rank_fallback_action_frames(
                    action_frames,
                    tokens,
                )
            )
            if not ranked:
                return None
            frame = ranked[0]
        elif isinstance(
            frames[0],
            (EnglishClauseFrame, EnglishSpatialClauseFrame),
        ):
            frame = frames[0]
        else:
            return None

        source_by_index = {token.index: token for token in tokens}
        decisions: list[_FallbackDecision] = []
        subject, subject_decisions = self._fallback_structural_nominal(
            frame.subject,
            tokens,
            role="subject",
        )
        decisions.extend(subject_decisions)
        subject_marked = frame.subject.quantifier is None
        complement: str | None = None
        oblique_surfaces: tuple[str, ...] = ()
        predicate: str
        if isinstance(frame, EnglishSpatialClauseFrame):
            complement, complement_decisions = (
                self._fallback_structural_nominal(
                    frame.location,
                    tokens,
                    role="object",
                )
            )
            decisions.extend(complement_decisions)
            physicality = self._spatial_landmark_physicality(
                frame.location
            )
            if physicality != SPATIAL_PHYSICAL:
                relation_tokens = tuple(
                    source_by_index[index]
                    for index in frame.relation_indexes
                    if index in source_by_index
                )
                relation_source = " ".join(
                    token.surface for token in relation_tokens
                )
                predicate = self._realize_retained_predicate(
                    relation_source,
                    tense=frame.tense,
                    polarity=frame.polarity,
                )
                decisions.append(
                    _FallbackDecision(
                        token_indexes=frame.relation_indexes,
                        source_text=relation_source,
                        output_text=predicate,
                        state="untranslated",
                        reason=(
                            "abstract-spatial-relation-requires-npcp"
                            if physicality == SPATIAL_ABSTRACT
                            else "spatial-physicality-not-established"
                        ),
                    )
                )
            else:
                predicate_root = ASAXI_SPATIAL_PREDICATES[
                    frame.relation
                ]
                predicate, _ = realize_predicate(
                    predicate_root,
                    tense=frame.tense,
                    polarity=frame.polarity,
                )
        elif isinstance(frame, EnglishClauseFrame):
            role = (
                "location"
                if frame.complement.locative is not None
                else "complement"
            )
            complement, complement_decisions = (
                self._fallback_structural_nominal(
                    frame.complement,
                    tokens,
                    role=role,
                )
            )
            decisions.extend(complement_decisions)
            predicate_root = (
                "bů"
                if frame.complement.locative is not None
                else "xiŕa"
            )
            predicate, _ = realize_predicate(
                predicate_root,
                tense=frame.tense,
                polarity=frame.polarity,
            )
        else:
            object_surface: str | None = None
            if frame.object is not None:
                object_surface, object_decisions = (
                    self._fallback_structural_nominal(
                        frame.object,
                        tokens,
                        role="object",
                    )
                )
                decisions.extend(object_decisions)
            complement = object_surface
            predicate_options = self._english_predicate_options(
                frame.predicate,
                forced_tense=frame.tense,
                polarity=frame.polarity,
            )
            rendered_obliques: list[str] = []
            predicate_base = (
                predicate_options[0].base
                if predicate_options
                else frame.predicate
            )
            for oblique in frame.obliques:
                nominal_surface, nominal_decisions = (
                    self._fallback_structural_nominal(
                        oblique.nominal,
                        tokens,
                        role="oblique",
                    )
                )
                decisions.extend(nominal_decisions)
                relation = self._fallback_oblique_relation(
                    oblique.kind,
                    predicate_base,
                )
                marker = ASAXI_CASE_MARKER_BY_RELATION[relation]
                rendered_obliques.append(
                    f"{marker} {nominal_surface}"
                )
                decisions.append(
                    _FallbackDecision(
                        token_indexes=oblique.marker_indexes,
                        source_text=" ".join(
                            source_by_index[index].surface
                            for index in oblique.marker_indexes
                            if index in source_by_index
                        ),
                        output_text=marker,
                        state="translated",
                        reason=(
                            f"structural-oblique-{relation.value}"
                        ),
                    )
                )
            oblique_surfaces = tuple(rendered_obliques)
            predicate_tokens = tuple(
                source_by_index[index]
                for index in frame.predicate_indexes
                if index in source_by_index
            )
            predicate_source = " ".join(
                token.surface for token in predicate_tokens
            )
            if predicate_options:
                predicate_option = predicate_options[0]
                predicate, _ = realize_predicate(
                    predicate_option.lexeme.lemma,
                    tense=predicate_option.tense,
                    polarity=predicate_option.polarity,
                )
                predicate_state = "translated"
                predicate_reason = "documented-structural-predicate"
            else:
                inferred_regular_past = (
                    frame.tense is None
                    and self._has_regular_past_surface(predicate_source)
                )
                fallback_tense = (
                    Tense.PAST
                    if inferred_regular_past
                    else frame.tense or Tense.NONPAST
                )
                predicate = self._realize_retained_predicate(
                    predicate_source,
                    tense=fallback_tense,
                    polarity=frame.polarity,
                )
                predicate_state = "untranslated"
                predicate_reason = (
                    "unresolved-predicate-with-"
                    + (
                        "provisional-regular-past-"
                        if inferred_regular_past
                        else ""
                    )
                    + f"{fallback_tense.value}-"
                    f"{frame.polarity.value}-grammar"
                )
            decisions.append(
                _FallbackDecision(
                    token_indexes=frame.predicate_indexes,
                    source_text=predicate_source,
                    output_text=predicate,
                    state=predicate_state,
                    reason=predicate_reason,
                )
            )

        grammatical_indexes = {
            index
            for index, role in frame.role_by_index
            if (
                role
                in {
                    "auxiliary",
                    "copula",
                    "future-auxiliary",
                    "negation",
                    "progressive-auxiliary",
                    "spatial-relation",
                }
                or role.startswith("wh-")
            )
        }
        covered = {
            index
            for decision in decisions
            for index in decision.token_indexes
        }
        for index in sorted(grammatical_indexes - covered):
            token = source_by_index.get(index)
            if token is None:
                continue
            decisions.append(
                _FallbackDecision(
                    token_indexes=(index,),
                    source_text=token.surface,
                    output_text="",
                    state="translated",
                    reason="structural-function-word",
                )
            )

        output = self._render_structural_fallback_clause(
            subject=subject,
            obliques=oblique_surfaces,
            complement=complement,
            predicate=predicate,
            subject_marked=subject_marked,
            interrogative=(
                frame.interrogative
                or any(
                    token.surface == "?"
                    for token in tokens
                    if token.kind == "punctuation"
                )
            ),
        )
        untranslated = sorted(
            {
                index
                for decision in decisions
                if decision.state == "untranslated"
                for index in decision.token_indexes
            }
        )
        translated = sorted(
            {
                index
                for decision in decisions
                if decision.state in {"translated", "provisional"}
                for index in decision.token_indexes
            }
        )
        provisional = sorted(
            {
                index
                for decision in decisions
                if decision.state == "provisional"
                for index in decision.token_indexes
            }
        )
        return (
            output,
            TranslationDiagnostic(
                code="BEST_EFFORT_STRUCTURAL_FALLBACK",
                severity=Severity.WARNING,
                message=(
                    "Recognized English grammar was transferred into "
                    "predicate-final Asaxi order. CAPITALIZED material has "
                    "no documented target lexeme and remains for review; "
                    "recognized tense and polarity remain visible on an "
                    "unresolved predicate shell."
                ),
                details={
                    "mode": "structural-grammar-fallback",
                    "frame_kind": frame.kind.value,
                    "translated_token_indexes": translated,
                    "untranslated_token_indexes": untranslated,
                    "provisional_token_indexes": provisional,
                    "decisions": [
                        decision.to_dict() for decision in decisions
                    ],
                },
            ),
        )

    @staticmethod
    def _has_regular_past_surface(source: str) -> bool:
        """Return provisional English regular-past evidence for a gap token.

        The untranslated surface is deliberately retained because an unknown
        form such as ``baked`` does not reveal whether its lemma is ``bake`` or
        a hypothetical ``bak``.  The Asaxi past prefix still remains visible,
        and the fallback decision labels this inference as provisional.
        """

        word = source.strip().casefold()
        return bool(
            re.fullmatch(r"[a-z]{2,}(?:ied|ed)", word)
            and word not in {"bed", "need", "red", "shed"}
        )

    @staticmethod
    def _realize_retained_predicate(
        source: str,
        *,
        tense: Tense,
        polarity: Polarity,
    ) -> str:
        """Expose target grammar without claiming an unknown target lexeme."""

        retained = source.strip().upper()
        if tense is Tense.NONPAST:
            return (
                retained
                if polarity is Polarity.POSITIVE
                else f"{retained}ná"
            )
        prefix = "zè" if tense is Tense.PAST else "pa"
        if polarity is Polarity.NEGATIVE:
            prefix += "ná"
        return prefix + retained

    def _rank_fallback_action_frames(
        self,
        frames: tuple[EnglishActionFrame, ...],
        tokens: tuple[_RawToken, ...],
    ) -> tuple[EnglishActionFrame, ...]:
        """Rank unresolved SVO analyses using source-grammar evidence.

        The frontend enumerates possible predicate positions without consulting
        the Asaxi lexicon. This fallback ranking therefore uses only English
        closed-class and finite-form evidence. It never turns an unknown word
        into a target lexeme; it only chooses where the visibly unresolved
        predicate belongs in the target clause.
        """

        by_index = {token.index: token for token in tokens}
        closed_class = {
            *ARTICLES,
            *POSSESSIVE_DETERMINERS,
            *UNIVERSAL_QUANTIFIERS,
            *COPULA_TENSES,
            *DO_AUXILIARIES,
            "and",
            "but",
            "not",
            "or",
            "to",
            "will",
            *ENGLISH_NONPREDICATE_FUNCTION_WORDS,
        }
        ranked: list[tuple[int, int, EnglishActionFrame]] = []
        for index, frame in enumerate(frames):
            predicate_token = by_index.get(frame.predicate_indexes[0])
            if predicate_token is None:
                continue
            predicate = predicate_token.normalized
            score = 0
            if predicate in closed_class:
                score += 100

            # A determiner cleanly starts an object phrase after the finite
            # verb; this is stronger evidence than simply choosing the first
            # word that could be an English nominal head.
            if frame.object is not None:
                object_tokens = tuple(
                    by_index[position]
                    for position in frame.object.source_indexes
                    if position in by_index
                )
                if (
                    object_tokens
                    and object_tokens[0].normalized
                    in {*ARTICLES, *POSSESSIVE_DETERMINERS}
                ):
                    score -= 20
            if frame.obliques:
                score -= 20

            subject_tokens = tuple(
                by_index[position]
                for position in frame.subject.head_indexes
                if position in by_index
            )
            subject_head = (
                subject_tokens[-1].normalized
                if subject_tokens
                else ""
            )
            subject_is_plural = (
                subject_head in {"i", "you", "we", "they"}
                or (
                    subject_head.endswith("s")
                    and not subject_head.endswith(("ss", "us", "is"))
                )
            )
            predicate_is_third_singular = (
                predicate.endswith("s")
                and not predicate.endswith(("ss", "us", "is"))
            )
            if subject_is_plural != predicate_is_third_singular:
                score -= 4
            else:
                score += 4

            if predicate.endswith(("ed", "ing")):
                score -= 3
            ranked.append((score, index, frame))

        ranked.sort(key=lambda item: item[:2])
        if len(ranked) > 1 and ranked[0][0] == ranked[1][0]:
            # A fallback must not manufacture a syntactic decision when the
            # source grammar itself provides no preference.
            return ()
        if ranked:
            best = ranked[0][2]
            object_has_determiner = False
            if best.object is not None:
                object_tokens = tuple(
                    by_index[position]
                    for position in best.object.source_indexes
                    if position in by_index
                )
                object_has_determiner = bool(
                    object_tokens
                    and object_tokens[0].normalized
                    in {*ARTICLES, *POSSESSIVE_DETERMINERS}
                )
            has_strong_source_anchor = (
                best.tense is not None
                or object_has_determiner
                or bool(best.obliques)
            )
            if not has_strong_source_anchor:
                # Agreement alone cannot resolve reduced-relative and other
                # garden-path analyses. Fall back lexically instead of
                # manufacturing one predicate boundary.
                return ()
        return tuple(frame for _, _, frame in ranked)

    def _fallback_structural_nominal(
        self,
        frame: EnglishNominalFrame,
        tokens: tuple[_RawToken, ...],
        *,
        role: str,
    ) -> tuple[str, tuple[_FallbackDecision, ...]]:
        exact = self._english_frame_nominal_options(
            frame,
            tokens,
            role=role,
        )
        source_by_index = {token.index: token for token in tokens}
        source_text = " ".join(
            source_by_index[index].surface
            for index in frame.source_indexes
            if index in source_by_index
        )
        if exact:
            provisional_initial_name = any(
                assumption.code
                == "SENTENCE_INITIAL_TITLECASE_NAME_DEFAULT"
                for option in exact
                for assumption in option.assumptions
            )
            return (
                exact[0].nominal.surface,
                (
                    _FallbackDecision(
                        token_indexes=frame.source_indexes,
                        source_text=source_text,
                        output_text=exact[0].nominal.surface,
                        state=(
                            "provisional"
                            if provisional_initial_name
                            else "translated"
                        ),
                        reason=(
                            "ambiguous-sentence-initial-titlecase"
                            if provisional_initial_name
                            else "documented-structural-nominal"
                        ),
                    ),
                ),
            )

        decisions: list[_FallbackDecision] = []
        pieces: list[str] = []
        quantifier_indexes = (
            set(frame.quantifier.source_indexes)
            if frame.quantifier is not None
            else set()
        )
        if frame.quantifier is not None:
            pieces.append("mămă")
            decisions.append(
                _FallbackDecision(
                    token_indexes=frame.quantifier.source_indexes,
                    source_text=frame.quantifier.source_form,
                    output_text="mămă",
                    state="translated",
                    reason="universal-quantifier",
                )
            )

        possessor_indexes = (
            set(frame.possessor.source_indexes)
            if frame.possessor is not None
            else set()
        )
        if frame.possessor is not None:
            possessor_options = self._english_possessor_options(
                frame.possessor,
                tokens,
            )
            if possessor_options:
                possessor_surface = possessor_options[0].nominal.surface
                pieces.extend(("sè", possessor_surface))
                state = "translated"
                reason = "documented-genitive-possessor"
            else:
                possessor_surface = " ".join(
                    source_by_index[index].surface.upper()
                    for index in frame.possessor.source_indexes
                    if index in source_by_index
                )
                pieces.extend(("sè", possessor_surface))
                state = "untranslated"
                reason = "possessor-not-recognized"
            decisions.append(
                _FallbackDecision(
                    token_indexes=frame.possessor.source_indexes,
                    source_text=" ".join(
                        source_by_index[index].surface
                        for index in frame.possessor.source_indexes
                        if index in source_by_index
                    ),
                    output_text=f"sè {possessor_surface}",
                    state=state,
                    reason=reason,
                )
            )

        head_indexes = set(frame.head_indexes)
        determiner_indexes = (
            set(frame.source_indexes)
            - head_indexes
            - possessor_indexes
            - quantifier_indexes
        )
        for index in sorted(determiner_indexes):
            token = source_by_index.get(index)
            if token is None:
                continue
            if token.normalized in {"a", "an"}:
                output_text = "anő"
                state = "translated"
                reason = "indefinite-article"
            else:
                output_text = token.surface.upper()
                state = "untranslated"
                reason = "noun-class-not-determined"
            pieces.append(output_text)
            decisions.append(
                _FallbackDecision(
                    token_indexes=(index,),
                    source_text=token.surface,
                    output_text=output_text,
                    state=state,
                    reason=reason,
                )
            )

        head_tokens = tuple(
            source_by_index[index]
            for index in frame.head_indexes
            if index in source_by_index
        )
        if frame.proper_name:
            head_surface = " ".join(
                token.surface.upper() for token in head_tokens
            )
            state = "translated"
            reason = "proper-name-convention"
            pieces.append(head_surface)
            decisions.append(
                _FallbackDecision(
                    token_indexes=frame.head_indexes,
                    source_text=" ".join(
                        token.surface for token in head_tokens
                    ),
                    output_text=head_surface,
                    state=state,
                    reason=reason,
                )
            )
        else:
            for head_position, token in enumerate(head_tokens):
                categories = (
                    ("noun", "pronoun", "adjective")
                    if head_position == len(head_tokens) - 1
                    else ("adjective", "noun")
                )
                matches = tuple(
                    lexeme
                    for category in categories
                    for lexeme in self.lexicon.english_matches(
                        token.normalized,
                        category,
                    )
                )
                if matches:
                    output_text = matches[0].surface_form
                    state = "translated"
                    reason = f"documented-{matches[0].category}"
                else:
                    plural = self._fallback_plural_nominal(token)
                    if plural is not None:
                        output_text = plural
                        state = "translated"
                        reason = "documented-plural-noun"
                    else:
                        output_text = token.surface.upper()
                        state = "untranslated"
                        reason = "no-documented-nominal-match"
                pieces.append(output_text)
                decisions.append(
                    _FallbackDecision(
                        token_indexes=(token.index,),
                        source_text=token.surface,
                        output_text=output_text,
                        state=state,
                        reason=reason,
                    )
                )
        return " ".join(piece for piece in pieces if piece), tuple(decisions)

    @staticmethod
    def _fallback_oblique_relation(
        kind: EnglishObliqueKind,
        predicate_base: str,
    ) -> CaseRelation:
        if kind is EnglishObliqueKind.TO:
            return (
                CaseRelation.TRANSFER_DATIVE
                if predicate_base in TRANSFER_ENGLISH_PREDICATES
                else CaseRelation.ALLATIVE
            )
        return {
            EnglishObliqueKind.FROM: CaseRelation.ABLATIVE,
            EnglishObliqueKind.FOR: CaseRelation.DATIVE,
            EnglishObliqueKind.WITH: CaseRelation.COMITATIVE,
            EnglishObliqueKind.UNTIL: CaseRelation.TERMINATIVE,
            EnglishObliqueKind.ABOUT: CaseRelation.TOPICAL,
            EnglishObliqueKind.BY: CaseRelation.INSTRUMENTAL,
        }[kind]

    @staticmethod
    def _render_structural_fallback_clause(
        *,
        subject: str,
        obliques: tuple[str, ...],
        complement: str | None,
        predicate: str,
        subject_marked: bool,
        interrogative: bool,
    ) -> str:
        pieces: list[str] = []
        subject_pieces = subject.split()
        if subject_marked:
            if subject_pieces and subject_pieces[0] in {"onă", "onýj"}:
                pieces.append("to" + subject_pieces[0])
                pieces.extend(subject_pieces[1:])
            else:
                pieces.append("to")
                pieces.extend(subject_pieces)
        else:
            pieces.extend(subject_pieces)
        for oblique in obliques:
            pieces.extend(oblique.split())
        if complement:
            pieces.extend(complement.split())
        pieces.append(predicate)
        if interrogative:
            pieces.append("kè")
        return " ".join(pieces) + ("?" if interrogative else ".")

    def _fallback_auxiliary_predicate(
        self,
        tokens: tuple[_RawToken, ...],
        position: int,
    ) -> tuple[_FallbackDecision, int] | None:
        auxiliary = tokens[position]
        if auxiliary.normalized not in {"do", "does", "did", "will"}:
            return None
        predicate_position = position + 1
        negative = False
        if (
            predicate_position < len(tokens)
            and tokens[predicate_position].normalized == "not"
        ):
            negative = True
            predicate_position += 1
        if (
            predicate_position >= len(tokens)
            or tokens[predicate_position].kind != "word"
        ):
            return None
        predicate = tokens[predicate_position]
        matches = self.lexicon.english_matches(
            predicate.normalized,
            "verb",
        )
        if not matches:
            return None
        tense = {
            "do": Tense.NONPAST,
            "does": Tense.NONPAST,
            "did": Tense.PAST,
            "will": Tense.FUTURE,
        }[auxiliary.normalized]
        surface, _trace = realize_predicate(
            matches[0].lemma,
            tense=tense,
            polarity=(
                Polarity.NEGATIVE
                if negative
                else Polarity.POSITIVE
            ),
        )
        consumed = tokens[position : predicate_position + 1]
        return (
            _FallbackDecision(
                token_indexes=tuple(token.index for token in consumed),
                source_text=" ".join(token.surface for token in consumed),
                output_text=surface,
                state="translated",
                reason="documented-auxiliary-predicate",
            ),
            predicate_position + 1,
        )

    def _fallback_lexical_phrase(
        self,
        tokens: tuple[_RawToken, ...],
        position: int,
    ) -> tuple[_FallbackDecision, int] | None:
        contiguous: list[_RawToken] = []
        for token in tokens[position:]:
            if token.kind != "word":
                break
            contiguous.append(token)
            if len(contiguous) >= self._fallback_phrase_limit:
                break
        for length in range(len(contiguous), 0, -1):
            selected = contiguous[:length]
            term = " ".join(token.normalized for token in selected)
            matches: list[Lexeme] = []
            for category in (
                "particle",
                "pronoun",
                "noun",
                "adjective",
                "adverb",
                "verb",
            ):
                matches.extend(
                    self.lexicon.by_english.get((category, term), ())
                )
            ordered: list[Lexeme] = []
            seen: set[str] = set()
            for lexeme in matches:
                if lexeme.identifier in seen:
                    continue
                seen.add(lexeme.identifier)
                ordered.append(lexeme)
            if not ordered:
                continue
            lexeme = ordered[0]
            return (
                _FallbackDecision(
                    token_indexes=tuple(
                        token.index for token in selected
                    ),
                    source_text=" ".join(
                        token.surface for token in selected
                    ),
                    output_text=lexeme.surface_form,
                    state="translated",
                    reason=f"documented-{lexeme.category}",
                ),
                position + length,
            )
        return None

    def _fallback_plural_nominal(
        self,
        token: _RawToken,
    ) -> str | None:
        for lexeme in self.database.lexemes:
            if lexeme.category != "noun":
                continue
            if not any(
                plural_noun(term) == token.normalized
                for term in split_english_gloss(lexeme)
            ):
                continue
            try:
                return pluralize_nominal(lexeme.lemma).surface
            except ValueError:
                continue
        return None

    def _fallback_definite_determiner(
        self,
        tokens: tuple[_RawToken, ...],
        position: int,
    ) -> str | None:
        if position >= len(tokens) or tokens[position].kind != "word":
            return None
        token = tokens[position]
        matches = self.lexicon.english_matches(
            token.normalized,
            "noun",
        )
        if not matches:
            for lexeme in self.database.lexemes:
                if lexeme.category != "noun":
                    continue
                if any(
                    plural_noun(term) == token.normalized
                    for term in split_english_gloss(lexeme)
                ):
                    matches += (lexeme,)
        classes = sorted(
            {
                lexeme.noun_class.value
                for lexeme in matches
                if lexeme.noun_class.is_present
            }
        )
        if len(classes) != 1:
            return None
        return "onă" if classes[0] == "warm" else "onýj"

    def _parse_controlled_english(
        self,
        words: list[_RawToken],
    ) -> (
        tuple[
            _RawToken,
            tuple[_EnglishPredicateInterpretation, ...],
            tuple[_RawToken, ...],
            bool,
            dict[int, str],
        ]
        | TranslationDiagnostic
    ):
        position = 0
        interrogative = False
        auxiliary: str | None = None
        first = words[0].normalized
        if first in {"do", "does", "did", "will"}:
            interrogative = True
            auxiliary = first
            position += 1
        if position >= len(words):
            return TranslationDiagnostic(
                code="CONTROLLED_CLAUSE_INCOMPLETE",
                severity=Severity.ERROR,
                message="The question has no subject.",
            )
        subject = words[position]
        position += 1
        if auxiliary is None and position < len(words):
            candidate = words[position].normalized
            if candidate in {"do", "does", "did", "will"}:
                auxiliary = candidate
                position += 1
        negative = False
        if (
            auxiliary is not None
            and position < len(words)
            and words[position].normalized == "not"
        ):
            negative = True
            position += 1
        if (
            auxiliary in {"do", "does", "did"}
            and not negative
            and not interrogative
        ):
            return TranslationDiagnostic(
                code="EMPHATIC_AUXILIARY_NOT_SUPPORTED",
                severity=Severity.ERROR,
                message=(
                    "Positive emphatic 'do' is outside controlled English; "
                    "use an ordinary declarative clause."
                ),
                token_index=words[position - 1].index,
            )
        if position >= len(words):
            return TranslationDiagnostic(
                code="PREDICATE_MISSING",
                severity=Severity.ERROR,
                message="The controlled-English clause has no predicate.",
            )
        verb_token = words[position]
        position += 1
        if auxiliary is not None:
            tense = {
                "did": Tense.PAST,
                "will": Tense.FUTURE,
                "do": Tense.NONPAST,
                "does": Tense.NONPAST,
            }[auxiliary]
        else:
            tense = None
        predicate_options = self._english_predicate_options(
            verb_token.normalized,
            forced_tense=tense,
            polarity=(
                Polarity.NEGATIVE
                if negative
                else Polarity.POSITIVE
            ),
        )
        if not predicate_options:
            return TranslationDiagnostic(
                code="ENGLISH_PREDICATE_NOT_RECOGNIZED",
                severity=Severity.ERROR,
                message=(
                    f"No documented Asaxi verb matches "
                    f"{verb_token.surface!r}."
                ),
                token_index=verb_token.index,
            )

        object_tokens = tuple(words[position:])
        if len(object_tokens) > 2 or (
            len(object_tokens) == 2
            and object_tokens[0].normalized not in ENGLISH_ARTICLES
        ):
            return TranslationDiagnostic(
                code="ENGLISH_NOUN_PHRASE_NOT_SUPPORTED",
                severity=Severity.ERROR,
                message=(
                    "Only an optional article plus one object head is "
                    "supported."
                ),
                token_index=object_tokens[0].index,
            )
        role_by_index = {
            subject.index: "subject",
            verb_token.index: "predicate",
        }
        if auxiliary is not None:
            role_by_index[
                words[0].index if interrogative else words[1].index
            ] = "auxiliary"
        if object_tokens:
            role_by_index[object_tokens[-1].index] = "object"
            if len(object_tokens) == 2:
                role_by_index[object_tokens[0].index] = "determiner"
        for word in words:
            if word.normalized == "not":
                role_by_index[word.index] = "negation"
        return (
            subject,
            tuple(predicate_options),
            object_tokens,
            interrogative,
            role_by_index,
        )

    def _asaxi_subject_options(
        self,
        token: _RawToken,
    ) -> tuple[_NominalInterpretation, ...]:
        analyses = self.morphology.analyze(token.normalized)
        lexemes = self.lexicon.by_surface.get(token.normalized, ())
        if not lexemes:
            return (
                _NominalInterpretation(
                    nominal=Nominal(token.normalized),
                    english_text=_capitalize(token.normalized),
                    assumptions=(
                        TranslationAssumption(
                            code="UNKNOWN_SUBJECT_AS_PROPER_NAME",
                            message=(
                                f"{token.surface!r} is not a compiled lexeme; "
                                "it was retained as a proper name."
                            ),
                        ),
                    ),
                    rule_trace=("nominal.unknown-proper-name",),
                ),
            )
        return self._asaxi_nominal_lexeme_options(
            token.normalized,
            analyses,
            lexemes,
            role="subject",
            article=None,
        )

    def _asaxi_object_options(
        self,
        tokens: list[_RawToken],
    ) -> tuple[_NominalInterpretation, ...]:
        if not tokens:
            return ()
        article = (
            ASAXI_DETERMINERS[tokens[0].normalized]
            if len(tokens) == 2
            else None
        )
        head = tokens[-1]
        analyses = self.morphology.analyze(head.normalized)
        lexemes: list[Lexeme] = list(
            self.lexicon.by_surface.get(head.normalized, ())
        )
        for analysis in analyses:
            if analysis.lexeme_id:
                lexemes.extend(
                    lexeme
                    for lexeme in self.database.lexemes
                    if lexeme.identifier == analysis.lexeme_id
                )
        unique = {lexeme.identifier: lexeme for lexeme in lexemes}
        if not unique:
            return ()
        return self._asaxi_nominal_lexeme_options(
            " ".join(token.normalized for token in tokens),
            analyses,
            tuple(unique[key] for key in sorted(unique)),
            role="object",
            article=article,
        )

    def _asaxi_nominal_lexeme_options(
        self,
        surface: str,
        analyses: tuple[MorphologicalAnalysis, ...],
        lexemes: tuple[Lexeme, ...],
        *,
        role: str,
        article: str | None,
    ) -> tuple[_NominalInterpretation, ...]:
        options: list[_NominalInterpretation] = []
        plural = _is_plural_analysis(analyses)
        choice_labels: list[str] = []
        records: list[tuple[Lexeme, str]] = []
        for lexeme in lexemes:
            if not lexeme_allowed_for_nominal_role(lexeme, role):
                continue
            for gloss in split_english_gloss(lexeme):
                records.append((lexeme, gloss))
                choice_labels.append(f"{gloss} [{lexeme.identifier}]")
        choices = tuple(dict.fromkeys(choice_labels))
        for lexeme, gloss in records:
            english = gloss
            if plural and lexeme.category == "noun":
                english = plural_noun(english)
            if role == "object":
                if english.casefold() in OBJECT_PRONOUNS:
                    english = OBJECT_PRONOUNS[english.casefold()]
                elif article == "definite":
                    english = "the " + english
                elif article == "indefinite":
                    english = _indefinite_article(english) + " " + english
                elif not plural and lexeme.category == "noun":
                    english = _indefinite_article(english) + " " + english
            elif role == "subject" and lexeme.category == "noun":
                english = "the " + english

            assumptions: list[TranslationAssumption] = []
            ambiguities: list[TranslationAmbiguity] = []
            if (
                role == "object"
                and article is None
                and not plural
                and lexeme.category == "noun"
            ):
                assumptions.append(
                    TranslationAssumption(
                        code="BARE_OBJECT_INDEFINITE_DEFAULT",
                        message=(
                            "The bare singular object was rendered with an "
                            "English indefinite article; Asaxi permits article "
                            "omission."
                        ),
                    )
                )
                ambiguities.append(
                    TranslationAmbiguity(
                        code="BARE_NOUN_DEFINITENESS",
                        message=(
                            "The Asaxi bare noun does not force one English "
                            "article interpretation."
                        ),
                        choices=("indefinite", "definite", "generic/bare"),
                        selected="indefinite",
                    )
                )
            selected = f"{gloss} [{lexeme.identifier}]"
            if len(choices) > 1:
                ambiguities.append(
                    TranslationAmbiguity(
                        code="NOMINAL_LEXICAL_AMBIGUITY",
                        message=(
                            f"The {role} has multiple compiled English "
                            "interpretations."
                        ),
                        choices=choices,
                        selected=selected,
                    )
                )
            options.append(
                _NominalInterpretation(
                    nominal=Nominal(
                        surface,
                        lexeme_id=lexeme.identifier,
                        noun_class=(
                            lexeme.noun_class.value
                            if lexeme.noun_class.is_present
                            else None
                        ),
                    ),
                    english_text=english,
                    assumptions=tuple(assumptions),
                    ambiguities=tuple(ambiguities),
                    rule_trace=("lexicon.nominal",),
                )
            )
        return tuple(options)

    def _english_subject_options(
        self,
        token: _RawToken,
    ) -> tuple[_NominalInterpretation, ...]:
        candidates = self.lexicon.english_candidates(
            token.normalized,
            "particle",
            "pronoun",
            "noun",
            thesaurus=self.thesaurus,
        )
        candidates = tuple(
            candidate
            for candidate in candidates
            if lexeme_allowed_for_nominal_role(
                candidate.lexeme,
                "subject",
            )
        )
        if candidates:
            choices = tuple(
                (
                    f"{candidate.lexeme.surface_form} "
                    f"[{candidate.lexeme.identifier}]"
                )
                for candidate in candidates
            )
            return tuple(
                _NominalInterpretation(
                    nominal=Nominal(
                        candidate.lexeme.surface_form,
                        lexeme_id=candidate.lexeme.identifier,
                        noun_class=(
                            candidate.lexeme.noun_class.value
                            if candidate.lexeme.noun_class.is_present
                            else None
                        ),
                    ),
                    english_text=token.surface,
                    assumptions=(
                        (
                            self._thesaurus_assumption(
                                source_term=token.normalized,
                                matched_term=candidate.matched_term,
                                candidate=(
                                    candidate.thesaurus_candidate
                                ),
                                part_of_speech=candidate.category,
                            ),
                        )
                        if candidate.thesaurus_candidate is not None
                        else ()
                    ),
                    ambiguities=(
                        (
                            TranslationAmbiguity(
                                code="ENGLISH_SUBJECT_AMBIGUOUS",
                                message=(
                                    "The English subject has multiple "
                                    "documented Asaxi equivalents."
                                ),
                                choices=choices,
                                selected=(
                                    f"{candidate.lexeme.surface_form} "
                                    f"[{candidate.lexeme.identifier}]"
                                ),
                            ),
                        )
                        if len(choices) > 1
                        else ()
                    ),
                    rule_trace=(
                        "lexicon.english-subject",
                        *(
                            ("lexicon.same-pos-thesaurus-fallback",)
                            if candidate.thesaurus_candidate is not None
                            else ()
                        ),
                    ),
                )
                for candidate in candidates
            )
        if token.surface[:1].isupper():
            return (
                _NominalInterpretation(
                    nominal=Nominal(token.surface.upper()),
                    english_text=token.surface,
                    assumptions=(
                        TranslationAssumption(
                            code="PROPER_NAME_RETAINED_UPPERCASE",
                            message=(
                                "The one-word proper name was retained and "
                                "capitalized under Asaxi's proper-name "
                                "convention."
                            ),
                        ),
                    ),
                    rule_trace=("nominal.controlled-proper-name",),
                ),
            )
        return ()

    def _english_object_options(
        self,
        tokens: tuple[_RawToken, ...],
    ) -> tuple[_NominalInterpretation, ...]:
        if not tokens:
            return ()
        article = tokens[0].normalized if len(tokens) == 2 else None
        head = tokens[-1]
        candidates = list(
            self.lexicon.english_candidates(
                head.normalized,
                "noun",
                "particle",
                "pronoun",
            )
        )
        plural_matches: list[EnglishLexicalCandidate] = []
        if not candidates:
            for lexeme in self.database.lexemes:
                if lexeme.category != "noun":
                    continue
                for term in split_english_gloss(lexeme):
                    if plural_noun(term) != head.normalized:
                        continue
                    plural_matches.append(
                        EnglishLexicalCandidate(
                            lexeme=lexeme,
                            source_term=head.normalized,
                            matched_term=term.casefold(),
                            category="noun",
                        )
                    )
        if not candidates and not plural_matches:
            candidates = list(
                self.lexicon.english_candidates(
                    head.normalized,
                    "noun",
                    "particle",
                    "pronoun",
                    thesaurus=self.thesaurus,
                )
            )
        records: list[
            tuple[EnglishLexicalCandidate, str, bool]
        ] = []
        for candidate in candidates:
            records.append(
                (
                    candidate,
                    candidate.lexeme.surface_form,
                    False,
                )
            )
        for candidate in plural_matches:
            try:
                surface = pluralize_nominal(
                    candidate.lexeme.lemma
                ).surface
            except ValueError:
                continue
            records.append((candidate, surface, True))
        options: list[_NominalInterpretation] = []
        for candidate, surface, plural in records:
            lexeme = candidate.lexeme
            assumptions: list[TranslationAssumption] = []
            thesaurus = candidate.thesaurus_candidate
            if (
                thesaurus is not None
                and thesaurus.query_lemma is not None
                and plural_noun(thesaurus.query_lemma)
                == head.normalized
            ):
                try:
                    surface = pluralize_nominal(lexeme.lemma).surface
                    plural = True
                except ValueError:
                    continue
            if thesaurus is not None:
                assumptions.append(
                    self._thesaurus_assumption(
                        source_term=head.normalized,
                        matched_term=candidate.matched_term,
                        candidate=thesaurus,
                        part_of_speech=candidate.category,
                    )
                )
            if article in {"a", "an"}:
                asaxi_surface = f"anő {surface}"
            elif article == "the":
                if not lexeme.noun_class.is_present:
                    continue
                determiner = (
                    "onă"
                    if lexeme.noun_class.value == "warm"
                    else "onýj"
                )
                asaxi_surface = f"{determiner} {surface}"
            else:
                asaxi_surface = surface
                if not plural and lexeme.category == "noun":
                    assumptions.append(
                        TranslationAssumption(
                            code="ENGLISH_BARE_NOUN_RETAINED",
                            message=(
                                "The English bare object was retained without "
                                "an Asaxi determiner."
                            ),
                        )
                    )
            options.append(
                _NominalInterpretation(
                    nominal=Nominal(
                        asaxi_surface,
                        lexeme_id=lexeme.identifier,
                        noun_class=(
                            lexeme.noun_class.value
                            if lexeme.noun_class.is_present
                            else None
                        ),
                    ),
                    english_text=" ".join(
                        token.surface for token in tokens
                    ),
                    assumptions=tuple(assumptions),
                    rule_trace=(
                        "nominal.english-plural"
                        if plural
                        else (
                            "lexicon.same-pos-thesaurus-fallback"
                            if thesaurus is not None
                            else "lexicon.english-nominal"
                        ),
                    ),
                )
            )
        return tuple(options)

    def _render_english(
        self,
        subject: str,
        verb: str,
        object_text: str | None,
        *,
        tense: Tense,
        polarity: Polarity,
        interrogative: bool,
    ) -> str:
        subject_lower = subject.casefold()
        plural_subject = subject_lower in {
            "i",
            "you",
            "we",
            "they",
        }
        object_suffix = f" {object_text}" if object_text else ""
        if interrogative:
            if tense is Tense.FUTURE:
                body = (
                    f"Will {subject} "
                    f"{'not ' if polarity is Polarity.NEGATIVE else ''}"
                    f"{verb}{object_suffix}"
                )
            elif tense is Tense.PAST:
                body = (
                    f"Did {subject} "
                    f"{'not ' if polarity is Polarity.NEGATIVE else ''}"
                    f"{verb}{object_suffix}"
                )
            else:
                auxiliary = "Do" if plural_subject else "Does"
                body = (
                    f"{auxiliary} {subject} "
                    f"{'not ' if polarity is Polarity.NEGATIVE else ''}"
                    f"{verb}{object_suffix}"
                )
            return body + "?"

        if tense is Tense.FUTURE:
            predicate = (
                f"will {'not ' if polarity is Polarity.NEGATIVE else ''}"
                f"{verb}"
            )
        elif tense is Tense.PAST:
            predicate = (
                f"did not {verb}"
                if polarity is Polarity.NEGATIVE
                else past_tense(verb)
            )
        elif polarity is Polarity.NEGATIVE:
            auxiliary = "do" if plural_subject else "does"
            predicate = f"{auxiliary} not {verb}"
        else:
            predicate = (
                verb if plural_subject else present_third_person(verb)
            )
        return _capitalize(
            f"{subject} {predicate}{object_suffix}."
        )

    def _render_tokens(
        self,
        tokens: tuple[_RawToken, ...],
        role_by_index: dict[int, str],
        *,
        source_direction: TranslationDirection,
        predicate: _PredicateCandidate | None = None,
    ) -> tuple[TranslationToken, ...]:
        rendered: list[TranslationToken] = []
        for token in tokens:
            morphology = ()
            if (
                token.kind == "word"
                and source_direction
                is TranslationDirection.ASAXI_TO_ENGLISH
            ):
                morphology = self.morphology.analyze(token.normalized)
            if (
                predicate is not None
                and role_by_index.get(token.index) == "predicate"
            ):
                morphology = (
                    MorphologicalAnalysis(
                        surface=predicate.surface,
                        lemma=predicate.lexeme.lemma,
                        category="verb",
                        features=(
                            ("tense", predicate.tense.value),
                            ("polarity", predicate.polarity.value),
                        ),
                        morphemes=predicate.morphemes,
                        rule_trace=predicate.rule_trace,
                        confidence="rule-confirmed",
                        lexeme_id=predicate.lexeme.identifier,
                    ),
                )
            rendered.append(
                TranslationToken(
                    index=token.index,
                    surface=token.surface,
                    normalized=token.normalized,
                    start=token.start,
                    end=token.end,
                    kind=token.kind,
                    role=role_by_index.get(token.index),
                    morphology=morphology,
                )
            )
        return tuple(rendered)

    @staticmethod
    def _gloss_ambiguity(
        lexeme: Lexeme,
        glosses: tuple[str, ...],
    ) -> TranslationAmbiguity | None:
        if len(glosses) < 2:
            return None
        return TranslationAmbiguity(
            code="UNSPLIT_SOURCE_GLOSS",
            message=(
                f"The source entry for {lexeme.lemma!r} contains multiple "
                "English gloss terms that have not been split into senses."
            ),
            choices=glosses,
            selected=glosses[0],
        )

    def _result(
        self,
        direction: TranslationDirection,
        text: str,
        normalized: str,
        alternatives: list[TranslationAlternative],
    ) -> TranslationResult:
        unique: dict[
            tuple[str, str],
            TranslationAlternative,
        ] = {}
        for alternative in alternatives:
            key = (
                alternative.output_text,
                repr(alternative.canonical_clause.to_dict()),
            )
            existing = unique.get(key)
            if existing is None:
                unique[key] = alternative
                continue

            def merge_records(
                left: tuple[object, ...],
                right: tuple[object, ...],
            ) -> tuple[object, ...]:
                merged: dict[str, object] = {}
                for record in (*left, *right):
                    serialized = getattr(record, "to_dict")()
                    merged.setdefault(repr(serialized), record)
                return tuple(merged.values())

            unique[key] = replace(
                existing,
                assumptions=merge_records(
                    existing.assumptions,
                    alternative.assumptions,
                ),
                ambiguities=merge_records(
                    existing.ambiguities,
                    alternative.ambiguities,
                ),
                rule_trace=tuple(
                    dict.fromkeys(
                        (
                            *existing.rule_trace,
                            *alternative.rule_trace,
                        )
                    )
                ),
            )
        ordered = rank_constructions(unique.values())
        numbered = tuple(
            replace(
                alternative,
                identifier=f"alt-{index:03d}",
            )
            for index, alternative in enumerate(ordered, start=1)
        )
        if not numbered:
            return self._unsupported(
                direction=direction,
                text=text,
                normalized=normalized,
                code="NO_TRANSLATION_ALTERNATIVE",
                message=(
                    "The clause parsed, but no lexical output "
                    "alternative could be generated."
                ),
            )
        ambiguous = len(numbered) > 1 or any(
            alternative.ambiguities for alternative in numbered
        ) or any(
            assumption.code
            in {
                "THESAURUS_SYNONYM_FALLBACK",
                "ANALYSIS_LIMIT_REACHED",
            }
            for alternative in numbered
            for assumption in alternative.assumptions
        )
        return TranslationResult(
            direction=direction,
            input_text=text,
            normalized_input=normalized,
            status=(
                TranslationStatus.AMBIGUOUS
                if ambiguous
                else TranslationStatus.OK
            ),
            alternatives=numbered,
            grammar_model=self.grammar_model,
            selected_alternative_id=numbered[0].identifier,
        )

    def _unsupported(
        self,
        direction: TranslationDirection,
        text: str,
        normalized: str,
        code: str,
        message: str,
        *,
        token_index: int | None = None,
    ) -> TranslationResult:
        return self._unsupported_from_diagnostic(
            direction=direction,
            text=text,
            normalized=normalized,
            diagnostic=TranslationDiagnostic(
                code=code,
                severity=Severity.ERROR,
                message=message,
                token_index=token_index,
            ),
        )

    def _unsupported_from_diagnostic(
        self,
        direction: TranslationDirection,
        text: str,
        normalized: str,
        diagnostic: TranslationDiagnostic,
    ) -> TranslationResult:
        if direction is TranslationDirection.ENGLISH_TO_ASAXI:
            fallback_output, fallback_diagnostic = (
                self._best_effort_english_to_asaxi(text)
            )
            diagnostics = (diagnostic, fallback_diagnostic)
        else:
            retain_diagnostic_token = (
                diagnostic.code.startswith("SOURCE_CONFLICT_")
                or diagnostic.code == "PREDICATE_NOT_RECOGNIZED"
            )
            blocked_token_indices = (
                frozenset({diagnostic.token_index})
                if retain_diagnostic_token
                and diagnostic.token_index is not None
                else frozenset()
            )
            fallback_output, fallback_diagnostic = (
                self._best_effort_asaxi_to_english(
                    text,
                    blocked_token_indices=blocked_token_indices,
                    primary_diagnostic_code=diagnostic.code,
                )
            )
            diagnostic = replace(
                diagnostic,
                details={
                    **diagnostic.details,
                    "best_effort": {
                        "code": fallback_diagnostic.code,
                        "message": fallback_diagnostic.message,
                        **fallback_diagnostic.details,
                    },
                },
            )
            diagnostics = (diagnostic,)
        return TranslationResult(
            direction=direction,
            input_text=text,
            normalized_input=normalized,
            status=TranslationStatus.UNSUPPORTED,
            alternatives=(),
            grammar_model=self.grammar_model,
            fallback_output_text=fallback_output,
            diagnostics=diagnostics,
        )


def translate(
    database: LanguageDatabase,
    text: str,
    direction: TranslationDirection | str,
    *,
    discourse_state: DiscourseState | None = None,
) -> TranslationResult:
    """Convenience API for callers that do not retain a translator instance."""

    return Translator(database).translate(
        text,
        direction,
        discourse_state=discourse_state,
    )
