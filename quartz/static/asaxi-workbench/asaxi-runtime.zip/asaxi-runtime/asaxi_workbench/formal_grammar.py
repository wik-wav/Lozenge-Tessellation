"""Source-cited formal grammar inventory for productive Asaxi morphology.

The human-readable vault remains authoritative and Vocab Forge remains the
editor for lexical morphemes.  This module compiles those morphemes together
with the Workbench-owned rule inventory into one deterministic, portable
record that parser and generator code can inspect.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import re
import tomllib
from typing import Any

from .models import LanguageDatabase, Morpheme, Severity


FORMAL_GRAMMAR_SCHEMA_VERSION = "0.5-provisional"
DEFAULT_RULE_INVENTORY = Path(__file__).with_name("formal_grammar.toml")
SOURCE_ANCHOR_RE = re.compile(r"#L(?P<line>\d+)$")


@dataclass(frozen=True)
class FormalGrammarDiagnostic:
    code: str
    severity: Severity
    message: str
    rule_id: str | None = None
    source_note: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "severity": self.severity.value,
            "message": self.message,
            "rule_id": self.rule_id,
            "source_note": self.source_note,
        }


@dataclass(frozen=True)
class ProductiveRule:
    identifier: str
    domain: str
    operation: str
    description: str
    status: str
    order: int
    slots: tuple[str, ...]
    inputs: tuple[str, ...]
    outputs: tuple[str, ...]
    constraints: tuple[str, ...]
    runtime_rule_ids: tuple[str, ...]
    source_notes: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.identifier,
            "domain": self.domain,
            "operation": self.operation,
            "description": self.description,
            "status": self.status,
            "order": self.order,
            "slots": list(self.slots),
            "inputs": list(self.inputs),
            "outputs": list(self.outputs),
            "constraints": list(self.constraints),
            "runtime_rule_ids": list(self.runtime_rule_ids),
            "source_notes": list(self.source_notes),
        }


@dataclass(frozen=True)
class FormalGrammar:
    schema_version: str
    inventory_digest: str
    orders: tuple[tuple[str, tuple[str, ...]], ...]
    rules: tuple[ProductiveRule, ...]
    morphemes: tuple[Morpheme, ...]
    diagnostics: tuple[FormalGrammarDiagnostic, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "source": {
                "kind": "workbench-formal-grammar",
                "digest": self.inventory_digest,
            },
            "orders": {
                name: list(slots)
                for name, slots in self.orders
            },
            "rules": [rule.to_dict() for rule in self.rules],
            "morphemes": [
                morpheme.to_dict()
                for morpheme in sorted(
                    self.morphemes,
                    key=lambda item: (item.notation.casefold(), item.identifier),
                )
            ],
            "diagnostics": [
                diagnostic.to_dict()
                for diagnostic in self.diagnostics
            ],
        }

    def rule(self, identifier: str) -> ProductiveRule:
        for rule in self.rules:
            if rule.identifier == identifier:
                return rule
        raise KeyError(identifier)

    def rules_for(self, domain: str) -> tuple[ProductiveRule, ...]:
        key = domain.casefold()
        return tuple(
            rule
            for rule in self.rules
            if rule.domain.casefold() == key
        )

    def rule_for_runtime_trace(self, identifier: str) -> ProductiveRule:
        """Resolve a runtime trace to its uniquely registered formal rule."""

        for rule in self.rules:
            if (
                rule.identifier == identifier
                or identifier in rule.runtime_rule_ids
            ):
                return rule
        raise KeyError(identifier)

    def render_json(self) -> str:
        return (
            json.dumps(
                self.to_dict(),
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
            )
            + "\n"
        )


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _string_tuple(value: object) -> tuple[str, ...]:
    if not isinstance(value, list):
        return ()
    return tuple(
        str(item).strip()
        for item in value
        if str(item).strip()
    )


def _source_path(note: str) -> tuple[Path, int | None]:
    match = SOURCE_ANCHOR_RE.search(note)
    if match is None:
        return Path(note), None
    return Path(note[: match.start()]), int(match.group("line"))


def _validate_source_note(
    note: str,
    *,
    vault_root: Path,
    rule_id: str,
) -> tuple[FormalGrammarDiagnostic, ...]:
    relative_path, line = _source_path(note)
    source = vault_root / relative_path
    if not source.is_file():
        return (
            FormalGrammarDiagnostic(
                code="FORMAL_RULE_SOURCE_MISSING",
                severity=Severity.ERROR,
                message=f"Rule source does not exist: {relative_path.as_posix()}",
                rule_id=rule_id,
                source_note=note,
            ),
        )
    if line is None:
        return ()
    try:
        with source.open("r", encoding="utf-8") as handle:
            line_count = sum(1 for _ in handle)
    except OSError as error:
        return (
            FormalGrammarDiagnostic(
                code="FORMAL_RULE_SOURCE_UNREADABLE",
                severity=Severity.ERROR,
                message=str(error),
                rule_id=rule_id,
                source_note=note,
            ),
        )
    if line > line_count:
        return (
            FormalGrammarDiagnostic(
                code="FORMAL_RULE_SOURCE_LINE_MISSING",
                severity=Severity.ERROR,
                message=(
                    f"Rule cites line {line}, but "
                    f"{relative_path.as_posix()} has {line_count} lines"
                ),
                rule_id=rule_id,
                source_note=note,
            ),
        )
    return ()


def compile_formal_grammar(
    database: LanguageDatabase,
    *,
    inventory_path: Path = DEFAULT_RULE_INVENTORY,
    vault_root: Path | None = None,
) -> FormalGrammar:
    """Compile the declarative inventory and Vocab Forge morphemes.

    ``vault_root`` is optional so packaged runtimes can consume an already
    compiled inventory.  Development and release verification pass it to
    validate every cited authoritative note.
    """

    path = inventory_path.resolve()
    with path.open("rb") as stream:
        payload = tomllib.load(stream)
    declared_schema = str(payload.get("schema_version", "")).strip()
    if declared_schema != FORMAL_GRAMMAR_SCHEMA_VERSION:
        raise ValueError(
            "Formal grammar schema mismatch: "
            f"expected {FORMAL_GRAMMAR_SCHEMA_VERSION!r}, "
            f"found {declared_schema!r}"
        )

    raw_orders = payload.get("orders")
    if not isinstance(raw_orders, dict):
        raise ValueError("Formal grammar inventory requires an [orders] table")
    orders = tuple(
        sorted(
            (
                str(name).strip(),
                _string_tuple(slots),
            )
            for name, slots in raw_orders.items()
            if str(name).strip()
        )
    )
    for name, slots in orders:
        if not slots:
            raise ValueError(f"Formal grammar order {name!r} has no slots")
        if len(set(slots)) != len(slots):
            raise ValueError(f"Formal grammar order {name!r} repeats a slot")

    raw_rules = payload.get("rules")
    if not isinstance(raw_rules, list):
        raise ValueError("Formal grammar inventory requires [[rules]] records")

    diagnostics: list[FormalGrammarDiagnostic] = []
    rules: list[ProductiveRule] = []
    seen_ids: set[str] = set()
    runtime_rule_owners: dict[str, str] = {}
    valid_statuses = {"confirmed", "provisional"}
    for raw in raw_rules:
        if not isinstance(raw, dict):
            raise ValueError("Every formal grammar rule must be a TOML table")
        identifier = str(raw.get("id", "")).strip()
        domain = str(raw.get("domain", "")).strip()
        operation = str(raw.get("operation", "")).strip()
        description = str(raw.get("description", "")).strip()
        status = str(raw.get("status", "confirmed")).strip().casefold()
        if not identifier or not domain or not operation or not description:
            raise ValueError(
                "Every formal grammar rule requires id, domain, operation, "
                "and description"
            )
        if identifier in seen_ids:
            raise ValueError(f"Duplicate formal grammar rule id: {identifier}")
        seen_ids.add(identifier)
        runtime_rule_ids = _string_tuple(raw.get("runtime_rule_ids"))
        if len(set(runtime_rule_ids)) != len(runtime_rule_ids):
            raise ValueError(
                f"Formal grammar rule {identifier!r} repeats a runtime rule id"
            )
        for runtime_rule_id in (identifier, *runtime_rule_ids):
            previous_owner = runtime_rule_owners.get(runtime_rule_id)
            if previous_owner is not None:
                raise ValueError(
                    f"Runtime rule id {runtime_rule_id!r} is registered by "
                    f"both {previous_owner!r} and {identifier!r}"
                )
            runtime_rule_owners[runtime_rule_id] = identifier
        if status not in valid_statuses:
            raise ValueError(
                f"Formal grammar rule {identifier!r} has invalid status "
                f"{status!r}"
            )
        source_notes = _string_tuple(raw.get("source_notes"))
        if not source_notes:
            diagnostics.append(
                FormalGrammarDiagnostic(
                    code="FORMAL_RULE_SOURCE_UNDECLARED",
                    severity=Severity.ERROR,
                    message="Productive rule has no authoritative citation",
                    rule_id=identifier,
                )
            )
        if vault_root is not None:
            for source_note in source_notes:
                diagnostics.extend(
                    _validate_source_note(
                        source_note,
                        vault_root=vault_root.resolve(),
                        rule_id=identifier,
                    )
                )
        rules.append(
            ProductiveRule(
                identifier=identifier,
                domain=domain,
                operation=operation,
                description=description,
                status=status,
                order=int(raw.get("order", 0)),
                slots=_string_tuple(raw.get("slots")),
                inputs=_string_tuple(raw.get("inputs")),
                outputs=_string_tuple(raw.get("outputs")),
                constraints=_string_tuple(raw.get("constraints")),
                runtime_rule_ids=runtime_rule_ids,
                source_notes=source_notes,
            )
        )

    rules.sort(
        key=lambda item: (
            item.domain.casefold(),
            item.order,
            item.identifier,
        )
    )
    diagnostics.sort(
        key=lambda item: (
            item.severity.value,
            item.rule_id or "",
            item.code,
            item.source_note or "",
        )
    )
    return FormalGrammar(
        schema_version=FORMAL_GRAMMAR_SCHEMA_VERSION,
        inventory_digest=_sha256(path),
        orders=orders,
        rules=tuple(rules),
        morphemes=database.morphemes,
        diagnostics=tuple(diagnostics),
    )


def write_formal_grammar(grammar: FormalGrammar, output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(grammar.render_json(), encoding="utf-8")
