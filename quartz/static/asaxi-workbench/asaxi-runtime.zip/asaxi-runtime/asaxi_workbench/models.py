"""Typed, serializable records used by the Asaxi language compiler."""

from __future__ import annotations

from dataclasses import dataclass, field as dataclass_field
from enum import Enum
from typing import Any, Iterable


class ValueState(str, Enum):
    """The source-level state of a field.

    The distinctions are intentionally preserved because ``x``, ``Null``, an
    empty field, and a genuinely inapplicable field do not mean the same thing
    in the source documentation.
    """

    PRESENT = "present"
    MISSING = "missing"
    EMPTY = "empty"
    PLACEHOLDER_X = "placeholder_x"
    PLACEHOLDER_NULL = "placeholder_null"
    NOT_APPLICABLE = "not_applicable"


@dataclass(frozen=True)
class FieldValue:
    state: ValueState
    value: str | None = None
    raw: str | None = None

    @classmethod
    def missing(cls) -> "FieldValue":
        return cls(ValueState.MISSING)

    @classmethod
    def from_raw(
        cls,
        raw: object,
        *,
        present: bool = True,
    ) -> "FieldValue":
        if not present:
            return cls.missing()
        if raw is None:
            return cls(ValueState.EMPTY, raw=None)
        text = str(raw).strip()
        normalized = text.casefold().rstrip(".")
        if not text:
            return cls(ValueState.EMPTY, raw=text)
        if normalized in {"x", "- x"}:
            return cls(ValueState.PLACEHOLDER_X, raw=text)
        if normalized in {"null", "- null"}:
            return cls(ValueState.PLACEHOLDER_NULL, raw=text)
        if normalized in {"n/a", "not applicable", "inapplicable"}:
            return cls(ValueState.NOT_APPLICABLE, raw=text)
        return cls(ValueState.PRESENT, value=text, raw=text)

    @property
    def is_present(self) -> bool:
        return self.state is ValueState.PRESENT

    def to_dict(self) -> dict[str, Any]:
        return {
            "state": self.state.value,
            "value": self.value,
            "raw": self.raw,
        }


class Severity(str, Enum):
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


@dataclass(frozen=True)
class SourceReference:
    path: str
    sha256: str
    line: int | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "path": self.path,
            "sha256": self.sha256,
            "line": self.line,
        }


@dataclass(frozen=True)
class GrammarSourceNote:
    """One authoritative grammar note in a versioned source snapshot."""

    path: str
    sha256: str

    def to_dict(self) -> dict[str, str]:
        return {"path": self.path, "sha256": self.sha256}


@dataclass(frozen=True)
class GrammarSourceChange:
    """Difference between the validated grammar lock and live notes."""

    path: str
    change: str
    validated_sha256: str | None = None
    current_sha256: str | None = None

    def to_dict(self) -> dict[str, str | None]:
        return {
            "path": self.path,
            "change": self.change,
            "validated_sha256": self.validated_sha256,
            "current_sha256": self.current_sha256,
        }


@dataclass(frozen=True)
class GrammarModelReference:
    """Compact grammar provenance attached to runtime API records."""

    model_version: str | None
    updated_on: str | None
    status: str
    validated_source_digest: str | None
    current_source_digest: str
    validated_with_workbench_version: str | None
    runtime_workbench_version: str
    validated_with_translation_engine_version: str | None
    note_count: int
    current_note_count: int
    change_count: int

    @property
    def source_snapshot_status(self) -> str:
        return self.status

    def to_dict(self) -> dict[str, Any]:
        return {
            "model_version": self.model_version,
            "updated_on": self.updated_on,
            "status": self.status,
            "status_scope": "source-snapshot",
            "source_snapshot_status": self.source_snapshot_status,
            "validated_source_digest": self.validated_source_digest,
            "current_source_digest": self.current_source_digest,
            "validated_with_workbench_version": (
                self.validated_with_workbench_version
            ),
            "runtime_workbench_version": self.runtime_workbench_version,
            "validated_with_translation_engine_version": (
                self.validated_with_translation_engine_version
            ),
            "note_count": self.note_count,
            "current_note_count": self.current_note_count,
            "change_count": self.change_count,
        }


@dataclass(frozen=True)
class GrammarModelRevision:
    """Versioned contract between Workshop behavior and grammar notes."""

    schema_version: str
    model_version: str | None
    updated_on: str | None
    validated_with_workbench_version: str | None
    validated_with_translation_engine_version: str | None
    status: str
    validated_source_digest: str | None
    current_source_digest: str
    notes: tuple[GrammarSourceNote, ...]
    current_notes: tuple[GrammarSourceNote, ...]
    changes: tuple[GrammarSourceChange, ...] = ()

    @property
    def source_snapshot_status(self) -> str:
        return self.status

    def reference(
        self,
        *,
        runtime_workbench_version: str,
    ) -> GrammarModelReference:
        return GrammarModelReference(
            model_version=self.model_version,
            updated_on=self.updated_on,
            status=self.status,
            validated_source_digest=self.validated_source_digest,
            current_source_digest=self.current_source_digest,
            validated_with_workbench_version=(
                self.validated_with_workbench_version
            ),
            runtime_workbench_version=runtime_workbench_version,
            validated_with_translation_engine_version=(
                self.validated_with_translation_engine_version
            ),
            note_count=len(self.notes),
            current_note_count=len(self.current_notes),
            change_count=len(self.changes),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "model_version": self.model_version,
            "updated_on": self.updated_on,
            "validated_with_workbench_version": (
                self.validated_with_workbench_version
            ),
            "validated_with_translation_engine_version": (
                self.validated_with_translation_engine_version
            ),
            "status": self.status,
            "status_scope": "source-snapshot",
            "source_snapshot_status": self.source_snapshot_status,
            "validated_source_digest": self.validated_source_digest,
            "current_source_digest": self.current_source_digest,
            "note_count": len(self.notes),
            "current_note_count": len(self.current_notes),
            "notes": [note.to_dict() for note in self.notes],
            "changes": [change.to_dict() for change in self.changes],
        }


@dataclass(frozen=True)
class Diagnostic:
    code: str
    severity: Severity
    message: str
    source_path: str | None = None
    line: int | None = None
    field: str | None = None
    details: dict[str, Any] = dataclass_field(default_factory=dict)

    def sort_key(self) -> tuple[Any, ...]:
        severity_order = {
            Severity.ERROR: 0,
            Severity.WARNING: 1,
            Severity.INFO: 2,
        }
        return (
            severity_order[self.severity],
            self.source_path or "",
            self.line or 0,
            self.code,
            self.message,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "severity": self.severity.value,
            "message": self.message,
            "source_path": self.source_path,
            "line": self.line,
            "field": self.field,
            "details": dict(sorted(self.details.items())),
        }


@dataclass(frozen=True)
class Example:
    asaxi: FieldValue
    translation_en: FieldValue
    translation_pl: FieldValue
    source_line: int | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "asaxi": self.asaxi.to_dict(),
            "translation_en": self.translation_en.to_dict(),
            "translation_pl": self.translation_pl.to_dict(),
            "source_line": self.source_line,
        }


@dataclass(frozen=True)
class Sense:
    index: int
    gloss_en: FieldValue
    gloss_pl: FieldValue
    examples: tuple[Example, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return {
            "index": self.index,
            "gloss_en": self.gloss_en.to_dict(),
            "gloss_pl": self.gloss_pl.to_dict(),
            "examples": [example.to_dict() for example in self.examples],
        }


class SpecificationStatus(str, Enum):
    CONFIRMED = "confirmed"
    PROPOSED = "proposed"
    INCOMPLETE = "incomplete"


@dataclass(frozen=True)
class DerivedTerm:
    """One source-listed lexical relation, including unlinked legacy text.

    Derived-term sections predate the current linked-note convention.  A
    structured record keeps an attested surface and gloss usable while also
    preserving the exact source text when a legacy line cannot be parsed
    completely.
    """

    identifier: str
    surface: str | None
    category: str | None
    gloss_en: FieldValue
    linked_target: str | None
    status: SpecificationStatus
    source_line: int | None
    raw_text: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.identifier,
            "surface": self.surface,
            "category": self.category,
            "gloss_en": self.gloss_en.to_dict(),
            "linked_target": self.linked_target,
            "status": self.status.value,
            "source_line": self.source_line,
            "raw_text": self.raw_text,
        }


@dataclass(frozen=True)
class LexicalVariant:
    """A source-attested surface form with explicit usage constraints.

    Obsidian ``aliases`` name notes and are not necessarily linguistic word
    forms.  Variants are compiled only from the lexeme's dedicated
    Alternative Forms sections so translation can recognize forms such as a
    song pronunciation without globally reinterpreting every note alias.
    """

    surface: str
    contexts: tuple[str, ...] = ("unrestricted",)
    note: str = ""
    source_line: int | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "surface": self.surface,
            "contexts": list(self.contexts),
            "note": self.note,
            "source_line": self.source_line,
        }


@dataclass(frozen=True)
class Lexeme:
    identifier: str
    lemma: str
    surface_form: str
    category: str
    source_category: str
    lexical_subtype: str | None
    title: FieldValue
    aliases: tuple[str, ...]
    tags: tuple[str, ...]
    frequency: int | None
    noun_class: FieldValue
    senses: tuple[Sense, ...]
    valency: FieldValue
    lexical_aspect: FieldValue
    pronunciation: FieldValue
    pitch_accent: FieldValue
    pitch_accent_class: FieldValue
    semantic_fields: tuple[str, ...]
    root_links: tuple[str, ...]
    derived_links: tuple[str, ...]
    derived_terms: tuple[DerivedTerm, ...]
    status: SpecificationStatus
    source: SourceReference
    unparsed_sections: tuple[str, ...] = ()
    variants: tuple[LexicalVariant, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.identifier,
            "lemma": self.lemma,
            "surface_form": self.surface_form,
            "category": self.category,
            "source_category": self.source_category,
            "lexical_subtype": self.lexical_subtype,
            "title": self.title.to_dict(),
            "aliases": list(self.aliases),
            "tags": list(self.tags),
            "frequency": self.frequency,
            "noun_class": self.noun_class.to_dict(),
            "senses": [sense.to_dict() for sense in self.senses],
            "valency": self.valency.to_dict(),
            "lexical_aspect": self.lexical_aspect.to_dict(),
            "pronunciation": self.pronunciation.to_dict(),
            "pitch_accent": self.pitch_accent.to_dict(),
            "pitch_accent_class": self.pitch_accent_class.to_dict(),
            "semantic_fields": list(self.semantic_fields),
            "derivation": {
                "roots": list(self.root_links),
                "derived_terms": list(self.derived_links),
                "derived_entries": [
                    term.to_dict() for term in self.derived_terms
                ],
            },
            "status": self.status.value,
            "source": self.source.to_dict(),
            "unparsed_sections": list(self.unparsed_sections),
            "variants": [variant.to_dict() for variant in self.variants],
        }


@dataclass(frozen=True)
class GrammarDocument:
    identifier: str
    title: str
    tags: tuple[str, ...]
    headings: tuple[str, ...]
    linked_notes: tuple[str, ...]
    proposed_sections: tuple[str, ...]
    status: SpecificationStatus
    source: SourceReference

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.identifier,
            "title": self.title,
            "tags": list(self.tags),
            "headings": list(self.headings),
            "linked_notes": list(self.linked_notes),
            "proposed_sections": list(self.proposed_sections),
            "status": self.status.value,
            "source": self.source.to_dict(),
        }


@dataclass(frozen=True)
class Morpheme:
    identifier: str
    notation: str
    form: str
    canonical_form: str
    role: str
    attachment: str
    lexical_type: str | None
    host_lexical_types: tuple[str, ...]
    description: str
    phones: tuple[str, ...]
    pitch_accent: FieldValue
    pitch_accent_class: FieldValue
    source_notes: tuple[str, ...]
    registry_source: SourceReference

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.identifier,
            "notation": self.notation,
            "form": self.form,
            "canonical_form": self.canonical_form,
            "role": self.role,
            "attachment": self.attachment,
            "lexical_type": self.lexical_type,
            "host_lexical_types": list(self.host_lexical_types),
            "description": self.description,
            "phones": list(self.phones),
            "pitch_accent": self.pitch_accent.to_dict(),
            "pitch_accent_class": self.pitch_accent_class.to_dict(),
            "source_notes": list(self.source_notes),
            "registry_source": self.registry_source.to_dict(),
        }


@dataclass(frozen=True)
class LanguageDatabase:
    schema_version: str
    compiler_version: str
    source_kind: str
    source_digest: str
    grammar_model: GrammarModelRevision
    lexemes: tuple[Lexeme, ...]
    grammar_documents: tuple[GrammarDocument, ...]
    morphemes: tuple[Morpheme, ...]
    diagnostics: tuple[Diagnostic, ...]
    statistics: dict[str, int]

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "compiler_version": self.compiler_version,
            "source": {
                "kind": self.source_kind,
                "digest": self.source_digest,
            },
            "grammar_model": self.grammar_model.to_dict(),
            "statistics": dict(sorted(self.statistics.items())),
            "lexemes": [lexeme.to_dict() for lexeme in self.lexemes],
            "grammar_documents": [
                document.to_dict() for document in self.grammar_documents
            ],
            "morphemes": [morpheme.to_dict() for morpheme in self.morphemes],
            "diagnostics": [
                diagnostic.to_dict() for diagnostic in self.diagnostics
            ],
        }

    def lexemes_for(self, lemma: str) -> tuple[Lexeme, ...]:
        key = lemma.casefold()
        return tuple(
            lexeme
            for lexeme in self.lexemes
            if lexeme.lemma.casefold() == key
        )

    def diagnostics_at(
        self,
        severities: Iterable[Severity],
    ) -> tuple[Diagnostic, ...]:
        selected = set(severities)
        return tuple(
            diagnostic
            for diagnostic in self.diagnostics
            if diagnostic.severity in selected
        )
