"""Evidence-based ordering for complete translation constructions.

The parser may materialize several valid structures.  This module ranks those
structures without teaching it phrase-specific preferred outputs: complete
source coverage, resolved discourse roles, and lower inference burden precede
lexical insertion order.  Every component remains serialized for review.
"""

from __future__ import annotations

from dataclasses import replace
from typing import Iterable

from .translation_models import (
    TranslationAlternative,
    TranslationAnalysisRank,
)


_HEAVY_INFERENCE_MARKERS = (
    "FALLBACK",
    "UNRESOLVED",
    "LIMIT_REACHED",
    "SOURCE_CONFLICT",
)
_GRAMMAR_FAMILIES = frozenset(
    {
        "argument",
        "clause",
        "directive",
        "discourse",
        "distribution",
        "frequency",
        "lexicon",
        "noun",
        "post-verbal",
        "pragmatics",
        "temporal",
        "translation",
        "validity",
        "verbalization",
    }
)


def _inference_cost(alternative: TranslationAlternative) -> int:
    # Ordinary assumptions expose choices that are already ranked by their
    # grammar-specific parser. Only a fallback/unresolved assumption is a
    # cross-construction deficit; counting every assumption here would erase
    # stronger local evidence such as valency, number, or topology.
    return 3 * sum(
        any(marker in assumption.code for marker in _HEAVY_INFERENCE_MARKERS)
        for assumption in alternative.assumptions
    )


def score_construction(
    alternative: TranslationAlternative,
) -> TranslationAnalysisRank:
    content_tokens = tuple(
        token
        for token in alternative.tokens
        if token.kind in {"word", "number"}
    )
    resolved = tuple(
        token
        for token in content_tokens
        if token.role is not None
        and not token.role.startswith(("unknown", "unresolved"))
    )
    families = tuple(
        sorted(
            {
                trace.split(".", 1)[0]
                for trace in alternative.rule_trace
                if trace.split(".", 1)[0] in _GRAMMAR_FAMILIES
            }
        )
    )
    unresolved_topic = any(
        ambiguity.code == "UNRESOLVED_OMITTED_TOPIC"
        for ambiguity in alternative.ambiguities
    ) or (
        alternative.canonical_clause.omitted_subject
        and not alternative.canonical_clause.discourse_subject
        and alternative.canonical_clause.directive is None
    )
    return TranslationAnalysisRank(
        source_token_count=len(content_tokens),
        resolved_token_count=len(resolved),
        unresolved_token_count=len(content_tokens) - len(resolved),
        unresolved_topic=unresolved_topic,
        inference_cost=_inference_cost(alternative),
        ambiguity_count=len(alternative.ambiguities),
        construction_families=families,
    )


def rank_constructions(
    alternatives: Iterable[TranslationAlternative],
) -> list[TranslationAlternative]:
    scored = [
        (index, replace(alternative, analysis_rank=score_construction(alternative)))
        for index, alternative in enumerate(alternatives)
    ]
    scored.sort(key=lambda item: (*item[1].analysis_rank.sort_key, item[0]))
    return [alternative for _index, alternative in scored]
