"""Discover and audit standardized examples in the Asaxi grammar book."""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import re
from typing import Any

from .compiler import ASAXI_RELATIVE_ROOT
from .models import LanguageDatabase
from .translation_models import TranslationStatus
from .translator import Translator


EXAMPLE_AUDIT_SCHEMA_VERSION = "0.2.0"
_ASAXI_MARKER = re.compile(r"^\s*-\s*\*\*Asaxi:\*\*\s*(.+?)\s*$")
_ENGLISH_MARKER = re.compile(r"^\s*-\s*\*\*English:\*\*\s*(.+?)\s*$")
_BLOCKQUOTE = re.compile(r"^\s*>\s?(.*?)\s*$")
_QUOTED_ENGLISH = re.compile(r'["“]([^"”]+)["”]')
_TABLE_SEPARATOR = re.compile(
    r"^\s*\|(?:\s*:?-+:?\s*\|)+\s*$"
)
_MARKDOWN_LINK = re.compile(r"\[\[([^|\]]+\|)?([^\]]+)\]\]")
_HTML_TAG = re.compile(r"<[^>]+>")
_WHITESPACE = re.compile(r"\s+")
_EDGE_MARKUP = " \t`*_\"'“”„"


@dataclass(frozen=True)
class DiscoveredGrammarExample:
    identifier: str
    source_path: str
    line: int
    asaxi: str
    english: str | None


@dataclass(frozen=True)
class GrammarExampleAuditResult:
    identifier: str
    source_path: str
    line: int
    asaxi: str
    expected_english: str | None
    classification: str
    observed_status: str | None
    selected_output: str | None

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.identifier,
            "source_path": self.source_path,
            "line": self.line,
            "asaxi": self.asaxi,
            "expected_english": self.expected_english,
            "classification": self.classification,
            "observed_status": self.observed_status,
            "selected_output": self.selected_output,
        }


@dataclass(frozen=True)
class GrammarExampleAuditReport:
    schema_version: str
    source_digest: str
    results: tuple[GrammarExampleAuditResult, ...]

    @property
    def counts(self) -> dict[str, int]:
        values = {
            "pass": 0,
            "misranked": 0,
            "mismatch": 0,
            "unsupported": 0,
            "source-ambiguous": 0,
        }
        for result in self.results:
            values[result.classification] = (
                values.get(result.classification, 0) + 1
            )
        values["total"] = len(self.results)
        return values

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "source_digest": self.source_digest,
            "summary": self.counts,
            "results": [result.to_dict() for result in self.results],
        }

    def to_json(self) -> str:
        return json.dumps(
            self.to_dict(),
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )


def _clean_markdown_text(value: str) -> str:
    text = _MARKDOWN_LINK.sub(lambda match: match.group(2), value)
    text = _HTML_TAG.sub("", text)
    return _WHITESPACE.sub(" ", text.strip(_EDGE_MARKUP)).strip()


def _comparison_text(value: str) -> str:
    text = _clean_markdown_text(value).casefold()
    text = text.replace("’", "'")
    # Grammar notes use square brackets to mark an explanatory constituent,
    # not literal punctuation expected in a translation (for example
    # ``walk [as I once did]``). Compare the words while retaining the raw
    # source string in the audit result.
    text = text.replace("[", "").replace("]", "")
    text = re.sub(r"[.!?]+$", "", text)
    return _WHITESPACE.sub(" ", text).strip()


def _looks_like_clause(value: str) -> bool:
    text = _clean_markdown_text(value)
    if not text or "[" in text or "]" in text:
        return False
    return bool(re.search(r"[.!?]\s*$", text))


def _table_cells(line: str) -> tuple[str, ...]:
    return tuple(
        _clean_markdown_text(cell)
        for cell in line.strip().strip("|").split("|")
    )


def _append_example(
    examples: list[DiscoveredGrammarExample],
    seen: set[tuple[str, int, str]],
    *,
    relative: str,
    line: int,
    asaxi: str,
    english: str | None,
) -> None:
    cleaned_asaxi = _clean_markdown_text(asaxi)
    cleaned_english = (
        _clean_markdown_text(english) if english is not None else None
    )
    key = (relative, line, cleaned_asaxi)
    if not cleaned_asaxi or key in seen:
        return
    seen.add(key)
    fingerprint = hashlib.sha256(
        f"{relative}:{line}:{cleaned_asaxi}".encode("utf-8")
    ).hexdigest()[:16]
    examples.append(
        DiscoveredGrammarExample(
            identifier=f"grammar-example.{fingerprint}",
            source_path=relative,
            line=line,
            asaxi=cleaned_asaxi,
            english=cleaned_english,
        )
    )


def discover_grammar_examples(
    vault_root: Path,
) -> tuple[DiscoveredGrammarExample, ...]:
    """Find every standardized ``Asaxi`` example row in grammar notes."""

    grammar_root = (
        vault_root.resolve()
        / ASAXI_RELATIVE_ROOT
        / "Grammar_Structure"
    ).resolve()
    examples: list[DiscoveredGrammarExample] = []
    seen: set[tuple[str, int, str]] = set()
    for note in sorted(grammar_root.rglob("*.md")):
        relative = note.relative_to(
            vault_root.resolve() / ASAXI_RELATIVE_ROOT
        ).as_posix()
        lines = note.read_text(encoding="utf-8").splitlines()
        for index, line in enumerate(lines):
            match = _ASAXI_MARKER.match(line)
            if match is None:
                continue
            asaxi = _clean_markdown_text(match.group(1))
            english: str | None = None
            for following in lines[index + 1:index + 13]:
                if _ASAXI_MARKER.match(following):
                    break
                english_match = _ENGLISH_MARKER.match(following)
                if english_match is not None:
                    english = _clean_markdown_text(
                        english_match.group(1)
                    )
                    break
                if following.startswith("#"):
                    break
            _append_example(
                examples,
                seen,
                relative=relative,
                line=index + 1,
                asaxi=asaxi,
                english=english,
            )

        pending_blockquote: tuple[int, str] | None = None
        for index, line in enumerate(lines):
            match = _BLOCKQUOTE.match(line)
            if match is None:
                pending_blockquote = None
                continue
            body = match.group(1).strip()
            if not body or body.startswith("-"):
                continue
            quoted = tuple(_QUOTED_ENGLISH.finditer(body))
            if quoted:
                english_match = quoted[-1]
                prefix = body[:english_match.start()].rstrip(" \t(")
                if "`" in prefix:
                    prefix = prefix.split("`", 1)[0].strip()
                if _looks_like_clause(prefix):
                    _append_example(
                        examples,
                        seen,
                        relative=relative,
                        line=index + 1,
                        asaxi=prefix,
                        english=english_match.group(1),
                    )
                    pending_blockquote = None
                    continue
                if pending_blockquote is not None:
                    pending_line, pending_asaxi = pending_blockquote
                    _append_example(
                        examples,
                        seen,
                        relative=relative,
                        line=pending_line,
                        asaxi=pending_asaxi,
                        english=english_match.group(1),
                    )
                    pending_blockquote = None
                continue
            if "`" not in body and _looks_like_clause(body):
                pending_blockquote = (index + 1, body)

        index = 0
        while index + 1 < len(lines):
            header_line = lines[index]
            if (
                "|" not in header_line
                or not _TABLE_SEPARATOR.match(lines[index + 1])
            ):
                index += 1
                continue
            headers = tuple(
                header.casefold() for header in _table_cells(header_line)
            )
            if "asaxi" in headers and "english" in headers:
                asaxi_column = headers.index("asaxi")
                english_column = headers.index("english")
            elif "sentence" in headers and "meaning" in headers:
                asaxi_column = headers.index("sentence")
                english_column = headers.index("meaning")
            else:
                index += 1
                continue
            row_index = index + 2
            while row_index < len(lines) and "|" in lines[row_index]:
                cells = _table_cells(lines[row_index])
                if (
                    max(asaxi_column, english_column) < len(cells)
                    and _looks_like_clause(cells[asaxi_column])
                ):
                    _append_example(
                        examples,
                        seen,
                        relative=relative,
                        line=row_index + 1,
                        asaxi=cells[asaxi_column],
                        english=cells[english_column],
                    )
                row_index += 1
            index = row_index
    return tuple(examples)


def audit_grammar_examples(
    database: LanguageDatabase,
    vault_root: Path,
) -> GrammarExampleAuditReport:
    """Classify discovered examples without pretending gaps are passes."""

    translator = Translator(database)
    results: list[GrammarExampleAuditResult] = []
    for example in discover_grammar_examples(vault_root):
        if not example.asaxi or example.english is None:
            results.append(
                GrammarExampleAuditResult(
                    identifier=example.identifier,
                    source_path=example.source_path,
                    line=example.line,
                    asaxi=example.asaxi,
                    expected_english=example.english,
                    classification="source-ambiguous",
                    observed_status=None,
                    selected_output=None,
                )
            )
            continue
        translation = translator.asaxi_to_english(example.asaxi)
        selected = translation.selected
        selected_output = (
            selected.output_text if selected is not None else None
        )
        if translation.status is TranslationStatus.UNSUPPORTED:
            classification = "unsupported"
        else:
            expected = _comparison_text(example.english)
            selected_comparison = (
                _comparison_text(selected_output)
                if selected_output is not None
                else None
            )
            observed_alternatives = {
                _comparison_text(alternative.output_text)
                for alternative in translation.alternatives
            }
            if expected == selected_comparison:
                classification = "pass"
            elif expected in observed_alternatives:
                classification = "misranked"
            else:
                classification = "mismatch"
        results.append(
            GrammarExampleAuditResult(
                identifier=example.identifier,
                source_path=example.source_path,
                line=example.line,
                asaxi=example.asaxi,
                expected_english=example.english,
                classification=classification,
                observed_status=translation.status.value,
                selected_output=selected_output,
            )
        )
    return GrammarExampleAuditReport(
        schema_version=EXAMPLE_AUDIT_SCHEMA_VERSION,
        source_digest=database.source_digest,
        results=tuple(results),
    )
