"""Deterministic document-level coverage for the Asaxi grammar book."""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
import re
import tomllib
from typing import Any

from .compiler import ASAXI_RELATIVE_ROOT
from .formal_grammar import FormalGrammar, compile_formal_grammar
from .grammar_conformance import (
    GrammarConformanceReport,
    load_grammar_conformance_manifest,
    run_grammar_conformance,
)
from .grammar_example_audit import (
    GrammarExampleAuditReport,
    audit_grammar_examples,
)
from .models import LanguageDatabase
from .translation_models import TRANSLATION_ENGINE_VERSION
from .version import WORKBENCH_VERSION


GRAMMAR_COVERAGE_SCHEMA_VERSION = "0.5.0"
GRAMMAR_CLAIM_SCHEMA_VERSION = "0.3.0"
DEFAULT_GRAMMAR_CLAIM_MANIFEST = (
    Path(__file__).with_name("grammar_coverage_claims.toml")
)


@dataclass(frozen=True)
class GrammarCoverageClaim:
    identifier: str
    case_ids: tuple[str, ...]


@dataclass(frozen=True)
class GrammarCoverageClaimInventory:
    source_path: str
    source_sha256: str
    inventory_status: str
    reviewed_with_workbench_version: str
    reviewed_with_translation_engine_version: str
    claims: tuple[GrammarCoverageClaim, ...]


@dataclass(frozen=True)
class GrammarDocumentCoverage:
    source_path: str
    state: str
    accounted: bool
    behaviorally_verified: bool
    formal_rule_ids: tuple[str, ...]
    conformance_case_ids: tuple[str, ...]
    claim_inventory_source_sha256: str | None
    current_source_sha256: str
    claim_inventory_current: bool | None
    claim_inventory_source_current: bool | None
    claim_inventory_runtime_compatible: bool | None
    claim_inventory_complete: bool | None
    claim_inventory_reviewed_with_workbench_version: str | None
    claim_inventory_reviewed_with_translation_engine_version: str | None
    required_claim_ids: tuple[str, ...]
    verified_claim_ids: tuple[str, ...]
    unverified_claim_ids: tuple[str, ...]
    unclaimed_conformance_case_ids: tuple[str, ...]
    unregistered_runtime_rule_ids: tuple[str, ...]
    example_counts: tuple[tuple[str, int], ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "source_path": self.source_path,
            "state": self.state,
            "accounted": self.accounted,
            "behaviorally_verified": self.behaviorally_verified,
            "formal_rule_ids": list(self.formal_rule_ids),
            "conformance_case_ids": list(self.conformance_case_ids),
            "claim_inventory_source_sha256": (
                self.claim_inventory_source_sha256
            ),
            "current_source_sha256": self.current_source_sha256,
            "claim_inventory_current": self.claim_inventory_current,
            "claim_inventory_source_current": (
                self.claim_inventory_source_current
            ),
            "claim_inventory_runtime_compatible": (
                self.claim_inventory_runtime_compatible
            ),
            "claim_inventory_complete": self.claim_inventory_complete,
            "claim_inventory_reviewed_with_workbench_version": (
                self.claim_inventory_reviewed_with_workbench_version
            ),
            "claim_inventory_reviewed_with_translation_engine_version": (
                self.claim_inventory_reviewed_with_translation_engine_version
            ),
            "required_claim_ids": list(self.required_claim_ids),
            "verified_claim_ids": list(self.verified_claim_ids),
            "unverified_claim_ids": list(self.unverified_claim_ids),
            "unclaimed_conformance_case_ids": list(
                self.unclaimed_conformance_case_ids
            ),
            "unregistered_runtime_rule_ids": list(
                self.unregistered_runtime_rule_ids
            ),
            "example_counts": dict(self.example_counts),
        }


@dataclass(frozen=True)
class GrammarCoverageReport:
    schema_version: str
    source_digest: str
    documents: tuple[GrammarDocumentCoverage, ...]

    @property
    def counts(self) -> dict[str, Any]:
        states: dict[str, int] = {}
        accounted = 0
        verified = 0
        for document in self.documents:
            states[document.state] = states.get(document.state, 0) + 1
            accounted += int(document.accounted)
            verified += int(document.behaviorally_verified)
        return {
            "total": len(self.documents),
            "accounted": accounted,
            "unaccounted": len(self.documents) - accounted,
            "behaviorally_verified": verified,
            "behaviorally_unverified": len(self.documents) - verified,
            "states": dict(sorted(states.items())),
        }

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "source_digest": self.source_digest,
            "summary": self.counts,
            "documents": [
                document.to_dict() for document in self.documents
            ],
        }

    def to_summary_dict(self) -> dict[str, Any]:
        """Return the compact implementation-coverage API record."""

        return {
            "schema_version": self.schema_version,
            "scope": "implementation",
            "source_digest": self.source_digest,
            "summary": self.counts,
        }

    def to_json(self) -> str:
        return json.dumps(
            self.to_dict(),
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )


def _formal_source_path(value: str) -> str | None:
    raw = value.rsplit("#L", 1)[0]
    try:
        return Path(raw).relative_to(ASAXI_RELATIVE_ROOT).as_posix()
    except ValueError:
        return None


def _portable_source_path(value: str) -> str:
    path = Path(value)
    if path.is_absolute() or ".." in path.parts or not value:
        raise ValueError(
            f"Grammar-coverage source path is not portable: {value!r}"
        )
    return path.as_posix()


def load_grammar_claim_inventory(
    path: Path | None = DEFAULT_GRAMMAR_CLAIM_MANIFEST,
) -> tuple[GrammarCoverageClaimInventory, ...]:
    """Load explicit claims required before a whole note is verified."""

    if path is None:
        return ()
    manifest = path.resolve()
    payload = tomllib.loads(manifest.read_text(encoding="utf-8"))
    version = str(payload.get("schema_version", ""))
    if version != GRAMMAR_CLAIM_SCHEMA_VERSION:
        raise ValueError(
            "Unsupported grammar-coverage claim schema "
            f"{version!r}; expected {GRAMMAR_CLAIM_SCHEMA_VERSION!r}"
        )
    inventories: list[GrammarCoverageClaimInventory] = []
    seen_paths: set[str] = set()
    for raw_document in payload.get("document", ()):
        source_path = _portable_source_path(
            str(raw_document["source_path"])
        )
        if source_path in seen_paths:
            raise ValueError(
                f"Duplicate grammar claim inventory: {source_path}"
            )
        seen_paths.add(source_path)
        source_sha256 = str(raw_document.get("source_sha256", "")).lower()
        if re.fullmatch(r"[0-9a-f]{64}", source_sha256) is None:
            raise ValueError(
                f"Grammar claim inventory has invalid source hash: "
                f"{source_path}"
            )
        inventory_status = str(
            raw_document.get("inventory_status", "")
        ).strip()
        if inventory_status != "complete":
            raise ValueError(
                "Grammar claim inventory must explicitly declare "
                f"inventory_status = 'complete': {source_path}"
            )
        reviewed_with_workbench_version = str(
            raw_document.get("reviewed_with_workbench_version", "")
        ).strip()
        if not reviewed_with_workbench_version:
            raise ValueError(
                "Grammar claim inventory must record its Workshop review "
                f"version: {source_path}"
            )
        reviewed_with_translation_engine_version = str(
            raw_document.get(
                "reviewed_with_translation_engine_version",
                "",
            )
        ).strip()
        if not reviewed_with_translation_engine_version:
            raise ValueError(
                "Grammar claim inventory must record its translation-engine "
                f"review version: {source_path}"
            )
        claims: list[GrammarCoverageClaim] = []
        seen_claims: set[str] = set()
        for raw_claim in raw_document.get("claim", ()):
            identifier = str(raw_claim["id"]).strip()
            if not identifier or identifier in seen_claims:
                raise ValueError(
                    f"Invalid or duplicate claim id in {source_path}: "
                    f"{identifier!r}"
                )
            seen_claims.add(identifier)
            case_ids = tuple(
                str(case_id).strip()
                for case_id in raw_claim.get("case_ids", ())
            )
            if not case_ids or any(not case_id for case_id in case_ids):
                raise ValueError(
                    f"Grammar claim {identifier!r} has no conformance cases"
                )
            if len(set(case_ids)) != len(case_ids):
                raise ValueError(
                    f"Grammar claim {identifier!r} repeats a case id"
                )
            claims.append(
                GrammarCoverageClaim(
                    identifier=identifier,
                    case_ids=case_ids,
                )
            )
        if not claims:
            raise ValueError(
                f"Grammar claim inventory has no claims: {source_path}"
            )
        inventories.append(
            GrammarCoverageClaimInventory(
                source_path=source_path,
                source_sha256=source_sha256,
                inventory_status=inventory_status,
                reviewed_with_workbench_version=(
                    reviewed_with_workbench_version
                ),
                reviewed_with_translation_engine_version=(
                    reviewed_with_translation_engine_version
                ),
                claims=tuple(claims),
            )
        )
    return tuple(sorted(inventories, key=lambda item: item.source_path))


def _coverage_state(
    *,
    formal_rule_ids: tuple[str, ...],
    conformance_passes: tuple[bool, ...],
    claim_passes: tuple[bool, ...] | None,
    claim_inventory_current: bool | None,
    claim_inventory_complete: bool | None,
    example_counts: dict[str, int],
) -> str:
    if claim_passes is not None:
        if claim_inventory_current is not True:
            return "claim-inventory-stale"
        if claim_inventory_complete is not True:
            return "claim-inventory-incomplete"
        if not all(conformance_passes) or not all(claim_passes):
            return "behavioral-gate-failing"
        example_total = sum(example_counts.values())
        if (
            example_total
            and example_counts.get("pass", 0) != example_total
        ):
            return "behavioral-gate-incomplete"
        return "behaviorally-verified"
    if conformance_passes:
        if not all(conformance_passes):
            return "behavioral-probes-failing"
        example_total = sum(example_counts.values())
        if example_total and example_counts.get("pass", 0) != example_total:
            return "behavioral-probes-incomplete"
        return "behavioral-probes-pass"
    example_total = sum(example_counts.values())
    if example_total:
        passed = example_counts.get("pass", 0)
        if passed == example_total:
            return "examples-pass"
        if passed:
            return "partial"
        if (
            example_counts.get("mismatch", 0)
            or example_counts.get("misranked", 0)
        ):
            return "analyzed-mismatch"
        if example_counts.get("unsupported", 0):
            return "unsupported"
        return "source-ambiguous"
    if formal_rule_ids:
        return "formalized-unprobed"
    return "unassessed"


def build_grammar_coverage(
    database: LanguageDatabase,
    vault_root: Path,
    *,
    conformance: GrammarConformanceReport | None = None,
    examples: GrammarExampleAuditReport | None = None,
    formal_grammar: FormalGrammar | None = None,
    claim_manifest_path: Path | None = DEFAULT_GRAMMAR_CLAIM_MANIFEST,
) -> GrammarCoverageReport:
    """Account for every grammar note without equating inventory with support."""

    root = vault_root.resolve()
    asaxi_root = (root / ASAXI_RELATIVE_ROOT).resolve()
    grammar_root = (asaxi_root / "Grammar_Structure").resolve()
    conformance = conformance or run_grammar_conformance(
        database,
        root,
    )
    examples = examples or audit_grammar_examples(database, root)
    formal_grammar = formal_grammar or compile_formal_grammar(
        database,
        vault_root=root,
    )
    inventories = load_grammar_claim_inventory(claim_manifest_path)

    rules_by_path: dict[str, set[str]] = {}
    for rule in formal_grammar.rules:
        for source_note in rule.source_notes:
            source_path = _formal_source_path(source_note)
            if source_path is not None:
                rules_by_path.setdefault(source_path, set()).add(
                    rule.identifier
                )

    cases_by_path: dict[str, list[tuple[str, bool]]] = {}
    cases_by_id = {}
    for result in conformance.results:
        cases_by_path.setdefault(result.source_path, []).append(
            (result.identifier, result.passed)
        )
        cases_by_id[result.identifier] = result

    inventories_by_path: dict[str, GrammarCoverageClaimInventory] = {}
    conformance_cases, _ = load_grammar_conformance_manifest()
    conformance_cases_by_id = {
        case.identifier: case for case in conformance_cases
    }
    registered_runtime_rule_ids = {
        runtime_rule_id
        for rule in formal_grammar.rules
        for runtime_rule_id in (rule.identifier, *rule.runtime_rule_ids)
    }
    for inventory in inventories:
        for claim in inventory.claims:
            for case_id in claim.case_ids:
                result = cases_by_id.get(case_id)
                if result is None:
                    raise ValueError(
                        f"Grammar claim {claim.identifier!r} references "
                        f"unknown conformance case {case_id!r}"
                    )
                if result.source_path != inventory.source_path:
                    raise ValueError(
                        f"Grammar claim {claim.identifier!r} cites "
                        f"{case_id!r} from {result.source_path!r}, not "
                        f"{inventory.source_path!r}"
                    )
                if case_id not in conformance_cases_by_id:
                    raise ValueError(
                        f"Grammar claim {claim.identifier!r} references "
                        f"{case_id!r}, which is absent from the conformance "
                        "manifest"
                    )
        inventories_by_path[inventory.source_path] = inventory

    current_hashes_by_path = {
        Path(note.path).relative_to(ASAXI_RELATIVE_ROOT).as_posix(): (
            note.sha256
        )
        for note in database.grammar_model.current_notes
    }

    examples_by_path: dict[str, dict[str, int]] = {}
    for result in examples.results:
        counts = examples_by_path.setdefault(result.source_path, {})
        counts[result.classification] = (
            counts.get(result.classification, 0) + 1
        )

    documents: list[GrammarDocumentCoverage] = []
    source_paths = {
        source.relative_to(asaxi_root).as_posix()
        for source in grammar_root.rglob("*.md")
    }
    missing_inventories = set(inventories_by_path) - source_paths
    if missing_inventories:
        raise ValueError(
            "Grammar claim inventory references missing note(s): "
            + ", ".join(sorted(missing_inventories))
        )
    for source in sorted(grammar_root.rglob("*.md")):
        source_path = source.relative_to(asaxi_root).as_posix()
        formal_ids = tuple(sorted(rules_by_path.get(source_path, ())))
        case_pairs = tuple(sorted(cases_by_path.get(source_path, ())))
        case_ids = tuple(identifier for identifier, _ in case_pairs)
        case_passes = tuple(passed for _, passed in case_pairs)
        example_counts = dict(
            sorted(examples_by_path.get(source_path, {}).items())
        )
        inventory = inventories_by_path.get(source_path)
        current_source_sha256 = current_hashes_by_path[source_path]
        claim_inventory_source_current = (
            inventory.source_sha256 == current_source_sha256
            if inventory is not None
            else None
        )
        claim_inventory_runtime_compatible = (
            inventory.reviewed_with_workbench_version == WORKBENCH_VERSION
            and inventory.reviewed_with_translation_engine_version
            == TRANSLATION_ENGINE_VERSION
            if inventory is not None
            else None
        )
        claim_inventory_current = (
            claim_inventory_source_current is True
            and claim_inventory_runtime_compatible is True
            if inventory is not None
            else None
        )
        required_claim_ids = (
            tuple(claim.identifier for claim in inventory.claims)
            if inventory is not None
            else ()
        )
        claimed_case_ids = (
            {
                case_id
                for claim in inventory.claims
                for case_id in claim.case_ids
            }
            if inventory is not None
            else set()
        )
        unclaimed_case_ids = (
            tuple(sorted(set(case_ids) - claimed_case_ids))
            if inventory is not None
            else ()
        )
        claimed_runtime_rule_ids = (
            {
                rule_id
                for case_id in claimed_case_ids
                for rule_id in conformance_cases_by_id[case_id].required_rules
            }
            if inventory is not None
            else set()
        )
        unregistered_runtime_rule_ids = tuple(
            sorted(claimed_runtime_rule_ids - registered_runtime_rule_ids)
        )
        claim_inventory_complete = (
            not unclaimed_case_ids and not unregistered_runtime_rule_ids
            if inventory is not None
            else None
        )
        claim_results = (
            tuple(
                claim_inventory_current
                and all(
                    cases_by_id[case_id].passed
                    for case_id in claim.case_ids
                )
                for claim in inventory.claims
            )
            if inventory is not None
            else None
        )
        verified_claim_ids = (
            tuple(
                claim.identifier
                for claim, passed in zip(
                    inventory.claims,
                    claim_results,
                    strict=True,
                )
                if passed
            )
            if inventory is not None and claim_results is not None
            else ()
        )
        unverified_claim_ids = tuple(
            claim_id
            for claim_id in required_claim_ids
            if claim_id not in verified_claim_ids
        )
        accounted = bool(
            formal_ids or case_ids or example_counts or inventory
        )
        state = _coverage_state(
            formal_rule_ids=formal_ids,
            conformance_passes=case_passes,
            claim_passes=claim_results,
            claim_inventory_current=claim_inventory_current,
            claim_inventory_complete=claim_inventory_complete,
            example_counts=example_counts,
        )
        documents.append(
            GrammarDocumentCoverage(
                source_path=source_path,
                state=state,
                accounted=accounted,
                behaviorally_verified=state == "behaviorally-verified",
                formal_rule_ids=formal_ids,
                conformance_case_ids=case_ids,
                claim_inventory_source_sha256=(
                    inventory.source_sha256
                    if inventory is not None
                    else None
                ),
                current_source_sha256=current_source_sha256,
                claim_inventory_current=claim_inventory_current,
                claim_inventory_source_current=(
                    claim_inventory_source_current
                ),
                claim_inventory_runtime_compatible=(
                    claim_inventory_runtime_compatible
                ),
                claim_inventory_complete=claim_inventory_complete,
                claim_inventory_reviewed_with_workbench_version=(
                    inventory.reviewed_with_workbench_version
                    if inventory is not None
                    else None
                ),
                claim_inventory_reviewed_with_translation_engine_version=(
                    inventory.reviewed_with_translation_engine_version
                    if inventory is not None
                    else None
                ),
                required_claim_ids=required_claim_ids,
                verified_claim_ids=verified_claim_ids,
                unverified_claim_ids=unverified_claim_ids,
                unclaimed_conformance_case_ids=unclaimed_case_ids,
                unregistered_runtime_rule_ids=(
                    unregistered_runtime_rule_ids
                ),
                example_counts=tuple(example_counts.items()),
            )
        )

    return GrammarCoverageReport(
        schema_version=GRAMMAR_COVERAGE_SCHEMA_VERSION,
        source_digest=database.grammar_model.current_source_digest,
        documents=tuple(documents),
    )
