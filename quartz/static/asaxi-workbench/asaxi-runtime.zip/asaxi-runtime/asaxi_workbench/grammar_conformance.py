"""Source-cited conformance checks for the documented Asaxi ruleset."""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
import tomllib
from typing import Any, Iterable

from .compiler import ASAXI_RELATIVE_ROOT
from .models import LanguageDatabase
from .translator import Translator


CONFORMANCE_SCHEMA_VERSION = "0.2.0"
DEFAULT_CONFORMANCE_MANIFEST = (
    Path(__file__).with_name("grammar_conformance.toml")
)


@dataclass(frozen=True)
class GrammarConformanceCase:
    identifier: str
    rule_family: str
    kind: str
    source_path: str
    source_contains: str
    input_text: str
    expected_statuses: tuple[str, ...]
    selected_output: str | None = None
    required_outputs: tuple[str, ...] = ()
    required_diagnostics: tuple[str, ...] = ()
    required_rules: tuple[str, ...] = ()
    required_roles: tuple[tuple[str, str], ...] = ()
    canonical_expectations: tuple[tuple[str, str], ...] = ()
    maximum_alternatives: int | None = None


@dataclass(frozen=True)
class GrammarConformanceCaseResult:
    identifier: str
    rule_family: str
    kind: str
    passed: bool
    source_path: str
    input_text: str
    observed_status: str
    selected_output: str | None
    alternative_count: int
    diagnostic_codes: tuple[str, ...]
    failures: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.identifier,
            "rule_family": self.rule_family,
            "kind": self.kind,
            "passed": self.passed,
            "source_path": self.source_path,
            "input": self.input_text,
            "observed_status": self.observed_status,
            "selected_output": self.selected_output,
            "alternative_count": self.alternative_count,
            "diagnostic_codes": list(self.diagnostic_codes),
            "failures": list(self.failures),
        }


@dataclass(frozen=True)
class GrammarConformanceReport:
    schema_version: str
    source_digest: str
    results: tuple[GrammarConformanceCaseResult, ...]

    @property
    def passed(self) -> int:
        return sum(result.passed for result in self.results)

    @property
    def failed(self) -> int:
        return len(self.results) - self.passed

    @property
    def is_success(self) -> bool:
        return self.failed == 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "source_digest": self.source_digest,
            "summary": {
                "total": len(self.results),
                "passed": self.passed,
                "failed": self.failed,
            },
            "results": [result.to_dict() for result in self.results],
        }

    def to_json(self) -> str:
        return json.dumps(
            self.to_dict(),
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )


def _portable_source_path(value: str) -> str:
    path = Path(value)
    if path.is_absolute() or ".." in path.parts:
        raise ValueError(
            f"Conformance source path must be relative and contained: {value}"
        )
    return path.as_posix()


def load_grammar_conformance_manifest(
    path: Path | None = None,
) -> tuple[tuple[GrammarConformanceCase, ...], tuple[str, ...]]:
    manifest_path = (path or DEFAULT_CONFORMANCE_MANIFEST).resolve()
    payload = tomllib.loads(manifest_path.read_text(encoding="utf-8"))
    schema_version = str(payload.get("schema_version", ""))
    if schema_version != CONFORMANCE_SCHEMA_VERSION:
        raise ValueError(
            "Unsupported grammar-conformance schema "
            f"{schema_version!r}; expected {CONFORMANCE_SCHEMA_VERSION!r}"
        )
    forbidden = tuple(
        str(value)
        for value in payload.get("forbidden_output_fragments", ())
    )
    cases: list[GrammarConformanceCase] = []
    seen: set[str] = set()
    for raw in payload.get("case", ()):
        identifier = str(raw["id"])
        if identifier in seen:
            raise ValueError(
                f"Duplicate grammar-conformance case id: {identifier}"
            )
        seen.add(identifier)
        case = GrammarConformanceCase(
            identifier=identifier,
            rule_family=str(raw["rule_family"]),
            kind=str(raw.get("kind", "attested-example")),
            source_path=_portable_source_path(str(raw["source_path"])),
            source_contains=str(raw["source_contains"]),
            input_text=str(raw["input"]),
            expected_statuses=tuple(
                str(value)
                for value in raw.get(
                    "expected_statuses",
                    ("ok", "ambiguous"),
                )
            ),
            selected_output=(
                str(raw["selected_output"])
                if "selected_output" in raw
                else None
            ),
            required_outputs=tuple(
                str(value)
                for value in raw.get("required_outputs", ())
            ),
            required_diagnostics=tuple(
                str(value)
                for value in raw.get("required_diagnostics", ())
            ),
            required_rules=tuple(
                str(value)
                for value in raw.get("required_rules", ())
            ),
            required_roles=tuple(
                sorted(
                    (
                        str(surface),
                        str(role),
                    )
                    for surface, role in raw.get(
                        "required_roles",
                        {},
                    ).items()
                )
            ),
            canonical_expectations=tuple(
                sorted(
                    (
                        str(field),
                        str(value),
                    )
                    for field, value in raw.get(
                        "canonical",
                        {},
                    ).items()
                )
            ),
            maximum_alternatives=(
                int(raw["maximum_alternatives"])
                if "maximum_alternatives" in raw
                else None
            ),
        )
        if not case.expected_statuses:
            raise ValueError(
                f"Conformance case {identifier!r} has no expected statuses"
            )
        rejection_case = set(case.expected_statuses) == {"unsupported"}
        if rejection_case:
            if not case.required_diagnostics:
                raise ValueError(
                    f"Rejection case {identifier!r} must assert at least one "
                    "diagnostic code"
                )
            if case.maximum_alternatives != 0:
                raise ValueError(
                    f"Rejection case {identifier!r} must set "
                    "maximum_alternatives = 0"
                )
        else:
            if case.selected_output is None and not case.required_outputs:
                raise ValueError(
                    f"Conformance case {identifier!r} has no expected output"
                )
            if (
                not case.required_rules
                or not case.required_roles
                or not case.canonical_expectations
                or case.maximum_alternatives is None
            ):
                raise ValueError(
                    f"Conformance case {identifier!r} must assert structural "
                    "evidence: rules, roles, canonical fields, and an "
                    "alternative ceiling"
                )
        if (
            case.maximum_alternatives is not None
            and case.maximum_alternatives < 0
        ):
            raise ValueError(
                f"Conformance case {identifier!r} has an invalid "
                "alternative ceiling"
            )
        cases.append(case)
    if not cases:
        raise ValueError("Grammar-conformance manifest has no cases")
    return tuple(cases), forbidden


def _canonical_value(alternative: Any, field: str) -> str | None:
    clause = alternative.canonical_clause
    if field == "subject_surface":
        return clause.subject.surface if clause.subject else None
    if field == "object_surface":
        return clause.object.surface if clause.object else None
    if field == "complement_surface":
        return clause.complement.surface if clause.complement else None
    if field == "location_surface":
        return clause.location.surface if clause.location else None
    if field == "time_surface":
        return clause.time.surface if clause.time else None
    if field == "predicate":
        return clause.predicate
    if field == "predicate_kind":
        return clause.predicate_kind.value
    if field == "tense":
        return clause.tense.value
    if field == "polarity":
        return clause.polarity.value
    if field == "validity_mode":
        return clause.validity_mode.value
    derivation = clause.verbal_derivation
    if field == "verbalization_mode":
        return derivation.mode.value if derivation else None
    if field == "verbalization_source_surface":
        return derivation.source.surface if derivation else None
    if field == "verbalization_source_lexeme_id":
        return derivation.source.lexeme_id if derivation else None
    if field == "verbalization_bridge":
        return derivation.bridge if derivation else None
    if field == "verbalization_aspectual_class":
        return derivation.aspectual_class if derivation else None
    if field == "verbalization_lexicalized_predicate_id":
        return derivation.lexicalized_predicate_id if derivation else None
    if field == "verbalization_attested_derived_surface":
        return derivation.attested_derived_surface if derivation else None
    agency = clause.causative_agency
    if field == "causative_voice":
        return agency.voice.value if agency else None
    if field == "causer_surface":
        return agency.causer.surface if agency else None
    if field == "causative_marker":
        return agency.marker if agency else None
    if field == "causative_source_subject_role":
        return agency.source_subject_role if agency else None
    directive = clause.directive
    if field == "directive_kind":
        return directive.kind.value if directive else None
    if field == "directive_placement":
        return directive.placement.value if directive else None
    if field == "directive_focus":
        return directive.focus.value if directive and directive.focus else None
    if field == "directive_addressee_surface":
        return directive.addressee.surface if directive else None
    if field == "directive_implicit_addressee":
        return (
            str(directive.implicit_addressee).casefold()
            if directive
            else None
        )
    if field == "directive_fused":
        return str(directive.fused).casefold() if directive else None
    if field == "directive_rapid_speech":
        return (
            str(directive.rapid_speech).casefold()
            if directive
            else None
        )
    if field == "directive_joint_participant_surface":
        return (
            directive.joint_participant.surface
            if directive and directive.joint_participant
            else None
        )
    if field == "preclausal_marker_kind":
        return (
            clause.preclausal_marker.kind.value
            if clause.preclausal_marker
            else None
        )
    if field == "discourse_marker_kind":
        return (
            clause.discourse_marker.kind.value
            if clause.discourse_marker
            else None
        )
    binder = clause.tte_binder
    qualification = binder.qualification if binder else None
    if field == "tte_function":
        return binder.function.value if binder else None
    if field == "epistemic_stance":
        return qualification.stance.value if qualification else None
    if field == "epistemic_forms":
        return " ".join(qualification.forms) if qualification else None
    if field == "zero_copula":
        return str(clause.zero_copula).casefold()
    if field == "subject_marked":
        return str(clause.subject_marked).casefold()
    if field == "temporal_aspect":
        return clause.temporal_aspect.value
    if field == "frequency_kind":
        return (
            clause.frequency.kind.value if clause.frequency else None
        )
    if field == "frequency_marker":
        return clause.frequency.marker if clause.frequency else None
    if field == "frequency_scope":
        return clause.frequency.scope if clause.frequency else None
    predicate_time = clause.predicate_time_binding
    if field == "predicate_word_time_marker":
        return predicate_time.marker if predicate_time else None
    if field == "predicate_word_time_orientation":
        return predicate_time.orientation.value if predicate_time else None
    if field == "predicate_word_time_scope":
        return predicate_time.scope.value if predicate_time else None
    if field == "predicate_word_time_placement":
        return predicate_time.placement.value if predicate_time else None
    if field == "predicate_word_time_fused":
        return (
            str(predicate_time.fused).casefold()
            if predicate_time
            else None
        )
    if field == "distribution_kind":
        return (
            clause.distribution.kind.value
            if clause.distribution
            else None
        )
    if field == "distribution_marker":
        return clause.distribution.marker if clause.distribution else None
    if field == "distribution_scope":
        return (
            clause.distribution.scope.value
            if clause.distribution
            else None
        )
    for prefix, nominal in (
        ("subject", clause.subject),
        ("object", clause.object),
        ("complement", clause.complement),
        ("location", clause.location),
        ("time", clause.time),
    ):
        quantifier = nominal.quantifier if nominal else None
        if field == f"{prefix}_quantifier_kind":
            return quantifier.kind.value if quantifier else None
        if field == f"{prefix}_quantifier_marker":
            return quantifier.marker if quantifier else None
        extent = nominal.extent if nominal else None
        if field == f"{prefix}_extent_kind":
            return extent.kind.value if extent else None
        if field == f"{prefix}_extent_marker":
            return extent.marker if extent else None
        if field == f"{prefix}_extent_denominator":
            return extent.denominator if extent else None
        if field == f"{prefix}_extent_denominator_value":
            return (
                str(extent.denominator_value)
                if extent and extent.denominator_value is not None
                else None
            )
        if field == f"{prefix}_extent_emphasized":
            return (
                str(extent.emphasized).casefold()
                if extent
                else None
            )
        if field == f"{prefix}_deixis":
            return nominal.deixis.value if nominal and nominal.deixis else None
        word_time = nominal.word_time_binding if nominal else None
        if field == f"{prefix}_word_time_marker":
            return word_time.marker if word_time else None
        if field == f"{prefix}_word_time_orientation":
            return word_time.orientation.value if word_time else None
        if field == f"{prefix}_word_time_scope":
            return word_time.scope.value if word_time else None
        if field == f"{prefix}_word_time_placement":
            return word_time.placement.value if word_time else None
        if field == f"{prefix}_word_time_fused":
            return (
                str(word_time.fused).casefold()
                if word_time
                else None
            )
        if field == f"{prefix}_possessor_surface":
            return (
                nominal.possessor.surface
                if nominal is not None and nominal.possessor is not None
                else None
            )
        verbal_nominal = (
            nominal.verbal_nominalization if nominal else None
        )
        if field == f"{prefix}_verbal_nominal_predicate":
            return verbal_nominal.predicate if verbal_nominal else None
        if field == f"{prefix}_verbal_nominal_lexeme_id":
            return (
                verbal_nominal.predicate_lexeme_id
                if verbal_nominal
                else None
            )
        if field == f"{prefix}_verbal_nominal_nominalizer":
            return verbal_nominal.nominalizer if verbal_nominal else None
        if field == f"{prefix}_verbal_nominal_specific":
            return (
                str(verbal_nominal.specific).casefold()
                if verbal_nominal
                else None
            )
        if field == f"{prefix}_verbal_nominal_proximal_marker":
            return (
                verbal_nominal.proximal_marker
                if verbal_nominal
                else None
            )
        if field == f"{prefix}_coordinated_count":
            return str(len(nominal.coordinated)) if nominal else None
        coordinated_prefix = f"{prefix}_coordinated_"
        if field.startswith(coordinated_prefix):
            remainder = field.removeprefix(coordinated_prefix)
            position_text, separator, attribute = remainder.partition("_")
            if separator and position_text.isdigit():
                position = int(position_text) - 1
                coordinated = (
                    nominal.coordinated[position]
                    if nominal is not None
                    and 0 <= position < len(nominal.coordinated)
                    else None
                )
                coordinated_verbal = (
                    coordinated.verbal_nominalization
                    if coordinated is not None
                    else None
                )
                if attribute == "surface":
                    return coordinated.surface if coordinated else None
                if attribute == "predicate":
                    return (
                        coordinated_verbal.predicate
                        if coordinated_verbal
                        else None
                    )
        distribution = nominal.distribution if nominal else None
        if field == f"{prefix}_distribution_kind":
            return distribution.kind.value if distribution else None
        if field == f"{prefix}_distribution_marker":
            return distribution.marker if distribution else None
        if field == f"{prefix}_distribution_scope":
            return distribution.scope.value if distribution else None
        if field == f"{prefix}_distribution_target_role":
            return distribution.target_role if distribution else None
    if field == "connector":
        return clause.connector.value if clause.connector else None
    linked = clause.coordinated_clause
    if field == "linked_predicate":
        return linked.predicate if linked else None
    if field == "linked_subject_surface":
        return (
            linked.subject.surface
            if linked is not None and linked.subject is not None
            else None
        )
    if field == "linked_object_surface":
        return (
            linked.object.surface
            if linked is not None and linked.object is not None
            else None
        )
    indexed_oblique = None
    indexed_parts = field.split("_", 2)
    if (
        len(indexed_parts) == 3
        and indexed_parts[0] == "oblique"
        and indexed_parts[1].isdigit()
    ):
        # Manifest indexes are one-based so source-cited assertions remain
        # readable to editors who are not thinking in Python offsets.
        position = int(indexed_parts[1]) - 1
        indexed_oblique = (
            clause.obliques[position]
            if 0 <= position < len(clause.obliques)
            else None
        )
        suffix = indexed_parts[2]
        if suffix == "relation":
            return (
                indexed_oblique.relation.value
                if indexed_oblique is not None
                else None
            )
        if suffix == "marker":
            return (
                indexed_oblique.marker
                if indexed_oblique is not None
                else None
            )
        if suffix == "nominal_surface":
            return (
                indexed_oblique.nominal.surface
                if indexed_oblique is not None
                else None
            )
        indexed_nominal = (
            indexed_oblique.nominal
            if indexed_oblique is not None
            else None
        )
        indexed_verbal_nominal = (
            indexed_nominal.verbal_nominalization
            if indexed_nominal is not None
            else None
        )
        if suffix == "verbal_nominal_predicate":
            return (
                indexed_verbal_nominal.predicate
                if indexed_verbal_nominal
                else None
            )
        if suffix == "verbal_nominal_lexeme_id":
            return (
                indexed_verbal_nominal.predicate_lexeme_id
                if indexed_verbal_nominal
                else None
            )
        if suffix == "coordinated_count":
            return (
                str(len(indexed_nominal.coordinated))
                if indexed_nominal is not None
                else None
            )
        if suffix.startswith("coordinated_"):
            remainder = suffix.removeprefix("coordinated_")
            position_text, separator, attribute = remainder.partition("_")
            if separator and position_text.isdigit():
                position = int(position_text) - 1
                coordinated = (
                    indexed_nominal.coordinated[position]
                    if indexed_nominal is not None
                    and 0 <= position < len(indexed_nominal.coordinated)
                    else None
                )
                coordinated_verbal = (
                    coordinated.verbal_nominalization
                    if coordinated is not None
                    else None
                )
                if attribute == "surface":
                    return coordinated.surface if coordinated else None
                if attribute == "predicate":
                    return (
                        coordinated_verbal.predicate
                        if coordinated_verbal
                        else None
                    )
        if suffix == "function":
            return (
                indexed_oblique.function
                if indexed_oblique is not None
                else None
            )
        if suffix.startswith("distribution_"):
            distribution = (
                indexed_oblique.nominal.distribution
                if indexed_oblique is not None
                else None
            )
            attribute = suffix.removeprefix("distribution_")
            if attribute == "kind":
                return distribution.kind.value if distribution else None
            if attribute == "marker":
                return distribution.marker if distribution else None
            if attribute == "scope":
                return distribution.scope.value if distribution else None
            if attribute == "target_role":
                return distribution.target_role if distribution else None
    first_oblique = clause.obliques[0] if clause.obliques else None
    if field == "oblique_count":
        return str(len(clause.obliques))
    if field == "oblique_relation":
        return (
            first_oblique.relation.value
            if first_oblique is not None
            else None
        )
    if field == "oblique_marker":
        return first_oblique.marker if first_oblique is not None else None
    if field == "oblique_nominal_surface":
        return (
            first_oblique.nominal.surface
            if first_oblique is not None
            else None
        )
    first_oblique_nominal = (
        first_oblique.nominal if first_oblique is not None else None
    )
    first_oblique_verbal_nominal = (
        first_oblique_nominal.verbal_nominalization
        if first_oblique_nominal is not None
        else None
    )
    if field == "oblique_verbal_nominal_predicate":
        return (
            first_oblique_verbal_nominal.predicate
            if first_oblique_verbal_nominal
            else None
        )
    if field == "oblique_verbal_nominal_lexeme_id":
        return (
            first_oblique_verbal_nominal.predicate_lexeme_id
            if first_oblique_verbal_nominal
            else None
        )
    if field == "oblique_coordinated_count":
        return (
            str(len(first_oblique_nominal.coordinated))
            if first_oblique_nominal is not None
            else None
        )
    if field.startswith("oblique_coordinated_"):
        remainder = field.removeprefix("oblique_coordinated_")
        position_text, separator, attribute = remainder.partition("_")
        if separator and position_text.isdigit():
            position = int(position_text) - 1
            coordinated = (
                first_oblique_nominal.coordinated[position]
                if first_oblique_nominal is not None
                and 0 <= position < len(first_oblique_nominal.coordinated)
                else None
            )
            coordinated_verbal = (
                coordinated.verbal_nominalization
                if coordinated is not None
                else None
            )
            if attribute == "surface":
                return coordinated.surface if coordinated else None
            if attribute == "predicate":
                return (
                    coordinated_verbal.predicate
                    if coordinated_verbal
                    else None
                )
    if field.startswith("oblique_distribution_"):
        distribution = (
            first_oblique.nominal.distribution
            if first_oblique is not None
            else None
        )
        if field == "oblique_distribution_kind":
            return distribution.kind.value if distribution else None
        if field == "oblique_distribution_marker":
            return distribution.marker if distribution else None
        if field == "oblique_distribution_scope":
            return distribution.scope.value if distribution else None
        if field == "oblique_distribution_target_role":
            return distribution.target_role if distribution else None
    if field == "oblique_function":
        return (
            first_oblique.function
            if first_oblique is not None
            else None
        )
    raise ValueError(f"Unknown canonical conformance field: {field}")


def _missing_roles(
    tokens: Iterable[Any],
    expected: tuple[tuple[str, str], ...],
) -> tuple[str, ...]:
    observed: dict[str, set[str | None]] = {}
    for token in tokens:
        observed.setdefault(token.surface, set()).add(token.role)
    return tuple(
        f"{surface!r} as {role!r}"
        for surface, role in expected
        if role not in observed.get(surface, set())
    )


def run_grammar_conformance(
    database: LanguageDatabase,
    vault_root: Path,
    *,
    manifest_path: Path | None = None,
) -> GrammarConformanceReport:
    """Validate general parser rules against source-cited examples/probes."""

    cases, forbidden_fragments = load_grammar_conformance_manifest(
        manifest_path
    )
    translator = Translator(database)
    asaxi_root = (vault_root.resolve() / ASAXI_RELATIVE_ROOT).resolve()
    results: list[GrammarConformanceCaseResult] = []

    for case in cases:
        failures: list[str] = []
        source = (asaxi_root / Path(case.source_path)).resolve()
        try:
            source.relative_to(asaxi_root)
        except ValueError:
            failures.append("source path escapes the authoritative Asaxi root")
        if not source.is_file():
            failures.append("source note is missing")
        else:
            source_text = source.read_text(encoding="utf-8")
            if case.source_contains not in source_text:
                failures.append(
                    "source evidence is no longer present in the cited note"
                )

        translation = translator.asaxi_to_english(case.input_text)
        selected = translation.selected
        selected_output = (
            selected.output_text if selected is not None else None
        )
        outputs = tuple(
            alternative.output_text
            for alternative in translation.alternatives
        )
        diagnostic_codes = tuple(
            diagnostic.code for diagnostic in translation.diagnostics
        )
        if translation.status.value not in case.expected_statuses:
            failures.append(
                f"status {translation.status.value!r} is not one of "
                f"{case.expected_statuses!r}"
            )
        if (
            case.selected_output is not None
            and selected_output != case.selected_output
        ):
            failures.append(
                f"selected output is {selected_output!r}, expected "
                f"{case.selected_output!r}"
            )
        for required in case.required_outputs:
            if required not in outputs:
                failures.append(
                    f"required interpretation is absent: {required!r}"
                )
        for required in case.required_diagnostics:
            if required not in diagnostic_codes:
                failures.append(
                    f"required diagnostic is absent: {required!r}"
                )
        for fragment in forbidden_fragments:
            leaking = tuple(
                output for output in outputs if fragment in output
            )
            if leaking:
                failures.append(
                    f"forbidden metadata fragment {fragment!r} leaked "
                    f"into {len(leaking)} interpretation(s)"
                )
        if selected is None:
            if (
                case.required_rules
                or case.required_roles
                or case.canonical_expectations
            ):
                failures.append(
                    "no selected interpretation exists for structural checks"
                )
        else:
            missing_rules = tuple(
                rule
                for rule in case.required_rules
                if rule not in selected.rule_trace
            )
            if missing_rules:
                failures.append(
                    "selected interpretation is missing rule trace(s): "
                    + ", ".join(missing_rules)
                )
            missing_roles = _missing_roles(
                selected.tokens,
                case.required_roles,
            )
            if missing_roles:
                failures.append(
                    "selected interpretation is missing token role(s): "
                    + ", ".join(missing_roles)
                )
            for field, expected in case.canonical_expectations:
                observed = _canonical_value(selected, field)
                if observed != expected:
                    failures.append(
                        f"canonical {field} is {observed!r}, expected "
                        f"{expected!r}"
                    )
        if (
            case.maximum_alternatives is not None
            and len(translation.alternatives)
            > case.maximum_alternatives
        ):
            failures.append(
                f"{len(translation.alternatives)} interpretations exceed "
                f"the bounded maximum of {case.maximum_alternatives}"
            )
        results.append(
            GrammarConformanceCaseResult(
                identifier=case.identifier,
                rule_family=case.rule_family,
                kind=case.kind,
                passed=not failures,
                source_path=case.source_path,
                input_text=case.input_text,
                observed_status=translation.status.value,
                selected_output=selected_output,
                alternative_count=len(translation.alternatives),
                diagnostic_codes=diagnostic_codes,
                failures=tuple(failures),
            )
        )
    return GrammarConformanceReport(
        schema_version=CONFORMANCE_SCHEMA_VERSION,
        source_digest=database.source_digest,
        results=tuple(results),
    )
