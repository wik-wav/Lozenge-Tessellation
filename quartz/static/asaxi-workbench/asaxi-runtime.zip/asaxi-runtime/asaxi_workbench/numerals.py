"""Shared documented Asaxi numeral forms used by grammar transfer."""

from __future__ import annotations


SIMPLE_CARDINAL_BY_VALUE: dict[int, str] = {
    0: "dzeŕo",
    1: "să",
    2: "tam",
    3: "fă",
    4: "bam",
    5: "ŕă",
    6: "sham",
    7: "shă",
    8: "sam",
    9: "wă",
    10: "dam",
}
SIMPLE_CARDINAL_VALUE_BY_FORM: dict[str, int] = {
    form: value for value, form in SIMPLE_CARDINAL_BY_VALUE.items()
}

# Note 39 defines denominator fractions with pù- and numbers. One is
# expressed as the whole (săsă), so productive partial extents begin at two.
FRACTION_DENOMINATOR_BY_VALUE: dict[int, str] = {
    value: form
    for value, form in SIMPLE_CARDINAL_BY_VALUE.items()
    if 2 <= value <= 10
}
FRACTION_DENOMINATOR_VALUE_BY_FORM: dict[str, int] = {
    form: value for value, form in FRACTION_DENOMINATOR_BY_VALUE.items()
}

ENGLISH_UNIT_FRACTION_BY_VALUE: dict[int, str] = {
    2: "half",
    3: "a third",
    4: "a quarter",
    5: "a fifth",
    6: "a sixth",
    7: "a seventh",
    8: "an eighth",
    9: "a ninth",
    10: "a tenth",
}
ENGLISH_FRACTION_VALUE_BY_FORM: dict[str, int] = {
    "half": 2,
    "third": 3,
    "quarter": 4,
    "fourth": 4,
    "fifth": 5,
    "sixth": 6,
    "seventh": 7,
    "eighth": 8,
    "ninth": 9,
    "tenth": 10,
}


def simple_cardinal_form(value: int) -> str | None:
    """Return the documented 0-10 cardinal form, if this slice covers it."""

    return SIMPLE_CARDINAL_BY_VALUE.get(value)


def simple_cardinal_value(form: str) -> int | None:
    """Return the value of one documented 0-10 cardinal form."""

    return SIMPLE_CARDINAL_VALUE_BY_FORM.get(form.casefold())


def fraction_denominator_form(value: int) -> str | None:
    """Return a supported pù- denominator without inventing larger forms."""

    return FRACTION_DENOMINATOR_BY_VALUE.get(value)


def fraction_denominator_value(form: str) -> int | None:
    """Return the value of a supported pù- denominator."""

    return FRACTION_DENOMINATOR_VALUE_BY_FORM.get(form.casefold())


def english_unit_fraction(value: int) -> str | None:
    """Return the conventional English singular unit-fraction expression."""

    return ENGLISH_UNIT_FRACTION_BY_VALUE.get(value)
