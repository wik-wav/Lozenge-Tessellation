"""Shared semantic evidence for Asaxi's physical-location constraint."""

from __future__ import annotations

from collections.abc import Iterable

from .models import Lexeme
from .translation_lexicon import split_english_gloss


# Grammar_Structure/07 licenses spatial prefixes and predicates only for
# physical location.  Unknown evidence stays unknown; it is never promoted to
# physical merely because an English preposition or Asaxi spatial form occurs.
ABSTRACT_SPATIAL_LANDMARK_HEADS = frozenset(
    {
        "category",
        "dream",
        "film",
        "group",
        "movie",
        "relationship",
        "society",
        "story",
        "system",
        "team",
        "theory",
        "trouble",
    }
)
PHYSICAL_SPATIAL_LANDMARK_FIELDS = frozenset(
    {
        "clothing",
        "environment",
        "food & drink",
        "geography (topography)",
        "housing & shelter",
        "materials",
        "objects",
        "place names",
        "the body",
        "tools",
    }
)
PHYSICAL_SPATIAL_LANDMARK_HEADS = frozenset(
    {
        "airport",
        "bed",
        "bottle",
        "box",
        "bridge",
        "building",
        "chair",
        "city",
        "container",
        "country",
        "cup",
        "field",
        "floor",
        "forest",
        "garden",
        "hill",
        "home",
        "hospital",
        "house",
        "island",
        "lake",
        "land",
        "mountain",
        "ocean",
        "office",
        "park",
        "place",
        "region",
        "river",
        "road",
        "room",
        "school",
        "sea",
        "shelf",
        "space",
        "station",
        "street",
        "table",
        "town",
        "tree",
        "village",
        "wall",
    }
)
SPATIAL_PHYSICAL = "physical"
SPATIAL_ABSTRACT = "abstract"
SPATIAL_UNKNOWN = "unknown"


def classify_spatial_landmark(
    surface: str,
    lexemes: Iterable[Lexeme] = (),
) -> str:
    """Classify a potential landmark using explicit lexical evidence.

    Multiword glosses contribute their component words so an Asaxi entry
    glossed ``social system`` is correctly recognized as abstract.  Semantic
    fields can establish physicality, but absent evidence remains unknown.
    """

    glosses = {surface.casefold().strip()}
    semantic_fields: set[str] = set()
    for lexeme in lexemes:
        glosses.update(
            term.casefold().strip()
            for term in split_english_gloss(lexeme)
            if term.strip()
        )
        semantic_fields.update(
            field.removeprefix("Smntc_Field ").strip().casefold()
            for field in lexeme.semantic_fields
        )
    gloss_words = {
        word.strip(".,;:!?()[]{}\"'")
        for gloss in glosses
        for word in gloss.split()
    }
    if (
        glosses & ABSTRACT_SPATIAL_LANDMARK_HEADS
        or gloss_words & ABSTRACT_SPATIAL_LANDMARK_HEADS
    ):
        return SPATIAL_ABSTRACT
    if (
        glosses & PHYSICAL_SPATIAL_LANDMARK_HEADS
        or gloss_words & PHYSICAL_SPATIAL_LANDMARK_HEADS
        or semantic_fields & PHYSICAL_SPATIAL_LANDMARK_FIELDS
    ):
        return SPATIAL_PHYSICAL
    return SPATIAL_UNKNOWN
