"""Deterministic static distribution for embedding in Quartz."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import pickle
import shutil
from typing import Any
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from .compiler import CompileConfig, compile_language, write_database
from .phrase_memory import DEFAULT_PHRASE_MEMORY_PATH, PhraseMemoryStore
from .version import WORKBENCH_VERSION
from .webapp import WEB_ROOT


QUARTZ_BUNDLE_SCHEMA_VERSION = "1.0"
PUBLIC_FILES = (
    "index.html",
    "styles.css",
    "app.js",
    "assets/Asaxi-alphabet-Merriweather24pt-Medium.ttf",
)
OPTIONAL_PUBLIC_FILES = ("assets/AsaxiAbugida.ttf",)
PYODIDE_FILES = (
    "pyodide.js",
    "pyodide.asm.js",
    "pyodide.asm.wasm",
    "pyodide-lock.json",
    "python_stdlib.zip",
)
BROWSER_RUNTIME_FILES = (
    "browser-worker.js",
    "asaxi-runtime.zip",
    "THIRD_PARTY_NOTICES.txt",
    *(f"pyodide/{name}" for name in PYODIDE_FILES),
)
PACKAGE_ROOT = Path(__file__).resolve().parent


def _public_files() -> tuple[str, ...]:
    return (
        *PUBLIC_FILES,
        *(
            relative
            for relative in OPTIONAL_PUBLIC_FILES
            if (WEB_ROOT / relative).is_file()
        ),
    )


def _asset_version(
    *,
    browser_runtime: bool,
    runtime_archive: Path | None = None,
) -> str:
    digest = hashlib.sha256()
    for name in ("index.html", "styles.css", "app.js"):
        digest.update(name.encode("ascii"))
        digest.update((WEB_ROOT / name).read_bytes())
    if browser_runtime:
        digest.update((WEB_ROOT / "browser-worker.js").read_bytes())
        if runtime_archive is None:
            raise ValueError("Browser export requires a runtime archive")
        digest.update(b"asaxi-runtime.zip")
        digest.update(runtime_archive.read_bytes())
    return digest.hexdigest()[:12]


def _public_output_files(
    public_files: tuple[str, ...],
    *,
    browser_runtime: bool,
) -> frozenset[str]:
    return frozenset(
        (
            *public_files,
            *(BROWSER_RUNTIME_FILES if browser_runtime else ()),
            "config.js",
            "authored-phrases.public.json",
            "asaxi-language-db.json",
            "quartz-bundle-manifest.json",
        )
    )


def _runtime_package_files() -> tuple[Path, ...]:
    files = [*PACKAGE_ROOT.glob("*.py")]
    files.extend(PACKAGE_ROOT.glob("*.toml"))
    files.extend(PACKAGE_ROOT.glob("*.json"))
    files.extend((PACKAGE_ROOT / "data").glob("*.json"))
    return tuple(sorted(files, key=lambda path: path.relative_to(PACKAGE_ROOT).as_posix()))


def _archive_info(name: str) -> ZipInfo:
    info = ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
    info.compress_type = ZIP_DEFLATED
    info.external_attr = 0o100644 << 16
    return info


def _write_browser_runtime_archive(
    destination: Path,
    database: Any,
    phrase_memory: PhraseMemoryStore,
) -> None:
    runtime_phrases = {
        "schema_version": "2.0",
        "entries": [
            entry.to_dict(public=True)
            for entry in phrase_memory.entries
            if entry.verified
        ],
    }
    rendered_phrases = (
        json.dumps(runtime_phrases, ensure_ascii=False, indent=2, sort_keys=True)
        + "\n"
    ).encode("utf-8")
    database_pickle = pickle.dumps(database, protocol=5)
    with ZipFile(destination, "w", compression=ZIP_DEFLATED, compresslevel=9) as archive:
        for source in _runtime_package_files():
            relative = source.relative_to(PACKAGE_ROOT).as_posix()
            if relative == "data/authored_phrases.json":
                continue
            archive.writestr(
                _archive_info(f"asaxi-runtime/asaxi_workbench/{relative}"),
                source.read_bytes(),
            )
        archive.writestr(
            _archive_info("asaxi-runtime/authored-phrases.runtime.json"),
            rendered_phrases,
        )
        archive.writestr(
            _archive_info("asaxi-runtime/asaxi-language-db.pickle"),
            database_pickle,
        )


def _copy_pyodide_runtime(source_root: Path, destination: Path) -> str:
    root = source_root.resolve()
    package_path = root / "package.json"
    if not package_path.is_file():
        raise ValueError(f"Pyodide package metadata was not found in {root}")
    metadata = json.loads(package_path.read_text(encoding="utf-8"))
    if metadata.get("license") != "MPL-2.0":
        raise ValueError("The configured Pyodide package must declare MPL-2.0")
    target_root = destination / "pyodide"
    target_root.mkdir(parents=True, exist_ok=True)
    for name in PYODIDE_FILES:
        source = root / name
        if not source.is_file():
            raise ValueError(f"Required Pyodide runtime file is missing: {source}")
        shutil.copyfile(source, target_root / name)
    version = str(metadata.get("version") or "unknown")
    notice = (
        f"Pyodide {version}\n"
        "SPDX-License-Identifier: MPL-2.0\n"
        "Project: https://github.com/pyodide/pyodide\n"
        "License: https://www.mozilla.org/MPL/2.0/\n"
    )
    (destination / "THIRD_PARTY_NOTICES.txt").write_text(
        notice,
        encoding="utf-8",
        newline="\n",
    )
    return version


def _reject_unexpected_output_files(
    destination: Path,
    expected_files: frozenset[str],
) -> None:
    if not destination.exists():
        return
    unexpected = sorted(
        path.relative_to(destination).as_posix()
        for path in destination.rglob("*")
        if path.is_file()
        and path.relative_to(destination).as_posix() not in expected_files
    )
    if unexpected:
        rendered = ", ".join(unexpected)
        raise ValueError(
            "Quartz export directory contains unexpected files; refusing "
            f"to publish a mixed bundle: {rendered}"
        )

def export_quartz_bundle(
    config: CompileConfig,
    output: Path,
    *,
    phrase_memory_path: Path | None = None,
    api_base: str = "",
    pyodide_root: Path | None = None,
) -> dict[str, Any]:
    """Build a static, public-safe Workbench bundle for Quartz."""

    destination = output.resolve()
    public_files = _public_files()
    browser_runtime = pyodide_root is not None and not api_base.strip()
    public_output_files = _public_output_files(
        public_files,
        browser_runtime=browser_runtime,
    )
    _reject_unexpected_output_files(destination, public_output_files)
    destination.mkdir(parents=True, exist_ok=True)
    phrase_memory = PhraseMemoryStore(
        phrase_memory_path or DEFAULT_PHRASE_MEMORY_PATH
    )
    database = compile_language(config)
    pyodide_version: str | None = None
    if browser_runtime:
        shutil.copyfile(WEB_ROOT / "browser-worker.js", destination / "browser-worker.js")
        _write_browser_runtime_archive(
            destination / "asaxi-runtime.zip",
            database,
            phrase_memory,
        )
        pyodide_version = _copy_pyodide_runtime(pyodide_root, destination)

    asset_version = _asset_version(
        browser_runtime=browser_runtime,
        runtime_archive=(
            destination / "asaxi-runtime.zip" if browser_runtime else None
        ),
    )
    for relative in public_files:
        source = WEB_ROOT / relative
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        if relative == "index.html":
            rendered = source.read_text(encoding="utf-8")
            for name in ("config.js", "styles.css", "app.js"):
                rendered = rendered.replace(
                    f'./{name}"',
                    f'./{name}?v={asset_version}"',
                )
            target.write_text(rendered, encoding="utf-8", newline="\n")
        else:
            shutil.copyfile(source, target)

    normalized_api_base = api_base.strip().rstrip("/")
    runtime_config = (
        "window.ASAXI_WORKBENCH_CONFIG = Object.freeze({\n"
        f"  apiBase: {json.dumps(normalized_api_base)},\n"
        f"  browserWorker: {json.dumps(f'./browser-worker.js?v={asset_version}' if browser_runtime else '')},\n"
        '  publicPhraseIndex: "./authored-phrases.public.json",\n'
        "})\n"
    )
    (destination / "config.js").write_text(
        runtime_config,
        encoding="utf-8",
        newline="\n",
    )

    phrase_memory.export_public(
        destination / "authored-phrases.public.json"
    )
    write_database(database, destination / "asaxi-language-db.json")
    grammar_model = database.grammar_model.reference(
        runtime_workbench_version=WORKBENCH_VERSION
    )
    manifest = {
        "schema_version": QUARTZ_BUNDLE_SCHEMA_VERSION,
        "workbench_version": WORKBENCH_VERSION,
        "translation_runtime": (
            "configured-http-api"
            if normalized_api_base
            else "browser-python"
            if browser_runtime
            else "api-required"
        ),
        "api_base": normalized_api_base,
        "asset_version": asset_version,
        "pyodide_version": pyodide_version,
        "authored_phrase_count": phrase_memory.verified_count,
        "grammar_model": grammar_model.to_dict(),
        "public_assets": sorted(
            public_output_files - {"quartz-bundle-manifest.json"}
        ),
        "developer_authoring_included": False,
    }
    (destination / "quartz-bundle-manifest.json").write_text(
        json.dumps(
            manifest,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
        newline="\n",
    )
    return manifest
