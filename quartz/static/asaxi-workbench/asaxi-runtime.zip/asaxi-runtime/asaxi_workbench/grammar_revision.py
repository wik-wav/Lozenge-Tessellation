"""Deterministic provenance for the grammar notes implemented by Workshop."""

from __future__ import annotations

from datetime import date
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
from typing import Iterable

from .models import (
    GrammarModelRevision,
    GrammarSourceChange,
    GrammarSourceNote,
)


GRAMMAR_MODEL_SCHEMA_VERSION = "1.0"
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


def grammar_source_digest(notes: Iterable[GrammarSourceNote]) -> str:
    """Hash a sorted path/hash inventory without timestamps or host paths."""

    ordered = normalize_grammar_notes(notes)
    payload = "\n".join(
        f"{note.path}:{note.sha256}" for note in ordered
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _validate_note(note: GrammarSourceNote) -> None:
    path = PurePosixPath(note.path)
    if path.is_absolute() or ".." in path.parts or not note.path:
        raise ValueError(
            f"Grammar-model note path is not portable: {note.path!r}"
        )
    if ":" in path.parts[0]:
        raise ValueError(
            f"Grammar-model note path contains a drive: {note.path!r}"
        )
    if not _SHA256_RE.fullmatch(note.sha256):
        raise ValueError(
            f"Grammar-model note has invalid SHA-256: {note.path!r}"
        )


def normalize_grammar_notes(
    notes: Iterable[GrammarSourceNote],
) -> tuple[GrammarSourceNote, ...]:
    ordered = tuple(sorted(notes, key=lambda note: note.path.casefold()))
    seen: set[str] = set()
    for note in ordered:
        _validate_note(note)
        key = note.path.casefold()
        if key in seen:
            raise ValueError(
                f"Grammar-model note path is duplicated: {note.path!r}"
            )
        seen.add(key)
    return ordered


def _load_manifest(path: Path) -> dict[str, object]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Grammar-model manifest must be a JSON object")
    if payload.get("schema_version") != GRAMMAR_MODEL_SCHEMA_VERSION:
        raise ValueError(
            "Unsupported grammar-model manifest schema: "
            f"{payload.get('schema_version')!r}"
        )
    return payload


def _manifest_notes(payload: dict[str, object]) -> tuple[GrammarSourceNote, ...]:
    raw_notes = payload.get("notes")
    if not isinstance(raw_notes, list):
        raise ValueError("Grammar-model manifest 'notes' must be an array")
    notes: list[GrammarSourceNote] = []
    for item in raw_notes:
        if not isinstance(item, dict):
            raise ValueError("Each grammar-model note must be an object")
        path = item.get("path")
        sha256 = item.get("sha256")
        if not isinstance(path, str) or not isinstance(sha256, str):
            raise ValueError(
                "Each grammar-model note needs string path and sha256 fields"
            )
        notes.append(GrammarSourceNote(path=path, sha256=sha256))
    return normalize_grammar_notes(notes)


def _required_text(payload: dict[str, object], field: str) -> str:
    value = payload.get(field)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(
            f"Grammar-model manifest {field!r} must be non-empty text"
        )
    return value.strip()


def _changes(
    validated: tuple[GrammarSourceNote, ...],
    current: tuple[GrammarSourceNote, ...],
) -> tuple[GrammarSourceChange, ...]:
    old = {note.path: note.sha256 for note in validated}
    new = {note.path: note.sha256 for note in current}
    changes: list[GrammarSourceChange] = []
    for path in sorted(set(old) | set(new), key=str.casefold):
        old_hash = old.get(path)
        new_hash = new.get(path)
        if old_hash == new_hash:
            continue
        change = (
            "added"
            if old_hash is None
            else "removed"
            if new_hash is None
            else "modified"
        )
        changes.append(
            GrammarSourceChange(
                path=path,
                change=change,
                validated_sha256=old_hash,
                current_sha256=new_hash,
            )
        )
    return tuple(changes)


def resolve_grammar_model_revision(
    current_notes: Iterable[GrammarSourceNote],
    manifest_path: Path | None,
) -> GrammarModelRevision:
    """Compare live notes with the last explicitly validated snapshot."""

    current = normalize_grammar_notes(current_notes)
    current_digest = grammar_source_digest(current)
    if manifest_path is None or not manifest_path.is_file():
        return GrammarModelRevision(
            schema_version=GRAMMAR_MODEL_SCHEMA_VERSION,
            model_version=None,
            updated_on=None,
            validated_with_workbench_version=None,
            validated_with_translation_engine_version=None,
            status="unversioned",
            validated_source_digest=None,
            current_source_digest=current_digest,
            notes=current,
            current_notes=current,
        )

    payload = _load_manifest(manifest_path)
    validated = _manifest_notes(payload)
    declared_digest = _required_text(payload, "source_digest")
    calculated_digest = grammar_source_digest(validated)
    if declared_digest != calculated_digest:
        raise ValueError(
            "Grammar-model manifest source_digest does not match its notes"
        )
    updated_on = _required_text(payload, "updated_on")
    try:
        date.fromisoformat(updated_on)
    except ValueError as error:
        raise ValueError(
            "Grammar-model manifest updated_on must be ISO YYYY-MM-DD"
        ) from error
    changes = _changes(validated, current)
    return GrammarModelRevision(
        schema_version=GRAMMAR_MODEL_SCHEMA_VERSION,
        model_version=_required_text(payload, "model_version"),
        updated_on=updated_on,
        validated_with_workbench_version=_required_text(
            payload,
            "validated_with_workbench_version",
        ),
        validated_with_translation_engine_version=_required_text(
            payload,
            "validated_with_translation_engine_version",
        ),
        status="current" if not changes else "source-drift",
        validated_source_digest=declared_digest,
        current_source_digest=current_digest,
        notes=validated,
        current_notes=current,
        changes=changes,
    )


def render_grammar_model_manifest(
    notes: Iterable[GrammarSourceNote],
    *,
    model_version: str,
    updated_on: str,
    workbench_version: str,
    translation_engine_version: str,
) -> bytes:
    """Render a reviewable lock after behavior and conformance are updated."""

    normalized = normalize_grammar_notes(notes)
    date.fromisoformat(updated_on)
    payload = {
        "schema_version": GRAMMAR_MODEL_SCHEMA_VERSION,
        "model_version": model_version,
        "updated_on": updated_on,
        "validated_with_workbench_version": workbench_version,
        "validated_with_translation_engine_version": (
            translation_engine_version
        ),
        "source_digest": grammar_source_digest(normalized),
        "notes": [note.to_dict() for note in normalized],
    }
    return (
        json.dumps(
            payload,
            ensure_ascii=False,
            sort_keys=True,
            indent=2,
        )
        + "\n"
    ).encode("utf-8")
