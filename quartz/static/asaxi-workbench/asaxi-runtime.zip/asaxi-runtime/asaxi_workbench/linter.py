"""Specification diagnostics for a compiled Asaxi language database."""

from __future__ import annotations

from collections import Counter
from pathlib import PurePosixPath, PureWindowsPath
import re

from .models import (
    Diagnostic,
    FieldValue,
    LanguageDatabase,
    Severity,
    SpecificationStatus,
    ValueState,
)
from .morphology import MorphologyEngine, tokenize_asaxi_text


UNRESOLVED_STATES = {
    ValueState.MISSING,
    ValueState.EMPTY,
    ValueState.PLACEHOLDER_X,
    ValueState.PLACEHOLDER_NULL,
}
LEXEME_LINK_RE = re.compile(
    r"\((?:noun|verb|adjective|particle|root word|number|idiom)\)$",
    re.IGNORECASE,
)


def _is_absolute_portable_path(value: str) -> bool:
    return PurePosixPath(value).is_absolute() or PureWindowsPath(value).is_absolute()


def _placeholder_diagnostic(
    value: FieldValue,
    *,
    field: str,
    source_path: str,
    required: bool,
) -> Diagnostic | None:
    if value.state not in UNRESOLVED_STATES:
        return None
    severity = Severity.WARNING if required else Severity.INFO
    return Diagnostic(
        code="REQUIRED_FIELD_UNRESOLVED" if required else "FIELD_UNRESOLVED",
        severity=severity,
        message=(
            f"{field} is {value.state.value}; the compiler preserved this "
            "state and did not infer a replacement"
        ),
        source_path=source_path,
        field=field,
    )


def lint_database(database: LanguageDatabase) -> list[Diagnostic]:
    diagnostics: list[Diagnostic] = []
    identifiers = Counter(lexeme.identifier for lexeme in database.lexemes)
    for identifier, count in sorted(identifiers.items()):
        if count > 1:
            diagnostics.append(
                Diagnostic(
                    code="DUPLICATE_LEXEME_ID",
                    severity=Severity.ERROR,
                    message=f"Lexeme id {identifier!r} occurs {count} times",
                    field="id",
                )
            )

    known_stems = {
        PurePosixPath(lexeme.source.path).stem.casefold()
        for lexeme in database.lexemes
    }
    for lexeme in database.lexemes:
        source_path = lexeme.source.path
        if _is_absolute_portable_path(source_path):
            diagnostics.append(
                Diagnostic(
                    code="ABSOLUTE_SOURCE_PATH",
                    severity=Severity.ERROR,
                    message="Compiled provenance contains an absolute path",
                    source_path=source_path,
                    field="source.path",
                )
            )
        required_fields: list[tuple[str, FieldValue]] = [
            ("senses[1].gloss_en", lexeme.senses[0].gloss_en),
        ]
        if lexeme.category == "noun":
            required_fields.append(("noun_class", lexeme.noun_class))
        if lexeme.category == "verb":
            required_fields.append(("valency", lexeme.valency))
        for field_name, value in required_fields:
            diagnostic = _placeholder_diagnostic(
                value,
                field=field_name,
                source_path=source_path,
                required=True,
            )
            if diagnostic:
                diagnostics.append(diagnostic)

        for sense in lexeme.senses:
            if (
                len(lexeme.senses) == 1
                and sense.gloss_en.is_present
                and "," in (sense.gloss_en.value or "")
            ):
                diagnostics.append(
                    Diagnostic(
                        code="UNSPLIT_TRANSLATION_CANDIDATE",
                        severity=Severity.WARNING,
                        message=(
                            "The English translation contains commas but the "
                            "entry has one sense; review whether distinct "
                            "senses or merely synonyms are intended"
                        ),
                        source_path=source_path,
                        field=f"senses[{sense.index}].gloss_en",
                    )
                )
            optional_values = (
                (f"senses[{sense.index}].gloss_pl", sense.gloss_pl),
            )
            for field_name, value in optional_values:
                diagnostic = _placeholder_diagnostic(
                    value,
                    field=field_name,
                    source_path=source_path,
                    required=False,
                )
                if diagnostic:
                    diagnostics.append(diagnostic)
            for example_index, example in enumerate(sense.examples, start=1):
                for suffix, value in (
                    ("asaxi", example.asaxi),
                    ("translation_en", example.translation_en),
                    ("translation_pl", example.translation_pl),
                ):
                    diagnostic = _placeholder_diagnostic(
                        value,
                        field=(
                            f"senses[{sense.index}].examples"
                            f"[{example_index}].{suffix}"
                        ),
                        source_path=source_path,
                        required=suffix in {"asaxi", "translation_en"},
                    )
                    if diagnostic:
                        diagnostics.append(diagnostic)

        for field_name, value in (
            ("pronunciation", lexeme.pronunciation),
            ("pitch_accent", lexeme.pitch_accent),
            ("pitch_accent_class", lexeme.pitch_accent_class),
        ):
            diagnostic = _placeholder_diagnostic(
                value,
                field=field_name,
                source_path=source_path,
                required=False,
            )
            if diagnostic:
                diagnostics.append(diagnostic)

        for root in lexeme.root_links:
            if root.casefold() not in known_stems:
                diagnostics.append(
                    Diagnostic(
                        code="ROOT_LINK_UNRESOLVED",
                        severity=Severity.WARNING,
                        message=f"Linked root {root!r} is not a compiled lexeme",
                        source_path=source_path,
                        field="derivation.roots",
                    )
                )
        for derived in lexeme.derived_links:
            if (
                LEXEME_LINK_RE.search(derived)
                and derived.casefold() not in known_stems
            ):
                diagnostics.append(
                    Diagnostic(
                        code="DERIVED_LINK_UNRESOLVED",
                        severity=Severity.WARNING,
                        message=(
                            f"Linked derived form {derived!r} is not a "
                            "compiled lexeme"
                        ),
                        source_path=source_path,
                        field="derivation.derived_terms",
                    )
                )

    for document in database.grammar_documents:
        if _is_absolute_portable_path(document.source.path):
            diagnostics.append(
                Diagnostic(
                    code="ABSOLUTE_SOURCE_PATH",
                    severity=Severity.ERROR,
                    message="Compiled provenance contains an absolute path",
                    source_path=document.source.path,
                    field="source.path",
                )
            )
        if document.status is SpecificationStatus.PROPOSED:
            diagnostics.append(
                Diagnostic(
                    code="PROPOSED_GRAMMAR_RULE",
                    severity=Severity.WARNING,
                    message=(
                        "Grammar document contains an explicitly proposed "
                        "section: "
                        + ", ".join(document.proposed_sections)
                    ),
                    source_path=document.source.path,
                )
            )

    # Unknown example forms are aggregated by token. This is deliberately
    # informational: names and not-yet-implemented stacked morphology are
    # expected during the compiler-first phase.
    engine = MorphologyEngine(database)
    unknown_sources: dict[str, set[str]] = {}
    unknown_counts: Counter[str] = Counter()
    for lexeme in database.lexemes:
        for sense in lexeme.senses:
            for example in sense.examples:
                if not example.asaxi.is_present:
                    continue
                for token in tokenize_asaxi_text(example.asaxi.value or ""):
                    if engine.analyze(token):
                        continue
                    unknown_counts[token] += 1
                    unknown_sources.setdefault(token, set()).add(
                        lexeme.source.path
                    )
    for token in sorted(unknown_counts, key=str.casefold):
        sources = sorted(unknown_sources[token], key=str.casefold)
        diagnostics.append(
            Diagnostic(
                code="EXAMPLE_TOKEN_UNANALYZED",
                severity=Severity.INFO,
                message=(
                    f"No lexical or currently implemented productive "
                    f"analysis for example token {token!r}"
                ),
                source_path=sources[0] if sources else None,
                field="examples.asaxi",
                details={
                    "occurrences": unknown_counts[token],
                    "source_count": len(sources),
                },
            )
        )
    return diagnostics
