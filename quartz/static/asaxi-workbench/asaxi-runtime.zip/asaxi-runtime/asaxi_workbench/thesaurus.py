"""Optional, provenance-bearing English thesaurus adapters.

The translator uses thesaurus results only to widen lexical lookup after an
exact documented gloss fails.  A thesaurus never supplies syntax, target
grammar, or an untyped semantic relation.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from importlib import metadata
from typing import Mapping, Protocol


SUPPORTED_PARTS_OF_SPEECH = frozenset(
    {"noun", "verb", "adjective", "adverb"}
)


@dataclass(frozen=True)
class ThesaurusCandidate:
    term: str
    relation: str
    provider: str
    provider_version: str | None = None
    sense_id: str | None = None
    query_lemma: str | None = None


class ThesaurusProvider(Protocol):
    """Small interface suitable for local and browser-build adapters."""

    name: str
    version: str | None
    available: bool

    def lookup(
        self,
        term: str,
        part_of_speech: str,
    ) -> tuple[ThesaurusCandidate, ...]:
        ...


class NullThesaurus:
    name = "none"
    version = None
    available = False

    def lookup(
        self,
        term: str,
        part_of_speech: str,
    ) -> tuple[ThesaurusCandidate, ...]:
        return ()


class StaticThesaurus:
    """Deterministic provider used by tests and small curated deployments."""

    name = "static"
    version = "1"
    available = True

    def __init__(
        self,
        entries: Mapping[
            tuple[str, str],
            tuple[str, ...] | list[str],
        ],
    ):
        self._entries = {
            (term.casefold(), part_of_speech): tuple(values)
            for (term, part_of_speech), values in entries.items()
        }

    def lookup(
        self,
        term: str,
        part_of_speech: str,
    ) -> tuple[ThesaurusCandidate, ...]:
        if part_of_speech not in SUPPORTED_PARTS_OF_SPEECH:
            return ()
        query = term.casefold()
        return tuple(
            ThesaurusCandidate(
                term=value.casefold(),
                relation="synonym",
                provider=self.name,
                provider_version=self.version,
                query_lemma=query,
            )
            for value in self._entries.get(
                (query, part_of_speech),
                (),
            )
            if value.casefold() != query
        )


class NltkWordNetThesaurus:
    """WordNet synonym adapter loaded only when NLTK and its corpus exist."""

    name = "wordnet"

    def __init__(self, wordnet: object, version: str | None):
        self._wordnet = wordnet
        self.version = version
        self.available = True

    @classmethod
    def discover(cls) -> NltkWordNetThesaurus | None:
        try:
            from nltk.corpus import wordnet

            # Force a corpus access now so callers never encounter a delayed
            # LookupError during translation.
            wordnet.synsets("translation", pos=wordnet.NOUN)
            version = metadata.version("nltk")
        except (ImportError, LookupError, metadata.PackageNotFoundError):
            return None
        return cls(wordnet, version)

    @lru_cache(maxsize=4096)
    def lookup(
        self,
        term: str,
        part_of_speech: str,
    ) -> tuple[ThesaurusCandidate, ...]:
        if part_of_speech not in SUPPORTED_PARTS_OF_SPEECH:
            return ()
        pos = {
            "noun": self._wordnet.NOUN,
            "verb": self._wordnet.VERB,
            "adjective": self._wordnet.ADJ,
            "adverb": self._wordnet.ADV,
        }[part_of_speech]
        query = term.casefold().replace(" ", "_")
        try:
            query_lemma = self._wordnet.morphy(query, pos) or query
            synsets = self._wordnet.synsets(query, pos=pos)
        except LookupError:
            return ()

        candidates: dict[
            tuple[str, str | None],
            tuple[int, int, ThesaurusCandidate],
        ] = {}
        for sense_rank, synset in enumerate(synsets):
            sense_id = synset.name()
            for lemma_rank, lemma in enumerate(synset.lemmas()):
                candidate_term = lemma.name().replace("_", " ").casefold()
                if candidate_term in {query, query_lemma}:
                    continue
                candidate = ThesaurusCandidate(
                    term=candidate_term,
                    relation="synonym",
                    provider=self.name,
                    provider_version=self.version,
                    sense_id=sense_id,
                    query_lemma=query_lemma.replace("_", " "),
                )
                key = (candidate.term, candidate.sense_id)
                current = candidates.get(key)
                ranked = (sense_rank, lemma_rank, candidate)
                if current is None or ranked[:2] < current[:2]:
                    candidates[key] = ranked
        return tuple(
            item[2]
            for item in sorted(
                candidates.values(),
                key=lambda item: (
                    item[0],
                    item[1],
                    item[2].term,
                    item[2].sense_id or "",
                ),
            )
        )


def discover_thesaurus() -> ThesaurusProvider:
    """Return the optional local WordNet adapter without making it required."""

    return NltkWordNetThesaurus.discover() or NullThesaurus()
