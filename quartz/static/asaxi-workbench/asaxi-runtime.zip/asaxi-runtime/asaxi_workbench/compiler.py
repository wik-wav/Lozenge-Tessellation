"""Compile the authoritative Asaxi notes into a portable language database."""

from __future__ import annotations

from dataclasses import dataclass, replace
import hashlib
import json
from pathlib import Path
import re
import tomllib
from typing import Any

from .markdown import (
    MarkdownSection,
    ParsedMarkdown,
    frontmatter_list,
    normalize_heading,
    parse_examples,
    parse_markdown,
    plain_markdown_value,
    wiki_links,
)
from .models import (
    Diagnostic,
    DerivedTerm,
    Example,
    FieldValue,
    GrammarSourceNote,
    GrammarDocument,
    LanguageDatabase,
    Lexeme,
    LexicalVariant,
    Morpheme,
    Sense,
    Severity,
    SourceReference,
    SpecificationStatus,
    ValueState,
)
from .grammar_revision import resolve_grammar_model_revision


SCHEMA_VERSION = "0.4.0-provisional"
COMPILER_VERSION = "0.4.0"
DEFAULT_GRAMMAR_MODEL_MANIFEST = (
    Path(__file__).resolve().parent / "grammar_model.json"
)
ASAXI_RELATIVE_ROOT = Path("01_Worldbuilding") / "Asaxi"
ENTRY_TYPE_RE = re.compile(r"\(([^()]*)\)\.md$", re.IGNORECASE)
SENSE_KEY_RE = re.compile(r"^trnsltion\. (En|Pl)(?: (\d+))?$", re.IGNORECASE)
EXAMPLE_SECTION_RE = re.compile(
    r"^example sentences?(?: (\d+))?$",
    re.IGNORECASE,
)
IPA_RE = re.compile(r"\bIPA:\s*(/[^\n]+/)", re.IGNORECASE)
VALENCY_RE = re.compile(
    r"\b(ambitransitive|ditransitive|monotransitive|intransitive|transitive)\b",
    re.IGNORECASE,
)
ASPECT_TERMS = (
    "punctual",
    "achievement",
    "durative",
    "activity",
    "state",
    "accomplishment",
)

LEXICAL_VARIANT_TOKEN_RE = re.compile(
    r"[^\W\d_]+(?:(?:[.'’-])[^\W\d_]+)*(?:['’])?",
    re.IGNORECASE,
)
LEXICAL_VARIANT_EXCLUSION_RE = re.compile(
    r"\b(?:incorrect|hypercorrection|misspelling|wrong|ungrammatical|"
    r"do not use|not used)\b",
    re.IGNORECASE,
)
DERIVED_TERM_LINK_RE = re.compile(
    r"\[\[([^\]|#]+)(?:#[^\]|]+)?(?:\|([^\]]+))?\]\]"
)
DERIVED_TERM_CATEGORY_RE = re.compile(
    r"\b(root word|adjective|adverb|verb|noun|particle|number|idiom)\b",
    re.IGNORECASE,
)
DERIVED_TERM_STATUS_RE = re.compile(
    r"\b(potential|proposed|tentative)\b",
    re.IGNORECASE,
)
DERIVED_TERM_REFERENCE_RE = re.compile(
    r"^(?:see\b|for\b.*\bsee\b|no\b.*(?:\bsee\b|\battested\b|"
    r"\bderived\b|\bcompounds?\b))",
    re.IGNORECASE,
)
DERIVED_TERM_STRUCTURE_RE = re.compile(
    r"^(?:compound|derived)\s+forms?|^examples?|^notes?|^usage(?:\s+notes?)?$",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class CompileConfig:
    vault_root: Path
    grammar_registry: Path | None
    repository_root: Path | None = None
    grammar_model_manifest: Path | None = None
    grammar_claim_manifest: Path | None = None

    @classmethod
    def discover(
        cls,
        *,
        start: Path | None = None,
        vault_root: Path | None = None,
        grammar_registry: Path | None = None,
    ) -> "CompileConfig":
        if vault_root is not None:
            resolved_vault = vault_root.resolve()
            repository = _find_repository_root(resolved_vault)
        else:
            origin = (start or Path(__file__).resolve()).resolve()
            repository = _find_repository_root(origin)
            if repository is None:
                raise RuntimeError(
                    "Could not locate the repository containing "
                    "Lozenge-T-Notes; pass --vault explicitly"
                )
            resolved_vault = (repository / "Lozenge-T-Notes").resolve()
        if not (resolved_vault / ASAXI_RELATIVE_ROOT).is_dir():
            raise RuntimeError(
                f"Authoritative Asaxi notes not found below {resolved_vault}"
            )

        registry = grammar_registry
        if registry is None and repository is not None:
            candidate = (
                repository
                / "99_Tools"
                / "vocab_forge"
                / "asaxi_grammar_morphemes.toml"
            )
            registry = candidate if candidate.is_file() else None
        authoritative_vault = bool(
            repository is not None
            and resolved_vault
            == (repository / "Lozenge-T-Notes").resolve()
        )
        return cls(
            vault_root=resolved_vault,
            grammar_registry=registry.resolve() if registry else None,
            repository_root=repository,
            grammar_model_manifest=(
                DEFAULT_GRAMMAR_MODEL_MANIFEST
                if authoritative_vault
                else None
            ),
            grammar_claim_manifest=(
                Path(__file__).resolve().with_name(
                    "grammar_coverage_claims.toml"
                )
                if authoritative_vault
                else None
            ),
        )


def _find_repository_root(start: Path) -> Path | None:
    current = start if start.is_dir() else start.parent
    for candidate in (current, *current.parents):
        if (
            (candidate / "99_Tools").is_dir()
            and (candidate / "Lozenge-T-Notes").is_dir()
        ):
            return candidate.resolve()
        if (
            candidate.name == "Lozenge-T-Notes"
            and (candidate / "01_Worldbuilding").is_dir()
        ):
            parent = candidate.parent
            if (parent / "99_Tools").is_dir():
                return parent.resolve()
    return None


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _portable_path(path: Path, config: CompileConfig) -> str:
    resolved = path.resolve()
    try:
        return resolved.relative_to(config.vault_root).as_posix()
    except ValueError:
        pass
    if config.repository_root is not None:
        try:
            return resolved.relative_to(config.repository_root).as_posix()
        except ValueError:
            pass
    return f"external/{resolved.name}"


def _source_reference(
    path: Path,
    config: CompileConfig,
    *,
    line: int | None = None,
) -> SourceReference:
    return SourceReference(
        path=_portable_path(path, config),
        sha256=_sha256(path),
        line=line,
    )


def _stable_identifier(namespace: str, key: str) -> str:
    digest = hashlib.sha256(key.encode("utf-8")).hexdigest()[:16]
    return f"asaxi.{namespace}.{digest}"


def _frontmatter_field(
    parsed: ParsedMarkdown,
    key: str,
) -> FieldValue:
    value, present, _ = parsed.frontmatter_value(key)
    return FieldValue.from_raw(value, present=present)


def _entry_source_category(path: Path) -> str:
    match = ENTRY_TYPE_RE.search(path.name)
    return match.group(1).strip().casefold() if match else ""


def _canonical_category(source_category: str, lemma: str) -> str:
    mapping = {
        "noun": "noun",
        "ga-noun": "noun",
        "verb": "verb",
        "adjective": "adjective",
        "particle": "particle",
        "root word": "root_word",
        "root-word": "root_word",
        "number": "number",
        "idiom": "idiom",
    }
    if source_category in mapping:
        return mapping[source_category]
    if lemma.startswith("-") or lemma.endswith("-"):
        return "morpheme"
    return "unknown"


def _lexical_subtype(category: str, lemma: str) -> str | None:
    if category == "verb":
        return "derived_u" if lemma.endswith("ů") else "root"
    if category == "morpheme":
        if lemma.startswith("-") and lemma.endswith("-"):
            return "bridge"
        if lemma.startswith("-"):
            return "suffix"
        if lemma.endswith("-"):
            return "prefix"
        return "free"
    return None


def _frequency(
    parsed: ParsedMarkdown,
    *,
    source_path: str,
) -> tuple[int | None, Diagnostic | None]:
    raw, present, line = parsed.frontmatter_value("freq")
    if not present or raw in (None, ""):
        return None, None
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return None, Diagnostic(
            code="INVALID_FREQUENCY",
            severity=Severity.WARNING,
            message=f"Frequency must be an integer from 1 to 100, got {raw!r}",
            source_path=source_path,
            line=line,
            field="frequency",
        )
    if not 1 <= value <= 100:
        return None, Diagnostic(
            code="INVALID_FREQUENCY",
            severity=Severity.WARNING,
            message=f"Frequency must be from 1 to 100, got {value}",
            source_path=source_path,
            line=line,
            field="frequency",
        )
    return value, None


def _section_value(
    parsed: ParsedMarkdown,
    names: tuple[str, ...],
) -> tuple[str | None, bool, int | None]:
    section = parsed.section(*names)
    if section is None:
        return None, False, None
    return plain_markdown_value(section.body), True, section.line


def _noun_class(parsed: ParsedMarkdown) -> FieldValue:
    raw, present, _ = _section_value(
        parsed,
        (
            "Noun class (warm / cold)",
            "Noun class",
            "Warmth",
        ),
    )
    if not present:
        return FieldValue.missing()
    assert raw is not None
    match = re.search(r"\b(warm|cold)\b", raw, re.IGNORECASE)
    if match:
        value = match.group(1).casefold()
        return FieldValue(ValueState.PRESENT, value=value, raw=raw)
    return FieldValue.from_raw(raw)


def _valency(parsed: ParsedMarkdown) -> FieldValue:
    frontmatter = _frontmatter_field(parsed, "Transitivity")
    if frontmatter.state is not ValueState.MISSING:
        return frontmatter
    raw, present, _ = _section_value(
        parsed,
        ("Transitivity / Valency", "Transitivity", "Valency"),
    )
    if not present:
        return FieldValue.missing()
    assert raw is not None
    match = VALENCY_RE.search(raw)
    if match:
        return FieldValue(
            ValueState.PRESENT,
            value=match.group(1).casefold(),
            raw=raw,
        )
    return FieldValue.from_raw(raw)


def _lexical_aspect(parsed: ParsedMarkdown) -> FieldValue:
    raw, present, _ = _section_value(parsed, ("Lexical Aspect",))
    if not present:
        return FieldValue.missing()
    assert raw is not None
    found = [
        term
        for term in ASPECT_TERMS
        if re.search(rf"\b{re.escape(term)}\b", raw, re.IGNORECASE)
    ]
    if found:
        return FieldValue(
            ValueState.PRESENT,
            value=" + ".join(found),
            raw=raw,
        )
    return FieldValue.from_raw(raw)


def _lexical_variants(
    parsed: ParsedMarkdown,
    *,
    lemma: str,
    source_path: str,
) -> tuple[tuple[LexicalVariant, ...], tuple[Diagnostic, ...]]:
    """Compile explicitly documented forms without treating note aliases as words."""

    variants: dict[tuple[str, tuple[str, ...]], LexicalVariant] = {}
    diagnostics: list[Diagnostic] = []
    for section in parsed.sections:
        if normalize_heading(section.title) not in {
            "alternative forms",
            "alternate forms",
        }:
            continue
        for offset, raw_line in enumerate(section.body.splitlines(), start=1):
            bullet = re.match(r"^\s*[-*]\s+(.+?)\s*$", raw_line)
            if bullet is None:
                continue
            note = re.sub(r"[*_`]", "", bullet.group(1)).strip()
            if not note:
                continue
            lowered = note.casefold()
            candidate_text = note
            if ":" in note:
                before, after = note.split(":", 1)
                candidate_text = (
                    after
                    if before.casefold().startswith(
                        ("in speech", "in song", "speech", "song")
                    )
                    else before
                )
            match = LEXICAL_VARIANT_TOKEN_RE.search(candidate_text)
            if match is None:
                continue
            surface = match.group(0).strip()
            if not surface or surface.casefold() == lemma.casefold():
                continue
            source_line = section.line + offset
            if LEXICAL_VARIANT_EXCLUSION_RE.search(note):
                diagnostics.append(
                    Diagnostic(
                        code="LEXICAL_VARIANT_EXCLUDED_BY_SOURCE",
                        severity=Severity.INFO,
                        message=(
                            f"Alternative form {surface!r} was retained as an "
                            "exclusion because its source note marks it as "
                            "non-usable."
                        ),
                        source_path=source_path,
                        line=source_line,
                        field="alternative_forms",
                    )
                )
                continue
            contexts: list[str] = []
            if "when followed" in lowered:
                contexts.append("before-following-material")
            if "speech" in lowered:
                contexts.append("speech")
            if "song" in lowered:
                contexts.append("song")
            if "emph" in lowered:
                contexts.append("emphatic")
            if "poetic" in lowered:
                contexts.append("poetic")
            if "slang" in lowered:
                contexts.append("slang")
            if "reduc" in lowered:
                contexts.append("reduced")
            if not contexts:
                contexts.append("unrestricted")
            context_tuple = tuple(sorted(set(contexts)))
            variants[(surface.casefold(), context_tuple)] = LexicalVariant(
                surface=surface,
                contexts=context_tuple,
                note=note,
                source_line=source_line,
            )
    return (
        tuple(
            variants[key]
            for key in sorted(variants, key=lambda item: (item[0], item[1]))
        ),
        tuple(diagnostics),
    )


def _derived_term_gloss(text: str, category: str | None) -> FieldValue:
    """Normalize a short parenthetical/dash gloss without inventing one."""

    value = plain_markdown_value(text).strip()
    value = re.sub(
        r"\s*\(?\b(?:potential|proposed|tentative)\b\)?\s*\.?$",
        "",
        value,
        flags=re.IGNORECASE,
    ).strip()
    value = value.strip(" \t-–—.()")
    if category:
        value = re.sub(
            rf"\s*[-–—]\s*{re.escape(category)}\s*$",
            "",
            value,
            flags=re.IGNORECASE,
        ).strip(" \t-–—.()")
        if value.casefold() == category.casefold():
            value = ""
    return FieldValue.from_raw(value) if value else FieldValue.missing()


def _derived_terms(
    parsed: ParsedMarkdown,
    *,
    source_path: str,
) -> tuple[tuple[DerivedTerm, ...], tuple[Diagnostic, ...]]:
    """Compile linked and legacy plain-text entries from Derived terms.

    The vault contains both modern wiki links and older bold-only entries.
    Every meaningful line is either represented structurally or retained as
    an incomplete record plus a diagnostic; undecodable source is never
    discarded silently.
    """

    section = parsed.section("Derived terms")
    if section is None:
        return (), ()
    entries: list[DerivedTerm] = []
    diagnostics: list[Diagnostic] = []
    example_subsection = False

    def retain_nonlexical(
        raw_line: str,
        *,
        source_line: int,
        code: str,
        message: str,
        severity: Severity = Severity.INFO,
    ) -> None:
        entries.append(
            DerivedTerm(
                identifier=_stable_identifier(
                    "derived-term",
                    f"{source_path}#L{source_line}",
                ),
                surface=None,
                category=None,
                gloss_en=FieldValue.missing(),
                linked_target=None,
                status=SpecificationStatus.INCOMPLETE,
                source_line=source_line,
                raw_text=raw_line,
            )
        )
        diagnostics.append(
            Diagnostic(
                code=code,
                severity=severity,
                message=message,
                source_path=source_path,
                line=source_line,
                field="derived_terms",
            )
        )

    for offset, raw_line in enumerate(section.body.splitlines(), start=1):
        source_line = section.line + offset
        heading = re.match(r"^\s*#{4,6}\s+(.+?)\s*$", raw_line)
        if heading is not None:
            heading_text = plain_markdown_value(heading.group(1)).strip(" :")
            example_subsection = bool(
                re.match(r"^examples?\b", heading_text, re.IGNORECASE)
            )
            retain_nonlexical(
                raw_line,
                source_line=source_line,
                code="DERIVED_TERM_SECTION_STRUCTURE",
                message=(
                    "A nested Derived terms heading was retained as section "
                    "structure, not compiled as a lexical entry."
                ),
            )
            continue
        if re.fullmatch(r"\s*[-*+]\s*", raw_line):
            continue
        list_item = re.match(r"^\s*[-*+]\s+", raw_line)
        content = re.sub(r"^\s*[-*+]\s+", "", raw_line).strip()
        if not content:
            continue
        if content.casefold() in {"null", "x", "none"}:
            retain_nonlexical(
                raw_line,
                source_line=source_line,
                code="DERIVED_TERM_EXPLICITLY_EMPTY",
                message=(
                    "The source explicitly marks this Derived terms slot as "
                    "empty; the placeholder was retained without inventing "
                    "a lexical entry."
                ),
            )
            continue
        if example_subsection:
            retain_nonlexical(
                raw_line,
                source_line=source_line,
                code="DERIVED_TERM_EXAMPLE_CONTENT",
                message=(
                    "Content under a nested example heading was retained but "
                    "not compiled as a derived lexical entry."
                ),
            )
            continue
        reference_text = plain_markdown_value(content)
        reference_text = re.sub(r"[*_`]", "", reference_text).strip()
        reference_text = reference_text.strip("() \t.")
        if DERIVED_TERM_REFERENCE_RE.match(reference_text):
            retain_nonlexical(
                raw_line,
                source_line=source_line,
                code="DERIVED_TERM_REFERENCE_ONLY",
                message=(
                    "The Derived terms line is source-authored reference "
                    "prose rather than a lexical entry."
                ),
            )
            continue
        if DERIVED_TERM_STRUCTURE_RE.fullmatch(reference_text.strip(" :")):
            retain_nonlexical(
                raw_line,
                source_line=source_line,
                code="DERIVED_TERM_SECTION_STRUCTURE",
                message=(
                    "A Derived terms label was retained as section structure, "
                    "not compiled as a lexical entry."
                ),
            )
            continue
        link = DERIVED_TERM_LINK_RE.search(content)
        linked_target: str | None = None
        category: str | None = None
        surface: str | None = None
        remainder = content
        formatted = re.match(
            r"^(?:\*\*|__|`)(?!\[\[)(.+?)(?:\*\*|__|`)",
            content,
        )
        if formatted is not None:
            # Keep leading/trailing morpheme marks intact here. The generic
            # plain-text helper intentionally strips punctuation, which would
            # turn a family label such as ``-go`` into the false lexeme ``go``.
            formatted_value = formatted.group(1).strip()
            candidate = LEXICAL_VARIANT_TOKEN_RE.fullmatch(formatted_value)
            if candidate is not None:
                surface = candidate.group(0)
                remainder = content[formatted.end():]
        if link is not None and surface is None:
            link_prefix = plain_markdown_value(content[:link.start()])
            link_prefix = re.sub(r"[*_`]", "", link_prefix)
            link_prefix = link_prefix.strip("() \t:;,.–—")
            if link_prefix:
                retain_nonlexical(
                    raw_line,
                    source_line=source_line,
                    code="DERIVED_TERM_REFERENCE_ONLY",
                    message=(
                        "A wiki link occurs inside Derived terms prose; the "
                        "line was retained as a reference instead of "
                        "mistaking the linked note for the derived surface."
                    ),
                )
                continue
            linked_target = link.group(1).strip()
            display = (link.group(2) or linked_target).strip()
            category_match = DERIVED_TERM_CATEGORY_RE.search(linked_target)
            if category_match is not None:
                category = category_match.group(1).casefold()
            surface = re.sub(
                r"(?:\s*\([^()]+\))+\s*$",
                "",
                display,
            ).strip()
            remainder = content[link.end():]
        elif surface is None:
            plain = plain_markdown_value(content)
            candidate = LEXICAL_VARIANT_TOKEN_RE.match(plain)
            explicitly_formatted = bool(
                re.match(r"^(?:\*\*|__|`)", content)
            )
            category_evidence = bool(
                DERIVED_TERM_CATEGORY_RE.search(content)
            )
            if candidate is not None and (
                explicitly_formatted
                or (list_item is not None and category_evidence)
            ):
                surface = candidate.group(0).strip()
                remainder = plain[candidate.end():]
        category_match = DERIVED_TERM_CATEGORY_RE.search(content)
        if category is None and category_match is not None:
            category = category_match.group(1).casefold()
        status = (
            SpecificationStatus.PROPOSED
            if DERIVED_TERM_STATUS_RE.search(content)
            else SpecificationStatus.CONFIRMED
            if surface
            else SpecificationStatus.INCOMPLETE
        )
        entry = DerivedTerm(
            identifier=_stable_identifier(
                "derived-term",
                f"{source_path}#L{source_line}",
            ),
            surface=surface,
            category=category,
            gloss_en=_derived_term_gloss(remainder, category),
            linked_target=linked_target,
            status=status,
            source_line=source_line,
            raw_text=raw_line,
        )
        entries.append(entry)
        if surface is None:
            diagnostics.append(
                Diagnostic(
                    code="DERIVED_TERM_UNPARSED",
                    severity=(
                        Severity.WARNING
                        if any(
                            ord(character) < 32
                            for character in content
                        )
                        or content.startswith("?")
                        else Severity.INFO
                    ),
                    message=(
                        "A Derived terms line was preserved but its lexical "
                        "surface could not be parsed safely."
                    ),
                    source_path=source_path,
                    line=source_line,
                    field="derived_terms",
                )
            )
    return tuple(entries), tuple(diagnostics)


def _pronunciation(parsed: ParsedMarkdown) -> FieldValue:
    section = parsed.section("Pronunciation")
    if section is None:
        return FieldValue.missing()
    match = IPA_RE.search(section.body)
    if match:
        return FieldValue.from_raw(match.group(1))
    return FieldValue.from_raw(plain_markdown_value(section.body))


def _sense_number(section: MarkdownSection) -> int | None:
    match = EXAMPLE_SECTION_RE.match(normalize_heading(section.title))
    if not match:
        return None
    return int(match.group(1) or "1")


def _compile_senses(
    parsed: ParsedMarkdown,
    *,
    source_path: str,
) -> tuple[tuple[Sense, ...], list[Diagnostic]]:
    values: dict[tuple[str, int], tuple[object, int | None]] = {}
    sense_numbers: set[int] = set()
    for key, value in parsed.frontmatter.items():
        match = SENSE_KEY_RE.match(key)
        if not match:
            continue
        language = match.group(1).casefold()
        index = int(match.group(2) or "1")
        values[(language, index)] = (value, parsed.frontmatter_lines.get(key))
        sense_numbers.add(index)

    examples_by_sense: dict[int, tuple[Example, ...]] = {}
    diagnostics: list[Diagnostic] = []
    for section in parsed.sections:
        sense_number = _sense_number(section)
        if sense_number is None:
            continue
        parsed_examples, problems = parse_examples(section)
        examples_by_sense[sense_number] = tuple(
            Example(
                asaxi=FieldValue.from_raw(
                    example.asaxi,
                    present=example.asaxi is not None,
                ),
                translation_en=FieldValue.from_raw(
                    example.english,
                    present=example.english is not None,
                ),
                translation_pl=FieldValue.from_raw(
                    example.polish,
                    present=example.polish is not None,
                ),
                source_line=example.line,
            )
            for example in parsed_examples
        )
        sense_numbers.add(sense_number)
        diagnostics.extend(
            Diagnostic(
                code="UNPARSED_EXAMPLE_RECORD",
                severity=Severity.WARNING,
                message=problem.message,
                source_path=source_path,
                line=problem.line,
                field=f"senses[{sense_number}].examples",
            )
            for problem in problems
        )

    if not sense_numbers:
        sense_numbers.add(1)
    senses: list[Sense] = []
    for index in sorted(sense_numbers):
        en, en_present = values.get(("en", index), (None, None))
        pl, pl_present = values.get(("pl", index), (None, None))
        senses.append(
            Sense(
                index=index,
                gloss_en=FieldValue.from_raw(
                    en,
                    present=en_present is not None,
                ),
                gloss_pl=FieldValue.from_raw(
                    pl,
                    present=pl_present is not None,
                ),
                examples=examples_by_sense.get(index, ()),
            )
        )
    return tuple(senses), diagnostics


KNOWN_LEXEME_SECTIONS = {
    "noun class (warm / cold)",
    "noun class",
    "warmth",
    "pronunciation",
    "pitch accent",
    "semantic field",
    "semantic fields",
    "translations",
    "example sentence",
    "alternative forms",
    "alternate forms",
    "etymology",
    "synonyms",
    "antonyms",
    "derived terms",
    "root noun",
    "usage note",
    "cultural note",
    "grammatical function",
    "transitivity / valency",
    "transitivity",
    "valency",
    "lexical aspect",
    "numeric value",
    "structure",
}


def _compile_lexeme(
    path: Path,
    parsed: ParsedMarkdown,
    config: CompileConfig,
) -> tuple[Lexeme | None, list[Diagnostic]]:
    diagnostics: list[Diagnostic] = []
    source = _source_reference(path, config)
    source_path = source.path
    word_raw, word_present, _ = parsed.frontmatter_value("Word (Asaxi)")
    tags_raw, _, _ = parsed.frontmatter_value("tags")
    tags = tuple(
        sorted(frontmatter_list(tags_raw), key=str.casefold)
    )
    if "grammar_concept" in {tag.casefold() for tag in tags}:
        return None, diagnostics
    source_category = _entry_source_category(path)
    if source_category == "list":
        return None, diagnostics
    if not word_present:
        return None, diagnostics

    lemma = str(word_raw or "").strip()
    if not lemma:
        diagnostics.append(
            Diagnostic(
                code="EMPTY_LEMMA",
                severity=Severity.ERROR,
                message="Word (Asaxi) is empty",
                source_path=source_path,
                field="lemma",
            )
        )
        return None, diagnostics

    category = _canonical_category(source_category, lemma)
    if category == "unknown":
        diagnostics.append(
            Diagnostic(
                code="UNKNOWN_LEXICAL_CATEGORY",
                severity=Severity.WARNING,
                message=(
                    f"Could not normalize source category "
                    f"{source_category!r}"
                ),
                source_path=source_path,
                field="category",
            )
        )

    explicit_id, explicit_id_present, _ = parsed.frontmatter_value("id")
    if explicit_id_present and str(explicit_id or "").strip():
        identifier = f"asaxi.lexeme.{str(explicit_id).strip()}"
    else:
        identifier = _stable_identifier("lexeme", source_path)

    aliases_raw, _, _ = parsed.frontmatter_value("aliases")
    variants, variant_diagnostics = _lexical_variants(
        parsed,
        lemma=lemma,
        source_path=source_path,
    )
    diagnostics.extend(variant_diagnostics)
    derived_terms, derived_term_diagnostics = _derived_terms(
        parsed,
        source_path=source_path,
    )
    diagnostics.extend(derived_term_diagnostics)
    frequency, frequency_diagnostic = _frequency(
        parsed,
        source_path=source_path,
    )
    if frequency_diagnostic:
        diagnostics.append(frequency_diagnostic)
    senses, sense_diagnostics = _compile_senses(
        parsed,
        source_path=source_path,
    )
    diagnostics.extend(sense_diagnostics)

    semantic_section = parsed.section("Semantic Field", "Semantic Fields")
    semantic_fields = tuple(
        sorted(
            (
                link
                for link in wiki_links(
                    semantic_section.body if semantic_section else ""
                )
                if re.match(r"Smntc?_Field ", link, re.IGNORECASE)
            ),
            key=str.casefold,
        )
    )
    root_section = parsed.section("Root Noun")
    etymology_section = parsed.section("Etymology")
    derived_section = parsed.section("Derived terms")
    root_links = tuple(
        sorted(
            set(
                (
                    *wiki_links(
                        root_section.body if root_section else ""
                    ),
                    *wiki_links(
                        etymology_section.body
                        if etymology_section
                        else ""
                    ),
                )
            ),
            key=str.casefold,
        )
    )
    derived_links = wiki_links(derived_section.body if derived_section else "")

    title = _frontmatter_field(parsed, "title")
    noun_class = _noun_class(parsed)
    valency = _valency(parsed)
    critical = [senses[0].gloss_en if senses else FieldValue.missing()]
    if category == "noun":
        critical.append(noun_class)
    if category == "verb":
        critical.append(valency)
    if any(
        value.state
        in {
            ValueState.MISSING,
            ValueState.EMPTY,
            ValueState.PLACEHOLDER_X,
            ValueState.PLACEHOLDER_NULL,
        }
        for value in critical
    ):
        status = SpecificationStatus.INCOMPLETE
    elif "proposed" in {tag.casefold() for tag in tags}:
        status = SpecificationStatus.PROPOSED
    else:
        status = SpecificationStatus.CONFIRMED

    unparsed_sections = tuple(
        sorted(
            {
                section.title
                for section in parsed.sections
                if normalize_heading(section.title)
                not in KNOWN_LEXEME_SECTIONS
                and _sense_number(section) is None
            },
            key=str.casefold,
        )
    )
    diagnostics.extend(
        Diagnostic(
            code="FRONTMATTER_PARSE_ERROR",
            severity=Severity.ERROR,
            message=problem.message,
            source_path=source_path,
            line=problem.line,
        )
        for problem in parsed.problems
    )

    return (
        Lexeme(
            identifier=identifier,
            lemma=lemma,
            surface_form=lemma,
            category=category,
            source_category=source_category,
            lexical_subtype=_lexical_subtype(category, lemma),
            title=title,
            aliases=tuple(
                sorted(frontmatter_list(aliases_raw), key=str.casefold)
            ),
            tags=tags,
            frequency=frequency,
            noun_class=noun_class,
            senses=senses,
            valency=valency,
            lexical_aspect=_lexical_aspect(parsed),
            pronunciation=_pronunciation(parsed),
            pitch_accent=_frontmatter_field(parsed, "pitch_accent"),
            pitch_accent_class=_frontmatter_field(
                parsed,
                "pitch_accent_class",
            ),
            semantic_fields=semantic_fields,
            root_links=root_links,
            derived_links=derived_links,
            derived_terms=derived_terms,
            status=status,
            source=source,
            unparsed_sections=unparsed_sections,
            variants=variants,
        ),
        diagnostics,
    )


def _compile_grammar_document(
    path: Path,
    parsed: ParsedMarkdown,
    config: CompileConfig,
) -> GrammarDocument:
    source = _source_reference(path, config)
    title_value, title_present, _ = parsed.frontmatter_value("title")
    title = (
        str(title_value).strip()
        if title_present and str(title_value or "").strip()
        else next(
            (heading for level, heading, _ in parsed.headings if level <= 2),
            path.stem,
        )
    )
    tags_raw, _, _ = parsed.frontmatter_value("tags")
    tags = tuple(sorted(frontmatter_list(tags_raw), key=str.casefold))
    headings = tuple(heading for _, heading, _ in parsed.headings)
    proposed = tuple(
        heading
        for heading in headings
        if "proposed" in heading.casefold()
    )
    status = (
        SpecificationStatus.PROPOSED
        if proposed or "proposed" in {tag.casefold() for tag in tags}
        else SpecificationStatus.CONFIRMED
    )
    return GrammarDocument(
        identifier=_stable_identifier("grammar", source.path),
        title=title,
        tags=tags,
        headings=headings,
        linked_notes=wiki_links(parsed.body),
        proposed_sections=proposed,
        status=status,
        source=source,
    )


def _registry_attachment(notation: str) -> str:
    if notation.startswith("-") and notation.endswith("-"):
        return "infix"
    if notation.startswith("-"):
        return "suffix"
    if notation.endswith("-"):
        return "prefix"
    return "free"


def _registry_form(notation: str) -> str:
    return notation.strip("-")


def _compile_registry(
    config: CompileConfig,
) -> tuple[tuple[Morpheme, ...], list[Diagnostic]]:
    path = config.grammar_registry
    if path is None:
        return (), [
            Diagnostic(
                code="MORPHEME_REGISTRY_UNAVAILABLE",
                severity=Severity.WARNING,
                message=(
                    "No transitional grammar-morpheme registry was found; "
                    "vault lexemes were still compiled"
                ),
            )
        ]
    source = _source_reference(path, config)
    diagnostics: list[Diagnostic] = []
    try:
        with path.open("rb") as stream:
            payload = tomllib.load(stream)
    except (OSError, tomllib.TOMLDecodeError) as error:
        return (), [
            Diagnostic(
                code="MORPHEME_REGISTRY_PARSE_ERROR",
                severity=Severity.ERROR,
                message=str(error),
                source_path=source.path,
            )
        ]
    if payload.get("schema_version") != 1:
        diagnostics.append(
            Diagnostic(
                code="MORPHEME_REGISTRY_SCHEMA",
                severity=Severity.ERROR,
                message="Unsupported morpheme registry schema_version",
                source_path=source.path,
            )
        )
    records = payload.get("morphemes")
    if not isinstance(records, dict):
        diagnostics.append(
            Diagnostic(
                code="MORPHEME_REGISTRY_SHAPE",
                severity=Severity.ERROR,
                message="Registry morphemes must be a TOML table",
                source_path=source.path,
            )
        )
        return (), diagnostics

    morphemes: list[Morpheme] = []
    for notation, raw in sorted(records.items(), key=lambda item: item[0].casefold()):
        if not isinstance(raw, dict):
            diagnostics.append(
                Diagnostic(
                    code="MORPHEME_RECORD_SHAPE",
                    severity=Severity.ERROR,
                    message=f"Morpheme {notation!r} is not a table",
                    source_path=source.path,
                )
            )
            continue
        source_notes_raw = raw.get("source_notes") or []
        source_notes = tuple(
            sorted(
                (str(note).strip() for note in source_notes_raw if str(note).strip()),
                key=str.casefold,
            )
        )
        for note in source_notes:
            note_path = note.split("#", 1)[0]
            if not (config.vault_root / Path(note_path)).is_file():
                diagnostics.append(
                    Diagnostic(
                        code="MORPHEME_SOURCE_MISSING",
                        severity=Severity.WARNING,
                        message=(
                            f"Morpheme {notation!r} cites a missing source "
                            f"note: {note}"
                        ),
                        source_path=source.path,
                        field="source_notes",
                    )
                )
        canonical = str(
            raw.get("canonical_form") or _registry_form(notation)
        ).strip()
        role = str(raw.get("role") or "").strip()
        attachment = str(
            raw.get("attachment") or _registry_attachment(notation)
        ).strip()
        if not role:
            diagnostics.append(
                Diagnostic(
                    code="MORPHEME_ROLE_MISSING",
                    severity=Severity.ERROR,
                    message=f"Morpheme {notation!r} has no role",
                    source_path=source.path,
                    field="role",
                )
            )
        morphemes.append(
            Morpheme(
                identifier=_stable_identifier(
                    "morpheme",
                    f"{notation}\0{role}",
                ),
                notation=notation,
                form=_registry_form(notation),
                canonical_form=canonical,
                role=role,
                attachment=attachment,
                lexical_type=(
                    str(raw["lexical_type"]).strip()
                    if raw.get("lexical_type")
                    else None
                ),
                host_lexical_types=tuple(
                    sorted(
                        (
                            str(value).strip()
                            for value in raw.get("host_lexical_types") or []
                            if str(value).strip()
                        ),
                        key=str.casefold,
                    )
                ),
                description=str(raw.get("description") or "").strip(),
                phones=tuple(
                    str(phone).strip()
                    for phone in raw.get("phones") or []
                    if str(phone).strip()
                ),
                pitch_accent=FieldValue.from_raw(
                    raw.get("pitch_accent"),
                    present="pitch_accent" in raw,
                ),
                pitch_accent_class=FieldValue.from_raw(
                    raw.get("pitch_accent_class"),
                    present="pitch_accent_class" in raw,
                ),
                source_notes=source_notes,
                registry_source=source,
            )
        )
    return tuple(morphemes), diagnostics


def _statistics(
    lexemes: tuple[Lexeme, ...],
    grammar_documents: tuple[GrammarDocument, ...],
    morphemes: tuple[Morpheme, ...],
    diagnostics: tuple[Diagnostic, ...],
) -> dict[str, int]:
    return {
        "lexemes": len(lexemes),
        "grammar_documents": len(grammar_documents),
        "morphemes": len(morphemes),
        "confirmed_lexemes": sum(
            lexeme.status is SpecificationStatus.CONFIRMED
            for lexeme in lexemes
        ),
        "proposed_lexemes": sum(
            lexeme.status is SpecificationStatus.PROPOSED
            for lexeme in lexemes
        ),
        "incomplete_lexemes": sum(
            lexeme.status is SpecificationStatus.INCOMPLETE
            for lexeme in lexemes
        ),
        "diagnostic_errors": sum(
            diagnostic.severity is Severity.ERROR
            for diagnostic in diagnostics
        ),
        "diagnostic_warnings": sum(
            diagnostic.severity is Severity.WARNING
            for diagnostic in diagnostics
        ),
        "diagnostic_info": sum(
            diagnostic.severity is Severity.INFO
            for diagnostic in diagnostics
        ),
    }


def compile_language(
    config: CompileConfig,
    *,
    include_lint: bool = True,
) -> LanguageDatabase:
    asaxi_root = config.vault_root / ASAXI_RELATIVE_ROOT
    lexeme_paths: list[Path] = []
    for directory_name in ("Lexicon", "Idioms_Expressions", "Grammar_Structure"):
        directory = asaxi_root / directory_name
        if directory.is_dir():
            lexeme_paths.extend(sorted(directory.glob("*.md")))
    lexeme_paths.extend(sorted(asaxi_root.glob("*.md")))

    lexemes: list[Lexeme] = []
    grammar_documents: list[GrammarDocument] = []
    diagnostics: list[Diagnostic] = []
    grammar_directory = asaxi_root / "Grammar_Structure"
    grammar_note_paths = tuple(sorted(grammar_directory.glob("*.md")))
    parsed_by_path: dict[Path, ParsedMarkdown] = {}

    for path in lexeme_paths:
        try:
            text = path.read_text(encoding="utf-8")
        except (OSError, UnicodeError) as error:
            diagnostics.append(
                Diagnostic(
                    code="SOURCE_READ_ERROR",
                    severity=Severity.ERROR,
                    message=str(error),
                    source_path=_portable_path(path, config),
                )
            )
            continue
        parsed = parse_markdown(text)
        parsed_by_path[path] = parsed
        lexeme, entry_diagnostics = _compile_lexeme(path, parsed, config)
        diagnostics.extend(entry_diagnostics)
        if lexeme is not None:
            lexemes.append(lexeme)

    grammar_document_paths = sorted(
        {
            *grammar_note_paths,
            *asaxi_root.glob("*.md"),
        }
    )
    for path in grammar_document_paths:
        parsed = parsed_by_path.get(path)
        if parsed is None:
            try:
                parsed = parse_markdown(path.read_text(encoding="utf-8"))
            except (OSError, UnicodeError):
                continue
        word, word_present, _ = parsed.frontmatter_value("Word (Asaxi)")
        tags, _, _ = parsed.frontmatter_value("tags")
        is_concept = "grammar_concept" in {
            tag.casefold() for tag in frontmatter_list(tags)
        }
        if is_concept or not word_present or not str(word or "").strip():
            grammar_documents.append(
                _compile_grammar_document(path, parsed, config)
            )

    morphemes, registry_diagnostics = _compile_registry(config)
    diagnostics.extend(registry_diagnostics)

    lexeme_tuple = tuple(
        sorted(
            lexemes,
            key=lambda item: (
                item.lemma.casefold(),
                item.category,
                item.source.path.casefold(),
            ),
        )
    )
    grammar_tuple = tuple(
        sorted(
            grammar_documents,
            key=lambda item: item.source.path.casefold(),
        )
    )
    source_pairs = {
        (lexeme.source.path, lexeme.source.sha256)
        for lexeme in lexeme_tuple
    }
    source_pairs.update(
        (document.source.path, document.source.sha256)
        for document in grammar_tuple
    )
    source_pairs.update(
        (morpheme.registry_source.path, morpheme.registry_source.sha256)
        for morpheme in morphemes
    )
    source_digest = hashlib.sha256(
        "\n".join(
            f"{path}:{digest}"
            for path, digest in sorted(source_pairs)
        ).encode("utf-8")
    ).hexdigest()
    grammar_notes: list[GrammarSourceNote] = []
    for path in grammar_note_paths:
        try:
            grammar_notes.append(
                GrammarSourceNote(
                    path=_portable_path(path, config),
                    sha256=_sha256(path),
                )
            )
        except OSError:
            # The ordinary source pass already emits a detailed diagnostic.
            # Omitting the unreadable note makes source drift visible too.
            continue
    grammar_model = resolve_grammar_model_revision(
        grammar_notes,
        config.grammar_model_manifest,
    )

    database = LanguageDatabase(
        schema_version=SCHEMA_VERSION,
        compiler_version=COMPILER_VERSION,
        source_kind="authoritative-obsidian-vault",
        source_digest=source_digest,
        grammar_model=grammar_model,
        lexemes=lexeme_tuple,
        grammar_documents=grammar_tuple,
        morphemes=tuple(
            sorted(morphemes, key=lambda item: item.notation.casefold())
        ),
        diagnostics=(),
        statistics={},
    )
    if include_lint:
        from .linter import lint_database

        diagnostics.extend(lint_database(database))
    diagnostic_tuple = tuple(sorted(diagnostics, key=Diagnostic.sort_key))
    return replace(
        database,
        diagnostics=diagnostic_tuple,
        statistics=_statistics(
            database.lexemes,
            database.grammar_documents,
            database.morphemes,
            diagnostic_tuple,
        ),
    )


def render_database(database: LanguageDatabase) -> bytes:
    return (
        json.dumps(
            database.to_dict(),
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
        + "\n"
    ).encode("utf-8")


def write_database(database: LanguageDatabase, output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    payload = render_database(database)
    temporary = output_path.with_suffix(output_path.suffix + ".tmp")
    temporary.write_bytes(payload)
    temporary.replace(output_path)
