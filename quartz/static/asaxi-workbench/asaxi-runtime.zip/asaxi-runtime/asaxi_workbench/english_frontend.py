"""Typed deterministic frontend for structural English transfer.

This module intentionally describes source-language structure only.  It does
not contain Asaxi words or target-language phrase templates.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from enum import Enum
from typing import Sequence

from .syntax import (
    CausativeVoice,
    DistributionKind,
    DistributionScope,
    FrequencyKind,
    Modality,
    NominalExtentKind,
    Polarity,
    TemporalAspect,
    Tense,
    WhRole,
)
from .numerals import ENGLISH_FRACTION_VALUE_BY_FORM


class EnglishFrameKind(str, Enum):
    IDENTITY = "identity"
    LOCATION = "location"
    ACTION = "action"
    DIRECTIVE = "directive"


class EnglishAspect(str, Enum):
    SIMPLE = "simple"
    PROGRESSIVE = "progressive"


class EnglishDirectiveForce(str, Enum):
    COMMAND = "command"
    PROHIBITION = "prohibition"
    ABSOLUTE_PROHIBITION = "absolute-prohibition"
    REQUEST = "request"
    INSTRUCTION = "instruction"
    POLITE_PROHIBITION = "polite-prohibition"
    CESSATION = "cessation"
    CONTINUATION = "continuation"
    SWITCH = "switch"
    HORTATIVE = "hortative"
    POLITE_HORTATIVE = "polite-hortative"


class EnglishPreclausalForce(str, Enum):
    REACTIVE_OBJECTION = "reactive-objection"
    REACTIVE_CONTINUATION = "reactive-continuation"
    AWE = "awe"
    EMOTIONAL_REALIZATION = "emotional-realization"


class EnglishDiscourseForce(str, Enum):
    AGREEMENT = "agreement"
    ASSERTION = "assertion"
    CASUAL_EMPHASIS = "casual-emphasis"
    SKEPTICISM = "skepticism"
    RESIGNATION = "resignation"
    CONTENTION = "contention"


class EnglishEpistemicForce(str, Enum):
    SURE = "sure"
    KNOWN = "known"
    THINK = "think"
    UNSURE = "unsure"
    DOUBT = "doubt"
    SUBJECTIVE_PAST = "subjective-past"
    MEMORY_FACT = "memory-fact"
    FUTURE_FACT = "future-fact"


class EnglishNominalQuantifierKind(str, Enum):
    UNIVERSAL = "universal"


class EnglishLocativeKind(str, Enum):
    PROXIMAL = "proximal"
    MEDIAL = "medial"
    DISTAL = "distal"
    INDEFINITE = "indefinite"


class EnglishSpatialRelation(str, Enum):
    INSIDE = "inside"
    OUTSIDE = "outside"
    ON = "on"
    BEHIND = "behind"
    BESIDE = "beside"
    IN_FRONT_OF = "in-front-of"
    ABOVE = "above"
    BELOW = "below"
    AMID = "amid"


class EnglishObliqueKind(str, Enum):
    TO = "to"
    FROM = "from"
    FOR = "for"
    WITH = "with"
    UNTIL = "until"
    ABOUT = "about"
    BY = "by"


@dataclass(frozen=True)
class EnglishInputToken:
    index: int
    surface: str
    normalized: str
    preceded_by_comma: bool = False
    followed_by_comma: bool = False


@dataclass(frozen=True)
class EnglishPossessor:
    source_indexes: tuple[int, ...]
    term: str
    proper_name: bool = False


@dataclass(frozen=True)
class EnglishNominalQuantifier:
    source_indexes: tuple[int, ...]
    kind: EnglishNominalQuantifierKind
    source_form: str


@dataclass(frozen=True)
class EnglishNominalExtent:
    source_indexes: tuple[int, ...]
    kind: NominalExtentKind
    source_form: str
    denominator_value: int | None = None
    emphasized: bool = False


@dataclass(frozen=True)
class EnglishNominalFrame:
    source_indexes: tuple[int, ...]
    head: str
    head_indexes: tuple[int, ...]
    determiner: str | None = None
    possessor: EnglishPossessor | None = None
    wh_word: str | None = None
    proper_name: bool = False
    quantifier: EnglishNominalQuantifier | None = None
    extent: EnglishNominalExtent | None = None
    locative: EnglishLocativeKind | None = None


@dataclass(frozen=True)
class EnglishClauseFrame:
    kind: EnglishFrameKind
    subject: EnglishNominalFrame
    complement: EnglishNominalFrame
    tense: Tense
    polarity: Polarity
    interrogative: bool
    role_by_index: tuple[tuple[int, str], ...]
    rule_trace: tuple[str, ...]
    preclausal_force: EnglishPreclausalForce | None = None
    discourse_force: EnglishDiscourseForce | None = None
    epistemic_force: EnglishEpistemicForce | None = None


@dataclass(frozen=True)
class EnglishSpatialClauseFrame:
    kind: EnglishFrameKind
    subject: EnglishNominalFrame
    location: EnglishNominalFrame
    relation: EnglishSpatialRelation
    relation_indexes: tuple[int, ...]
    tense: Tense
    polarity: Polarity
    interrogative: bool
    role_by_index: tuple[tuple[int, str], ...]
    rule_trace: tuple[str, ...]
    preclausal_force: EnglishPreclausalForce | None = None
    discourse_force: EnglishDiscourseForce | None = None
    epistemic_force: EnglishEpistemicForce | None = None


@dataclass(frozen=True)
class EnglishObliqueFrame:
    source_indexes: tuple[int, ...]
    marker_indexes: tuple[int, ...]
    source_marker: str
    kind: EnglishObliqueKind
    nominal: EnglishNominalFrame


@dataclass(frozen=True)
class EnglishActionFrame:
    kind: EnglishFrameKind
    subject: EnglishNominalFrame
    predicate: str
    predicate_indexes: tuple[int, ...]
    object: EnglishNominalFrame | None
    adjunct: EnglishNominalFrame | None
    wh_role: WhRole | None
    tense: Tense | None
    polarity: Polarity
    interrogative: bool
    role_by_index: tuple[tuple[int, str], ...]
    rule_trace: tuple[str, ...]
    aspect: EnglishAspect = EnglishAspect.SIMPLE
    obliques: tuple[EnglishObliqueFrame, ...] = ()
    frequency_kind: FrequencyKind | None = None
    frequency_indexes: tuple[int, ...] = ()
    temporal_aspect: TemporalAspect = TemporalAspect.NONE
    temporal_aspect_indexes: tuple[int, ...] = ()
    modality: Modality = Modality.NONE
    modality_indexes: tuple[int, ...] = ()
    distribution_kind: DistributionKind | None = None
    distribution_scope: DistributionScope | None = None
    distribution_target_role: str | None = None
    distribution_indexes: tuple[int, ...] = ()
    causer: EnglishNominalFrame | None = None
    causative_voice: CausativeVoice | None = None
    causative_indexes: tuple[int, ...] = ()
    preclausal_force: EnglishPreclausalForce | None = None
    discourse_force: EnglishDiscourseForce | None = None
    epistemic_force: EnglishEpistemicForce | None = None
    time: EnglishNominalFrame | None = None


@dataclass(frozen=True)
class EnglishDirectiveFrame:
    kind: EnglishFrameKind
    force: EnglishDirectiveForce
    predicate: str
    predicate_indexes: tuple[int, ...]
    object: EnglishNominalFrame | None
    role_by_index: tuple[tuple[int, str], ...]
    rule_trace: tuple[str, ...]
    preclausal_force: EnglishPreclausalForce | None = None
    discourse_force: EnglishDiscourseForce | None = None
    epistemic_force: EnglishEpistemicForce | None = None


EnglishStructuralFrame = (
    EnglishClauseFrame
    | EnglishSpatialClauseFrame
    | EnglishActionFrame
    | EnglishDirectiveFrame
)


COPULA_TENSES = {
    "am": Tense.NONPAST,
    "is": Tense.NONPAST,
    "are": Tense.NONPAST,
    "was": Tense.PAST,
    "were": Tense.PAST,
}
FUTURE_AUXILIARIES = frozenset({"will", "'ll", "’ll"})
NEGATIVE_FUTURE_AUXILIARIES = frozenset({"won't", "won’t"})
WH_FORMS = frozenset({"what", "who"})
ACTION_WH_ROLES = {
    "who": WhRole.OBJECT,
    "what": WhRole.OBJECT,
    "where": WhRole.LOCATION,
    "when": WhRole.TIME,
    "why": WhRole.REASON,
    "how": WhRole.MANNER,
}
DO_AUXILIARIES = {
    "do": Tense.NONPAST,
    "does": Tense.NONPAST,
    "did": Tense.PAST,
}
NEGATIVE_DO_AUXILIARIES = {
    "don't": Tense.NONPAST,
    "don’t": Tense.NONPAST,
    "doesn't": Tense.NONPAST,
    "doesn’t": Tense.NONPAST,
    "didn't": Tense.PAST,
    "didn’t": Tense.PAST,
}
WH_COPULA_CONTRACTIONS = {
    "what's": ("what", Tense.NONPAST),
    "what’s": ("what", Tense.NONPAST),
    "who's": ("who", Tense.NONPAST),
    "who’s": ("who", Tense.NONPAST),
}
POSSESSIVE_DETERMINERS = {
    "my": "i",
    "your": "you",
    "his": "he",
    "her": "she",
    "its": "it",
    "our": "we",
    "their": "they",
}
PERSONAL_PRONOUN_FORMS = frozenset(
    {
        "i",
        "you",
        "he",
        "she",
        "it",
        "we",
        "they",
        "me",
        "him",
        "her",
        "us",
        "them",
    }
)
ARTICLES = frozenset({"a", "an", "the"})
UNIVERSAL_QUANTIFIERS = frozenset({"all", "each", "every"})
COMPLETE_EXTENT_WORDS = frozenset({"entire", "whole"})
ENGLISH_TIME_HEADS = frozenset(
    {
        "day",
        "evening",
        "morning",
        "night",
        "today",
        "tomorrow",
        "week",
        "year",
        "yesterday",
    }
)
DEICTIC_LOCATIVES = {
    "here": EnglishLocativeKind.PROXIMAL,
    "there": EnglishLocativeKind.MEDIAL,
    "over there": EnglishLocativeKind.DISTAL,
    "somewhere": EnglishLocativeKind.INDEFINITE,
}
SPATIAL_PREPOSITIONS = {
    ("in",): EnglishSpatialRelation.INSIDE,
    ("inside",): EnglishSpatialRelation.INSIDE,
    ("inside", "of"): EnglishSpatialRelation.INSIDE,
    ("outside",): EnglishSpatialRelation.OUTSIDE,
    ("outside", "of"): EnglishSpatialRelation.OUTSIDE,
    ("on",): EnglishSpatialRelation.ON,
    ("on", "top", "of"): EnglishSpatialRelation.ON,
    ("behind",): EnglishSpatialRelation.BEHIND,
    ("beside",): EnglishSpatialRelation.BESIDE,
    ("next", "to"): EnglishSpatialRelation.BESIDE,
    ("in", "front", "of"): EnglishSpatialRelation.IN_FRONT_OF,
    ("above",): EnglishSpatialRelation.ABOVE,
    ("over",): EnglishSpatialRelation.ABOVE,
    ("below",): EnglishSpatialRelation.BELOW,
    ("under",): EnglishSpatialRelation.BELOW,
    ("underneath",): EnglishSpatialRelation.BELOW,
    ("amid",): EnglishSpatialRelation.AMID,
    ("amidst",): EnglishSpatialRelation.AMID,
    ("in", "the", "middle", "of"): EnglishSpatialRelation.AMID,
}
ACTION_OBLIQUE_MARKERS = {
    ("out", "of"): EnglishObliqueKind.FROM,
    ("from",): EnglishObliqueKind.FROM,
    ("to",): EnglishObliqueKind.TO,
    ("onto",): EnglishObliqueKind.TO,
    ("for",): EnglishObliqueKind.FOR,
    ("with",): EnglishObliqueKind.WITH,
    ("until",): EnglishObliqueKind.UNTIL,
    ("about",): EnglishObliqueKind.ABOUT,
    ("by",): EnglishObliqueKind.BY,
}

# These are source-language analyses, not target phrase templates.  Each form
# maps to a typed event-frequency meaning; the Asaxi renderer independently
# chooses the documented target particle.
ENGLISH_EVENT_FREQUENCIES = {
    ("from", "time", "to", "time"): FrequencyKind.INTERMITTENT,
    ("every", "other", "day"): FrequencyKind.ALTERNATE_DAILY,
    ("absolutely", "never"): FrequencyKind.EMPHATIC_NEVER,
    ("every", "day"): FrequencyKind.DAILY,
    ("each", "day"): FrequencyKind.DAILY,
    ("every", "time"): FrequencyKind.EVERY_TIME,
    ("at", "any", "time"): FrequencyKind.WHENEVER,
    ("every", "year"): FrequencyKind.YEARLY,
    ("each", "year"): FrequencyKind.YEARLY,
    ("often",): FrequencyKind.OFTEN,
    ("usually",): FrequencyKind.USUAL,
    ("never",): FrequencyKind.NEVER,
    ("always",): FrequencyKind.ETERNAL,
    ("forever",): FrequencyKind.ETERNAL,
    ("sometimes",): FrequencyKind.SOMETIME,
    ("sometime",): FrequencyKind.SOMETIME,
    ("daily",): FrequencyKind.DAILY,
    ("yearly",): FrequencyKind.YEARLY,
    ("annually",): FrequencyKind.YEARLY,
    ("whenever",): FrequencyKind.WHENEVER,
}
ENGLISH_EVENT_FREQUENCY_FORMS = tuple(
    sorted(
        ENGLISH_EVENT_FREQUENCIES,
        key=lambda form: (-len(form), form),
    )
)
ENGLISH_TEMPORAL_ASPECTS = {
    ("not", "yet"): TemporalAspect.PROSPECTIVE,
    ("currently",): TemporalAspect.CURRENT,
    ("now",): TemporalAspect.CURRENT,
    ("already",): TemporalAspect.RETROSPECTIVE,
    ("still",): TemporalAspect.PERSISTIVE,
}
ENGLISH_TEMPORAL_ASPECT_FORMS = tuple(
    sorted(
        ENGLISH_TEMPORAL_ASPECTS,
        key=lambda form: (-len(form), form),
    )
)
ENGLISH_ACTION_MODALITIES = {
    "want": (Modality.DESIDERATIVE, Tense.NONPAST),
    "wants": (Modality.DESIDERATIVE, Tense.NONPAST),
    "wanted": (Modality.DESIDERATIVE, Tense.PAST),
    "try": (Modality.CONATIVE, Tense.NONPAST),
    "tries": (Modality.CONATIVE, Tense.NONPAST),
    "tried": (Modality.CONATIVE, Tense.PAST),
}
ENGLISH_DISTRIBUTIVES = {
    ("one", "by", "one"): DistributionKind.SEQUENTIAL,
    ("item", "by", "item"): DistributionKind.SEQUENTIAL,
    ("individually",): DistributionKind.GENERAL,
    ("separately",): DistributionKind.GENERAL,
    ("apiece",): DistributionKind.GENERAL,
    ("here", "and", "there"): DistributionKind.SPATIAL,
}
ENGLISH_DISTRIBUTIVE_FORMS = tuple(
    sorted(
        ENGLISH_DISTRIBUTIVES,
        key=lambda form: (-len(form), form),
    )
)
ENGLISH_CAUSATIVE_FORMS = {
    "allow": (CausativeVoice.PERMISSIVE, (Tense.NONPAST,), "to"),
    "allows": (CausativeVoice.PERMISSIVE, (Tense.NONPAST,), "to"),
    "allowed": (CausativeVoice.PERMISSIVE, (Tense.PAST,), "to"),
    "let": (
        CausativeVoice.PERMISSIVE,
        (Tense.NONPAST, Tense.PAST),
        "bare",
    ),
    "lets": (CausativeVoice.PERMISSIVE, (Tense.NONPAST,), "bare"),
    "force": (CausativeVoice.COERCIVE, (Tense.NONPAST,), "to"),
    "forces": (CausativeVoice.COERCIVE, (Tense.NONPAST,), "to"),
    "forced": (CausativeVoice.COERCIVE, (Tense.PAST,), "to"),
    "make": (CausativeVoice.COERCIVE, (Tense.NONPAST,), "bare"),
    "makes": (CausativeVoice.COERCIVE, (Tense.NONPAST,), "bare"),
    "made": (CausativeVoice.COERCIVE, (Tense.PAST,), "bare"),
    "prohibit": (
        CausativeVoice.PROHIBITIVE,
        (Tense.NONPAST,),
        "from",
    ),
    "prohibits": (
        CausativeVoice.PROHIBITIVE,
        (Tense.NONPAST,),
        "from",
    ),
    "prohibited": (
        CausativeVoice.PROHIBITIVE,
        (Tense.PAST,),
        "from",
    ),
}

# These edge patterns identify conventional pragmatic force only when a comma
# separates them from the proposition. That boundary keeps ordinary lexical
# uses such as "the answer is right" available to the clause parser.
ENGLISH_PRECLAUSAL_FORMS = {
    ("but", "wait"): EnglishPreclausalForce.REACTIVE_OBJECTION,
    ("however",): EnglishPreclausalForce.REACTIVE_OBJECTION,
    ("and", "so"): EnglishPreclausalForce.REACTIVE_CONTINUATION,
    ("and", "then"): EnglishPreclausalForce.REACTIVE_CONTINUATION,
    ("wow",): EnglishPreclausalForce.AWE,
    ("woah",): EnglishPreclausalForce.AWE,
    ("oh",): EnglishPreclausalForce.EMOTIONAL_REALIZATION,
}
ENGLISH_POSTCLAUSAL_FORMS = {
    ("right",): EnglishDiscourseForce.AGREEMENT,
    ("i", "tell", "you"): EnglishDiscourseForce.ASSERTION,
    ("yo",): EnglishDiscourseForce.CASUAL_EMPHASIS,
    ("is", "that", "so"): EnglishDiscourseForce.SKEPTICISM,
    ("i", "object"): EnglishDiscourseForce.CONTENTION,
}
ENGLISH_FRONTED_DISCOURSE_FORMS = {
    ("alas",): EnglishDiscourseForce.RESIGNATION,
}
ENGLISH_PRECLAUSAL_PATTERNS = tuple(
    sorted(ENGLISH_PRECLAUSAL_FORMS, key=lambda form: (-len(form), form))
)
ENGLISH_POSTCLAUSAL_PATTERNS = tuple(
    sorted(ENGLISH_POSTCLAUSAL_FORMS, key=lambda form: (-len(form), form))
)
ENGLISH_FRONTED_DISCOURSE_PATTERNS = tuple(
    sorted(
        ENGLISH_FRONTED_DISCOURSE_FORMS,
        key=lambda form: (-len(form), form),
    )
)

# These wrappers qualify a complete proposition. They are intentionally
# recognized only with an overt ``that`` boundary, so lexical clauses such as
# "I know John" remain ordinary actions rather than becoming target-language
# epistemic morphology.
ENGLISH_EPISTEMIC_FORMS = {
    (
        "i", "am", "certain", "it", "will", "be", "the", "case", "that",
    ): EnglishEpistemicForce.FUTURE_FACT,
    (
        "i", "remember", "it", "as", "a", "fact", "that",
    ): EnglishEpistemicForce.MEMORY_FACT,
    (
        "i", "think", "it", "was", "the", "case", "that",
    ): EnglishEpistemicForce.SUBJECTIVE_PAST,
    (
        "i", "am", "not", "at", "all", "sure", "that",
    ): EnglishEpistemicForce.UNSURE,
    ("i", "know", "for", "a", "fact", "that"): EnglishEpistemicForce.SURE,
    ("i", "do", "not", "think", "that"): EnglishEpistemicForce.DOUBT,
    ("i", "don't", "think", "that"): EnglishEpistemicForce.DOUBT,
    ("i", "don’t", "think", "that"): EnglishEpistemicForce.DOUBT,
    ("i", "am", "sure", "that"): EnglishEpistemicForce.SURE,
    ("i", "know", "that"): EnglishEpistemicForce.KNOWN,
    ("i", "think", "that"): EnglishEpistemicForce.THINK,
    ("i", "reckon", "that"): EnglishEpistemicForce.THINK,
    ("i", "suspect", "that"): EnglishEpistemicForce.UNSURE,
}
ENGLISH_EPISTEMIC_PATTERNS = tuple(
    sorted(ENGLISH_EPISTEMIC_FORMS, key=lambda form: (-len(form), form))
)


class EnglishStructuralFrontend:
    """Recognize source constructions that require structural transfer."""

    def parse(
        self,
        words: Sequence[EnglishInputToken],
        *,
        directive_hint: bool = False,
    ) -> tuple[EnglishStructuralFrame, ...]:
        if not words or (len(words) < 2 and not directive_hint):
            return ()
        pragmatic = self._extract_pragmatics(words)
        if pragmatic is None:
            return ()
        (
            words,
            preclausal_force,
            preclausal_indexes,
            discourse_force,
            discourse_indexes,
        ) = pragmatic
        if not words or (len(words) < 2 and not directive_hint):
            return ()
        epistemic = self.extract_epistemic(words)
        if epistemic is not None:
            proposition, epistemic_force, epistemic_indexes = epistemic
            frames = self.parse(proposition, directive_hint=False)
            if not frames or any(
                isinstance(frame, EnglishDirectiveFrame) for frame in frames
            ):
                return ()
            frames = self._apply_epistemic(
                frames,
                force=epistemic_force,
                indexes=epistemic_indexes,
            )
            return self._apply_pragmatics(
                frames,
                preclausal_force=preclausal_force,
                preclausal_indexes=preclausal_indexes,
                discourse_force=discourse_force,
                discourse_indexes=discourse_indexes,
            )
        if directive_hint:
            directive = self._parse_directive(
                words,
                directive_hint=True,
            )
            if directive:
                return self._apply_pragmatics(
                    directive,
                    preclausal_force=preclausal_force,
                    preclausal_indexes=preclausal_indexes,
                    discourse_force=discourse_force,
                    discourse_indexes=discourse_indexes,
                )
        extracted = self._extract_event_frequency(words)
        if extracted is None:
            return ()
        core_words, frequency_kind, frequency_indexes = extracted
        core_words, time = self._extract_time_nominal(core_words)
        aspect_extracted = self._extract_temporal_aspect(core_words)
        if aspect_extracted is None:
            return ()
        (
            core_words,
            temporal_aspect,
            temporal_aspect_indexes,
        ) = aspect_extracted
        modality_extracted = self._extract_action_modality(core_words)
        if modality_extracted is None:
            return ()
        (
            core_words,
            modality,
            modality_tense,
            modality_indexes,
        ) = modality_extracted
        distribution_extracted = self._extract_distribution(core_words)
        if distribution_extracted is None:
            return ()
        (
            core_words,
            distribution_kind,
            distribution_indexes,
        ) = distribution_extracted
        frames = self._parse_core(
            core_words,
            directive_hint=directive_hint,
        )
        if not frames:
            return frames
        if (
            frequency_kind is None
            and temporal_aspect is TemporalAspect.NONE
            and modality is Modality.NONE
            and distribution_kind is None
            and time is None
        ):
            return self._apply_pragmatics(
                frames,
                preclausal_force=preclausal_force,
                preclausal_indexes=preclausal_indexes,
                discourse_force=discourse_force,
                discourse_indexes=discourse_indexes,
            )
        if not all(isinstance(frame, EnglishActionFrame) for frame in frames):
            # Frequency transfer is deliberately bounded to event predicates.
            # Returning no structural parse keeps the modifier visible to the
            # existing unsupported/fallback path instead of dropping it.
            return ()
        enriched: list[EnglishActionFrame] = []
        for frame in frames:
            distribution_scope, distribution_target = (
                self._distribution_scope(
                    frame,
                    distribution_indexes,
                )
                if distribution_kind is not None
                else (None, None)
            )
            enriched.append(
                replace(
                    frame,
                    frequency_kind=frequency_kind,
                    frequency_indexes=frequency_indexes,
                    temporal_aspect=temporal_aspect,
                    temporal_aspect_indexes=temporal_aspect_indexes,
                    modality=modality,
                    modality_indexes=modality_indexes,
                    distribution_kind=distribution_kind,
                    distribution_scope=distribution_scope,
                    distribution_target_role=distribution_target,
                    distribution_indexes=distribution_indexes,
                    time=time,
                    tense=(
                        frame.tense
                        if frame.tense is not None
                        else modality_tense
                    ),
                    role_by_index=tuple(
                        sorted(
                            (
                                *frame.role_by_index,
                                *(
                                    (index, "frequency-adverb")
                                    for index in frequency_indexes
                                ),
                                *(
                                    (index, "temporal-aspect")
                                    for index in temporal_aspect_indexes
                                ),
                                *(
                                    (index, "modality")
                                    for index in modality_indexes
                                ),
                                *(
                                    (index, "distributive")
                                    for index in distribution_indexes
                                ),
                                *(
                                    self._nominal_roles(time, "time").items()
                                    if time is not None
                                    else ()
                                ),
                            )
                        )
                    ),
                    rule_trace=(
                        *frame.rule_trace,
                        *(
                            (
                                "english.frontend.event-frequency",
                                "english.frontend.frequency."
                                f"{frequency_kind.value}",
                            )
                            if frequency_kind is not None
                            else ()
                        ),
                        *(
                            (
                                "english.frontend.temporal-aspect",
                                "english.frontend.temporal-aspect."
                                f"{temporal_aspect.value}",
                            )
                            if temporal_aspect is not TemporalAspect.NONE
                            else ()
                        ),
                        *(
                            (
                                "english.frontend.action-modality",
                                "english.frontend.modality."
                                f"{modality.value}",
                            )
                            if modality is not Modality.NONE
                            else ()
                        ),
                        *(
                            (
                                "english.frontend.distributive",
                                "english.frontend.distributive."
                                f"{distribution_kind.value}",
                                "english.frontend.distributive-scope."
                                f"{distribution_scope.value}",
                                "english.frontend.distributive-target."
                                f"{distribution_target}",
                            )
                            if distribution_kind is not None
                            and distribution_scope is not None
                            else ()
                        ),
                        *(
                            ("english.frontend.time-nominal",)
                            if time is not None
                            else ()
                        ),
                    ),
                )
            )
        return self._apply_pragmatics(
            tuple(enriched),
            preclausal_force=preclausal_force,
            preclausal_indexes=preclausal_indexes,
            discourse_force=discourse_force,
            discourse_indexes=discourse_indexes,
        )

    @staticmethod
    def _apply_epistemic(
        frames: Sequence[EnglishStructuralFrame],
        *,
        force: EnglishEpistemicForce,
        indexes: tuple[int, ...],
    ) -> tuple[EnglishStructuralFrame, ...]:
        role_updates = {index: "epistemic-marker" for index in indexes}
        return tuple(
            replace(
                frame,
                epistemic_force=force,
                role_by_index=tuple(
                    sorted({**dict(frame.role_by_index), **role_updates}.items())
                ),
                rule_trace=(
                    *frame.rule_trace,
                    "english.frontend.epistemic-wrapper",
                    f"english.frontend.epistemic.{force.value}",
                ),
            )
            for frame in frames
        )

    @staticmethod
    def extract_epistemic(
        words: Sequence[EnglishInputToken],
    ) -> tuple[
        tuple[EnglishInputToken, ...],
        EnglishEpistemicForce,
        tuple[int, ...],
    ] | None:
        normalized = tuple(word.normalized for word in words)
        for pattern in ENGLISH_EPISTEMIC_PATTERNS:
            width = len(pattern)
            if normalized[:width] == pattern and len(words) > width:
                return (
                    tuple(words[width:]),
                    ENGLISH_EPISTEMIC_FORMS[pattern],
                    tuple(word.index for word in words[:width]),
                )
        return None

    @staticmethod
    def _apply_pragmatics(
        frames: Sequence[EnglishStructuralFrame],
        *,
        preclausal_force: EnglishPreclausalForce | None,
        preclausal_indexes: tuple[int, ...],
        discourse_force: EnglishDiscourseForce | None,
        discourse_indexes: tuple[int, ...],
    ) -> tuple[EnglishStructuralFrame, ...]:
        if preclausal_force is None and discourse_force is None:
            return tuple(frames)
        role_updates = {
            **{index: "preclausal-marker" for index in preclausal_indexes},
            **{index: "discourse-marker" for index in discourse_indexes},
        }
        trace = (
            *(
                (
                    "english.frontend.preclausal-pragmatics",
                    "english.frontend.preclausal."
                    f"{preclausal_force.value}",
                )
                if preclausal_force is not None
                else ()
            ),
            *(
                (
                    "english.frontend.postclausal-pragmatics",
                    "english.frontend.discourse."
                    f"{discourse_force.value}",
                )
                if discourse_force is not None
                else ()
            ),
        )
        return tuple(
            replace(
                frame,
                preclausal_force=preclausal_force,
                discourse_force=discourse_force,
                role_by_index=tuple(
                    sorted({**dict(frame.role_by_index), **role_updates}.items())
                ),
                rule_trace=(*frame.rule_trace, *trace),
            )
            for frame in frames
        )

    @staticmethod
    def _extract_pragmatics(
        words: Sequence[EnglishInputToken],
    ) -> tuple[
        tuple[EnglishInputToken, ...],
        EnglishPreclausalForce | None,
        tuple[int, ...],
        EnglishDiscourseForce | None,
        tuple[int, ...],
    ] | None:
        """Strip only comma-bounded conventional markers from clause edges."""

        core = tuple(words)
        preclausal_force = None
        preclausal_indexes: tuple[int, ...] = ()
        discourse_force = None
        discourse_indexes: tuple[int, ...] = ()

        normalized = tuple(word.normalized for word in core)
        for pattern in ENGLISH_PRECLAUSAL_PATTERNS:
            width = len(pattern)
            if (
                normalized[:width] == pattern
                and len(core) > width
                and core[width - 1].followed_by_comma
            ):
                preclausal_force = ENGLISH_PRECLAUSAL_FORMS[pattern]
                preclausal_indexes = tuple(
                    word.index for word in core[:width]
                )
                core = core[width:]
                break

        normalized = tuple(word.normalized for word in core)
        for pattern in ENGLISH_FRONTED_DISCOURSE_PATTERNS:
            width = len(pattern)
            if (
                normalized[:width] == pattern
                and len(core) > width
                and core[width - 1].followed_by_comma
            ):
                discourse_force = ENGLISH_FRONTED_DISCOURSE_FORMS[pattern]
                discourse_indexes = tuple(
                    word.index for word in core[:width]
                )
                core = core[width:]
                break

        normalized = tuple(word.normalized for word in core)
        for pattern in ENGLISH_POSTCLAUSAL_PATTERNS:
            width = len(pattern)
            start = len(core) - width
            if (
                start > 0
                and normalized[start:] == pattern
                and core[start].preceded_by_comma
            ):
                if discourse_force is not None:
                    return None
                discourse_force = ENGLISH_POSTCLAUSAL_FORMS[pattern]
                discourse_indexes = tuple(
                    word.index for word in core[start:]
                )
                core = core[:start]
                break

        if not core:
            return None
        return (
            core,
            preclausal_force,
            preclausal_indexes,
            discourse_force,
            discourse_indexes,
        )

    @classmethod
    def _extract_time_nominal(
        cls,
        words: Sequence[EnglishInputToken],
    ) -> tuple[
        tuple[EnglishInputToken, ...],
        EnglishNominalFrame | None,
    ]:
        """Detach a bounded English time NP without losing its extent.

        The frontend has no access to the compiled Asaxi lexicon, so this
        recognizes ordinary English calendar heads explicitly.  It accepts a
        comma-delimited fronted NP and an equivalent clause-final NP; lexical
        validation still happens in the translator.
        """

        core = tuple(words)
        for end, word in enumerate(core, start=1):
            if not word.followed_by_comma or end >= len(core):
                continue
            candidate = cls._parse_time_nominal(core[:end])
            if candidate is not None:
                return core[end:], candidate
            break

        for start in range(1, len(core)):
            if any(
                start >= len(marker)
                and tuple(
                    word.normalized
                    for word in core[start - len(marker):start]
                ) == marker
                for marker in ACTION_OBLIQUE_MARKERS
            ):
                continue
            candidate = cls._parse_time_nominal(core[start:])
            if candidate is not None:
                return core[:start], candidate
        return core, None

    @classmethod
    def _parse_time_nominal(
        cls,
        words: Sequence[EnglishInputToken],
    ) -> EnglishNominalFrame | None:
        if not words:
            return None
        normalized = tuple(word.normalized for word in words)
        if (
            len(words) == 3
            and normalized[:2] == ("all", "day")
            and normalized[2] in ENGLISH_TIME_HEADS
        ):
            return EnglishNominalFrame(
                source_indexes=tuple(word.index for word in words),
                head=normalized[2],
                head_indexes=(words[2].index,),
                extent=EnglishNominalExtent(
                    source_indexes=(words[0].index, words[1].index),
                    kind=NominalExtentKind.COMPLETE,
                    source_form="all day",
                ),
            )
        nominal = cls._parse_nominal(words)
        if nominal is None or nominal.head not in ENGLISH_TIME_HEADS:
            return None
        return nominal

    @staticmethod
    def _distribution_scope(
        frame: EnglishActionFrame,
        indexes: tuple[int, ...],
    ) -> tuple[DistributionScope, str]:
        """Resolve English adjacency into one explicit Asaxi scope."""

        first = min(indexes)
        if first == max(frame.subject.source_indexes) + 1:
            return DistributionScope.NOMINAL, "subject"
        if (
            frame.object is not None
            and first == max(frame.object.source_indexes) + 1
        ):
            return DistributionScope.NOMINAL, "object"
        if (
            frame.adjunct is not None
            and first == max(frame.adjunct.source_indexes) + 1
        ):
            return DistributionScope.NOMINAL, "location"
        return DistributionScope.EVENT, "event"

    @staticmethod
    def _extract_distribution(
        words: Sequence[EnglishInputToken],
    ) -> tuple[
        tuple[EnglishInputToken, ...],
        DistributionKind | None,
        tuple[int, ...],
    ] | None:
        normalized = tuple(word.normalized for word in words)
        matches: list[tuple[int, int, DistributionKind]] = []
        position = 0
        while position < len(words):
            match: tuple[int, int, DistributionKind] | None = None
            for form in ENGLISH_DISTRIBUTIVE_FORMS:
                end = position + len(form)
                if normalized[position:end] == form:
                    match = (
                        position,
                        end,
                        ENGLISH_DISTRIBUTIVES[form],
                    )
                    break
            if match is None:
                position += 1
                continue
            matches.append(match)
            position = match[1]
        if not matches:
            return tuple(words), None, ()
        if len(matches) != 1:
            return None
        start, end, kind = matches[0]
        core = tuple((*words[:start], *words[end:]))
        if len(core) < 2:
            return None
        return (
            core,
            kind,
            tuple(word.index for word in words[start:end]),
        )

    def _parse_core(
        self,
        words: Sequence[EnglishInputToken],
        *,
        directive_hint: bool = False,
    ) -> tuple[EnglishStructuralFrame, ...]:
        causative = self._parse_causative_action(words)
        if causative:
            return causative
        directive = self._parse_directive(
            words,
            directive_hint=directive_hint,
        )
        if directive:
            return directive
        wh_fronted = self._parse_fronted_wh_identity(words)
        if wh_fronted:
            return wh_fronted
        wh_action = self._parse_fronted_wh_action(words)
        if wh_action:
            return wh_action
        spatial = self._parse_spatial_copula(words)
        if spatial:
            return spatial
        future_progressive = self._parse_future_progressive_action(words)
        if future_progressive:
            return future_progressive
        future_identity = self._parse_future_identity(words)
        if future_identity:
            return future_identity
        inverted_progressive = self._parse_inverted_progressive_action(
            words
        )
        if inverted_progressive:
            return inverted_progressive
        progressive = self._parse_declarative_progressive_action(words)
        if progressive:
            return progressive
        declarative = self._parse_declarative_identity(words)
        if declarative:
            return declarative
        inverted = self._parse_inverted_identity(words)
        if inverted:
            return inverted
        auxiliary_action = self._parse_auxiliary_action(words)
        if auxiliary_action:
            return auxiliary_action
        declarative_action = self._parse_declarative_action(words)
        if declarative_action:
            return declarative_action
        return ()

    def _parse_causative_action(
        self,
        words: Sequence[EnglishInputToken],
    ) -> tuple[EnglishActionFrame, ...]:
        """Parse bounded English causer-causee-action constructions."""

        operator_positions = tuple(
            index
            for index, word in enumerate(words)
            if word.normalized in ENGLISH_CAUSATIVE_FORMS
        )
        if len(operator_positions) != 1:
            return ()
        operator_position = operator_positions[0]
        operator = words[operator_position]
        voice, lexical_tenses, complement_style = (
            ENGLISH_CAUSATIVE_FORMS[operator.normalized]
        )

        auxiliary_forms = {
            **DO_AUXILIARIES,
            **NEGATIVE_DO_AUXILIARIES,
            **{
                form: Tense.FUTURE
                for form in (
                    FUTURE_AUXILIARIES
                    | NEGATIVE_FUTURE_AUXILIARIES
                )
            },
        }
        auxiliary_positions = tuple(
            index
            for index, word in enumerate(words[:operator_position])
            if word.normalized in auxiliary_forms
        )
        if len(auxiliary_positions) > 1:
            return ()
        auxiliary_index: int | None = None
        negation_indexes: tuple[int, ...] = ()
        interrogative = False
        if auxiliary_positions:
            auxiliary_position = auxiliary_positions[0]
            auxiliary = words[auxiliary_position]
            auxiliary_index = auxiliary.index
            tenses = (auxiliary_forms[auxiliary.normalized],)
            polarity = (
                Polarity.NEGATIVE
                if auxiliary.normalized
                in (
                    set(NEGATIVE_DO_AUXILIARIES)
                    | NEGATIVE_FUTURE_AUXILIARIES
                )
                else Polarity.POSITIVE
            )
            interrogative = auxiliary_position == 0
            if interrogative:
                causer_words = tuple(words[1:operator_position])
            else:
                causer_words = tuple(words[:auxiliary_position])
                bridge_words = tuple(
                    words[auxiliary_position + 1:operator_position]
                )
                if bridge_words:
                    if (
                        len(bridge_words) != 1
                        or bridge_words[0].normalized != "not"
                    ):
                        return ()
                    polarity = Polarity.NEGATIVE
                    negation_indexes = (bridge_words[0].index,)
        else:
            causer_words = tuple(words[:operator_position])
            tenses = lexical_tenses
            polarity = Polarity.POSITIVE
        if not causer_words:
            return ()
        causer = self._parse_nominal(causer_words)
        if causer is None:
            return ()

        tail = tuple(words[operator_position + 1:])
        parsed_tails = self._parse_causative_tail(
            tail,
            complement_style=complement_style,
        )
        frames: list[EnglishActionFrame] = []
        for (
            causee,
            predicate,
            complement_marker_indexes,
            object_frame,
            obliques,
        ) in parsed_tails:
            for tense in tenses:
                roles = self._nominal_roles(causer, "causer")
                roles.update(self._nominal_roles(causee, "causee"))
                roles[operator.index] = "causative-operator"
                roles[predicate.index] = "predicate"
                for index in complement_marker_indexes:
                    roles[index] = "causative-complement-marker"
                if auxiliary_index is not None:
                    roles[auxiliary_index] = (
                        "future-auxiliary"
                        if tense is Tense.FUTURE
                        else "auxiliary"
                    )
                for index in negation_indexes:
                    roles[index] = "negation"
                if object_frame is not None:
                    roles.update(
                        self._nominal_roles(object_frame, "object")
                    )
                roles.update(self._oblique_roles(obliques))
                frames.append(
                    EnglishActionFrame(
                        kind=EnglishFrameKind.ACTION,
                        subject=causee,
                        predicate=predicate.normalized,
                        predicate_indexes=(predicate.index,),
                        object=object_frame,
                        adjunct=None,
                        wh_role=None,
                        tense=tense,
                        polarity=polarity,
                        interrogative=interrogative,
                        role_by_index=tuple(sorted(roles.items())),
                        rule_trace=(
                            "english.frontend.causative-action",
                            "english.frontend.causer-causee-action",
                            f"english.frontend.causative.{voice.value}",
                        ),
                        obliques=obliques,
                        causer=causer,
                        causative_voice=voice,
                        causative_indexes=(
                            operator.index,
                            *complement_marker_indexes,
                        ),
                    )
                )
        return tuple(frames)

    def _parse_causative_tail(
        self,
        words: Sequence[EnglishInputToken],
        *,
        complement_style: str,
    ) -> tuple[
        tuple[
            EnglishNominalFrame,
            EnglishInputToken,
            tuple[int, ...],
            EnglishNominalFrame | None,
            tuple[EnglishObliqueFrame, ...],
        ],
        ...,
    ]:
        splits: list[
            tuple[
                EnglishNominalFrame,
                EnglishInputToken,
                tuple[int, ...],
                EnglishNominalFrame | None,
                tuple[EnglishObliqueFrame, ...],
            ]
        ] = []
        if complement_style in {"to", "from"}:
            marker_positions = tuple(
                index
                for index, word in enumerate(words)
                if word.normalized == complement_style
                and index > 0
                and index + 1 < len(words)
            )
            if len(marker_positions) != 1:
                return ()
            marker_position = marker_positions[0]
            causee = self._parse_nominal(words[:marker_position])
            if causee is None:
                return ()
            predicate = words[marker_position + 1]
            for object_frame, obliques in self._parse_action_arguments(
                words[marker_position + 2:]
            ):
                splits.append(
                    (
                        causee,
                        predicate,
                        (words[marker_position].index,),
                        object_frame,
                        obliques,
                    )
                )
            return tuple(splits)

        for predicate_position in range(1, len(words)):
            causee = self._parse_nominal(words[:predicate_position])
            if causee is None:
                continue
            predicate = words[predicate_position]
            for object_frame, obliques in self._parse_action_arguments(
                words[predicate_position + 1:]
            ):
                splits.append(
                    (
                        causee,
                        predicate,
                        (),
                        object_frame,
                        obliques,
                    )
                )
        return tuple(splits)

    @staticmethod
    def _extract_event_frequency(
        words: Sequence[EnglishInputToken],
    ) -> tuple[
        tuple[EnglishInputToken, ...],
        FrequencyKind | None,
        tuple[int, ...],
    ] | None:
        """Remove one recognized English event-frequency expression.

        Longest-match scanning prevents ``absolutely never`` from also being
        counted as bare ``never``.  Two independent frequency expressions are
        rejected so neither one can be silently discarded.
        """

        normalized = tuple(word.normalized for word in words)
        matches: list[tuple[int, int, FrequencyKind]] = []
        position = 0
        while position < len(words):
            match: tuple[int, int, FrequencyKind] | None = None
            for form in ENGLISH_EVENT_FREQUENCY_FORMS:
                end = position + len(form)
                if normalized[position:end] == form:
                    match = (
                        position,
                        end,
                        ENGLISH_EVENT_FREQUENCIES[form],
                    )
                    break
            if match is None:
                position += 1
                continue
            matches.append(match)
            position = match[1]

        if not matches:
            return tuple(words), None, ()
        if len(matches) != 1:
            return None
        start, end, kind = matches[0]
        core = tuple((*words[:start], *words[end:]))
        if len(core) < 2:
            return None
        return (
            core,
            kind,
            tuple(word.index for word in words[start:end]),
        )

    @staticmethod
    def _extract_temporal_aspect(
        words: Sequence[EnglishInputToken],
    ) -> tuple[
        tuple[EnglishInputToken, ...],
        TemporalAspect,
        tuple[int, ...],
    ] | None:
        """Remove one overt English relative-time modifier.

        The source expressions correspond directly to the documented Asaxi
        ``-nå`` semantic matrix.  The method does not infer a perfect aspect
        from an auxiliary; it only transfers an explicit lexical cue.
        """

        normalized = tuple(word.normalized for word in words)
        matches: list[tuple[int, int, TemporalAspect]] = []
        position = 0
        while position < len(words):
            match: tuple[int, int, TemporalAspect] | None = None
            for form in ENGLISH_TEMPORAL_ASPECT_FORMS:
                end = position + len(form)
                if normalized[position:end] == form:
                    match = (
                        position,
                        end,
                        ENGLISH_TEMPORAL_ASPECTS[form],
                    )
                    break
            if match is None:
                position += 1
                continue
            matches.append(match)
            position = match[1]

        if not matches:
            return tuple(words), TemporalAspect.NONE, ()
        if len(matches) != 1:
            return None
        start, end, aspect = matches[0]
        core = tuple((*words[:start], *words[end:]))
        if len(core) < 2:
            return None
        return (
            core,
            aspect,
            tuple(word.index for word in words[start:end]),
        )

    @staticmethod
    def _extract_action_modality(
        words: Sequence[EnglishInputToken],
    ) -> tuple[
        tuple[EnglishInputToken, ...],
        Modality,
        Tense | None,
        tuple[int, ...],
    ] | None:
        """Collapse one English ``want/try to VERB`` operator.

        Removing only the matrix operator lets the ordinary source parser
        recover the arguments of the lexical verb.  Auxiliary tense and
        polarity remain in the core sequence; simple inflected modality forms
        provide tense only when the core parser has no stronger auxiliary.
        """

        matches = [
            (
                position,
                ENGLISH_ACTION_MODALITIES[word.normalized],
            )
            for position, word in enumerate(words[:-2])
            if (
                word.normalized in ENGLISH_ACTION_MODALITIES
                and words[position + 1].normalized == "to"
            )
        ]
        if not matches:
            return tuple(words), Modality.NONE, None, ()
        if len(matches) != 1:
            return None
        position, (modality, tense) = matches[0]
        core = tuple((*words[:position], *words[position + 2:]))
        if len(core) < 2:
            return None
        return (
            core,
            modality,
            tense,
            (words[position].index, words[position + 1].index),
        )

    def _parse_directive(
        self,
        words: Sequence[EnglishInputToken],
        *,
        directive_hint: bool = False,
    ) -> tuple[EnglishDirectiveFrame, ...]:
        """Parse finite English source forms for documented Asaxi commands."""

        start: int
        marker_roles: dict[int, str]
        trace: tuple[str, ...]
        if words[0].normalized in {"let's", "let’s"}:
            force = EnglishDirectiveForce.HORTATIVE
            start = 1
            marker_roles = {words[0].index: "joint-action-marker"}
            trace = (
                "english.frontend.directive",
                "english.frontend.hortative",
            )
        elif (
            len(words) >= 3
            and tuple(word.normalized for word in words[:2])
            == ("shall", "we")
        ):
            force = EnglishDirectiveForce.POLITE_HORTATIVE
            start = 2
            marker_roles = {
                words[0].index: "directive-marker",
                words[1].index: "joint-participant",
            }
            trace = (
                "english.frontend.directive",
                "english.frontend.polite-hortative",
            )
        elif words[0].normalized in {"please", "kindly"}:
            start = 1
            marker_roles = {words[0].index: "directive-marker"}
            if (
                len(words) >= 4
                and words[1].normalized == "do"
                and words[2].normalized == "not"
            ):
                force = EnglishDirectiveForce.POLITE_PROHIBITION
                marker_roles[words[1].index] = "auxiliary"
                marker_roles[words[2].index] = "negation"
                start = 3
                trace = (
                    "english.frontend.directive",
                    "english.frontend.polite-prohibition",
                )
            else:
                force = EnglishDirectiveForce.REQUEST
                trace = (
                    "english.frontend.directive",
                    "english.frontend.request",
                )
        elif (
            len(words) >= 5
            and tuple(word.normalized for word in words[:4])
            == ("you", "are", "requested", "to")
        ):
            force = EnglishDirectiveForce.INSTRUCTION
            start = 4
            marker_roles = {
                words[0].index: "implicit-addressee",
                words[1].index: "auxiliary",
                words[2].index: "directive-marker",
                words[3].index: "infinitive-marker",
            }
            trace = (
                "english.frontend.directive",
                "english.frontend.formal-instruction",
            )
        elif (
            len(words) >= 3
            and tuple(word.normalized for word in words[:2])
            == ("do", "not")
        ):
            force = EnglishDirectiveForce.PROHIBITION
            start = 2
            marker_roles = {
                words[0].index: "auxiliary",
                words[1].index: "negation",
            }
            trace = (
                "english.frontend.directive",
                "english.frontend.prohibition",
            )
        elif len(words) >= 2 and words[0].normalized == "no":
            force = EnglishDirectiveForce.ABSOLUTE_PROHIBITION
            start = 1
            marker_roles = {words[0].index: "directive-marker"}
            trace = (
                "english.frontend.directive",
                "english.frontend.absolute-prohibition",
            )
        elif len(words) >= 2 and words[0].normalized == "stop":
            force = EnglishDirectiveForce.CESSATION
            start = 1
            marker_roles = {words[0].index: "directive-marker"}
            trace = (
                "english.frontend.directive",
                "english.frontend.cessation",
            )
        elif (
            len(words) >= 2
            and words[0].normalized in {"continue", "keep"}
        ):
            force = EnglishDirectiveForce.CONTINUATION
            start = 1
            marker_roles = {words[0].index: "directive-marker"}
            trace = (
                "english.frontend.directive",
                "english.frontend.continuation",
            )
        elif directive_hint and words[-1].normalized == "now":
            force = EnglishDirectiveForce.SWITCH
            start = 0
            marker_roles = {words[-1].index: "directive-marker"}
            words = words[:-1]
            trace = (
                "english.frontend.directive",
                "english.frontend.immediate-switch",
            )
        elif directive_hint:
            force = EnglishDirectiveForce.COMMAND
            start = 0
            marker_roles = {}
            trace = (
                "english.frontend.directive",
                "english.frontend.command",
            )
        else:
            return ()

        frames: list[EnglishDirectiveFrame] = []
        for object_start in range(start + 1, len(words) + 1):
            predicate_words = words[start:object_start]
            object_words = words[object_start:]
            object_frame = (
                self._parse_nominal(object_words) if object_words else None
            )
            if object_words and object_frame is None:
                continue
            roles = dict(marker_roles)
            for word in predicate_words:
                roles[word.index] = "predicate"
            if object_frame is not None:
                roles.update(self._nominal_roles(object_frame, "object"))
            frames.append(
                EnglishDirectiveFrame(
                    kind=EnglishFrameKind.DIRECTIVE,
                    force=force,
                    predicate=" ".join(
                        word.normalized for word in predicate_words
                    ),
                    predicate_indexes=tuple(
                        word.index for word in predicate_words
                    ),
                    object=object_frame,
                    role_by_index=tuple(sorted(roles.items())),
                    rule_trace=trace,
                )
            )
        return tuple(frames)

    def _parse_spatial_copula(
        self,
        words: Sequence[EnglishInputToken],
    ) -> tuple[EnglishSpatialClauseFrame, ...]:
        """Parse physical English copular locations into semantic relations."""

        first = words[0].normalized
        if first in FUTURE_AUXILIARIES | NEGATIVE_FUTURE_AUXILIARIES:
            polarity = (
                Polarity.NEGATIVE
                if first in NEGATIVE_FUTURE_AUXILIARIES
                else Polarity.POSITIVE
            )
            be_positions = [
                index
                for index, word in enumerate(words[2:], start=2)
                if word.normalized == "be"
            ]
            if len(be_positions) != 1:
                return ()
            be_position = be_positions[0]
            subject_words = words[1:be_position]
            if (
                subject_words
                and subject_words[-1].normalized == "not"
                and polarity is Polarity.POSITIVE
            ):
                polarity = Polarity.NEGATIVE
                subject_words = subject_words[:-1]
            return self._build_spatial_frame(
                subject_words=subject_words,
                complement_words=words[be_position + 1:],
                tense=Tense.FUTURE,
                polarity=polarity,
                interrogative=True,
                auxiliary_indexes=(words[0].index, words[be_position].index),
                negation_indexes=tuple(
                    word.index
                    for word in words[1:be_position]
                    if word.normalized == "not"
                ),
            )

        future_positions = [
            index
            for index, word in enumerate(words)
            if word.normalized
            in FUTURE_AUXILIARIES | NEGATIVE_FUTURE_AUXILIARIES
        ]
        if len(future_positions) == 1:
            position = future_positions[0]
            if 0 < position < len(words) - 2:
                polarity = (
                    Polarity.NEGATIVE
                    if words[position].normalized
                    in NEGATIVE_FUTURE_AUXILIARIES
                    else Polarity.POSITIVE
                )
                be_position = position + 1
                if (
                    be_position < len(words)
                    and words[be_position].normalized == "not"
                    and polarity is Polarity.POSITIVE
                ):
                    polarity = Polarity.NEGATIVE
                    be_position += 1
                if (
                    be_position < len(words)
                    and words[be_position].normalized == "be"
                ):
                    return self._build_spatial_frame(
                        subject_words=words[:position],
                        complement_words=words[be_position + 1:],
                        tense=Tense.FUTURE,
                        polarity=polarity,
                        interrogative=False,
                        auxiliary_indexes=(
                            words[position].index,
                            words[be_position].index,
                        ),
                        negation_indexes=tuple(
                            word.index
                            for word in words[position + 1:be_position]
                            if word.normalized == "not"
                        ),
                    )

        if first in COPULA_TENSES:
            polarity = Polarity.POSITIVE
            content_start = 1
            negation_indexes: tuple[int, ...] = ()
            if (
                content_start < len(words)
                and words[content_start].normalized == "not"
            ):
                polarity = Polarity.NEGATIVE
                negation_indexes = (words[content_start].index,)
                content_start += 1
            for split in range(content_start + 1, len(words)):
                built = self._build_spatial_frame(
                    subject_words=words[content_start:split],
                    complement_words=words[split:],
                    tense=COPULA_TENSES[first],
                    polarity=polarity,
                    interrogative=True,
                    auxiliary_indexes=(words[0].index,),
                    negation_indexes=negation_indexes,
                )
                if built:
                    return built
            return ()

        copula_positions = [
            index
            for index, word in enumerate(words)
            if word.normalized in COPULA_TENSES
        ]
        if len(copula_positions) != 1:
            return ()
        position = copula_positions[0]
        if position == 0 or position == len(words) - 1:
            return ()
        complement_start = position + 1
        polarity = Polarity.POSITIVE
        negation_indexes = ()
        if (
            complement_start < len(words)
            and words[complement_start].normalized == "not"
        ):
            polarity = Polarity.NEGATIVE
            negation_indexes = (words[complement_start].index,)
            complement_start += 1
        return self._build_spatial_frame(
            subject_words=words[:position],
            complement_words=words[complement_start:],
            tense=COPULA_TENSES[words[position].normalized],
            polarity=polarity,
            interrogative=False,
            auxiliary_indexes=(words[position].index,),
            negation_indexes=negation_indexes,
        )

    def _build_spatial_frame(
        self,
        *,
        subject_words: Sequence[EnglishInputToken],
        complement_words: Sequence[EnglishInputToken],
        tense: Tense,
        polarity: Polarity,
        interrogative: bool,
        auxiliary_indexes: tuple[int, ...],
        negation_indexes: tuple[int, ...],
    ) -> tuple[EnglishSpatialClauseFrame, ...]:
        subject = self._parse_nominal(subject_words)
        if subject is None:
            return ()
        relation_match = self._spatial_relation(complement_words)
        if relation_match is None:
            return ()
        relation, relation_words, location_words = relation_match
        location = self._parse_nominal(location_words)
        if location is None:
            return ()
        roles = self._nominal_roles(subject, "subject")
        roles.update(self._nominal_roles(location, "location"))
        for index in auxiliary_indexes:
            roles[index] = (
                "future-auxiliary"
                if len(auxiliary_indexes) == 2
                and index == auxiliary_indexes[0]
                else "copula"
            )
        for index in negation_indexes:
            roles[index] = "negation"
        for word in relation_words:
            roles[word.index] = "spatial-relation"
        return (
            EnglishSpatialClauseFrame(
                kind=EnglishFrameKind.LOCATION,
                subject=subject,
                location=location,
                relation=relation,
                relation_indexes=tuple(
                    word.index for word in relation_words
                ),
                tense=tense,
                polarity=polarity,
                interrogative=interrogative,
                role_by_index=tuple(sorted(roles.items())),
                rule_trace=(
                    "english.frontend.spatial-copula",
                    f"english.frontend.spatial-{relation.value}",
                    (
                        "english.frontend.yes-no-inversion"
                        if interrogative
                        else "english.frontend.declarative-order"
                    ),
                ),
            ),
        )

    @staticmethod
    def _spatial_relation(
        words: Sequence[EnglishInputToken],
    ) -> tuple[
        EnglishSpatialRelation,
        tuple[EnglishInputToken, ...],
        tuple[EnglishInputToken, ...],
    ] | None:
        for length in sorted(
            {len(marker) for marker in SPATIAL_PREPOSITIONS},
            reverse=True,
        ):
            if len(words) <= length:
                continue
            marker = tuple(word.normalized for word in words[:length])
            relation = SPATIAL_PREPOSITIONS.get(marker)
            if relation is None:
                continue
            return (
                relation,
                tuple(words[:length]),
                tuple(words[length:]),
            )
        return None

    def _parse_future_identity(
        self,
        words: Sequence[EnglishInputToken],
    ) -> tuple[EnglishClauseFrame, ...]:
        """Parse ``X will (not) be Y`` and future copular inversion."""

        first = words[0].normalized
        if first in FUTURE_AUXILIARIES | NEGATIVE_FUTURE_AUXILIARIES:
            polarity = (
                Polarity.NEGATIVE
                if first in NEGATIVE_FUTURE_AUXILIARIES
                else Polarity.POSITIVE
            )
            be_positions = [
                index
                for index, word in enumerate(words[2:], start=2)
                if word.normalized == "be"
            ]
            if len(be_positions) != 1:
                return ()
            be_position = be_positions[0]
            subject_words = words[1:be_position]
            if (
                subject_words
                and subject_words[-1].normalized == "not"
                and polarity is Polarity.POSITIVE
            ):
                polarity = Polarity.NEGATIVE
                subject_words = subject_words[:-1]
            subject = self._parse_nominal(subject_words)
            complement = self._parse_nominal(words[be_position + 1:])
            if subject is None or complement is None:
                return ()
            roles = self._nominal_roles(subject, "subject")
            roles.update(self._nominal_roles(complement, "complement"))
            roles[words[0].index] = "future-auxiliary"
            roles[words[be_position].index] = "copula"
            for word in words[1:be_position]:
                if word.normalized == "not":
                    roles[word.index] = "negation"
            return (
                EnglishClauseFrame(
                    kind=EnglishFrameKind.IDENTITY,
                    subject=subject,
                    complement=complement,
                    tense=Tense.FUTURE,
                    polarity=polarity,
                    interrogative=True,
                    role_by_index=tuple(sorted(roles.items())),
                    rule_trace=(
                        "english.frontend.copular-identity",
                        "english.frontend.future-auxiliary",
                        "english.frontend.yes-no-inversion",
                    ),
                ),
            )

        future_positions = [
            index
            for index, word in enumerate(words)
            if word.normalized
            in FUTURE_AUXILIARIES | NEGATIVE_FUTURE_AUXILIARIES
        ]
        if len(future_positions) != 1:
            return ()
        position = future_positions[0]
        if position == 0 or position >= len(words) - 2:
            return ()
        polarity = (
            Polarity.NEGATIVE
            if words[position].normalized in NEGATIVE_FUTURE_AUXILIARIES
            else Polarity.POSITIVE
        )
        be_position = position + 1
        if (
            be_position < len(words)
            and words[be_position].normalized == "not"
            and polarity is Polarity.POSITIVE
        ):
            polarity = Polarity.NEGATIVE
            be_position += 1
        if (
            be_position >= len(words)
            or words[be_position].normalized != "be"
            or be_position == len(words) - 1
        ):
            return ()
        subject = self._parse_nominal(words[:position])
        complement = self._parse_nominal(words[be_position + 1:])
        if subject is None or complement is None:
            return ()
        roles = self._nominal_roles(subject, "subject")
        roles.update(self._nominal_roles(complement, "complement"))
        roles[words[position].index] = "future-auxiliary"
        roles[words[be_position].index] = "copula"
        for word in words[position + 1:be_position]:
            if word.normalized == "not":
                roles[word.index] = "negation"
        return (
            EnglishClauseFrame(
                kind=EnglishFrameKind.IDENTITY,
                subject=subject,
                complement=complement,
                tense=Tense.FUTURE,
                polarity=polarity,
                interrogative=False,
                role_by_index=tuple(sorted(roles.items())),
                rule_trace=(
                    "english.frontend.copular-identity",
                    "english.frontend.future-auxiliary",
                    "english.frontend.declarative-order",
                ),
            ),
        )

    def _parse_declarative_progressive_action(
        self,
        words: Sequence[EnglishInputToken],
    ) -> tuple[EnglishActionFrame, ...]:
        """Parse bounded ``subject + be + verb-ing (+ object)`` clauses."""

        copula_positions = [
            index
            for index, word in enumerate(words)
            if word.normalized in COPULA_TENSES
        ]
        if len(copula_positions) != 1:
            return ()
        copula_position = copula_positions[0]
        if copula_position == 0:
            return ()
        predicate_position = copula_position + 1
        polarity = Polarity.POSITIVE
        if (
            predicate_position < len(words)
            and words[predicate_position].normalized == "not"
        ):
            polarity = Polarity.NEGATIVE
            predicate_position += 1
        if predicate_position >= len(words):
            return ()
        predicate = words[predicate_position]
        if not predicate.normalized.endswith("ing"):
            return ()
        subject = self._parse_nominal(words[:copula_position])
        if subject is None:
            return ()
        frames: list[EnglishActionFrame] = []
        for object_frame, obliques in self._parse_action_arguments(
            words[predicate_position + 1:]
        ):
            roles = self._nominal_roles(subject, "subject")
            roles[words[copula_position].index] = (
                "progressive-auxiliary"
            )
            if polarity is Polarity.NEGATIVE:
                roles[words[copula_position + 1].index] = "negation"
            roles[predicate.index] = "predicate"
            if object_frame is not None:
                roles.update(
                    self._nominal_roles(object_frame, "object")
                )
            roles.update(self._oblique_roles(obliques))
            frames.append(
                EnglishActionFrame(
                    kind=EnglishFrameKind.ACTION,
                    subject=subject,
                    predicate=predicate.normalized,
                    predicate_indexes=(predicate.index,),
                    object=object_frame,
                    adjunct=None,
                    wh_role=None,
                    tense=COPULA_TENSES[
                        words[copula_position].normalized
                    ],
                    polarity=polarity,
                    interrogative=False,
                    role_by_index=tuple(sorted(roles.items())),
                    rule_trace=(
                        "english.frontend.declarative-action",
                        "english.frontend.progressive-auxiliary",
                        "english.frontend.progressive-declarative",
                    ),
                    aspect=EnglishAspect.PROGRESSIVE,
                    obliques=obliques,
                )
            )
        return tuple(frames)

    def _parse_future_progressive_action(
        self,
        words: Sequence[EnglishInputToken],
    ) -> tuple[EnglishActionFrame, ...]:
        """Parse declarative and inverted ``will be verb-ing`` clauses."""

        future_forms = FUTURE_AUXILIARIES | NEGATIVE_FUTURE_AUXILIARIES
        positions = [
            index
            for index, word in enumerate(words)
            if word.normalized in future_forms
        ]
        if len(positions) != 1:
            return ()
        auxiliary_position = positions[0]
        interrogative = auxiliary_position == 0
        polarity = (
            Polarity.NEGATIVE
            if words[auxiliary_position].normalized
            in NEGATIVE_FUTURE_AUXILIARIES
            else Polarity.POSITIVE
        )
        if interrogative:
            be_positions = [
                index
                for index, word in enumerate(words[2:], start=2)
                if word.normalized == "be"
            ]
            if len(be_positions) != 1:
                return ()
            be_position = be_positions[0]
            subject_words = words[1:be_position]
        else:
            if auxiliary_position == 0:
                return ()
            subject_words = words[:auxiliary_position]
            be_position = auxiliary_position + 1
            if (
                be_position < len(words)
                and words[be_position].normalized == "not"
            ):
                polarity = Polarity.NEGATIVE
                be_position += 1
            if (
                be_position >= len(words)
                or words[be_position].normalized != "be"
            ):
                return ()

        negation_indexes: list[int] = []
        if subject_words and subject_words[-1].normalized == "not":
            polarity = Polarity.NEGATIVE
            negation_indexes.append(subject_words[-1].index)
            subject_words = subject_words[:-1]
        for word in words[auxiliary_position + 1:be_position]:
            if word.normalized == "not":
                polarity = Polarity.NEGATIVE
                negation_indexes.append(word.index)

        predicate_position = be_position + 1
        if (
            predicate_position < len(words)
            and words[predicate_position].normalized == "not"
        ):
            polarity = Polarity.NEGATIVE
            negation_indexes.append(words[predicate_position].index)
            predicate_position += 1
        return self._build_progressive_action_frame(
            words=words,
            subject_words=subject_words,
            predicate_position=predicate_position,
            tense=Tense.FUTURE,
            polarity=polarity,
            interrogative=interrogative,
            auxiliary_index=words[auxiliary_position].index,
            progressive_auxiliary_index=words[be_position].index,
            negation_indexes=tuple(sorted(set(negation_indexes))),
            trace_marker="english.frontend.future-auxiliary",
        )

    def _parse_inverted_progressive_action(
        self,
        words: Sequence[EnglishInputToken],
    ) -> tuple[EnglishActionFrame, ...]:
        """Parse ``is/was subject (not) verb-ing`` yes/no questions."""

        if words[0].normalized not in COPULA_TENSES:
            return ()
        frames: list[EnglishActionFrame] = []
        for predicate_position in range(2, len(words)):
            if not words[predicate_position].normalized.endswith("ing"):
                continue
            subject_words = words[1:predicate_position]
            polarity = Polarity.POSITIVE
            negation_indexes: tuple[int, ...] = ()
            if subject_words and subject_words[-1].normalized == "not":
                polarity = Polarity.NEGATIVE
                negation_indexes = (subject_words[-1].index,)
                subject_words = subject_words[:-1]
            frames.extend(
                self._build_progressive_action_frame(
                    words=words,
                    subject_words=subject_words,
                    predicate_position=predicate_position,
                    tense=COPULA_TENSES[words[0].normalized],
                    polarity=polarity,
                    interrogative=True,
                    auxiliary_index=None,
                    progressive_auxiliary_index=words[0].index,
                    negation_indexes=negation_indexes,
                    trace_marker="english.frontend.yes-no-inversion",
                )
            )
        return tuple(frames)

    def _build_progressive_action_frame(
        self,
        *,
        words: Sequence[EnglishInputToken],
        subject_words: Sequence[EnglishInputToken],
        predicate_position: int,
        tense: Tense,
        polarity: Polarity,
        interrogative: bool,
        auxiliary_index: int | None,
        progressive_auxiliary_index: int,
        negation_indexes: tuple[int, ...],
        trace_marker: str,
    ) -> tuple[EnglishActionFrame, ...]:
        if predicate_position >= len(words):
            return ()
        predicate = words[predicate_position]
        if not predicate.normalized.endswith("ing"):
            return ()
        subject = self._parse_nominal(subject_words)
        if subject is None:
            return ()
        frames: list[EnglishActionFrame] = []
        for object_frame, obliques in self._parse_action_arguments(
            words[predicate_position + 1:]
        ):
            roles = self._nominal_roles(subject, "subject")
            if auxiliary_index is not None:
                roles[auxiliary_index] = "future-auxiliary"
            roles[progressive_auxiliary_index] = (
                "progressive-auxiliary"
            )
            for index in negation_indexes:
                roles[index] = "negation"
            roles[predicate.index] = "predicate"
            if object_frame is not None:
                roles.update(
                    self._nominal_roles(object_frame, "object")
                )
            roles.update(self._oblique_roles(obliques))
            frames.append(
                EnglishActionFrame(
                    kind=EnglishFrameKind.ACTION,
                    subject=subject,
                    predicate=predicate.normalized,
                    predicate_indexes=(predicate.index,),
                    object=object_frame,
                    adjunct=None,
                    wh_role=None,
                    tense=tense,
                    polarity=polarity,
                    interrogative=interrogative,
                    role_by_index=tuple(sorted(roles.items())),
                    rule_trace=(
                        "english.frontend.declarative-action",
                        "english.frontend.progressive-auxiliary",
                        trace_marker,
                    ),
                    aspect=EnglishAspect.PROGRESSIVE,
                    obliques=obliques,
                )
            )
        return tuple(frames)

    def _parse_auxiliary_action(
        self,
        words: Sequence[EnglishInputToken],
    ) -> tuple[EnglishActionFrame, ...]:
        """Parse simple actions with do-support or future auxiliaries."""

        auxiliary_tenses = {
            **DO_AUXILIARIES,
            **NEGATIVE_DO_AUXILIARIES,
            **{
                form: Tense.FUTURE
                for form in (
                    FUTURE_AUXILIARIES
                    | NEGATIVE_FUTURE_AUXILIARIES
                )
            },
        }
        positions = [
            index
            for index, word in enumerate(words)
            if word.normalized in auxiliary_tenses
        ]
        if len(positions) != 1:
            return ()
        auxiliary_position = positions[0]
        auxiliary = words[auxiliary_position]
        tense = auxiliary_tenses[auxiliary.normalized]
        polarity = (
            Polarity.NEGATIVE
            if auxiliary.normalized
            in (
                set(NEGATIVE_DO_AUXILIARIES)
                | NEGATIVE_FUTURE_AUXILIARIES
            )
            else Polarity.POSITIVE
        )
        interrogative = auxiliary_position == 0
        if interrogative:
            frames: list[EnglishActionFrame] = []
            for predicate_position in range(2, len(words)):
                if words[predicate_position].normalized == "not":
                    continue
                subject_words = words[1:predicate_position]
                frame_polarity = polarity
                negation_indexes: tuple[int, ...] = ()
                if subject_words and subject_words[-1].normalized == "not":
                    frame_polarity = Polarity.NEGATIVE
                    negation_indexes = (subject_words[-1].index,)
                    subject_words = subject_words[:-1]
                built = self._build_auxiliary_action_frame(
                    words=words,
                    subject_words=subject_words,
                    predicate_position=predicate_position,
                    tense=tense,
                    polarity=frame_polarity,
                    interrogative=True,
                    auxiliary_index=auxiliary.index,
                    negation_indexes=negation_indexes,
                )
                frames.extend(built)
            return tuple(frames)

        if auxiliary_position == 0:
            return ()
        subject_words = words[:auxiliary_position]
        predicate_position = auxiliary_position + 1
        negation_indexes: tuple[int, ...] = ()
        if (
            predicate_position < len(words)
            and words[predicate_position].normalized == "not"
        ):
            polarity = Polarity.NEGATIVE
            negation_indexes = (words[predicate_position].index,)
            predicate_position += 1
        return self._build_auxiliary_action_frame(
            words=words,
            subject_words=subject_words,
            predicate_position=predicate_position,
            tense=tense,
            polarity=polarity,
            interrogative=False,
            auxiliary_index=auxiliary.index,
            negation_indexes=negation_indexes,
        )

    def _build_auxiliary_action_frame(
        self,
        *,
        words: Sequence[EnglishInputToken],
        subject_words: Sequence[EnglishInputToken],
        predicate_position: int,
        tense: Tense,
        polarity: Polarity,
        interrogative: bool,
        auxiliary_index: int,
        negation_indexes: tuple[int, ...],
    ) -> tuple[EnglishActionFrame, ...]:
        if predicate_position >= len(words):
            return ()
        subject = self._parse_nominal(subject_words)
        if subject is None:
            return ()
        predicate = words[predicate_position]
        frames: list[EnglishActionFrame] = []
        for object_frame, obliques in self._parse_action_arguments(
            words[predicate_position + 1:]
        ):
            roles = self._nominal_roles(subject, "subject")
            roles[auxiliary_index] = (
                "future-auxiliary"
                if tense is Tense.FUTURE
                else "auxiliary"
            )
            for index in negation_indexes:
                roles[index] = "negation"
            roles[predicate.index] = "predicate"
            if object_frame is not None:
                roles.update(
                    self._nominal_roles(object_frame, "object")
                )
            roles.update(self._oblique_roles(obliques))
            frames.append(
                EnglishActionFrame(
                    kind=EnglishFrameKind.ACTION,
                    subject=subject,
                    predicate=predicate.normalized,
                    predicate_indexes=(predicate.index,),
                    object=object_frame,
                    adjunct=None,
                    wh_role=None,
                    tense=tense,
                    polarity=polarity,
                    interrogative=interrogative,
                    role_by_index=tuple(sorted(roles.items())),
                    rule_trace=(
                        "english.frontend.auxiliary-action",
                        (
                            "english.frontend.yes-no-inversion"
                            if interrogative
                            else "english.frontend.declarative-order"
                        ),
                    ),
                    obliques=obliques,
                )
            )
        return tuple(frames)

    def _parse_declarative_action(
        self,
        words: Sequence[EnglishInputToken],
    ) -> tuple[EnglishActionFrame, ...]:
        """Enumerate simple subject-predicate-object analyses.

        Lexical filtering belongs to the transfer layer.  This frontend only
        records structurally possible splits, just as the inverted copular
        parser does.  Auxiliary clauses remain on the established controlled
        English path until they receive their own typed frame.
        """

        if any(
            word.normalized
            in {
                *DO_AUXILIARIES,
                *NEGATIVE_DO_AUXILIARIES,
                *FUTURE_AUXILIARIES,
                *NEGATIVE_FUTURE_AUXILIARIES,
                "not",
            }
            for word in words
        ):
            return ()

        frames: list[EnglishActionFrame] = []
        for predicate_position in range(1, len(words)):
            subject = self._parse_nominal(words[:predicate_position])
            if subject is None:
                continue
            tail = words[predicate_position + 1:]
            for object_frame, obliques in self._parse_action_arguments(
                tail
            ):
                roles = self._nominal_roles(subject, "subject")
                roles[words[predicate_position].index] = "predicate"
                if object_frame is not None:
                    roles.update(
                        self._nominal_roles(object_frame, "object")
                    )
                roles.update(self._oblique_roles(obliques))
                frames.append(
                    EnglishActionFrame(
                        kind=EnglishFrameKind.ACTION,
                        subject=subject,
                        predicate=words[predicate_position].normalized,
                        predicate_indexes=(
                            words[predicate_position].index,
                        ),
                        object=object_frame,
                        adjunct=None,
                        wh_role=None,
                        tense=None,
                        polarity=Polarity.POSITIVE,
                        interrogative=False,
                        role_by_index=tuple(sorted(roles.items())),
                        rule_trace=(
                            "english.frontend.declarative-action",
                            "english.frontend.subject-predicate-object",
                            "english.frontend.marked-obliques",
                        ),
                        obliques=obliques,
                    )
                )
        return tuple(frames)

    def _parse_fronted_wh_action(
        self,
        words: Sequence[EnglishInputToken],
    ) -> tuple[EnglishActionFrame, ...]:
        wh_word = words[0].normalized
        wh_role = ACTION_WH_ROLES.get(wh_word)
        if wh_role is None:
            return ()
        wh_nominal = EnglishNominalFrame(
            source_indexes=(words[0].index,),
            head=wh_word,
            head_indexes=(words[0].index,),
            wh_word=wh_word,
        )

        if words[1].normalized in DO_AUXILIARIES:
            return self._parse_do_supported_wh_action(
                words,
                wh_nominal=wh_nominal,
                wh_role=wh_role,
            )
        if (
            words[1].normalized in COPULA_TENSES
            and wh_role
            in {
                WhRole.LOCATION,
                WhRole.TIME,
                WhRole.REASON,
                WhRole.MANNER,
            }
        ):
            return self._parse_progressive_adverbial_wh_action(
                words,
                wh_nominal=wh_nominal,
                wh_role=wh_role,
            )
        if wh_word not in WH_FORMS:
            return ()

        object_frame = (
            self._parse_nominal(words[2:])
            if len(words) > 2
            else None
        )
        if len(words) > 2 and object_frame is None:
            return ()
        roles = self._nominal_roles(wh_nominal, "subject")
        roles[words[0].index] = "wh-subject"
        roles[words[1].index] = "predicate"
        if object_frame is not None:
            roles.update(self._nominal_roles(object_frame, "object"))
        return (
            EnglishActionFrame(
                kind=EnglishFrameKind.ACTION,
                subject=wh_nominal,
                predicate=words[1].normalized,
                predicate_indexes=(words[1].index,),
                object=object_frame,
                adjunct=None,
                wh_role=WhRole.SUBJECT,
                tense=None,
                polarity=Polarity.POSITIVE,
                interrogative=True,
                role_by_index=tuple(sorted(roles.items())),
                rule_trace=(
                    "english.frontend.action-wh",
                    "english.frontend.fronted-wh-subject",
                ),
            ),
        )

    def _parse_do_supported_wh_action(
        self,
        words: Sequence[EnglishInputToken],
        *,
        wh_nominal: EnglishNominalFrame,
        wh_role: WhRole,
    ) -> tuple[EnglishActionFrame, ...]:
        position = 2
        if position + 1 >= len(words):
            return ()
        if (
            wh_nominal.wh_word in WH_FORMS
            and words[position].normalized == "not"
        ):
            predicate_position = position + 1
            tail = words[predicate_position + 1:]
            object_frame = self._parse_nominal(tail) if tail else None
            if tail and object_frame is None:
                return ()
            roles = self._nominal_roles(wh_nominal, "subject")
            roles[words[0].index] = "wh-subject"
            roles[words[1].index] = "auxiliary"
            roles[words[position].index] = "negation"
            roles[words[predicate_position].index] = "predicate"
            if object_frame is not None:
                roles.update(self._nominal_roles(object_frame, "object"))
            return (
                EnglishActionFrame(
                    kind=EnglishFrameKind.ACTION,
                    subject=wh_nominal,
                    predicate=words[predicate_position].normalized,
                    predicate_indexes=(words[predicate_position].index,),
                    object=object_frame,
                    adjunct=None,
                    wh_role=WhRole.SUBJECT,
                    tense=DO_AUXILIARIES[words[1].normalized],
                    polarity=Polarity.NEGATIVE,
                    interrogative=True,
                    role_by_index=tuple(sorted(roles.items())),
                    rule_trace=(
                        "english.frontend.action-wh",
                        "english.frontend.do-support",
                        "english.frontend.fronted-wh-subject",
                        "english.frontend.negative",
                    ),
                ),
            )

        frames: list[EnglishActionFrame] = []
        for predicate_position in range(position + 1, len(words)):
            subject_words = words[position:predicate_position]
            polarity = Polarity.POSITIVE
            negation_index: int | None = None
            if (
                subject_words
                and subject_words[-1].normalized == "not"
            ):
                polarity = Polarity.NEGATIVE
                negation_index = subject_words[-1].index
                subject_words = subject_words[:-1]
            subject = self._parse_nominal(subject_words)
            if subject is None:
                continue
            tail = words[predicate_position + 1:]
            if wh_role is WhRole.OBJECT:
                if tail:
                    continue
                object_frame = wh_nominal
                adjunct = None
            else:
                object_frame = self._parse_nominal(tail) if tail else None
                if tail and object_frame is None:
                    continue
                adjunct = wh_nominal

            roles = self._nominal_roles(subject, "subject")
            roles[words[0].index] = f"wh-{wh_role.value}"
            roles[words[1].index] = "auxiliary"
            if negation_index is not None:
                roles[negation_index] = "negation"
            roles[words[predicate_position].index] = "predicate"
            if object_frame is not None and object_frame is not wh_nominal:
                roles.update(self._nominal_roles(object_frame, "object"))
            frames.append(
                EnglishActionFrame(
                    kind=EnglishFrameKind.ACTION,
                    subject=subject,
                    predicate=words[predicate_position].normalized,
                    predicate_indexes=(words[predicate_position].index,),
                    object=object_frame,
                    adjunct=adjunct,
                    wh_role=wh_role,
                    tense=DO_AUXILIARIES[words[1].normalized],
                    polarity=polarity,
                    interrogative=True,
                    role_by_index=tuple(sorted(roles.items())),
                    rule_trace=(
                        "english.frontend.action-wh",
                        "english.frontend.do-support",
                        f"english.frontend.fronted-wh-{wh_role.value}",
                    ),
                )
            )
        return tuple(frames)

    def _parse_progressive_adverbial_wh_action(
        self,
        words: Sequence[EnglishInputToken],
        *,
        wh_nominal: EnglishNominalFrame,
        wh_role: WhRole,
    ) -> tuple[EnglishActionFrame, ...]:
        """Parse ``where is X walking`` without treating *where* as a noun."""

        frames: list[EnglishActionFrame] = []
        for predicate_position in range(3, len(words)):
            predicate = words[predicate_position]
            if not predicate.normalized.endswith("ing"):
                continue
            subject_words = words[2:predicate_position]
            polarity = Polarity.POSITIVE
            negation_index: int | None = None
            if (
                subject_words
                and subject_words[-1].normalized == "not"
            ):
                polarity = Polarity.NEGATIVE
                negation_index = subject_words[-1].index
                subject_words = subject_words[:-1]
            subject = self._parse_nominal(subject_words)
            if subject is None:
                continue
            tail = words[predicate_position + 1:]
            object_frame = self._parse_nominal(tail) if tail else None
            if tail and object_frame is None:
                continue

            roles = self._nominal_roles(subject, "subject")
            roles[words[0].index] = f"wh-{wh_role.value}"
            roles[words[1].index] = "progressive-auxiliary"
            roles[predicate.index] = "predicate"
            if negation_index is not None:
                roles[negation_index] = "negation"
            if object_frame is not None:
                roles.update(self._nominal_roles(object_frame, "object"))
            frames.append(
                EnglishActionFrame(
                    kind=EnglishFrameKind.ACTION,
                    subject=subject,
                    predicate=predicate.normalized,
                    predicate_indexes=(predicate.index,),
                    object=object_frame,
                    adjunct=wh_nominal,
                    wh_role=wh_role,
                    tense=COPULA_TENSES[words[1].normalized],
                    polarity=polarity,
                    interrogative=True,
                    role_by_index=tuple(sorted(roles.items())),
                    rule_trace=(
                        "english.frontend.action-wh",
                        "english.frontend.progressive-auxiliary",
                        f"english.frontend.fronted-wh-{wh_role.value}",
                    ),
                )
            )
        return tuple(frames)

    def _parse_fronted_wh_identity(
        self,
        words: Sequence[EnglishInputToken],
    ) -> tuple[EnglishClauseFrame, ...]:
        first = words[0].normalized
        if first in WH_COPULA_CONTRACTIONS:
            wh_form, tense = WH_COPULA_CONTRACTIONS[first]
            subject_words = words[1:]
            copula_indexes = (words[0].index,)
            wh_indexes = (words[0].index,)
        elif (
            first in WH_FORMS
            and len(words) >= 3
            and words[1].normalized in COPULA_TENSES
        ):
            wh_form = first
            tense = COPULA_TENSES[words[1].normalized]
            subject_words = words[2:]
            copula_indexes = (words[1].index,)
            wh_indexes = (words[0].index,)
        else:
            return ()
        post_copular = self._parse_nominal(subject_words)
        if post_copular is None:
            return ()
        wh_nominal = EnglishNominalFrame(
            source_indexes=wh_indexes,
            head=wh_form,
            head_indexes=wh_indexes,
            wh_word=wh_form,
        )

        complement_wh = self._fronted_wh_frame(
            subject=post_copular,
            complement=wh_nominal,
            wh_indexes=wh_indexes,
            copula_indexes=copula_indexes,
            tense=tense,
            wh_role="complement",
        )
        if not self._allows_subject_wh(post_copular):
            return (complement_wh,)

        subject_wh = self._fronted_wh_frame(
            subject=wh_nominal,
            complement=post_copular,
            wh_indexes=wh_indexes,
            copula_indexes=copula_indexes,
            tense=tense,
            wh_role="subject",
        )
        if wh_form == "who":
            return (subject_wh, complement_wh)
        return (complement_wh, subject_wh)

    def _fronted_wh_frame(
        self,
        *,
        subject: EnglishNominalFrame,
        complement: EnglishNominalFrame,
        wh_indexes: tuple[int, ...],
        copula_indexes: tuple[int, ...],
        tense: Tense,
        wh_role: str,
    ) -> EnglishClauseFrame:
        roles = self._nominal_roles(subject, "subject")
        roles.update(self._nominal_roles(complement, "complement"))
        for index in wh_indexes:
            roles[index] = f"wh-{wh_role}"
        for index in copula_indexes:
            roles[index] = (
                f"wh-{wh_role}+copula"
                if index in wh_indexes
                else "copula"
            )
        return EnglishClauseFrame(
            kind=EnglishFrameKind.IDENTITY,
            subject=subject,
            complement=complement,
            tense=tense,
            polarity=Polarity.POSITIVE,
            interrogative=True,
            role_by_index=tuple(sorted(roles.items())),
            rule_trace=(
                "english.frontend.copular-identity",
                f"english.frontend.fronted-wh-{wh_role}",
            ),
        )

    @staticmethod
    def _allows_subject_wh(
        post_copular: EnglishNominalFrame,
    ) -> bool:
        """Keep subject-wh only for non-specific predicative material."""

        return (
            post_copular.possessor is None
            and post_copular.determiner != "the"
            and not post_copular.proper_name
        )

    def _parse_declarative_identity(
        self,
        words: Sequence[EnglishInputToken],
    ) -> tuple[EnglishClauseFrame, ...]:
        copula_positions = [
            index
            for index, token in enumerate(words)
            if token.normalized in COPULA_TENSES
        ]
        if len(copula_positions) != 1:
            return ()
        position = copula_positions[0]
        if position == 0 or position == len(words) - 1:
            return ()
        complement_start = position + 1
        polarity = Polarity.POSITIVE
        if (
            complement_start < len(words)
            and words[complement_start].normalized == "not"
        ):
            polarity = Polarity.NEGATIVE
            complement_start += 1
        if complement_start >= len(words):
            return ()
        subject = self._parse_nominal(words[:position])
        complement = self._parse_nominal(words[complement_start:])
        if subject is None or complement is None:
            return ()
        roles = self._nominal_roles(subject, "subject")
        roles.update(self._nominal_roles(complement, "complement"))
        roles[words[position].index] = "copula"
        if polarity is Polarity.NEGATIVE:
            roles[words[position + 1].index] = "negation"
        return (
            EnglishClauseFrame(
                kind=EnglishFrameKind.IDENTITY,
                subject=subject,
                complement=complement,
                tense=COPULA_TENSES[words[position].normalized],
                polarity=polarity,
                interrogative=False,
                role_by_index=tuple(sorted(roles.items())),
                rule_trace=(
                    "english.frontend.copular-identity",
                    "english.frontend.declarative-order",
                ),
            ),
        )

    def _parse_inverted_identity(
        self,
        words: Sequence[EnglishInputToken],
    ) -> tuple[EnglishClauseFrame, ...]:
        if words[0].normalized not in COPULA_TENSES or len(words) < 3:
            return ()
        polarity = Polarity.POSITIVE
        start = 1
        if words[start].normalized == "not":
            polarity = Polarity.NEGATIVE
            start += 1
        frames: list[EnglishClauseFrame] = []
        # Keep every structurally possible split. Lexical resolution later
        # removes impossible NPs instead of letting this frontend guess.
        for split in range(start + 1, len(words)):
            subject = self._parse_nominal(words[start:split])
            complement = self._parse_nominal(words[split:])
            if subject is None or complement is None:
                continue
            roles = self._nominal_roles(subject, "subject")
            roles.update(self._nominal_roles(complement, "complement"))
            roles[words[0].index] = "copula"
            if polarity is Polarity.NEGATIVE:
                roles[words[1].index] = "negation"
            frames.append(
                EnglishClauseFrame(
                    kind=EnglishFrameKind.IDENTITY,
                    subject=subject,
                    complement=complement,
                    tense=COPULA_TENSES[words[0].normalized],
                    polarity=polarity,
                    interrogative=True,
                    role_by_index=tuple(sorted(roles.items())),
                    rule_trace=(
                        "english.frontend.copular-identity",
                        "english.frontend.yes-no-inversion",
                    ),
                )
            )
        return tuple(frames)

    def _parse_action_arguments(
        self,
        words: Sequence[EnglishInputToken],
    ) -> tuple[
        tuple[
            EnglishNominalFrame | None,
            tuple[EnglishObliqueFrame, ...],
        ],
        ...,
    ]:
        """Split a bounded action tail into theme and marked participants."""

        if not words:
            return ((None, ()),)
        markers: list[
            tuple[
                int,
                int,
                EnglishObliqueKind,
                tuple[EnglishInputToken, ...],
            ]
        ] = []
        position = 0
        marker_lengths = sorted(
            {len(marker) for marker in ACTION_OBLIQUE_MARKERS},
            reverse=True,
        )
        while position < len(words):
            matched = None
            for length in marker_lengths:
                marker_words = tuple(words[position:position + length])
                marker = tuple(
                    word.normalized for word in marker_words
                )
                kind = ACTION_OBLIQUE_MARKERS.get(marker)
                if kind is not None:
                    matched = (
                        position,
                        position + length,
                        kind,
                        marker_words,
                    )
                    break
            if matched is not None:
                markers.append(matched)
                position = matched[1]
            else:
                position += 1

        if not markers:
            nominal = self._parse_nominal(words)
            return ((nominal, ()),) if nominal is not None else ()

        object_words = words[:markers[0][0]]
        object_frame = (
            self._parse_nominal(object_words)
            if object_words
            else None
        )
        if object_words and object_frame is None:
            return ()
        obliques: list[EnglishObliqueFrame] = []
        for index, (start, end, kind, marker_words) in enumerate(markers):
            nominal_end = (
                markers[index + 1][0]
                if index + 1 < len(markers)
                else len(words)
            )
            nominal_words = words[end:nominal_end]
            nominal = self._parse_nominal(nominal_words)
            if nominal is None:
                return ()
            obliques.append(
                EnglishObliqueFrame(
                    source_indexes=tuple(
                        word.index
                        for word in words[start:nominal_end]
                    ),
                    marker_indexes=tuple(
                        word.index for word in marker_words
                    ),
                    source_marker=" ".join(
                        word.normalized for word in marker_words
                    ),
                    kind=kind,
                    nominal=nominal,
                )
            )
        return ((object_frame, tuple(obliques)),)

    @classmethod
    def _oblique_roles(
        cls,
        obliques: Sequence[EnglishObliqueFrame],
    ) -> dict[int, str]:
        roles: dict[int, str] = {}
        for oblique in obliques:
            for index in oblique.marker_indexes:
                roles[index] = f"oblique-{oblique.kind.value}-marker"
            roles.update(
                cls._nominal_roles(
                    oblique.nominal,
                    f"oblique-{oblique.kind.value}",
                )
            )
        return roles

    @staticmethod
    def _parse_nominal(
        words: Sequence[EnglishInputToken],
    ) -> EnglishNominalFrame | None:
        if not words:
            return None
        normalized_phrase = " ".join(word.normalized for word in words)
        locative = DEICTIC_LOCATIVES.get(normalized_phrase)
        if locative is not None:
            return EnglishNominalFrame(
                source_indexes=tuple(word.index for word in words),
                head=normalized_phrase,
                head_indexes=tuple(word.index for word in words),
                locative=locative,
            )
        if len(words) == 1 and words[0].normalized in WH_FORMS:
            return EnglishNominalFrame(
                source_indexes=(words[0].index,),
                head=words[0].normalized,
                head_indexes=(words[0].index,),
                wh_word=words[0].normalized,
            )

        determiner: str | None = None
        possessor: EnglishPossessor | None = None
        quantifier: EnglishNominalQuantifier | None = None
        extent: EnglishNominalExtent | None = None
        head_words = words
        first = head_words[0]
        if first.normalized in UNIVERSAL_QUANTIFIERS:
            quantifier_indexes = [first.index]
            quantifier = EnglishNominalQuantifier(
                source_indexes=(first.index,),
                kind=EnglishNominalQuantifierKind.UNIVERSAL,
                source_form=first.normalized,
            )
            head_words = head_words[1:]
            if not head_words:
                return None
            if head_words[0].normalized == "of":
                quantifier_indexes.append(head_words[0].index)
                head_words = head_words[1:]
                if not head_words:
                    return None
                quantifier = replace(
                    quantifier,
                    source_indexes=tuple(quantifier_indexes),
                )
            first = head_words[0]
        if first.normalized in POSSESSIVE_DETERMINERS:
            if len(head_words) < 2:
                return None
            possessor = EnglishPossessor(
                source_indexes=(first.index,),
                term=POSSESSIVE_DETERMINERS[first.normalized],
            )
            head_words = head_words[1:]
        elif first.normalized.endswith(("'s", "’s")):
            if len(head_words) < 2:
                return None
            base = first.surface[:-2].strip()
            if not base:
                return None
            possessor = EnglishPossessor(
                source_indexes=(first.index,),
                term=base,
                proper_name=base[:1].isupper(),
            )
            head_words = head_words[1:]
        elif first.normalized in ARTICLES:
            if len(head_words) < 2:
                return None
            determiner = first.normalized
            head_words = head_words[1:]

        if not head_words:
            return None
        first = head_words[0]
        if first.normalized in COMPLETE_EXTENT_WORDS:
            extent = EnglishNominalExtent(
                source_indexes=(first.index,),
                kind=NominalExtentKind.COMPLETE,
                source_form=first.normalized,
                emphasized=True,
            )
            head_words = head_words[1:]
        elif first.normalized in ENGLISH_FRACTION_VALUE_BY_FORM:
            extent_indexes = [first.index]
            denominator_value = ENGLISH_FRACTION_VALUE_BY_FORM[
                first.normalized
            ]
            head_words = head_words[1:]
            if head_words and head_words[0].normalized == "of":
                extent_indexes.append(head_words[0].index)
                head_words = head_words[1:]
            if head_words and head_words[0].normalized in ARTICLES:
                determiner = head_words[0].normalized
                head_words = head_words[1:]
            extent = EnglishNominalExtent(
                source_indexes=tuple(extent_indexes),
                kind=NominalExtentKind.FRACTIONAL,
                source_form=first.normalized,
                denominator_value=denominator_value,
            )

        if not head_words:
            return None

        head = " ".join(word.normalized for word in head_words)
        if not head:
            return None
        return EnglishNominalFrame(
            source_indexes=tuple(word.index for word in words),
            head=head,
            head_indexes=tuple(word.index for word in head_words),
            determiner=determiner,
            possessor=possessor,
            quantifier=quantifier,
            extent=extent,
            proper_name=(
                len(head_words) == 1
                and head_words[0].surface[:1].isupper()
                and head_words[0].normalized
                not in PERSONAL_PRONOUN_FORMS
            ),
        )

    @staticmethod
    def _nominal_roles(
        nominal: EnglishNominalFrame,
        role: str,
    ) -> dict[int, str]:
        roles = {
            index: f"{role}-head"
            for index in nominal.head_indexes
        }
        if nominal.possessor is not None:
            for index in nominal.possessor.source_indexes:
                roles[index] = f"{role}-possessor"
        if nominal.determiner is not None:
            determiner_indexes = (
                set(nominal.source_indexes)
                - set(nominal.head_indexes)
                - (
                    set(nominal.possessor.source_indexes)
                    if nominal.possessor is not None
                    else set()
                )
                - (
                    set(nominal.quantifier.source_indexes)
                    if nominal.quantifier is not None
                    else set()
                )
                - (
                    set(nominal.extent.source_indexes)
                    if nominal.extent is not None
                    else set()
                )
            )
            for index in determiner_indexes:
                roles[index] = f"{role}-determiner"
        if nominal.quantifier is not None:
            for index in nominal.quantifier.source_indexes:
                roles[index] = f"{role}-quantifier"
        if nominal.extent is not None:
            for index in nominal.extent.source_indexes:
                roles[index] = f"{role}-extent"
        return roles
