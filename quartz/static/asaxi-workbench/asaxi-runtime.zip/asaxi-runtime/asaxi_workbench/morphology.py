"""Deterministic morphology foundations for Asaxi.

These rules implement only operations that are explicit in the authoritative
notes. They return traces so later parser and UI layers can show exactly which
rule fired.
"""

from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Any

from .models import LanguageDatabase, Lexeme


PURE_VOWELS = frozenset("aeioù")
DIPHTHONG_OR_IMPURE_VOWELS = frozenset("ýáèůåăěëỏő")
SYLLABIC_NASALS = ("mm", "nn")
VERB_PREFIX_SLOTS = ("tense", "negation", "aspect", "voice", "bridge")


@dataclass(frozen=True)
class GeneratedForm:
    surface: str
    lemma: str
    features: tuple[tuple[str, str], ...]
    morphemes: tuple[str, ...]
    rule_trace: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "surface": self.surface,
            "lemma": self.lemma,
            "features": dict(self.features),
            "morphemes": list(self.morphemes),
            "rule_trace": list(self.rule_trace),
        }


@dataclass(frozen=True)
class MorphologicalAnalysis:
    surface: str
    lemma: str
    category: str
    features: tuple[tuple[str, str], ...]
    morphemes: tuple[str, ...]
    rule_trace: tuple[str, ...]
    confidence: str
    lexeme_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "surface": self.surface,
            "lemma": self.lemma,
            "category": self.category,
            "features": dict(self.features),
            "morphemes": list(self.morphemes),
            "rule_trace": list(self.rule_trace),
            "confidence": self.confidence,
            "lexeme_id": self.lexeme_id,
        }


def _has_reduplicated_diphthong_tail(word: str) -> bool:
    """Return true for tails such as ``båbå``.

    The source rule replaces the final diphthong of a repeated final syllable.
    Searching short repeated tails is deterministic and avoids claiming a
    complete syllabifier at this foundation stage.
    """

    for size in range(2, min(5, len(word) // 2 + 1)):
        unit = word[-size:]
        if (
            word.endswith(unit + unit)
            and unit[-1] in DIPHTHONG_OR_IMPURE_VOWELS
        ):
            return True
    return False


def pluralize_nominal(lemma: str) -> GeneratedForm:
    """Generate the documented regular nominal plural."""

    word = lemma.strip().casefold()
    if not word or " " in word:
        raise ValueError("Nominal plural generation requires one lemma")
    if word.endswith("o"):
        surface = word[:-1] + "a"
        rule = "plural.replace-final-o"
        morphemes = (word[:-1], "-a")
    elif word.endswith(("a", "á")):
        surface = word + "ma"
        rule = "plural.a-ending-ma"
        morphemes = (word, "-ma")
    elif word.endswith(SYLLABIC_NASALS):
        surface = word[:-1] + "a"
        rule = "plural.resolve-syllabic-nasal"
        morphemes = (word[:-1], "-a")
    elif _has_reduplicated_diphthong_tail(word):
        surface = word[:-1] + "a"
        rule = "plural.reduce-reduplicated-diphthong"
        morphemes = (word[:-1], "-a")
    elif word[-1] in PURE_VOWELS:
        surface = word + "wa"
        rule = "plural.pure-vowel-w-bridge"
        morphemes = (word, "-w-", "-a")
    else:
        surface = word + "a"
        rule = "plural.append-a"
        morphemes = (word, "-a")
    return GeneratedForm(
        surface=surface,
        lemma=word,
        features=(("number", "plural"),),
        morphemes=morphemes,
        rule_trace=(rule,),
    )


def attach_ga(form: str) -> GeneratedForm:
    """Attach the lexical ``ga`` modifier using its documented coalescence."""

    root = form.strip().casefold()
    if not root or " " in root:
        raise ValueError("ga attachment requires one form")
    if root.startswith("a"):
        surface = "g" + root
        rule = "ga.coalesce-before-a"
    elif root.startswith("i"):
        surface = "gă" + root[1:]
        rule = "ga.coalesce-before-i"
    else:
        surface = "ga" + root
        rule = "ga.default-fusion"
    return GeneratedForm(
        surface=surface,
        lemma=root,
        features=(("derivation", "ga-compound"),),
        morphemes=("ga-", root),
        rule_trace=(rule,),
    )


def verbalize_nominal(
    lemma: str,
    *,
    bridge: str = "n",
    reduce_syllabic_nasal: bool = True,
) -> GeneratedForm:
    """Generate noun + bridge + ``ů`` with documented root reductions."""

    root = lemma.strip().casefold()
    bridge_form = bridge.strip("-").casefold()
    if not root or not bridge_form or " " in root:
        raise ValueError("Verbalization requires one noun and one bridge")
    reduced = root
    trace: list[str] = []
    if reduce_syllabic_nasal and root.endswith(("mm", "nn")):
        reduced = root[:-1]
        trace.append("verbalize.reduce-syllabic-nasal")
    elif reduce_syllabic_nasal and root.endswith("nŋ"):
        reduced = root[:-2] + "ŋ"
        trace.append("verbalize.reduce-syllabic-nasal")
    elif (
        len(root) == 4
        and root[0] == root[2]
        and root[1] == root[3]
        and root[0] not in PURE_VOWELS | DIPHTHONG_OR_IMPURE_VOWELS
        and root[1] in PURE_VOWELS | DIPHTHONG_OR_IMPURE_VOWELS
    ):
        reduced = root[:2]
        trace.append("verbalize.reduce-reduplicated-syllable")
    surface = reduced + bridge_form + "ů"
    trace.append("verbalize.bridge-plus-u")
    return GeneratedForm(
        surface=surface,
        lemma=root,
        features=(
            ("derivation", "active-verb"),
            ("bridge", bridge_form),
        ),
        morphemes=(reduced, f"-{bridge_form}-", "-ů"),
        rule_trace=tuple(trace),
    )


def compose_verb_stack(
    root: str,
    *,
    tense: str = "",
    negation: str = "",
    aspect: str = "",
    voice: str = "",
    bridge: str = "",
) -> GeneratedForm:
    """Compose the documented prefix block in its canonical slot order."""

    values = {
        "tense": tense,
        "negation": negation,
        "aspect": aspect,
        "voice": voice,
        "bridge": bridge,
    }
    pieces = [
        values[slot].strip("-")
        for slot in VERB_PREFIX_SLOTS
        if values[slot].strip("-")
    ]
    root_form = root.strip()
    if not root_form:
        raise ValueError("Verb root is empty")
    surface = "".join(pieces) + root_form
    features = tuple(
        (slot, values[slot].strip("-"))
        for slot in VERB_PREFIX_SLOTS
        if values[slot].strip("-")
    )
    return GeneratedForm(
        surface=surface,
        lemma=root_form,
        features=features,
        morphemes=tuple(f"{piece}-" for piece in pieces) + (root_form,),
        rule_trace=("verb-prefix-order.tense-negation-aspect-voice-bridge",),
    )


class MorphologyEngine:
    def __init__(self, database: LanguageDatabase):
        self.database = database
        self._by_surface: dict[str, list[Lexeme]] = {}
        self._variant_by_surface: dict[str, list[tuple[Lexeme, object]]] = {}
        for lexeme in database.lexemes:
            self._by_surface.setdefault(
                lexeme.surface_form.casefold(),
                [],
            ).append(lexeme)
            for variant in lexeme.variants:
                if "before-following-material" in variant.contexts:
                    continue
                self._variant_by_surface.setdefault(
                    variant.surface.casefold(),
                    [],
                ).append((lexeme, variant))
        self._noun_plural_index: dict[str, list[Lexeme]] = {}
        self._ga_index: dict[str, list[Lexeme]] = {}
        self._verbalization_index: dict[str, list[tuple[Lexeme, str]]] = {}
        for lexeme in database.lexemes:
            if lexeme.category == "noun" and " " not in lexeme.lemma:
                try:
                    plural = pluralize_nominal(lexeme.lemma).surface
                    self._noun_plural_index.setdefault(plural, []).append(lexeme)
                    ga_form = attach_ga(lexeme.lemma).surface
                    self._ga_index.setdefault(ga_form, []).append(lexeme)
                    for bridge in ("n", "x", "w", "k", "ŕ", "sh", "ch"):
                        verbal = verbalize_nominal(
                            lexeme.lemma,
                            bridge=bridge,
                        ).surface
                        self._verbalization_index.setdefault(
                            verbal,
                            [],
                        ).append((lexeme, bridge))
                except ValueError:
                    continue

    def analyze(self, surface: str) -> tuple[MorphologicalAnalysis, ...]:
        word = surface.strip().casefold()
        analyses: list[MorphologicalAnalysis] = []
        for lexeme in self._by_surface.get(word, ()):
            analyses.append(
                MorphologicalAnalysis(
                    surface=word,
                    lemma=lexeme.lemma,
                    category=lexeme.category,
                    features=(("lexical", "true"),),
                    morphemes=(lexeme.surface_form,),
                    rule_trace=("lexicon.exact",),
                    confidence="exact",
                    lexeme_id=lexeme.identifier,
                )
            )
        for lexeme, variant in self._variant_by_surface.get(word, ()):
            analyses.append(
                MorphologicalAnalysis(
                    surface=word,
                    lemma=lexeme.lemma,
                    category=lexeme.category,
                    features=(
                        ("lexical", "true"),
                        ("surface_variant", variant.surface),
                        ("variant_contexts", ",".join(variant.contexts)),
                    ),
                    morphemes=(variant.surface,),
                    rule_trace=("lexicon.source-variant",),
                    confidence="source-attested-variant",
                    lexeme_id=lexeme.identifier,
                )
            )
        for lexeme in self._noun_plural_index.get(word, ()):
            generated = pluralize_nominal(lexeme.lemma)
            analyses.append(
                MorphologicalAnalysis(
                    surface=word,
                    lemma=lexeme.lemma,
                    category="noun",
                    features=generated.features,
                    morphemes=generated.morphemes,
                    rule_trace=generated.rule_trace,
                    confidence="rule-confirmed",
                    lexeme_id=lexeme.identifier,
                )
            )
        for lexeme in self._ga_index.get(word, ()):
            generated = attach_ga(lexeme.lemma)
            analyses.append(
                MorphologicalAnalysis(
                    surface=word,
                    lemma=lexeme.lemma,
                    category="noun",
                    features=generated.features,
                    morphemes=generated.morphemes,
                    rule_trace=generated.rule_trace,
                    confidence="rule-confirmed",
                    lexeme_id=lexeme.identifier,
                )
            )
        for lexeme, bridge in self._verbalization_index.get(word, ()):
            generated = verbalize_nominal(lexeme.lemma, bridge=bridge)
            analyses.append(
                MorphologicalAnalysis(
                    surface=word,
                    lemma=lexeme.lemma,
                    category="verb",
                    features=generated.features,
                    morphemes=generated.morphemes,
                    rule_trace=generated.rule_trace,
                    confidence="rule-confirmed",
                    lexeme_id=lexeme.identifier,
                )
            )

        # One-level registry analysis establishes the transducer interface
        # without pretending that all productive stacked morphology is solved.
        for morpheme in self.database.morphemes:
            form = morpheme.form.casefold()
            if not form:
                continue
            remainder = ""
            if morpheme.attachment == "prefix" and word.startswith(form):
                remainder = word[len(form):]
            elif morpheme.attachment == "suffix" and word.endswith(form):
                remainder = word[:-len(form)]
            if not remainder:
                continue
            for lexeme in self._by_surface.get(remainder, ()):
                if (
                    morpheme.host_lexical_types
                    and lexeme.category not in morpheme.host_lexical_types
                ):
                    continue
                analyses.append(
                    MorphologicalAnalysis(
                        surface=word,
                        lemma=lexeme.lemma,
                        category=lexeme.category,
                        features=(("morphological_role", morpheme.role),),
                        morphemes=(
                            morpheme.notation,
                            lexeme.surface_form,
                        )
                        if morpheme.attachment == "prefix"
                        else (
                            lexeme.surface_form,
                            morpheme.notation,
                        ),
                        rule_trace=("registry.single-affix",),
                        confidence="registry-supported",
                        lexeme_id=lexeme.identifier,
                    )
                )

        unique: dict[tuple[Any, ...], MorphologicalAnalysis] = {}
        for analysis in analyses:
            key = (
                analysis.lemma,
                analysis.category,
                analysis.features,
                analysis.morphemes,
                analysis.lexeme_id,
            )
            unique[key] = analysis
        return tuple(
            sorted(
                unique.values(),
                key=lambda item: (
                    item.confidence,
                    item.lemma,
                    item.category,
                    item.morphemes,
                ),
            )
        )


ASAXI_WORD_RE = re.compile(
    r"[^\W\d_]+(?:(?:[.'’-])[^\W\d_]+)*(?:['’])?",
    re.IGNORECASE,
)


def tokenize_asaxi_text(text: str) -> tuple[str, ...]:
    return tuple(
        match.group(0).casefold()
        for match in ASAXI_WORD_RE.finditer(text)
    )
