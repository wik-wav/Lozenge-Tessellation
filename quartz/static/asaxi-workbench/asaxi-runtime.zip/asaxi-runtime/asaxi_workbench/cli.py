"""Command-line interface for the local Asaxi Language Workbench."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Sequence

from .compiler import (
    CompileConfig,
    compile_language,
    write_database,
)
from .models import Diagnostic, LanguageDatabase, Severity
from .formal_grammar import (
    DEFAULT_RULE_INVENTORY,
    compile_formal_grammar,
    write_formal_grammar,
)
from .grammar_conformance import run_grammar_conformance
from .grammar_coverage import build_grammar_coverage
from .grammar_example_audit import audit_grammar_examples
from .grammar_revision import render_grammar_model_manifest
from .morphology import (
    MorphologyEngine,
    pluralize_nominal,
    verbalize_nominal,
)
from .phrase_memory import DEFAULT_PHRASE_MEMORY_PATH
from .quartz_export import export_quartz_bundle
from .translation_models import (
    TRANSLATION_ENGINE_VERSION,
    TranslationDirection,
    TranslationStatus,
)
from .syntax import DiscourseReferent, DiscourseState, Nominal
from .translator import Translator
from .version import WORKBENCH_VERSION
from .webapp import run_server


PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_OUTPUT = PROJECT_ROOT / "build" / "asaxi-language-db.json"
DEFAULT_FORMAL_GRAMMAR_OUTPUT = (
    PROJECT_ROOT / "build" / "asaxi-formal-grammar.json"
)
DEFAULT_GRAMMAR_MODEL_CANDIDATE = (
    PROJECT_ROOT / "build" / "grammar_model.candidate.json"
)
DEFAULT_QUARTZ_EXPORT = (
    PROJECT_ROOT / "dist" / "quartz" / "asaxi-workbench"
)


def _common_source_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--vault",
        type=Path,
        help="Authoritative Obsidian vault root",
    )
    parser.add_argument(
        "--registry",
        type=Path,
        help="Transitional grammar-morpheme TOML registry",
    )


def _config(args: argparse.Namespace) -> CompileConfig:
    return CompileConfig.discover(
        vault_root=args.vault,
        grammar_registry=args.registry,
    )


def _compile(args: argparse.Namespace) -> int:
    database = compile_language(_config(args))
    output = args.output.resolve()
    write_database(database, output)
    stats = database.statistics
    print(
        f"Compiled {stats['lexemes']} lexemes, "
        f"{stats['grammar_documents']} grammar documents, and "
        f"{stats['morphemes']} formal morphemes."
    )
    print(
        f"Diagnostics: {stats['diagnostic_errors']} errors, "
        f"{stats['diagnostic_warnings']} warnings, "
        f"{stats['diagnostic_info']} info."
    )
    print(f"Output: {output}")
    if args.fail_on_errors and stats["diagnostic_errors"]:
        return 1
    return 0


def _compile_grammar(args: argparse.Namespace) -> int:
    config = _config(args)
    database = compile_language(config)
    grammar = compile_formal_grammar(
        database,
        inventory_path=args.rules,
        vault_root=config.vault_root,
    )
    output = args.output.resolve()
    write_formal_grammar(grammar, output)
    errors = sum(
        diagnostic.severity is Severity.ERROR
        for diagnostic in grammar.diagnostics
    )
    warnings = sum(
        diagnostic.severity is Severity.WARNING
        for diagnostic in grammar.diagnostics
    )
    print(
        f"Compiled {len(grammar.rules)} productive rules and "
        f"{len(grammar.morphemes)} formal morphemes."
    )
    print(f"Diagnostics: {errors} errors, {warnings} warnings.")
    print(f"Output: {output}")
    if args.fail_on_errors and errors:
        return 1
    return 0


def _format_diagnostic(diagnostic: Diagnostic) -> str:
    location = diagnostic.source_path or "<database>"
    if diagnostic.line:
        location += f":{diagnostic.line}"
    field = f" [{diagnostic.field}]" if diagnostic.field else ""
    return (
        f"{diagnostic.severity.value.upper():7} "
        f"{diagnostic.code} {location}{field}: {diagnostic.message}"
    )


def _lint(args: argparse.Namespace) -> int:
    database = compile_language(_config(args))
    diagnostics = database.diagnostics
    if args.json:
        print(
            json.dumps(
                [item.to_dict() for item in diagnostics],
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
            )
        )
    else:
        visible = diagnostics if args.all else diagnostics[: args.limit]
        for diagnostic in visible:
            print(_format_diagnostic(diagnostic))
        if len(visible) < len(diagnostics):
            print(
                f"... {len(diagnostics) - len(visible)} more diagnostics; "
                "use --all or --json to show every record"
            )
        stats = database.statistics
        print(
            f"Summary: {stats['diagnostic_errors']} errors, "
            f"{stats['diagnostic_warnings']} warnings, "
            f"{stats['diagnostic_info']} info"
        )
    if database.statistics["diagnostic_errors"]:
        return 1
    if args.strict and database.statistics["diagnostic_warnings"]:
        return 1
    return 0


def _inspect(args: argparse.Namespace) -> int:
    database = compile_language(_config(args))
    matches = database.lexemes_for(args.lemma)
    if not matches:
        print(f"No compiled lexeme found for {args.lemma!r}", file=sys.stderr)
        return 1
    print(
        json.dumps(
            [match.to_dict() for match in matches],
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
    )
    return 0


def _morph(args: argparse.Namespace) -> int:
    if args.operation == "plural":
        payload = pluralize_nominal(args.word).to_dict()
    elif args.operation == "verbalize":
        payload = verbalize_nominal(
            args.word,
            bridge=args.bridge,
        ).to_dict()
    else:
        database = compile_language(_config(args))
        payload = [
            analysis.to_dict()
            for analysis in MorphologyEngine(database).analyze(args.word)
        ]
    print(
        json.dumps(
            payload,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
    )
    return 0 if payload else 1


def _translate(args: argparse.Namespace) -> int:
    if bool(args.topic_asaxi) != bool(args.topic_english):
        print(
            "ERROR: --topic-asaxi and --topic-english must be supplied "
            "together.",
            file=sys.stderr,
        )
        return 2
    discourse_state = (
        DiscourseState(
            topic=DiscourseReferent(
                nominal=Nominal(args.topic_asaxi),
                english_text=args.topic_english,
            )
        )
        if args.topic_asaxi
        else None
    )
    database = compile_language(_config(args))
    result = Translator(database).translate(
        " ".join(args.text),
        args.direction,
        discourse_state=discourse_state,
    )
    if args.json:
        print(
            json.dumps(
                result.to_dict(),
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
            )
        )
    else:
        selected = result.selected
        if selected is not None:
            print(selected.output_text)
        elif result.fallback_output_text:
            print(result.fallback_output_text)
        print(f"Status: {result.status.value}")
        if len(result.alternatives) > 1:
            print("Alternatives:")
            for alternative in result.alternatives[1:]:
                print(f"  {alternative.output_text}")
        for diagnostic in result.diagnostics:
            print(
                f"{diagnostic.severity.value.upper()}: "
                f"{diagnostic.code}: {diagnostic.message}",
                file=sys.stderr,
            )
    return (
        1
        if result.status is TranslationStatus.UNSUPPORTED
        else 0
    )


def _check_grammar(args: argparse.Namespace) -> int:
    config = _config(args)
    database = compile_language(config)
    conformance = run_grammar_conformance(
        database,
        config.vault_root,
        manifest_path=args.cases,
    )
    discovered = audit_grammar_examples(
        database,
        config.vault_root,
    )
    coverage = build_grammar_coverage(
        database,
        config.vault_root,
        conformance=conformance,
        examples=discovered,
        claim_manifest_path=config.grammar_claim_manifest,
    )
    if args.json:
        print(
            json.dumps(
                {
                    "conformance": conformance.to_dict(),
                    "discovered_examples": discovered.to_dict(),
                    "document_coverage": coverage.to_dict(),
                },
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
            )
        )
    else:
        print(
            f"Curated conformance: {conformance.passed}/"
            f"{len(conformance.results)} passed"
        )
        for result in conformance.results:
            if result.passed and not args.all:
                continue
            label = "PASS" if result.passed else "FAIL"
            location = f"{result.source_path}"
            print(f"{label:4} {result.identifier} [{location}]")
            for failure in result.failures:
                print(f"     {failure}")
        counts = discovered.counts
        print(
            "Discovered grammar examples: "
            f"{counts['total']} total; {counts['pass']} pass, "
            f"{counts['misranked']} misranked, "
            f"{counts['mismatch']} mismatch, "
            f"{counts['unsupported']} unsupported, "
            f"{counts['source-ambiguous']} source-ambiguous"
        )
        coverage_counts = coverage.counts
        print(
            "Grammar documents: "
            f"{coverage_counts['total']} total; "
            f"{coverage_counts['accounted']} accounted, "
            f"{coverage_counts['unaccounted']} unaccounted; "
            f"{coverage_counts['behaviorally_verified']} behaviorally "
            "verified, "
            f"{coverage_counts['behaviorally_unverified']} behaviorally "
            "unverified"
        )
        if args.all:
            for result in discovered.results:
                print(
                    f"{result.classification.upper():16} "
                    f"{result.source_path}:{result.line} "
                    f"{result.asaxi}"
                )
                if result.classification in {"mismatch", "misranked"}:
                    print(
                        f"                 expected: "
                        f"{result.expected_english}"
                    )
                    print(
                        f"                 selected: "
                        f"{result.selected_output}"
                    )
            for document in coverage.documents:
                print(
                    f"{document.state.upper():24} "
                    f"{document.source_path}"
                )
    discovered_failure = (
        args.strict_discovered
        and any(
            result.classification != "pass"
            for result in discovered.results
        )
    )
    coverage_failure = (
        args.strict_coverage
        and (
            coverage.counts["unaccounted"] > 0
            or coverage.counts["behaviorally_unverified"] > 0
        )
    )
    return (
        0
        if (
            conformance.is_success
            and not discovered_failure
            and not coverage_failure
        )
        else 1
    )


def _serve(args: argparse.Namespace) -> int:
    run_server(
        _config(args),
        host=args.host,
        port=args.port,
        open_browser=args.open,
        phrase_memory_path=args.phrase_memory,
        developer_phrase_authoring=args.developer_phrases,
    )
    return 0


def _export_quartz(args: argparse.Namespace) -> int:
    manifest = export_quartz_bundle(
        _config(args),
        args.output,
        phrase_memory_path=args.phrase_memory,
        api_base=args.api_base,
        pyodide_root=args.pyodide_root,
    )
    print(
        f"Exported Quartz bundle to {args.output.resolve()}\n"
        f"Reviewed authored phrases: {manifest['authored_phrase_count']}\n"
        f"Translation runtime: {manifest['translation_runtime']}"
    )
    return 0


def _grammar_status(args: argparse.Namespace) -> int:
    config = _config(args)
    database = compile_language(config, include_lint=False)
    revision = database.grammar_model
    coverage = build_grammar_coverage(
        database,
        config.vault_root,
        claim_manifest_path=config.grammar_claim_manifest,
    )
    if args.json:
        payload = (
            revision.to_dict()
            if args.all
            else revision.reference(
                runtime_workbench_version=WORKBENCH_VERSION,
            ).to_dict()
        )
        payload["implementation_coverage"] = coverage.to_summary_dict()
        print(json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2))
    else:
        print(
            "Grammar model: "
            f"{revision.model_version or 'unversioned'}"
        )
        print(f"Grammar source snapshot: {revision.source_snapshot_status}")
        print(f"Last model update: {revision.updated_on or 'not recorded'}")
        print(
            "Validated with Workshop: "
            f"{revision.validated_with_workbench_version or 'not recorded'}"
        )
        print(f"Runtime Workshop: {WORKBENCH_VERSION}")
        print(f"Grammar notes in lock: {len(revision.notes)}")
        print(
            "Validated digest: "
            f"{revision.validated_source_digest or 'not recorded'}"
        )
        print(f"Current digest: {revision.current_source_digest}")
        counts = coverage.counts
        print(
            "Implementation coverage: "
            f"{counts['behaviorally_verified']}/{counts['total']} notes "
            "behaviorally verified"
        )
        print(
            "Inventory coverage: "
            f"{counts['accounted']}/{counts['total']} notes accounted for"
        )
        if revision.changes:
            print("Changed notes:")
            for change in revision.changes:
                print(f"  {change.change}: {change.path}")
    return 0 if revision.source_snapshot_status == "current" else 1


def _snapshot_grammar(args: argparse.Namespace) -> int:
    database = compile_language(_config(args), include_lint=False)
    payload = render_grammar_model_manifest(
        database.grammar_model.current_notes,
        model_version=args.model_version,
        updated_on=args.updated_on,
        workbench_version=WORKBENCH_VERSION,
        translation_engine_version=TRANSLATION_ENGINE_VERSION,
    )
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(payload)
    rendered = json.loads(payload)
    print(
        f"Wrote grammar-model candidate {args.model_version} with "
        f"{len(rendered['notes'])} notes."
    )
    print(f"Source digest: {rendered['source_digest']}")
    print(f"Output: {output}")
    print("Review and accept this lock only after grammar tests pass.")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="asaxi-workbench",
        description=(
            "Compile and inspect the authoritative Asaxi language "
            "specification offline"
        ),
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    compile_parser = subparsers.add_parser(
        "compile",
        help="Compile a deterministic portable language database",
    )
    _common_source_arguments(compile_parser)
    compile_parser.add_argument(
        "--output",
        type=Path,
        default=DEFAULT_OUTPUT,
    )
    compile_parser.add_argument(
        "--fail-on-errors",
        action="store_true",
        help="Return a failing exit status after writing when errors exist",
    )
    compile_parser.set_defaults(handler=_compile)

    grammar_parser = subparsers.add_parser(
        "compile-grammar",
        help="Compile the source-cited productive-morphology inventory",
    )
    _common_source_arguments(grammar_parser)
    grammar_parser.add_argument(
        "--rules",
        type=Path,
        default=DEFAULT_RULE_INVENTORY,
        help="Workbench formal-grammar TOML inventory",
    )
    grammar_parser.add_argument(
        "--output",
        type=Path,
        default=DEFAULT_FORMAL_GRAMMAR_OUTPUT,
    )
    grammar_parser.add_argument(
        "--fail-on-errors",
        action="store_true",
        help="Return a failing exit status after writing when errors exist",
    )
    grammar_parser.set_defaults(handler=_compile_grammar)

    grammar_status_parser = subparsers.add_parser(
        "grammar-status",
        help="Compare live grammar notes with the validated model lock",
    )
    _common_source_arguments(grammar_status_parser)
    grammar_status_parser.add_argument(
        "--json",
        action="store_true",
        help="Print portable revision metadata as JSON",
    )
    grammar_status_parser.add_argument(
        "--all",
        action="store_true",
        help="Include the complete note lock and change records with --json",
    )
    grammar_status_parser.set_defaults(handler=_grammar_status)

    snapshot_parser = subparsers.add_parser(
        "snapshot-grammar",
        help="Write a review candidate for a newly implemented grammar model",
    )
    _common_source_arguments(snapshot_parser)
    snapshot_parser.add_argument("--model-version", required=True)
    snapshot_parser.add_argument(
        "--updated-on",
        required=True,
        help="Model update date in ISO YYYY-MM-DD form",
    )
    snapshot_parser.add_argument(
        "--output",
        type=Path,
        default=DEFAULT_GRAMMAR_MODEL_CANDIDATE,
    )
    snapshot_parser.set_defaults(handler=_snapshot_grammar)

    lint_parser = subparsers.add_parser(
        "lint",
        help="Compile in memory and report specification diagnostics",
    )
    _common_source_arguments(lint_parser)
    lint_parser.add_argument("--strict", action="store_true")
    lint_parser.add_argument("--json", action="store_true")
    lint_parser.add_argument("--all", action="store_true")
    lint_parser.add_argument("--limit", type=int, default=200)
    lint_parser.set_defaults(handler=_lint)

    inspect_parser = subparsers.add_parser(
        "inspect",
        help="Show the normalized record for one lemma",
    )
    _common_source_arguments(inspect_parser)
    inspect_parser.add_argument("lemma")
    inspect_parser.set_defaults(handler=_inspect)

    morph_parser = subparsers.add_parser(
        "morph",
        help="Exercise the deterministic morphology foundation",
    )
    _common_source_arguments(morph_parser)
    morph_parser.add_argument(
        "operation",
        choices=("analyze", "plural", "verbalize"),
    )
    morph_parser.add_argument("word")
    morph_parser.add_argument("--bridge", default="n")
    morph_parser.set_defaults(handler=_morph)

    translate_parser = subparsers.add_parser(
        "translate",
        help="Translate the supported canonical simple-clause fragment",
    )
    _common_source_arguments(translate_parser)
    translate_parser.add_argument(
        "direction",
        choices=tuple(direction.value for direction in TranslationDirection),
    )
    translate_parser.add_argument(
        "text",
        nargs="+",
        help="One canonical Asaxi or controlled-English clause",
    )
    translate_parser.add_argument(
        "--json",
        action="store_true",
        help="Print the complete versioned translation result",
    )
    translate_parser.add_argument(
        "--topic-asaxi",
        help=(
            "Explicit Asaxi discourse topic for resolving pro-drop; "
            "requires --topic-english"
        ),
    )
    translate_parser.add_argument(
        "--topic-english",
        help=(
            "English realization of --topic-asaxi for resolving pro-drop"
        ),
    )
    translate_parser.set_defaults(handler=_translate)

    grammar_check_parser = subparsers.add_parser(
        "check-grammar",
        aliases=("self-check",),
        help=(
            "Run source-cited conformance and audit grammar-book examples"
        ),
    )
    _common_source_arguments(grammar_check_parser)
    grammar_check_parser.add_argument(
        "--cases",
        type=Path,
        help="Override the curated conformance TOML manifest",
    )
    grammar_check_parser.add_argument(
        "--json",
        action="store_true",
        help="Print the complete portable report",
    )
    grammar_check_parser.add_argument(
        "--all",
        action="store_true",
        help="Print every curated and discovered example result",
    )
    grammar_check_parser.add_argument(
        "--strict-discovered",
        action="store_true",
        help=(
            "Fail when any automatically discovered example is unsupported, "
            "mismatched, or source-ambiguous"
        ),
    )
    grammar_check_parser.add_argument(
        "--strict-coverage",
        action="store_true",
        help=(
            "Fail while any grammar document lacks a machine linkage or a "
            "passing behavioral gate"
        ),
    )
    grammar_check_parser.set_defaults(handler=_check_grammar)

    serve_parser = subparsers.add_parser(
        "serve",
        help="Run the local translator GUI",
    )
    _common_source_arguments(serve_parser)
    serve_parser.add_argument("--host", default="127.0.0.1")
    serve_parser.add_argument("--port", type=int, default=8765)
    serve_parser.add_argument(
        "--phrase-memory",
        type=Path,
        help="Authored phrase-memory JSON (defaults to packaged project data)",
    )
    serve_parser.add_argument(
        "--developer-phrases",
        action="store_true",
        help="Enable loopback-only authored phrase editing controls",
    )
    serve_parser.add_argument(
        "--open",
        action="store_true",
        help="Open the local GUI in the default browser",
    )
    serve_parser.set_defaults(handler=_serve)

    quartz_parser = subparsers.add_parser(
        "export-quartz",
        help="Build the public static Workbench bundle for Quartz",
    )
    _common_source_arguments(quartz_parser)
    quartz_parser.add_argument(
        "--output",
        type=Path,
        default=DEFAULT_QUARTZ_EXPORT,
    )
    quartz_parser.add_argument(
        "--phrase-memory",
        type=Path,
        default=DEFAULT_PHRASE_MEMORY_PATH,
    )
    quartz_parser.add_argument(
        "--api-base",
        default="",
        help=(
            "Public Workbench API origin; omit for phrasebook-only static mode"
        ),
    )
    quartz_parser.add_argument(
        "--pyodide-root",
        type=Path,
        help=(
            "Installed pyodide package directory; enables the exact Python "
            "translator in a static browser worker when --api-base is omitted"
        ),
    )
    quartz_parser.set_defaults(handler=_export_quartz)
    return parser


def _configure_unicode_stdio() -> None:
    """Use deterministic UTF-8 for Asaxi output on Windows code pages."""

    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if callable(reconfigure):
            reconfigure(encoding="utf-8", errors="backslashreplace")


def main(argv: Sequence[str] | None = None) -> int:
    _configure_unicode_stdio()
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.handler(args))
    except (OSError, RuntimeError, ValueError) as error:
        parser.error(str(error))
    return 2


def compile_for_browser(
    config: CompileConfig,
) -> dict:
    """Stable embedding API for the future local and Quartz frontends."""

    database: LanguageDatabase = compile_language(config)
    return database.to_dict()


def translate_for_browser(
    config: CompileConfig,
    text: str,
    direction: TranslationDirection | str,
    *,
    discourse_state: DiscourseState | None = None,
) -> dict:
    """Portable result API for the local and future Quartz frontends."""

    database = compile_language(config)
    return Translator(database).translate(
        text,
        direction,
        discourse_state=discourse_state,
    ).to_dict()
