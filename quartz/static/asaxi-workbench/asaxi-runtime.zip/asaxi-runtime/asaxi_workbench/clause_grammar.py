"""Documented Milestone 0.5 Asaxi clause analysis.

This parser is intentionally additive.  The long-standing simple-clause path
still handles its original grammar first; this module receives only clauses
that path declined.  Every place where the authoritative notes permit more
than one reading becomes an explicit alternative or ambiguity record.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
import itertools
import re
from typing import Any, Iterable, Sequence

from .models import (
    LanguageDatabase,
    Lexeme,
    LexicalVariant,
    Severity,
    SpecificationStatus,
)
from .morphology import (
    MorphologicalAnalysis,
    MorphologyEngine,
    verbalize_nominal,
)
from .numerals import (
    FRACTION_DENOMINATOR_VALUE_BY_FORM,
    english_unit_fraction,
)
from .productive_morphology import (
    VerbComplexSpec,
    VerbMood,
    VerbPolarity,
    VerbRootKind,
    VerbTense,
    VerbVoice,
    compose_ga_compound,
    reduce_class_suffix,
    realize_verb_complex,
)
from .spatial_semantics import (
    SPATIAL_ABSTRACT,
    classify_spatial_landmark,
)
from .syntax import (
    ASAXI_DISCOURSE_MARKER_FORMS,
    ASAXI_EPISTEMIC_FORMS,
    ASAXI_PRECLAUSAL_MARKERS,
    ASAXI_VOWELS,
    ActionSwitch,
    CaseRelation,
    CanonicalClause,
    CausativeAgency,
    CausativeVoice,
    ClauseConnector,
    Directive,
    DirectiveFocus,
    DirectiveKind,
    DirectivePlacement,
    DeicticDistance,
    DistributionKind,
    DistributionScope,
    DiscourseReferent,
    DiscourseMarker,
    DiscourseMarkerKind,
    DiscourseState,
    DistributiveModifier,
    EventFrequency,
    EpistemicQualification,
    EpistemicStance,
    FrequencyKind,
    Modality,
    Nominal,
    NominalExtent,
    NominalExtentKind,
    NominalQuantifier,
    NominalQuantifierKind,
    Polarity,
    PostVerbalScope,
    PreclausalMarker,
    PreclausalMarkerKind,
    PredicateKind,
    PotentialMode,
    PronounAnimacy,
    PronounKind,
    PronounPerson,
    Register,
    ResultativeMode,
    RelationalPhrase,
    RelativeClause,
    RelativeRole,
    TemporalAspect,
    Tense,
    TteBinder,
    TteFunction,
    SubjunctiveMode,
    ValidityMode,
    VerbalDerivation,
    VerbalNominalization,
    VerbalizationMode,
    WhRole,
    WordTimeBinding,
    WordTimeOrientation,
    WordTimePlacement,
    WordTimeScope,
    discourse_marker_form,
    directive_focus_for,
    realize_solicitative_form,
)
from .translation_lexicon import (
    TranslationLexicon,
    english_gerund_forms,
    english_verb_bases,
    past_participle,
    past_tense,
    plural_noun,
    present_participle,
    present_third_person,
    split_english_gloss,
    split_english_gloss_value,
)
from .translation_models import (
    TranslationAlternative,
    TranslationAmbiguity,
    TranslationAssumption,
    TranslationDiagnostic,
    TranslationToken,
)


SUBJECT_MARKERS = {"to": Register.OBJECTIVE, "ă": Register.SUBJECTIVE}
DETERMINERS = {
    "anő": "indefinite",
    "onă": "definite",
    "onýj": "definite",
    "ponă": "specific-indefinite",
    "ponýj": "specific-indefinite",
}
DETERMINER_NOUN_CLASSES = {
    "anő": None,
    "onă": "warm",
    "onýj": "cold",
    "ponă": "warm",
    "ponýj": "cold",
}
# The NPCP fusion rule requires adjacent particles to form one block.  The
# objective subject marker therefore fuses with every determiner, including
# neutral ``anő`` (``to`` + ``anő`` -> ``toanő``), while the determiner remains
# a distinct virtual morpheme for agreement and glossing.
FUSED_SUBJECT_DETERMINERS = {
    f"to{determiner}": determiner
    for determiner in DETERMINERS
}
WORD_TIME_ORIENTATION_BY_MARKER = {
    "sỏni": WordTimeOrientation.RETROSPECTIVE,
    "pỏni": WordTimeOrientation.PROSPECTIVE,
}
WORD_TIME_MARKERS = tuple(
    sorted(WORD_TIME_ORIENTATION_BY_MARKER, key=lambda item: (-len(item), item))
)


def _fused_subject_rules(surface: str) -> tuple[str, ...]:
    determiner = FUSED_SUBJECT_DETERMINERS.get(surface)
    if determiner is None:
        return ()
    return (
        "clause.fused-subject-determiner",
        *(
            ("clause.fused-subject-definite-determiner",)
            if DETERMINERS[determiner] == "definite"
            else ()
        ),
    )
DEICTIC_PREFIXES = {
    "o": DeicticDistance.PROXIMAL,
    "no": DeicticDistance.MEDIAL,
    "ko": DeicticDistance.DISTAL,
    "gă": DeicticDistance.INDEFINITE,
}
PRECLAUSAL_MARKER_BY_FORM = {
    form: kind for kind, form in ASAXI_PRECLAUSAL_MARKERS.items()
}
DISCOURSE_MARKER_BY_FORM = {
    form: kind
    for kind, forms in ASAXI_DISCOURSE_MARKER_FORMS.items()
    for form in forms
}

RESULTATIVE_TAIL_FORMS = {
    "tomo'": ResultativeMode.CESSATIVE,
    "tomo": ResultativeMode.CESSATIVE,
}
POTENTIAL_TAIL_FORMS = {
    "ken": PotentialMode.AFFIRMATIVE,
    "ken.ná": PotentialMode.NEGATIVE,
}
SUBJUNCTIVE_TAIL_FORMS = {
    "xăxă": SubjunctiveMode.HYPOTHETICAL,
    "dăxă": SubjunctiveMode.OPTATIVE,
    "pùxă": SubjunctiveMode.AVERSIVE,
    "xădăchỏxă": SubjunctiveMode.SUPPLICATIVE,
}
INNER_POST_VERBAL_FORMS = {
    **{
        form: ("resultative", value)
        for form, value in RESULTATIVE_TAIL_FORMS.items()
    },
    **{
        form: ("potential", value)
        for form, value in POTENTIAL_TAIL_FORMS.items()
    },
    **{
        form: ("subjunctive", value)
        for form, value in SUBJUNCTIVE_TAIL_FORMS.items()
    },
}
INNER_POST_VERBAL_ORDER = (
    "resultative",
    "potential",
    "subjunctive",
)
PRECLAUSAL_ENGLISH = {
    PreclausalMarkerKind.REACTIVE_OBJECTION: "But wait",
    PreclausalMarkerKind.REACTIVE_CONTINUATION: "And so",
    PreclausalMarkerKind.AWE: "Woah",
    PreclausalMarkerKind.EMOTIONAL_REALIZATION: "Oh",
}
EPISTEMIC_STANCE_BY_FORMS = {
    forms: stance for stance, forms in ASAXI_EPISTEMIC_FORMS.items()
}
EPISTEMIC_FORM_PATTERNS = tuple(
    sorted(EPISTEMIC_STANCE_BY_FORMS, key=lambda forms: (-len(forms), forms))
)


def _split_deictic_surface(
    surface: str,
) -> tuple[str, str, DeicticDistance] | None:
    if "-" not in surface:
        return None
    prefix, head = surface.split("-", 1)
    distance = DEICTIC_PREFIXES.get(prefix)
    if distance is None or not head:
        return None
    return prefix, head, distance


def _split_attainable_surface(surface: str) -> str | None:
    """Return the head of the documented productive ``ono-`` nominal."""

    prefix = "ono-"
    if not surface.startswith(prefix) or len(surface) == len(prefix):
        return None
    return surface[len(prefix):]


WH_WORDS = {
    "kshá": ("who", WhRole.SUBJECT),
    "kjo": ("what", WhRole.OBJECT),
    "ksi": ("where", WhRole.LOCATION),
    "kvå": ("when", WhRole.TIME),
    "ksè": ("why", WhRole.REASON),
    "ksá": ("how", WhRole.MANNER),
}
CONNECTORS = {
    "ŕa": ClauseConnector.AND,
    "si": ClauseConnector.OR,
    "dzè": ClauseConnector.BUT,
    "chě": ClauseConnector.IF,
    "chěná": ClauseConnector.UNLESS,
    "chěxa": ClauseConnector.EVEN_IF,
    "sèwo": ClauseConnector.BECAUSE,
    "sèni": ClauseConnector.SO,
    "vå": ClauseConnector.WHEN,
    "nivå": ClauseConnector.WHILE,
    "zå": ClauseConnector.THEN,
    "måniåkam": ClauseConnector.BY_THE_TIME,
}
CONNECTOR_ENGLISH = {
    ClauseConnector.AND: "and",
    ClauseConnector.OR: "or",
    ClauseConnector.BUT: "but",
    ClauseConnector.IF: "if",
    ClauseConnector.UNLESS: "unless",
    ClauseConnector.EVEN_IF: "even if",
    ClauseConnector.BECAUSE: "because",
    ClauseConnector.SO: "so",
    ClauseConnector.WHEN: "when",
    ClauseConnector.WHILE: "while",
    ClauseConnector.THEN: "then",
    ClauseConnector.BY_THE_TIME: "by the time",
}
PREFIXED_CONNECTORS = frozenset(
    {
        ClauseConnector.IF,
        ClauseConnector.UNLESS,
        ClauseConnector.EVEN_IF,
        ClauseConnector.BECAUSE,
        ClauseConnector.WHEN,
        ClauseConnector.WHILE,
        ClauseConnector.BY_THE_TIME,
    }
)
COMMA_INFIX_CONNECTORS = frozenset(
    {
        ClauseConnector.SO,
        ClauseConnector.THEN,
    }
)
CONNECTOR_RULES = {
    ClauseConnector.AND: "clause.coordination-tail",
    ClauseConnector.OR: "clause.coordination-tail",
    ClauseConnector.BUT: "clause.coordination-tail",
    ClauseConnector.IF: "clause.conditional-tail",
    ClauseConnector.UNLESS: "clause.conditional-tail",
    ClauseConnector.EVEN_IF: "clause.conditional-tail",
    ClauseConnector.BECAUSE: "clause.causal-tail",
    ClauseConnector.SO: "clause.causal-tail",
    ClauseConnector.WHEN: "clause.temporal-tail",
    ClauseConnector.WHILE: "clause.temporal-tail",
    ClauseConnector.THEN: "clause.temporal-tail",
    ClauseConnector.BY_THE_TIME: "clause.temporal-tail",
}
TEMPORAL_ASPECT_MARKERS = {
    "nå": TemporalAspect.CURRENT,
    "panå": TemporalAspect.PROSPECTIVE,
    "hùnå": TemporalAspect.RETROSPECTIVE,
    "vanå": TemporalAspect.PERSISTIVE,
}
FREQUENCY_MARKERS = {
    "izånixå": FrequencyKind.INTERMITTENT,
    "nanå": FrequencyKind.OFTEN,
    "gănå": FrequencyKind.SOMETIME,
    "onå": FrequencyKind.ETERNAL,
    "opùnå": FrequencyKind.USUAL,
    "nåsi": FrequencyKind.NEVER,
    "náxănåsi": FrequencyKind.EMPHATIC_NEVER,
    "ximă": FrequencyKind.DAILY,
    "tammă": FrequencyKind.ALTERNATE_DAILY,
    "gămă": FrequencyKind.WHENEVER,
    "åmă": FrequencyKind.EVERY_TIME,
    "txămă": FrequencyKind.YEARLY,
}
MID_CLAUSE_FREQUENCY = {
    FrequencyKind.OFTEN: "often",
    FrequencyKind.USUAL: "usually",
    FrequencyKind.NEVER: "never",
    FrequencyKind.EMPHATIC_NEVER: "absolutely never",
}
FINAL_FREQUENCY = {
    FrequencyKind.INTERMITTENT: "from time to time",
    FrequencyKind.SOMETIME: "sometime",
    FrequencyKind.ETERNAL: "forever",
    FrequencyKind.DAILY: "every day",
    FrequencyKind.ALTERNATE_DAILY: "every other day",
    FrequencyKind.WHENEVER: "at any time",
    FrequencyKind.EVERY_TIME: "every time",
    FrequencyKind.YEARLY: "yearly",
}
DISTRIBUTIVE_PARTICLES = {
    "ojano": DistributionKind.GENERAL,
    "jonojo": DistributionKind.SEQUENTIAL,
    "okonoko": DistributionKind.SPATIAL,
}
DISTRIBUTIVE_ENGLISH = {
    DistributionKind.GENERAL: "individually",
    DistributionKind.SEQUENTIAL: "one by one",
    DistributionKind.SPATIAL: "here and there",
}
# The valency chapter documents all three before their target nominal. The
# dedicated ojano note additionally documents a post-nominal argument form.
POST_NOMINAL_DISTRIBUTIVES = frozenset({"ojano"})
NOMINAL_DISTRIBUTIVE_ROLES = frozenset(
    {
        "subject",
        "object",
        "location",
        "recipient",
        "source",
        "goal",
        "partner",
        "instrument",
        "limit",
        "topic",
    }
)
SPATIAL_PREDICATES = {
    "vanů": "inside",
    "pănů": "outside",
    "nanů": "on",
    "hùnů": "behind",
    "ỏnů": "amid",
    "banů": "beside",
    "panů": "in front of",
    "xanů": "above",
    "pùnů": "below",
    "gănů": "somewhere around",
}
DEICTIC_PREDICATES = {
    "o": "here",
    "no": "there",
    "ko": "over there",
    "gă": "somewhere",
    "oxiŕa": "here",
    "noxiŕa": "there",
    "koxiŕa": "over there",
    "o-xiŕa": "here",
    "no-xiŕa": "there",
    "ko-xiŕa": "over there",
    "onèŕa": "here",
}
TOPOLOGICAL_VALIDITY_PREDICATES = {
    "vaŕa": "inside",
    "naŕa": "on",
    "xaŕa": "above",
    "ỏŕa": "amid",
    "pùŕa": "below",
    "baŕa": "beside",
    "hùŕa": "behind",
    "paŕa": "in front of",
}
RELATIONAL_PREDICATES = {
    # Glosses are infinitival.  Rendering applies English tense and polarity
    # from the canonical clause instead of freezing these forms in present
    # tense.
    "sèŕa": (
        PredicateKind.POSSESSION,
        ("belong to", "be part of", "be a member of"),
    ),
    "sè": (PredicateKind.POSSESSION, ("be with",)),
    "dåŕa": (PredicateKind.RELATION, ("be intended for",)),
    "då": (PredicateKind.RELATION, ("be for",)),
    "izoŕa": (
        PredicateKind.RELATION,
        ("originate from", "derive from", "be made of"),
    ),
    "izo": (PredicateKind.RELATION, ("come from",)),
    "băŕa": (PredicateKind.RELATION, ("be caused by",)),
    "bă": (PredicateKind.RELATION, ("be due to",)),
    "záŕa": (
        PredicateKind.RELATION,
        ("accompany", "belong with", "be inseparable from"),
    ),
    "zá": (PredicateKind.RELATION, ("be with",)),
    # The grammar attests both change-of-state and directional/destiny senses.
    # They remain alternatives until lexical semantics can disambiguate them.
    "niŕa": (PredicateKind.RELATION, ("become", "lead to")),
    "ni": (PredicateKind.RELATION, ("be towards", "head towards")),
    "måmåŕa": (
        PredicateKind.RELATION,
        ("last until", "expire at", "end at"),
    ),
    "måmå": (PredicateKind.RELATION, ("be until",)),
}
RELATIONAL_PREDICATE_ALIASES = {
    "nìŕa": "niŕa",
}
CIRCUMSTANTIAL_NPCP_PREDICATES = {
    "sè": (PredicateKind.POSSESSION, "be with"),
    "då": (PredicateKind.RELATION, "be for"),
    "izo": (PredicateKind.RELATION, "be from"),
    "bă": (PredicateKind.RELATION, "be due to"),
    "zá": (PredicateKind.RELATION, "be with"),
    "ni": (PredicateKind.RELATION, "be to"),
    "måmå": (PredicateKind.RELATION, "be until"),
}
BOUND_VALIDITY_PREFIXES = frozenset(
    {"xi", "va", "na", "xa", "pù", "pa", "hù", "ba"}
)
CASE_MARKERS = {
    "då": (
        CaseRelation.DATIVE,
        "recipient-or-beneficiary",
        ("to", "for"),
    ),
    "dåni": (
        CaseRelation.TRANSFER_DATIVE,
        "transfer-recipient",
        ("to",),
    ),
    "izo": (
        CaseRelation.ABLATIVE,
        "source",
        ("from",),
    ),
    "ni": (
        CaseRelation.ALLATIVE,
        "goal",
        ("to",),
    ),
    "zá": (
        CaseRelation.COMITATIVE,
        "partner",
        ("with",),
    ),
    "bă": (
        CaseRelation.INSTRUMENTAL,
        "instrument-cause-or-path",
        ("with", "by"),
    ),
    "måmå": (
        CaseRelation.TERMINATIVE,
        "limit",
        ("until",),
    ),
    "ăni": (
        CaseRelation.TOPICAL,
        "topic",
        ("about",),
    ),
}
CASE_ARGUMENT_ROLES = {
    CaseRelation.DATIVE: "recipient",
    CaseRelation.TRANSFER_DATIVE: "recipient",
    CaseRelation.ABLATIVE: "source",
    CaseRelation.ALLATIVE: "goal",
    CaseRelation.COMITATIVE: "partner",
    CaseRelation.INSTRUMENTAL: "instrument",
    CaseRelation.TERMINATIVE: "limit",
    CaseRelation.TOPICAL: "topic",
}
IDENTITY_FORMS = {
    "xiŕa": (Tense.NONPAST, Polarity.POSITIVE),
    "nèŕa": (Tense.NONPAST, Polarity.NEGATIVE),
    "zèxiŕa": (Tense.PAST, Polarity.POSITIVE),
    "zènèŕa": (Tense.PAST, Polarity.NEGATIVE),
    "paxiŕa": (Tense.FUTURE, Polarity.POSITIVE),
    "panèŕa": (Tense.FUTURE, Polarity.NEGATIVE),
}
PERFORMANCE_FORMS = {
    "ů": (Tense.NONPAST, Polarity.POSITIVE),
    "ůná": (Tense.NONPAST, Polarity.NEGATIVE),
    "bů": (Tense.NONPAST, Polarity.POSITIVE),
    "bůná": (Tense.NONPAST, Polarity.NEGATIVE),
    "zèbů": (Tense.PAST, Polarity.POSITIVE),
    "zènábů": (Tense.PAST, Polarity.NEGATIVE),
    "paxů": (Tense.FUTURE, Polarity.POSITIVE),
    "panáxů": (Tense.FUTURE, Polarity.NEGATIVE),
    "pabů": (Tense.FUTURE, Polarity.POSITIVE),
    "panábů": (Tense.FUTURE, Polarity.NEGATIVE),
}
UNIVERSAL_NOMINAL_QUANTIFIERS = {
    "mămă": NominalQuantifierKind.UNIVERSAL,
}
NOMINAL_CATEGORIES = {
    "noun",
    "pronoun",
    "proper noun",
    "proper-noun",
    "name",
}
NOMINAL_MODIFIER_CATEGORIES = {
    "adjective",
    "root_word",
}
NOMINAL_COMPLEMENT_CATEGORIES = NOMINAL_CATEGORIES | {
    "adjective",
}
VICINITY_NOMINAL_MODIFIERS = frozenset(
    {
        "o-gă",
        "no-gă",
        "ko-gă",
        "gă-gă",
    }
)
VICINITY_MODIFIER_ENGLISH = {
    "o-gă": "from around here",
    "no-gă": "from around there near you",
    "ko-gă": "from way over there",
    "gă-gă": "from somewhere",
}
VICINITY_LOCATION_ENGLISH = {
    "o-gă": "around here",
    "no-gă": "around there",
    "ko-gă": "around there in the distance",
    "gă-gă": "somewhere around",
}
VICINITY_LOCATION_PREDICATES = frozenset({"ỏnů", "ỏŕa"})
PERSONAL_PRONOUNS = frozenset(
    {
        "wo",
        "wa",
        "no",
        "na",
        "xő",
        "xa",
        "ko",
        "ka",
        "gő",
        "gja",
        "jo",
        "hja",
    }
)
PERSONAL_PRONOUN_ENGLISH = {
    "wo": "I",
    "wa": "we",
    "no": "you",
    "na": "you (all)",
    "xő": "he",
    "xa": "they (m)",
    "ko": "she",
    "ka": "they (f)",
    "gő": "they",
    "gja": "they (nb)",
    "jo": "it",
    "hja": "they (things)",
}
PERSONAL_PRONOUN_FEATURES = {
    "wo": (PronounPerson.FIRST, PronounAnimacy.ANIMATE),
    "wa": (PronounPerson.FIRST, PronounAnimacy.ANIMATE),
    "no": (PronounPerson.SECOND, PronounAnimacy.ANIMATE),
    "na": (PronounPerson.SECOND, PronounAnimacy.ANIMATE),
    "xő": (PronounPerson.THIRD, PronounAnimacy.ANIMATE),
    "xa": (PronounPerson.THIRD, PronounAnimacy.ANIMATE),
    "ko": (PronounPerson.THIRD, PronounAnimacy.ANIMATE),
    "ka": (PronounPerson.THIRD, PronounAnimacy.ANIMATE),
    "gő": (PronounPerson.THIRD, PronounAnimacy.ANIMATE),
    "gja": (PronounPerson.THIRD, PronounAnimacy.ANIMATE),
    "jo": (PronounPerson.THIRD, PronounAnimacy.INANIMATE),
    "hja": (PronounPerson.THIRD, PronounAnimacy.INANIMATE),
}
PLURAL_PERSONAL_PRONOUNS = frozenset(
    {"wa", "na", "xa", "ka", "gja", "hja"}
)
REFLEXIVE_PRONOUNS = frozenset(
    f"ni{pronoun}"
    for pronoun in PERSONAL_PRONOUNS
)
REFLEXIVE_PRONOUN_ENGLISH = {
    "niwo": "myself",
    "niwa": "ourselves",
    "nino": "yourself",
    "nina": "yourselves",
    "nixő": "himself",
    "nixa": "themselves",
    "niko": "herself",
    "nika": "themselves",
    "nigő": "themself",
    "nigja": "themselves",
    "nijo": "itself",
    "nihja": "themselves",
}
RECIPROCAL_PRONOUNS = frozenset({"gőnigő"})
PRONOMINAL_PARTICLE_FORMS = (
    PERSONAL_PRONOUNS
    | REFLEXIVE_PRONOUNS
    | RECIPROCAL_PRONOUNS
)
PRONOMINAL_ENGLISH_GLOSSES = frozenset(
    {
        "i",
        "you",
        "he",
        "she",
        "it",
        "we",
        "they",
        "me",
        "him",
        "her",
        "us",
        "them",
        "myself",
        "yourself",
        "yourselves",
        "himself",
        "herself",
        "itself",
        "ourselves",
        "themself",
        "themselves",
        "each other",
        "one another",
    }
)
GA_HEAD_CATEGORIES = {"noun"}
# Productive ga-compounds may be built from noun roots, whereas a spaced
# modifier-head phrase follows the documented adjective/root-word syntax.
# Keeping these inventories separate prevents an illicit direct object from
# being swallowed as a generic bare-noun modifier.
GA_MODIFIER_CATEGORIES = NOMINAL_CATEGORIES | NOMINAL_MODIFIER_CATEGORIES
OBJECT_PRONOUNS = {
    "i": "me",
    "he": "him",
    "she": "her",
    "we": "us",
    "they": "them",
}
MAX_NOMINAL_OPTIONS = 64
MAX_CLAUSE_ALTERNATIVES = 256
LEGACY_LOWERCASE_DIRECTIVE_VOCATIVES = frozenset({"john", "tom"})
MAX_GA_MODIFIERS = 8
MAX_GA_LEXICAL_OPTIONS = 16


@dataclass(frozen=True)
class _VerbalizationModeSpec:
    mode: VerbalizationMode
    bridge: str
    english_head: str
    takes_complement: bool
    requires_complement: bool = False


VERBALIZATION_MODE_SPECS = (
    _VerbalizationModeSpec(
        VerbalizationMode.PERFORMANCE,
        "n",
        "use",
        True,
    ),
    _VerbalizationModeSpec(
        VerbalizationMode.INTERACTION,
        "x",
        "apply",
        True,
        True,
    ),
    _VerbalizationModeSpec(
        VerbalizationMode.SEMBLANCE,
        "w",
        "act like",
        False,
    ),
    _VerbalizationModeSpec(
        VerbalizationMode.TRANSFORMATIVE,
        "k",
        "turn",
        True,
        True,
    ),
    _VerbalizationModeSpec(
        VerbalizationMode.GENERATIVE,
        "ŕ",
        "produce",
        True,
    ),
    _VerbalizationModeSpec(
        VerbalizationMode.PRIVATIVE,
        "sh",
        "remove",
        True,
        True,
    ),
    _VerbalizationModeSpec(
        VerbalizationMode.SUBJECTIVE,
        "ch",
        "feel like",
        False,
    ),
    _VerbalizationModeSpec(
        VerbalizationMode.VISUAL,
        "j",
        "look like",
        False,
    ),
    _VerbalizationModeSpec(
        VerbalizationMode.AUDITORY,
        "s",
        "sound like",
        False,
    ),
    _VerbalizationModeSpec(
        VerbalizationMode.OLFACTORY,
        "ŋ",
        "smell like",
        False,
    ),
    _VerbalizationModeSpec(
        VerbalizationMode.TACTILE,
        "p",
        "feel like",
        False,
    ),
    _VerbalizationModeSpec(
        VerbalizationMode.GUSTATORY,
        "zh",
        "taste like",
        False,
    ),
)
VERBALIZATION_MODE_BY_MODE = {
    spec.mode: spec for spec in VERBALIZATION_MODE_SPECS
}
CANONICAL_TENSE_TO_VERB = {
    Tense.NONPAST: VerbTense.NONPAST,
    Tense.PAST: VerbTense.PAST,
    Tense.FUTURE: VerbTense.FUTURE,
}
CANONICAL_POLARITY_TO_VERB = {
    Polarity.POSITIVE: VerbPolarity.POSITIVE,
    Polarity.NEGATIVE: VerbPolarity.NEGATIVE,
}
CANONICAL_MODALITY_TO_VERB = {
    Modality.NONE: VerbMood.NONE,
    Modality.DESIDERATIVE: VerbMood.DESIDERATIVE,
    Modality.CONATIVE: VerbMood.CONATIVE,
}
CAUSATIVE_REALIZATIONS = (
    (
        CausativeVoice.PERMISSIVE,
        Polarity.POSITIVE,
        VerbVoice.PERMISSIVE,
        VerbPolarity.POSITIVE,
    ),
    (
        CausativeVoice.PERMISSIVE,
        Polarity.NEGATIVE,
        VerbVoice.PERMISSIVE,
        VerbPolarity.NEGATIVE,
    ),
    (
        CausativeVoice.COERCIVE,
        Polarity.POSITIVE,
        VerbVoice.COERCIVE,
        VerbPolarity.POSITIVE,
    ),
    (
        CausativeVoice.PROHIBITIVE,
        Polarity.POSITIVE,
        VerbVoice.PERMISSIVE,
        VerbPolarity.NEGATIVE_EMPHATIC,
    ),
)
SEPARATE_DIRECTIVE_MARKERS = {
    "hè": (
        DirectiveKind.COMMAND,
        DirectivePlacement.SUFFIX,
        ("hè",),
    ),
    "è": (
        DirectiveKind.COMMAND,
        DirectivePlacement.SUFFIX,
        ("è",),
    ),
    "náhè": (
        DirectiveKind.PROHIBITION,
        DirectivePlacement.SUFFIX,
        ("ná", "hè"),
    ),
    "náxăhè": (
        DirectiveKind.ABSOLUTE_PROHIBITION,
        DirectivePlacement.SUFFIX,
        ("ná", "xă", "hè"),
    ),
}


def category_allowed_for_nominal_role(
    category: str,
    role: str,
) -> bool:
    """Apply the documented head/modifier distinction across parsers."""

    if role == "modifier":
        return category in NOMINAL_MODIFIER_CATEGORIES
    if role == "complement":
        return category in NOMINAL_COMPLEMENT_CATEGORIES
    return category in NOMINAL_CATEGORIES


def lexeme_allowed_for_nominal_role(
    lexeme: Lexeme,
    role: str,
) -> bool:
    """Recognize nominal lexemes and the documented closed pronoun class."""

    if (
        role == "modifier"
        and lexeme.surface_form in VICINITY_NOMINAL_MODIFIERS
    ):
        return True
    if category_allowed_for_nominal_role(lexeme.category, role):
        return True
    if role == "modifier" or lexeme.category != "particle":
        return False
    if lexeme.surface_form in (
        REFLEXIVE_PRONOUNS | RECIPROCAL_PRONOUNS
    ):
        return True
    if lexeme.surface_form not in PERSONAL_PRONOUNS:
        return False
    return any(
        gloss.casefold() in PRONOMINAL_ENGLISH_GLOSSES
        for gloss in split_english_gloss(lexeme)
    )


def valency_allows_direct_object(value: str) -> bool:
    """Return whether a normalized source valency licenses an object.

    Exact lexical labels are used here: ``intransitive`` must never match
    merely because its spelling contains the substring ``transitive``.
    """

    labels = set(re.findall(r"[a-z]+", value.casefold()))
    return bool(
        labels
        & {
            "transitive",
            "monotransitive",
            "ditransitive",
            "ambitransitive",
        }
    )


@dataclass(frozen=True)
class ExpandedParseOutcome:
    alternatives: tuple[TranslationAlternative, ...]
    diagnostic: TranslationDiagnostic | None = None


@dataclass(frozen=True)
class _VerbalizationBase:
    surface: str
    derivation: VerbalDerivation
    source_glosses: tuple[str, ...]
    explicit_derived_glosses: tuple[str, ...]
    explicit_derived_term_ids: tuple[str, ...]
    morphemes: tuple[str, ...]
    rule_trace: tuple[str, ...]


@dataclass(frozen=True)
class _DirectiveForm:
    kind: DirectiveKind
    placement: DirectivePlacement
    markers: tuple[str, ...]
    fused: bool = False
    rapid_speech: bool = False

    @property
    def focus(self) -> DirectiveFocus:
        return directive_focus_for(self.kind, self.placement)


@dataclass(frozen=True)
class _PredicateReading:
    surface: str
    lemma: str
    kind: PredicateKind
    english_glosses: tuple[str, ...]
    tense: Tense = Tense.NONPAST
    polarity: Polarity = Polarity.POSITIVE
    modality: Modality = Modality.NONE
    causative_voice: CausativeVoice | None = None
    directive_form: _DirectiveForm | None = None
    validity_mode: ValidityMode = ValidityMode.NONE
    lexeme: Lexeme | None = None
    morphemes: tuple[str, ...] = ()
    rule_trace: tuple[str, ...] = ()
    takes_complement: bool | None = None
    temporal_aspect: TemporalAspect = TemporalAspect.NONE
    temporal_aspect_index: int | None = None
    frequency: EventFrequency | None = None
    frequency_index: int | None = None
    post_verbal_scope: PostVerbalScope = PostVerbalScope()
    post_verbal_indices: tuple[tuple[int, str], ...] = ()
    verbal_derivation: VerbalDerivation | None = None
    verbalization_source_gloss: str | None = None
    verbalization_source_glosses: tuple[str, ...] = ()
    explicit_derived_term: bool = False
    requires_complement: bool = False
    word_time_binding: WordTimeBinding | None = None
    word_time_index: int | None = None

    @property
    def is_transitive(self) -> bool:
        if self.takes_complement is not None:
            return self.takes_complement
        if self.kind in {
            PredicateKind.IDENTITY,
            PredicateKind.PERFORMANCE,
            PredicateKind.LOCATION,
            PredicateKind.POSSESSION,
            PredicateKind.RELATION,
        }:
            return True
        if self.lexeme is None or not self.lexeme.valency.is_present:
            return False
        return valency_allows_direct_object(str(self.lexeme.valency.value))


@dataclass(frozen=True)
class _NominalReading:
    nominal: Nominal
    english_text: str
    token_indices: tuple[int, ...]
    roles: tuple[tuple[int, str], ...]
    assumptions: tuple[TranslationAssumption, ...] = ()
    ambiguities: tuple[TranslationAmbiguity, ...] = ()
    rule_trace: tuple[str, ...] = ()
    structural_cost: int = 0


@dataclass(frozen=True)
class _CaseArgumentReading:
    phrase: RelationalPhrase
    english_text: str
    roles: tuple[tuple[int, str], ...]
    assumptions: tuple[TranslationAssumption, ...] = ()
    ambiguities: tuple[TranslationAmbiguity, ...] = ()
    rule_trace: tuple[str, ...] = ()
    structural_cost: int = 0


@dataclass(frozen=True)
class _DirectiveArgumentReading:
    direct: _NominalReading | None = None
    obliques: tuple[_CaseArgumentReading, ...] = ()
    roles: tuple[tuple[int, str], ...] = ()
    assumptions: tuple[TranslationAssumption, ...] = ()
    ambiguities: tuple[TranslationAmbiguity, ...] = ()
    rule_trace: tuple[str, ...] = ()
    structural_cost: int = 0


@dataclass(frozen=True)
class _ClauseReading:
    clause: CanonicalClause
    output_text: str
    roles: tuple[tuple[int, str], ...]
    predicate: _PredicateReading | None
    predicate_index: int | None
    subject_english: str | None
    assumptions: tuple[TranslationAssumption, ...] = ()
    ambiguities: tuple[TranslationAmbiguity, ...] = ()
    rule_trace: tuple[str, ...] = ()
    predicate_english: str | None = None
    complement_english: str | None = None


@dataclass(frozen=True)
class _PragmaticEnvelope:
    preclausal: PreclausalMarker | None = None
    preclausal_index: int | None = None
    discourse: DiscourseMarker | None = None
    discourse_index: int | None = None

    @property
    def is_empty(self) -> bool:
        return self.preclausal is None and self.discourse is None


@dataclass(frozen=True)
class _TteEnvelope:
    binder: TteBinder | None = None
    token_indices: tuple[int, ...] = ()

    @property
    def is_empty(self) -> bool:
        return self.binder is None


@dataclass(frozen=True)
class _GaCompoundCandidate:
    modifiers: tuple[Lexeme, ...]
    head: Lexeme
    rule_trace: tuple[str, ...]


@dataclass(frozen=True)
class _GaCompoundAnalysis:
    candidates: tuple[_GaCompoundCandidate, ...]
    limited: bool = False


def _capitalize(text: str) -> str:
    return text[:1].upper() + text[1:] if text else text


def _append_event_distribution(text: str, phrase: str) -> str:
    punctuation = text[-1:] if text[-1:] in {".", "?", "!"} else ""
    stem = text[:-1] if punctuation else text
    return f"{stem} {phrase}{punctuation}"


def _subject_for_agreement(text: str) -> str:
    normalized = re.sub(
        r"\s+\([^)]*\)\s*$",
        "",
        text.casefold(),
    )
    for phrase in DISTRIBUTIVE_ENGLISH.values():
        suffix = f", {phrase},"
        if normalized.endswith(suffix):
            return normalized[:-len(suffix)].rstrip()
    return normalized


def _english_coordination(items: Sequence[str]) -> str:
    if not items:
        return ""
    if len(items) == 1:
        return items[0]
    if len(items) == 2:
        return f"{items[0]} and {items[1]}"
    return f"{', '.join(items[:-1])}, and {items[-1]}"


def _indefinite_article(noun: str) -> str:
    return "an" if noun[:1].casefold() in "aeiou" else "a"


def _validity_surface(
    canonical: str,
    tense: Tense,
    polarity: Polarity,
) -> tuple[str, tuple[str, ...], tuple[str, ...]]:
    """Realize documented tense/polarity outside a non-``xi`` Slot A.

    Relational and constitutional validity use ordinary ``ná`` negation;
    pure existence keeps its separate ``nè`` paradigm in ``IDENTITY_FORMS``.
    """

    tense_prefix = {
        Tense.NONPAST: "",
        Tense.PAST: "zè",
        Tense.FUTURE: "pa",
    }[tense]
    polarity_prefix = "ná" if polarity is Polarity.NEGATIVE else ""
    surface = tense_prefix + polarity_prefix + canonical
    morphemes: list[str] = []
    if tense_prefix:
        morphemes.append(tense_prefix)
    if polarity_prefix:
        morphemes.append(polarity_prefix)
    if canonical.endswith("ŕa"):
        morphemes.extend((canonical[:-2], "ŕa"))
    else:
        morphemes.append(canonical)
    trace: list[str] = []
    if tense is not Tense.NONPAST:
        trace.append("clause.validity-tense-stack")
    if polarity is Polarity.NEGATIVE:
        trace.append("clause.validity-relational-negation")
    return surface, tuple(morphemes), tuple(trace)


def _constitutional_predicate_glosses(
    lexeme: Lexeme,
    *,
    class_suffix_reduced: bool,
) -> tuple[str, ...]:
    """Convert compiled ga-noun senses into copular complements.

    The source lexicon stores these concepts as nouns.  A reduced classifier
    (for example ``gajýnn-shá`` -> ``gajýnn-ŕa``) therefore receives an
    English indefinite article.  Unreduced property terms such as ``gapo``
    remain bare complements, yielding "is red" rather than "is a red".
    """

    cleaned: list[str] = []
    for gloss in split_english_gloss(lexeme):
        candidate = re.sub(r"\s*\([^)]*\)\s*$", "", gloss).strip()
        if not candidate:
            continue
        if class_suffix_reduced and not candidate.casefold().startswith(
            ("a ", "an ", "the ", "some ", "this ", "that ")
        ):
            candidate = f"{_indefinite_article(candidate)} {candidate}"
        cleaned.append(candidate)
    return tuple(dict.fromkeys(cleaned))


def _strip_terminal_punctuation(text: str) -> str:
    return text.rstrip().rstrip(".?!").rstrip()


def _render_pragmatic_english(
    text: str,
    envelope: _PragmaticEnvelope,
) -> str:
    """Render typed attitude without changing the proposition itself."""

    output = text
    if envelope.discourse is not None:
        stem = _strip_terminal_punctuation(output)
        kind = envelope.discourse.kind
        if kind is DiscourseMarkerKind.AGREEMENT:
            output = f"{stem}, right?"
        elif kind is DiscourseMarkerKind.ASSERTION:
            output = f"{stem}, I tell you."
        elif kind is DiscourseMarkerKind.CASUAL_EMPHASIS:
            output = f"{stem}, yo."
        elif kind is DiscourseMarkerKind.SKEPTICISM:
            output = f"{stem}, is that so?"
        elif kind is DiscourseMarkerKind.RESIGNATION:
            output = f"Alas, {stem}."
        elif kind is DiscourseMarkerKind.CONTENTION:
            output = f"{stem}, I object!"

    if envelope.preclausal is not None:
        prefix = PRECLAUSAL_ENGLISH[envelope.preclausal.kind]
        punctuation = output[-1:] if output[-1:] in {".", "?", "!"} else "."
        proposition = _embedded_english_proposition(output)
        output = f"{prefix}, {proposition}{punctuation}"
        if envelope.preclausal.kind is PreclausalMarkerKind.AWE:
            output = _strip_terminal_punctuation(output) + "!"
    return output


def _embedded_english_proposition(text: str) -> str:
    """Remove sentence punctuation and decapitalize grammatical openers."""

    stem = _strip_terminal_punctuation(text)
    first, separator, rest = stem.partition(" ")
    if first.casefold() in {
        "a", "an", "the", "this", "that", "these", "those", "every",
        "each", "all", "some", "no", "he", "she", "we", "they", "it",
        "who", "what", "where", "when", "why", "how",
    }:
        first = first.casefold()
    return first + (separator + rest if separator else "")


def _render_tte_english(
    text: str,
    envelope: _TteEnvelope,
) -> str:
    binder = envelope.binder
    if binder is None:
        return text
    proposition = _embedded_english_proposition(text)
    if binder.function is TteFunction.BARE:
        return f"It is said that {proposition}."
    qualification = binder.qualification
    if (
        binder.function is not TteFunction.EPISTEMIC
        or qualification is None
    ):
        return text
    templates = {
        EpistemicStance.SURE: "I am sure that {proposition}.",
        EpistemicStance.KNOWN: "I know that {proposition}.",
        EpistemicStance.THINK: "I think that {proposition}.",
        EpistemicStance.UNSURE: "I suspect that {proposition}.",
        EpistemicStance.DOUBT: "I do not think that {proposition}.",
        EpistemicStance.SUBJECTIVE_PAST: (
            "I think it was the case that {proposition}."
        ),
        EpistemicStance.MEMORY_FACT: (
            "I remember it as a fact that {proposition}."
        ),
        EpistemicStance.FUTURE_FACT: (
            "I am certain it will be the case that {proposition}."
        ),
    }
    return templates[qualification.stance].format(proposition=proposition)


def _directive_forms(root: str) -> tuple[tuple[str, _DirectiveForm], ...]:
    """Generate the documented command/flow forms for one predicate root."""

    if not root:
        return ()
    suffix_commands: list[tuple[str, _DirectiveForm]]
    if root.endswith("ů"):
        # Both variants are explicitly illustrated in the command chapter.
        # The first preserves ů plus h-elided -è; the second fuses ů+hè to wë.
        suffix_commands = [
            (
                root + "è",
                _DirectiveForm(
                    DirectiveKind.COMMAND,
                    DirectivePlacement.SUFFIX,
                    ("è",),
                ),
            ),
            (
                root[:-1] + "wë",
                _DirectiveForm(
                    DirectiveKind.COMMAND,
                    DirectivePlacement.SUFFIX,
                    ("wë",),
                    fused=True,
                ),
            ),
        ]
    elif root[-1] in ASAXI_VOWELS:
        suffix_commands = [
            (
                root + "hè",
                _DirectiveForm(
                    DirectiveKind.COMMAND,
                    DirectivePlacement.SUFFIX,
                    ("hè",),
                ),
            )
        ]
    else:
        suffix_commands = [
            (
                root + "è",
                _DirectiveForm(
                    DirectiveKind.COMMAND,
                    DirectivePlacement.SUFFIX,
                    ("è",),
                ),
            )
        ]

    forms: list[tuple[str, _DirectiveForm]] = [
        *suffix_commands,
        (
            "hè" + root,
            _DirectiveForm(
                DirectiveKind.COMMAND,
                DirectivePlacement.PREFIX,
                ("hè",),
            ),
        ),
        (
            root + "náhè",
            _DirectiveForm(
                DirectiveKind.PROHIBITION,
                DirectivePlacement.SUFFIX,
                ("ná", "hè"),
            ),
        ),
        (
            root + "náxăhè",
            _DirectiveForm(
                DirectiveKind.ABSOLUTE_PROHIBITION,
                DirectivePlacement.SUFFIX,
                ("ná", "xă", "hè"),
            ),
        ),
        (
            "nă" + root,
            _DirectiveForm(
                DirectiveKind.CESSATION,
                DirectivePlacement.PREFIX,
                ("nă",),
            ),
        ),
        (
            root + "nă",
            _DirectiveForm(
                DirectiveKind.CESSATION,
                DirectivePlacement.SUFFIX,
                ("nă",),
            ),
        ),
        (
            "sů" + root,
            _DirectiveForm(
                DirectiveKind.CONTINUATION,
                DirectivePlacement.PREFIX,
                ("sů",),
            ),
        ),
        (
            root + "sů",
            _DirectiveForm(
                DirectiveKind.CONTINUATION,
                DirectivePlacement.SUFFIX,
                ("sů",),
            ),
        ),
    ]
    if root.endswith("nů"):
        # Note 53's productively derived exenů + suffixal nă is attested as
        # exenă.  The analyzer later restricts this contraction to an
        # explicitly listed, unlexicalized -n- performance derivation, so an
        # unrelated lexical -nů verb cannot be shortened by spelling alone.
        forms.append(
            (
                root[:-1] + "ă",
                _DirectiveForm(
                    DirectiveKind.CESSATION,
                    DirectivePlacement.SUFFIX,
                    ("nă",),
                    fused=True,
                ),
            )
        )
    forms.extend(
        (
            "nåhè" + surface,
            _DirectiveForm(
                DirectiveKind.SWITCH,
                DirectivePlacement.CIRCUMFIX,
                ("nåhè", *directive.markers),
                fused=directive.fused,
            ),
        )
        for surface, directive in suffix_commands
    )
    forms.extend(
        (
            surface[:-1] + "wa",
            _DirectiveForm(
                DirectiveKind.HORTATIVE,
                DirectivePlacement.SUFFIX,
                ("hè", "wa"),
                rapid_speech=True,
            ),
        )
        for surface, directive in suffix_commands
        if directive.markers == ("hè",)
    )
    forms.extend(
        (
            surface + "wa",
            _DirectiveForm(
                DirectiveKind.HORTATIVE,
                DirectivePlacement.SUFFIX,
                (*directive.markers, "wa"),
                fused=directive.fused,
            ),
        )
        for surface, directive in suffix_commands
    )
    forms.append(
        (
            root + "kăwa",
            _DirectiveForm(
                DirectiveKind.POLITE_HORTATIVE,
                DirectivePlacement.SUFFIX,
                ("kă", "wa"),
            ),
        )
    )
    solicitative_forms = (
        _DirectiveForm(
            DirectiveKind.REQUEST,
            DirectivePlacement.SUFFIX,
            ("kă",),
        ),
        _DirectiveForm(
            DirectiveKind.REQUEST,
            DirectivePlacement.PREFIX,
            ("kă",),
        ),
        _DirectiveForm(
            DirectiveKind.INSTRUCTION,
            DirectivePlacement.SUFFIX,
            ("xă", "kă"),
        ),
        _DirectiveForm(
            DirectiveKind.INSTRUCTION,
            DirectivePlacement.PREFIX,
            ("xă", "kă"),
        ),
        _DirectiveForm(
            DirectiveKind.POLITE_PROHIBITION,
            DirectivePlacement.SUFFIX,
            ("ná", "xă", "kă"),
        ),
    )
    forms.extend(
        (
            realize_solicitative_form(
                root,
                directive.kind,
                directive.placement,
            ),
            directive,
        )
        for directive in solicitative_forms
    )
    return tuple(dict.fromkeys(forms))


def _directive_root_candidates(surface: str) -> tuple[str, ...]:
    """Return reversible base proposals for documented directive affixes.

    These are only proposals.  Callers must regenerate the directive paradigm
    from each proposed base and require an exact surface/form match before
    accepting an analysis.
    """

    candidates: list[str] = []

    def add(candidate: str) -> None:
        if candidate and candidate != surface and candidate not in candidates:
            candidates.append(candidate)

    if surface.startswith("nåhè"):
        inner = surface[len("nåhè"):]
        if inner.endswith("wë"):
            add(inner[:-2] + "ů")
        if inner.endswith("ůè"):
            add(inner[:-1])
        if inner.endswith("hè"):
            add(inner[:-2])
        if inner.endswith("è"):
            add(inner[:-1])

    for suffix in ("náxăhè", "náhè"):
        if surface.endswith(suffix):
            add(surface[:-len(suffix)])
    for suffix in ("náxăkă", "xăkă", "kă"):
        if surface.endswith(suffix):
            add(surface[:-len(suffix)])

    if surface.endswith("kăwa"):
        add(surface[:-len("kăwa")])
    if surface.endswith("wëwa"):
        add(surface[:-len("wëwa")] + "ů")
    if surface.endswith("ůèwa"):
        add(surface[:-len("èwa")])
    if surface.endswith("hèwa"):
        add(surface[:-len("hèwa")])
    if surface.endswith("hwa"):
        add(surface[:-len("hwa")])
    if surface.endswith("èwa"):
        add(surface[:-len("èwa")])

    for prefix in ("hè", "nă", "sů"):
        if surface.startswith(prefix):
            add(surface[len(prefix):])
    for prefix in ("xăkă", "kă"):
        if surface.startswith(prefix + "x"):
            add(surface[len(prefix) + 1:])
        if surface.startswith(prefix):
            add(surface[len(prefix):])
    for suffix in ("nă", "sů"):
        if surface.endswith(suffix):
            add(surface[:-len(suffix)])
    if surface.endswith("nă"):
        # Reversible proposal for the source-attested -nů + nă contraction.
        # Exact paradigm regeneration and derivational provenance are both
        # required before a caller may accept it.
        add(surface[:-1] + "ů")

    if surface.endswith("wë"):
        add(surface[:-2] + "ů")
    if surface.endswith("ůè"):
        add(surface[:-1])
    if surface.endswith("hè"):
        add(surface[:-2])
    if surface.endswith("è"):
        add(surface[:-1])
    return tuple(candidates)


def determiner_agrees_with_noun_class(
    determiner: str,
    noun_class: str | None,
) -> bool:
    """Apply documented warm/cold concord to a determined nominal.

    ``anő`` is class-neutral. Class-bearing determiners require a known head
    class: accepting an unclassified head would make the validator claim
    concord that it cannot actually establish.
    """

    required = DETERMINER_NOUN_CLASSES.get(determiner)
    if determiner not in DETERMINER_NOUN_CLASSES:
        return False
    return required is None or noun_class == required


def pronoun_binding_is_licensed(
    subject: Nominal,
    dependent: Nominal | None,
) -> bool:
    """Validate documented reflexive and reciprocal antecedent constraints."""

    return pronoun_binding_issue(subject, dependent) is None


def pronoun_binding_issue(
    subject: Nominal,
    dependent: Nominal | None,
) -> tuple[str, str] | None:
    """Return the first documented antecedent constraint that is not met.

    Noun class is deliberately not consulted here: the grammar distinguishes
    warm/cold class from animate/inanimate pronoun agreement.  If a lexical
    antecedent has no explicit animacy evidence, the analyzer reports that
    missing evidence instead of guessing from warmth.
    """

    if dependent is None:
        return None
    if dependent.pronoun_kind is PronounKind.REFLEXIVE:
        if dependent.number != subject.number:
            return (
                "REFLEXIVE_NUMBER_MISMATCH",
                "The reflexive pronoun does not agree in number with its "
                "antecedent.",
            )
        if (
            dependent.person is not None
            and (
                subject.person is None
                or dependent.person is not subject.person
            )
        ):
            return (
                "REFLEXIVE_PERSON_MISMATCH",
                "The reflexive pronoun does not agree in person with its "
                "antecedent.",
            )
        if (
            dependent.animacy is not None
            and subject.animacy is None
        ):
            return (
                "REFLEXIVE_ANTECEDENT_ANIMACY_UNKNOWN",
                "The antecedent has no explicit animate/inanimate feature, "
                "so the reflexive's animacy agreement cannot be established.",
            )
        if (
            dependent.animacy is not None
            and dependent.animacy is not subject.animacy
        ):
            return (
                "REFLEXIVE_ANIMACY_MISMATCH",
                "The reflexive pronoun does not agree in animacy with its "
                "antecedent.",
            )
        if (
            subject.pronoun_kind is PronounKind.PERSONAL
            and dependent.pronoun_base is not None
            and dependent.pronoun_base != subject.surface
        ):
            return (
                "REFLEXIVE_PRONOUN_BASE_MISMATCH",
                "The reflexive pronoun is not derived from the overt subject "
                "pronoun.",
            )
    elif dependent.pronoun_kind is PronounKind.RECIPROCAL:
        if subject.number != "plural" and not subject.coordinated:
            return (
                "RECIPROCAL_REQUIRES_PLURAL_ANTECEDENT",
                "The reciprocal pronoun requires a plural or coordinated "
                "antecedent.",
            )
    return None


def _pronoun_binding_rule(nominal: Nominal | None) -> tuple[str, ...]:
    if nominal is None:
        return ()
    if nominal.pronoun_kind is PronounKind.REFLEXIVE:
        return ("nominal.reflexive-antecedent-agreement",)
    if nominal.pronoun_kind is PronounKind.RECIPROCAL:
        return ("nominal.reciprocal-plural-antecedent",)
    return ()


class ExpandedAsaxiClauseParser:
    """Analyze the bounded clause structures documented for Milestone 0.5."""

    def __init__(
        self,
        database: LanguageDatabase,
        lexicon: TranslationLexicon,
        morphology: MorphologyEngine,
    ):
        self.database = database
        self.lexicon = lexicon
        self.morphology = morphology
        self._lexemes_by_id = {
            lexeme.identifier: lexeme for lexeme in database.lexemes
        }
        self._verbalization_bases = self._build_verbalization_bases()
        self._productive_predicate_cache: dict[
            str,
            tuple[_PredicateReading, ...],
        ] = {}
        self._productive_causative_cache: dict[
            str,
            tuple[_PredicateReading, ...],
        ] = {}
        self._directive_predicate_cache: dict[
            str,
            tuple[_PredicateReading, ...],
        ] = {}
        self._predicates = self._build_predicate_index()
        (
            self._ga_modifier_surfaces,
            self._ga_head_surfaces,
        ) = self._build_ga_part_indexes()
        self._ga_compound_cache: dict[
            str,
            _GaCompoundAnalysis,
        ] = {}

    @staticmethod
    def _split_subject_marker(
        words: Sequence[Any],
    ) -> tuple[Any | None, Any | None]:
        """Return the overt marker and an optional virtual determiner token.

        A fused source word remains one output token and one source span.  The
        virtual determiner exists only during syntax analysis so ordinary
        determiner agreement and noun-phrase rules remain authoritative.
        """

        if not words:
            return None, None
        token = words[0]
        if token.normalized in SUBJECT_MARKERS:
            return token, None
        determiner = FUSED_SUBJECT_DETERMINERS.get(token.normalized)
        if determiner is None:
            return None, None
        marker_length = len("to")
        return (
            token,
            replace(
                token,
                surface=token.surface[marker_length:],
                normalized=determiner,
                start=min(token.end, token.start + marker_length),
            ),
        )

    def should_preempt_legacy(self, tokens: Sequence[Any]) -> bool:
        """Return whether a documented structure needs typed parsing first."""

        if any(
            token.kind == "word"
            and (
                token.normalized in WH_WORDS
                or token.normalized in PRONOMINAL_PARTICLE_FORMS
                or token.normalized in FUSED_SUBJECT_DETERMINERS
                or token.normalized == "tte"
            )
            for token in tokens
        ):
            return True
        words = tuple(
            token
            for token in tokens
            if token.kind in {"word", "number"}
            and token.normalized != "kè"
        )
        if not words:
            return False
        if words[-1].normalized in {"vaxiŕa", "vanèŕa"}:
            return True
        if (
            words[0].normalized in PRECLAUSAL_MARKER_BY_FORM
            or words[-1].normalized in DISCOURSE_MARKER_BY_FORM
        ):
            return True
        if any(
            token.normalized in CIRCUMSTANTIAL_NPCP_PREDICATES
            for token in words[1:-1]
        ):
            return True
        readings = self._all_predicate_readings(words[-1].normalized)
        if any(
            reading.kind is not PredicateKind.ACTION
            or reading.validity_mode is not ValidityMode.NONE
            or reading.causative_voice is not None
            or reading.directive_form is not None
            for reading in readings
        ):
            return True
        # Preserve the long-standing lexical action path when a conventional
        # verb exists. Productive unlexicalized predicates need the typed path
        # because their mode and valency are grammatical, not dictionary data.
        return bool(readings) and not any(
            reading.lexeme is not None for reading in readings
        )

    @staticmethod
    def _extract_pragmatic_envelope(
        words: Sequence[Any],
        comma_indices: set[int],
        *,
        extract_preclausal: bool = True,
        extract_discourse: bool = True,
    ) -> tuple[list[Any], _PragmaticEnvelope]:
        """Peel off only positionally and phonologically licensed markers."""

        core = list(words)
        preclausal: PreclausalMarker | None = None
        preclausal_index: int | None = None
        discourse: DiscourseMarker | None = None
        discourse_index: int | None = None

        if extract_preclausal and core:
            first = core[0]
            kind = PRECLAUSAL_MARKER_BY_FORM.get(first.normalized)
            if kind is not None and first.index + 1 in comma_indices:
                preclausal = PreclausalMarker(
                    kind=kind,
                    form=first.normalized,
                )
                preclausal_index = first.index
                core = core[1:]

        if extract_discourse and len(core) >= 2:
            marker_token = core[-1]
            kind = DISCOURSE_MARKER_BY_FORM.get(marker_token.normalized)
            if kind is not None:
                forms = ASAXI_DISCOURSE_MARKER_FORMS[kind]
                preceding = core[-2].normalized
                if len(forms) == 1:
                    expected = forms[0]
                else:
                    expected = (
                        discourse_marker_form(kind, preceding)
                    )
                if marker_token.normalized == expected:
                    discourse = DiscourseMarker(
                        kind=kind,
                        form=marker_token.normalized,
                    )
                    discourse_index = marker_token.index
                    core = core[:-1]

        return core, _PragmaticEnvelope(
            preclausal=preclausal,
            preclausal_index=preclausal_index,
            discourse=discourse,
            discourse_index=discourse_index,
        )

    @staticmethod
    def _extract_inquiry(
        words: Sequence[Any],
        question_indices: set[int],
        discourse: DiscourseMarker | None,
    ) -> tuple[list[Any], bool]:
        """Separate proposition inquiry from an outer pragmatic tag."""

        core = list(words)
        tag_question = (
            discourse is not None
            and discourse.kind
            in {
                DiscourseMarkerKind.AGREEMENT,
                DiscourseMarkerKind.SKEPTICISM,
            }
        )
        interrogative = bool(question_indices) and not tag_question
        if core and core[0].normalized == "kè":
            question_indices.add(core[0].index)
            core = core[1:]
            interrogative = True
        if core and core[-1].normalized == "kè":
            question_indices.add(core[-1].index)
            core = core[:-1]
            interrogative = True
        return core, interrogative

    @staticmethod
    def _extract_tte_envelope(
        words: Sequence[Any],
    ) -> tuple[
        list[Any],
        _TteEnvelope,
        TranslationDiagnostic | None,
    ]:
        """Peel off a proposition-final generalized ``tte`` construction."""

        core = list(words)
        for forms in EPISTEMIC_FORM_PATTERNS:
            width = len(forms)
            if len(core) <= width:
                continue
            suffix = tuple(token.normalized for token in core[-width:])
            if suffix != forms:
                continue
            tokens = core[-width:]
            stance = EPISTEMIC_STANCE_BY_FORMS[forms]
            return (
                core[:-width],
                _TteEnvelope(
                    binder=TteBinder(
                        function=TteFunction.EPISTEMIC,
                        qualification=EpistemicQualification(
                            stance=stance,
                            forms=forms,
                        ),
                    ),
                    token_indices=tuple(token.index for token in tokens),
                ),
                None,
            )

        if len(core) > 1 and core[-1].normalized == "tte":
            token = core[-1]
            return (
                core[:-1],
                _TteEnvelope(
                    binder=TteBinder(function=TteFunction.BARE),
                    token_indices=(token.index,),
                ),
                None,
            )
        return core, _TteEnvelope(), None

    @staticmethod
    def _apply_tte_envelope(
        reading: _ClauseReading,
        envelope: _TteEnvelope,
    ) -> _ClauseReading:
        if envelope.is_empty:
            return reading
        binder = envelope.binder
        if binder is None:
            return reading
        roles = dict(reading.roles)
        for position, index in enumerate(envelope.token_indices):
            roles[index] = (
                "epistemic-quotative"
                if position == 0
                else "epistemic-predicate"
            )
        return replace(
            reading,
            clause=replace(
                reading.clause,
                tte_binder=binder,
            ),
            output_text=_render_tte_english(
                reading.output_text,
                envelope,
            ),
            roles=tuple(sorted(roles.items())),
            ambiguities=(
                *reading.ambiguities,
                *(
                    (ExpandedAsaxiClauseParser._tte_cognizer_ambiguity(),)
                    if (
                        binder.function is TteFunction.EPISTEMIC
                        and binder.cognizer_omitted
                    )
                    else ()
                ),
            ),
            rule_trace=(
                *reading.rule_trace,
                "clause.tte-binder",
                f"tte.{binder.function.value}",
                *(
                    (f"epistemic.{binder.qualification.stance.value}",)
                    if binder.qualification is not None
                    else ()
                ),
            ),
        )

    @staticmethod
    def _apply_tte_envelope_to_alternative(
        alternative: TranslationAlternative,
        envelope: _TteEnvelope,
    ) -> TranslationAlternative:
        if envelope.is_empty:
            return alternative
        binder = envelope.binder
        if binder is None:
            return alternative
        roles = {
            index: (
                "epistemic-quotative"
                if position == 0
                else "epistemic-predicate"
            )
            for position, index in enumerate(envelope.token_indices)
        }
        return replace(
            alternative,
            canonical_clause=replace(
                alternative.canonical_clause,
                tte_binder=binder,
            ),
            output_text=_render_tte_english(
                alternative.output_text,
                envelope,
            ),
            tokens=tuple(
                replace(token, role=roles.get(token.index, token.role))
                for token in alternative.tokens
            ),
            ambiguities=(
                *alternative.ambiguities,
                *(
                    (ExpandedAsaxiClauseParser._tte_cognizer_ambiguity(),)
                    if (
                        binder.function is TteFunction.EPISTEMIC
                        and binder.cognizer_omitted
                    )
                    else ()
                ),
            ),
            rule_trace=(
                *alternative.rule_trace,
                "clause.tte-binder",
                f"tte.{binder.function.value}",
                *(
                    (f"epistemic.{binder.qualification.stance.value}",)
                    if binder.qualification is not None
                    else ()
                ),
            ),
        )

    @staticmethod
    def _tte_scope_ambiguity(selected: str) -> TranslationAmbiguity:
        return TranslationAmbiguity(
            code="TTE_SCOPE_AMBIGUOUS",
            message=(
                "A final tte sequence after linked clauses can bind the "
                "complete coordination or only its final clause."
            ),
            choices=("complete-linked-proposition", "final-clause"),
            selected=selected,
        )

    @staticmethod
    def _tte_cognizer_ambiguity() -> TranslationAmbiguity:
        return TranslationAmbiguity(
            code="TTE_COGNIZER_OMITTED",
            message=(
                "The cognitive subject is omitted; discourse may identify "
                "the speaker or another salient cognizer."
            ),
            choices=("speaker", "discourse-context"),
            selected="speaker",
        )

    @staticmethod
    def _quote_english(
        proposition: str,
        matrix: str,
        *,
        quoted: bool,
    ) -> str:
        matrix_punctuation = (
            matrix[-1:] if matrix[-1:] in {".", "?", "!"} else "."
        )
        matrix_stem = _strip_terminal_punctuation(matrix)
        if quoted:
            quote = proposition.strip()
            if quote[-1:] not in {".", "?", "!"}:
                quote += "."
            reporting = _embedded_english_proposition(matrix)
            return f"“{quote}” {reporting}{matrix_punctuation}"
        embedded = _embedded_english_proposition(proposition)
        return f"{matrix_stem} that {embedded}."

    def _parse_interior_tte(
        self,
        text: str,
        tokens: Sequence[Any],
        words: Sequence[Any],
        tte_token: Any,
        *,
        discourse_state: DiscourseState | None,
    ) -> ExpandedParseOutcome:
        """Parse one documented topic, explanatory, or quotative binder."""

        left_tokens = tuple(
            token for token in tokens if token.index < tte_token.index
        )
        right_tokens = tuple(
            token for token in tokens if token.index > tte_token.index
        )
        left_words = tuple(
            token
            for token in words
            if token.index < tte_token.index
        )
        right_words = tuple(
            token
            for token in words
            if token.index > tte_token.index
        )
        if not left_words or not right_words:
            return ExpandedParseOutcome(())

        quoted = any(
            token.kind == "punctuation"
            and token.surface in {'"', "„", "“", "”", "«", "»"}
            for token in left_tokens
        )
        comma_after_marker = any(
            token.surface == ","
            and token.index == tte_token.index + 1
            for token in right_tokens
        )
        left_outcome = self.parse(
            " ".join(token.surface for token in left_tokens),
            left_tokens,
            discourse_state=discourse_state,
        )
        right_outcome = self.parse(
            " ".join(token.surface for token in right_tokens),
            right_tokens,
            discourse_state=None,
        )
        alternatives: list[TranslationAlternative] = []

        # A one-nominal left constituent followed by a comment is the
        # documented casual-topic construction. Quotation marks override this
        # reading because quoted one-word utterances are also attested.
        topic_readings = (
            self._parse_nominal_span(left_words, role="subject")
            if len(left_words) == 1 and not quoted
            else ()
        )
        if len(left_words) == 1 and not quoted and not topic_readings:
            token = left_words[0]
            topic_readings = (
                _NominalReading(
                    nominal=Nominal(token.surface),
                    english_text=token.surface[:1].upper() + token.surface[1:],
                    token_indices=(token.index,),
                    roles=((token.index, "tte-topic"),),
                    assumptions=(
                        TranslationAssumption(
                            code="TTE_TOPIC_LEXEME_UNRESOLVED",
                            message=(
                                "The binder licenses this surface as a topic, "
                                "but no compiled lexical gloss was available."
                            ),
                        ),
                    ),
                    rule_trace=("tte.topic-preserved-surface",),
                ),
            )
        for topic in topic_readings:
            topic_state = DiscourseState(
                topic=DiscourseReferent(
                    nominal=topic.nominal,
                    english_text=topic.english_text,
                )
            )
            comments = self.parse(
                " ".join(token.surface for token in right_tokens),
                right_tokens,
                discourse_state=topic_state,
            )
            for comment in comments.alternatives:
                binder = TteBinder(
                    function=TteFunction.TOPIC,
                    topic=topic.nominal,
                    comma_after_marker=comma_after_marker,
                )
                punctuation = (
                    comment.output_text[-1:]
                    if comment.output_text[-1:] in {".", "?", "!"}
                    else "."
                )
                output_text = (
                    f"As for {topic.english_text}, "
                    f"{_embedded_english_proposition(comment.output_text)}"
                    f"{punctuation}"
                )
                roles = {
                    **{
                        token.index: token.role
                        for token in comment.tokens
                        if token.role is not None
                    },
                    **dict(topic.roles),
                    tte_token.index: "tte-topic-binder",
                }
                reading = _ClauseReading(
                    clause=replace(
                        comment.canonical_clause,
                        tte_binder=binder,
                    ),
                    output_text=output_text,
                    roles=tuple(sorted(roles.items())),
                    predicate=None,
                    predicate_index=None,
                    subject_english=comment.output_text,
                    assumptions=(*topic.assumptions, *comment.assumptions),
                    ambiguities=(*topic.ambiguities, *comment.ambiguities),
                    rule_trace=(
                        "clause.tte-binder",
                        "tte.topic",
                        *topic.rule_trace,
                        *comment.rule_trace,
                    ),
                )
                alternatives.append(self._to_alternative(reading, tokens))

            if not comments.alternatives:
                comment_interrogative = any(
                    token.normalized == "kè" for token in right_words
                ) or any(
                    token.surface == "?" for token in right_tokens
                )
                comment_words = tuple(
                    token
                    for token in right_words
                    if token.normalized != "kè"
                )
                complements = self._parse_nominal_span(
                    comment_words,
                    role="complement",
                )
                for complement in complements:
                    binder = TteBinder(
                        function=TteFunction.TOPIC,
                        topic=topic.nominal,
                        comma_after_marker=comma_after_marker,
                    )
                    clause = CanonicalClause(
                        predicate="xiŕa",
                        complement=complement.nominal,
                        interrogative=comment_interrogative,
                        predicate_kind=PredicateKind.CONSTITUTION,
                        validity_mode=ValidityMode.ESSENTIAL,
                        zero_copula=True,
                        omitted_subject=True,
                        discourse_subject=True,
                        subject_marked=False,
                        tte_binder=binder,
                    )
                    copula = "Is" if comment_interrogative else "is"
                    output_text = (
                        f"{copula} {topic.english_text} "
                        f"{complement.english_text}"
                        f"{'?' if comment_interrogative else '.'}"
                    )
                    if not comment_interrogative:
                        output_text = f"As for {topic.english_text}, {output_text}"
                    else:
                        output_text = (
                            f"As for {topic.english_text}, "
                            f"{output_text[:1].lower() + output_text[1:]}"
                        )
                    roles = {
                        **dict(topic.roles),
                        **dict(complement.roles),
                        tte_token.index: "tte-topic-binder",
                        **{
                            token.index: "interrogative"
                            for token in right_words
                            if token.normalized == "kè"
                        },
                    }
                    reading = _ClauseReading(
                        clause=clause,
                        output_text=output_text,
                        roles=tuple(sorted(roles.items())),
                        predicate=None,
                        predicate_index=None,
                        subject_english=topic.english_text,
                        assumptions=(
                            *topic.assumptions,
                            *complement.assumptions,
                        ),
                        ambiguities=(
                            *topic.ambiguities,
                            *complement.ambiguities,
                        ),
                        rule_trace=(
                            "clause.tte-binder",
                            "tte.topic",
                            "copula.zero-omission",
                            *topic.rule_trace,
                            *complement.rule_trace,
                        ),
                    )
                    alternatives.append(
                        self._to_alternative(reading, tokens)
                    )

        for bound, matrix in itertools.product(
            left_outcome.alternatives,
            right_outcome.alternatives,
        ):
            matrix_is_clause = (
                quoted
                or matrix.canonical_clause.predicate_kind
                is PredicateKind.ACTION
                or matrix.canonical_clause.subject is not None
            )
            if matrix_is_clause:
                binder = TteBinder(
                    function=TteFunction.QUOTATIVE,
                    matrix_clause=matrix.canonical_clause,
                    quoted=quoted,
                    comma_after_marker=comma_after_marker,
                    cognizer=matrix.canonical_clause.subject,
                    cognizer_omitted=(
                        matrix.canonical_clause.subject is None
                    ),
                )
                output_text = self._quote_english(
                    bound.output_text,
                    matrix.output_text,
                    quoted=quoted,
                )
                trace_kind = "tte.quotative"
            else:
                fragment = Nominal(
                    " ".join(token.normalized for token in right_words)
                )
                binder = TteBinder(
                    function=TteFunction.EXPLANATORY,
                    matrix_fragment=fragment,
                    comma_after_marker=True,
                )
                output_text = (
                    f"{_strip_terminal_punctuation(bound.output_text)}, so "
                    f"{_embedded_english_proposition(matrix.output_text)}."
                )
                trace_kind = "tte.explanatory"
            roles = {
                **{
                    token.index: token.role
                    for token in (*bound.tokens, *matrix.tokens)
                    if token.role is not None
                },
                tte_token.index: "tte-binder",
            }
            reading = _ClauseReading(
                clause=replace(bound.canonical_clause, tte_binder=binder),
                output_text=output_text,
                roles=tuple(sorted(roles.items())),
                predicate=None,
                predicate_index=None,
                subject_english=bound.output_text,
                assumptions=(*bound.assumptions, *matrix.assumptions),
                ambiguities=(*bound.ambiguities, *matrix.ambiguities),
                rule_trace=(
                    "clause.tte-binder",
                    trace_kind,
                    *bound.rule_trace,
                    *matrix.rule_trace,
                ),
            )
            alternatives.append(self._to_alternative(reading, tokens))

        # Explanatory result fragments need not be independently finite.
        if left_outcome.alternatives and not right_outcome.alternatives:
            result_nominals = self._parse_nominal_span(
                right_words,
                role="complement",
            )
            for bound, result in itertools.product(
                left_outcome.alternatives,
                result_nominals,
            ):
                binder = TteBinder(
                    function=TteFunction.EXPLANATORY,
                    matrix_fragment=result.nominal,
                    comma_after_marker=True,
                )
                roles = {
                    **{
                        token.index: token.role
                        for token in bound.tokens
                        if token.role is not None
                    },
                    **dict(result.roles),
                    tte_token.index: "tte-explanatory-binder",
                }
                reading = _ClauseReading(
                    clause=replace(bound.canonical_clause, tte_binder=binder),
                    output_text=(
                        f"{_strip_terminal_punctuation(bound.output_text)}, "
                        f"so it is {result.english_text}."
                    ),
                    roles=tuple(sorted(roles.items())),
                    predicate=None,
                    predicate_index=None,
                    subject_english=bound.output_text,
                    assumptions=(*bound.assumptions, *result.assumptions),
                    ambiguities=(*bound.ambiguities, *result.ambiguities),
                    rule_trace=(
                        "clause.tte-binder",
                        "tte.explanatory",
                        *bound.rule_trace,
                        *result.rule_trace,
                    ),
                )
                alternatives.append(self._to_alternative(reading, tokens))

        if alternatives:
            return ExpandedParseOutcome(
                tuple(alternatives[:MAX_CLAUSE_ALTERNATIVES])
            )
        return ExpandedParseOutcome(
            (),
            TranslationDiagnostic(
                code="TTE_CONSTRUCTION_UNRESOLVED",
                severity=Severity.ERROR,
                message=(
                    "tte was preserved, but its bound constituent or following "
                    "comment could not be analyzed by the documented grammar."
                ),
                token_index=tte_token.index,
            ),
        )

    @staticmethod
    def _apply_pragmatic_envelope(
        reading: _ClauseReading,
        envelope: _PragmaticEnvelope,
    ) -> _ClauseReading:
        if envelope.is_empty:
            return reading
        roles = dict(reading.roles)
        trace = list(reading.rule_trace)
        if envelope.preclausal is not None:
            roles[envelope.preclausal_index] = "preclausal-marker"
            trace.extend(
                (
                    "pragmatics.preclausal-marker",
                    "pragmatics.preclausal."
                    + envelope.preclausal.kind.value,
                )
            )
        if envelope.discourse is not None:
            roles[envelope.discourse_index] = "discourse-marker"
            trace.extend(
                (
                    "post-verbal.discourse",
                    "discourse." + envelope.discourse.kind.value,
                )
            )
        return replace(
            reading,
            clause=replace(
                reading.clause,
                preclausal_marker=envelope.preclausal,
                discourse_marker=envelope.discourse,
            ),
            output_text=_render_pragmatic_english(
                reading.output_text,
                envelope,
            ),
            roles=tuple(sorted(roles.items())),
            rule_trace=tuple(trace),
        )

    @staticmethod
    def _apply_pragmatic_envelope_to_alternative(
        alternative: TranslationAlternative,
        envelope: _PragmaticEnvelope,
    ) -> TranslationAlternative:
        if envelope.is_empty:
            return alternative
        role_by_index = {
            envelope.preclausal_index: "preclausal-marker",
            envelope.discourse_index: "discourse-marker",
        }
        role_by_index.pop(None, None)
        clause = alternative.canonical_clause
        trace = list(alternative.rule_trace)
        if envelope.preclausal is not None:
            trace.extend(
                (
                    "pragmatics.preclausal-marker",
                    "pragmatics.preclausal."
                    + envelope.preclausal.kind.value,
                )
            )
        if envelope.discourse is not None:
            trace.extend(
                (
                    "post-verbal.discourse",
                    "discourse." + envelope.discourse.kind.value,
                )
            )
        return replace(
            alternative,
            canonical_clause=replace(
                clause,
                preclausal_marker=envelope.preclausal,
                discourse_marker=envelope.discourse,
            ),
            output_text=_render_pragmatic_english(
                alternative.output_text,
                envelope,
            ),
            tokens=tuple(
                replace(token, role=role_by_index.get(token.index, token.role))
                for token in alternative.tokens
            ),
            rule_trace=tuple(trace),
        )

    def parse(
        self,
        text: str,
        tokens: Sequence[Any],
        *,
        discourse_state: DiscourseState | None = None,
    ) -> ExpandedParseOutcome:
        words = [
            token for token in tokens
            if token.kind in {"word", "number"}
        ]
        if not words:
            return ExpandedParseOutcome(())

        question_indices: set[int] = {
            token.index
            for token in tokens
            if token.surface == "?"
        }
        comma_indices: set[int] = {
            token.index for token in tokens if token.surface == ","
        }
        tte_probe_words = (
            words[:-1]
            if words[-1].normalized in DISCOURSE_MARKER_BY_FORM
            else words
        )
        epistemic_suffix = any(
            len(tte_probe_words) > len(forms)
            and tuple(
                token.normalized
                for token in tte_probe_words[-len(forms):]
            ) == forms
            for forms in EPISTEMIC_FORM_PATTERNS
        )
        interior_tte = [
            token
            for token in words[:-1]
            if token.normalized == "tte"
        ]
        if interior_tte and not epistemic_suffix:
            return self._parse_interior_tte(
                text,
                tokens,
                words,
                interior_tte[-1],
                discourse_state=discourse_state,
            )

        contains_connector = any(
            token.normalized in CONNECTORS
            for token in words[1:-1]
        )
        words, pragmatic_envelope = self._extract_pragmatic_envelope(
            words,
            comma_indices,
            extract_discourse=not contains_connector,
        )
        (
            words,
            tte_envelope,
            tte_diagnostic,
        ) = self._extract_tte_envelope(words)
        if tte_diagnostic is not None:
            return ExpandedParseOutcome((), tte_diagnostic)
        interrogative = False
        if not contains_connector:
            words, interrogative = self._extract_inquiry(
                words,
                question_indices,
                pragmatic_envelope.discourse,
            )
        if (
            not tte_envelope.is_empty
            and tte_envelope.binder is not None
            and tte_envelope.binder.function is TteFunction.EPISTEMIC
            and interrogative
        ):
            return ExpandedParseOutcome(
                (),
                TranslationDiagnostic(
                    code="EPISTEMIC_PROPOSITION_MUST_BE_STATEMENT",
                    severity=Severity.ERROR,
                    message=(
                        "The documented tte construction qualifies a statement. "
                        "Use an outer agreement or skepticism discourse marker "
                        "for a tag question."
                    ),
                    token_index=tte_envelope.token_indices[0],
                ),
            )
        if not words:
            return ExpandedParseOutcome(())

        source_conflict_diagnostic = self._source_conflict_diagnostic(words)
        if source_conflict_diagnostic is not None:
            return ExpandedParseOutcome((), source_conflict_diagnostic)

        connector_positions = [
            index
            for index, token in enumerate(words)
            if token.normalized in CONNECTORS
            and index > 0
            and index + 1 < len(words)
        ]
        if connector_positions:
            connector_position = connector_positions[0]
            left_words, left_pragmatics = self._extract_pragmatic_envelope(
                words[:connector_position],
                comma_indices,
                extract_preclausal=False,
            )
            connector_token = words[connector_position]
            right_words, right_pragmatics = self._extract_pragmatic_envelope(
                words[connector_position + 1:],
                comma_indices,
                extract_preclausal=False,
            )
            left_question_indices = {
                index for index in question_indices
                if index < connector_token.index
            }
            right_question_indices = {
                index for index in question_indices
                if index > connector_token.index
            }
            left_words, left_interrogative = self._extract_inquiry(
                left_words,
                left_question_indices,
                left_pragmatics.discourse,
            )
            right_words, right_interrogative = self._extract_inquiry(
                right_words,
                right_question_indices,
                right_pragmatics.discourse,
            )
            left = [
                self._apply_pragmatic_envelope(reading, left_pragmatics)
                for reading in self._parse_single(
                left_words,
                interrogative=left_interrogative,
                question_indices=left_question_indices,
                comma_indices=comma_indices,
                discourse_state=discourse_state,
                )
            ]
            combined: list[TranslationAlternative] = []
            final_scope_combined: list[TranslationAlternative] = []
            for first in left:
                independent_right = [
                    self._apply_pragmatic_envelope(reading, right_pragmatics)
                    for reading in self._parse_single(
                        right_words,
                        interrogative=right_interrogative,
                        question_indices=right_question_indices,
                        comma_indices=comma_indices,
                        discourse_state=None,
                    )
                ]
                linked_state = self._linked_discourse_state(
                    first,
                    discourse_state,
                )
                needs_context = (
                    not independent_right
                    or any(
                        reading.clause.omitted_subject
                        for reading in independent_right
                    )
                )
                contextual_right = (
                    [
                        self._apply_pragmatic_envelope(
                            reading,
                            right_pragmatics,
                        )
                        for reading in self._parse_single(
                            right_words,
                            interrogative=right_interrogative,
                            question_indices=right_question_indices,
                            comma_indices=comma_indices,
                            discourse_state=linked_state,
                        )
                    ]
                    if linked_state is not None and needs_context
                    else []
                )
                explicit_right = [
                    reading
                    for reading in independent_right
                    if not reading.clause.omitted_subject
                ]
                right = [
                    *explicit_right,
                    *contextual_right,
                ]
                if not right:
                    right = independent_right
                combined.extend(
                    self._coordinate(
                        (first,),
                        right,
                        connector_token,
                        tokens,
                    )
                )
                if not tte_envelope.is_empty:
                    qualified_right = [
                        self._apply_tte_envelope(reading, tte_envelope)
                        for reading in right
                    ]
                    final_scope_combined.extend(
                        self._coordinate(
                            (first,),
                            qualified_right,
                            connector_token,
                            tokens,
                        )
                    )
            if combined:
                root_scoped: list[TranslationAlternative] = []
                for alternative in combined:
                    qualified = self._apply_tte_envelope_to_alternative(
                        alternative,
                        tte_envelope,
                    )
                    if not tte_envelope.is_empty:
                        qualified = replace(
                            qualified,
                            ambiguities=(
                                *qualified.ambiguities,
                                self._tte_scope_ambiguity(
                                    "complete-linked-proposition"
                                ),
                            ),
                        )
                    root_scoped.append(qualified)
                final_scoped = [
                    replace(
                        alternative,
                        ambiguities=(
                            *alternative.ambiguities,
                            self._tte_scope_ambiguity("final-clause"),
                        ),
                    )
                    for alternative in final_scope_combined
                ]
                return ExpandedParseOutcome(
                    tuple(
                        self._apply_pragmatic_envelope_to_alternative(
                            alternative,
                            pragmatic_envelope,
                        )
                        for alternative in (
                            *root_scoped,
                            *final_scoped,
                        )[:MAX_CLAUSE_ALTERNATIVES]
                    )
                )

        wh_diagnostic = self._wh_constraint_diagnostic(words)
        if wh_diagnostic is not None:
            return ExpandedParseOutcome((), wh_diagnostic)

        readings = self._parse_single(
            words,
            interrogative=interrogative,
            question_indices=question_indices,
            comma_indices=comma_indices,
            discourse_state=discourse_state,
        )
        if not readings:
            if sum(
                token.normalized == "ja" for token in words
            ) > 1:
                return ExpandedParseOutcome(
                    (),
                    TranslationDiagnostic(
                        code="NONFINAL_NOMINAL_CONNECTOR",
                        severity=Severity.ERROR,
                        message=(
                            "A nominal list may contain one ja connector, "
                            "placed before its final member. Repeated ja "
                            "inside one unresolved argument is not silently "
                            "nested."
                        ),
                        token_index=next(
                            token.index
                            for token in words
                            if token.normalized == "ja"
                        ),
                    ),
                )
            determiner_diagnostic = (
                self._determiner_constraint_diagnostic(words)
            )
            if determiner_diagnostic is not None:
                return ExpandedParseOutcome((), determiner_diagnostic)
            binding_diagnostic = (
                self._closed_pronoun_constraint_diagnostic(words)
            )
            if binding_diagnostic is not None:
                return ExpandedParseOutcome((), binding_diagnostic)
            vicinity_diagnostic = self._vicinity_constraint_diagnostic(words)
            if vicinity_diagnostic is not None:
                return ExpandedParseOutcome((), vicinity_diagnostic)
            physicality_diagnostic = (
                self._physical_spatial_constraint_diagnostic(words)
            )
            if physicality_diagnostic is not None:
                return ExpandedParseOutcome((), physicality_diagnostic)
            specificity_diagnostic = (
                self._essential_location_subject_diagnostic(words)
            )
            if specificity_diagnostic is not None:
                return ExpandedParseOutcome((), specificity_diagnostic)
            source_conflict_diagnostic = self._source_conflict_diagnostic(words)
            if source_conflict_diagnostic is not None:
                return ExpandedParseOutcome((), source_conflict_diagnostic)
            causative_diagnostic = self._causative_constraint_diagnostic(words)
            if causative_diagnostic is not None:
                return ExpandedParseOutcome((), causative_diagnostic)
            predicate_shape_diagnostic = (
                self._predicate_shape_diagnostic(words)
            )
            if predicate_shape_diagnostic is not None:
                return ExpandedParseOutcome((), predicate_shape_diagnostic)
            validity_diagnostic = self._validity_constraint_diagnostic(words)
            if validity_diagnostic is not None:
                return ExpandedParseOutcome((), validity_diagnostic)
            unknown_predicate_diagnostic = (
                self._unknown_marked_predicate_diagnostic(words)
            )
            if unknown_predicate_diagnostic is not None:
                return ExpandedParseOutcome((), unknown_predicate_diagnostic)
            if (
                len(words) == 1
                and self._predicate_readings(words[0].normalized)
                and discourse_state is None
            ):
                return ExpandedParseOutcome(
                    (),
                    TranslationDiagnostic(
                        code="DISCOURSE_TOPIC_REQUIRED",
                        severity=Severity.ERROR,
                        message=(
                            "This pro-drop clause has no overt argument. "
                            "Supply an explicit discourse topic to resolve it."
                        ),
                        token_index=words[0].index,
                    ),
                )
            return ExpandedParseOutcome(())
        return ExpandedParseOutcome(
            tuple(
                self._to_alternative(
                    self._apply_pragmatic_envelope(
                    self._apply_tte_envelope(
                        reading,
                        tte_envelope,
                        ),
                        pragmatic_envelope,
                    ),
                    tokens,
                )
                for reading in readings
            )
        )

    def _determiner_constraint_diagnostic(
        self,
        words: Sequence[Any],
    ) -> TranslationDiagnostic | None:
        """Report a locally provable determiner/head class mismatch."""

        for position, determiner in enumerate(words[:-1]):
            determiner_form = FUSED_SUBJECT_DETERMINERS.get(
                determiner.normalized,
                determiner.normalized,
            )
            if determiner_form not in DETERMINER_NOUN_CLASSES:
                continue
            required = DETERMINER_NOUN_CLASSES[determiner_form]
            if required is None:
                continue
            head_token = words[position + 1]
            heads = self._parse_nominal_atom(head_token, role="subject")
            known_classes = tuple(
                sorted(
                    {
                        head.nominal.noun_class
                        for head in heads
                        if head.nominal.noun_class is not None
                    }
                )
            )
            if known_classes and required not in known_classes:
                observed = ", ".join(known_classes)
                return TranslationDiagnostic(
                    code="DETERMINER_NOUN_CLASS_MISMATCH",
                    severity=Severity.ERROR,
                    message=(
                        f"The determiner {determiner_form!r} in "
                        f"{determiner.surface!r} requires a "
                        f"{required} nominal head, but "
                        f"{head_token.surface!r} is classified as {observed}."
                    ),
                    token_index=determiner.index,
                )
        return None

    def _closed_pronoun_constraint_diagnostic(
        self,
        words: Sequence[Any],
    ) -> TranslationDiagnostic | None:
        """Explain failed reflexive/reciprocal binding in simple SOV clauses.

        This is deliberately a diagnostic pass after ordinary parsing fails.
        It does not invent a parse: it only reports a constraint when the
        overt subject span and the closed dependent form are independently
        recognizable.
        """

        for position, token in enumerate(words):
            if token.normalized not in (
                REFLEXIVE_PRONOUNS | RECIPROCAL_PRONOUNS
            ):
                continue
            subject_start = (
                1
                if words
                and words[0].normalized in SUBJECT_MARKERS
                else 0
            )
            if position <= subject_start:
                return TranslationDiagnostic(
                    code="BOUND_PRONOUN_REQUIRES_OBJECT_POSITION",
                    severity=Severity.ERROR,
                    message=(
                        "Reflexive and reciprocal pronouns occupy a dependent "
                        "object position and cannot serve as the overt subject."
                    ),
                    token_index=token.index,
                )
            subjects = self._parse_nominal_span(
                words[subject_start:position],
                role="subject",
            )
            dependents = self._parse_closed_pronoun(
                token,
                role="object",
            )
            if not subjects or not dependents:
                continue
            issues = tuple(
                issue
                for subject, dependent in itertools.product(
                    subjects,
                    dependents,
                )
                if (
                    issue := pronoun_binding_issue(
                        subject.nominal,
                        dependent.nominal,
                    )
                )
                is not None
            )
            if not issues:
                continue
            code, message = sorted(set(issues))[0]
            return TranslationDiagnostic(
                code=code,
                severity=Severity.ERROR,
                message=message,
                token_index=token.index,
            )
        return None

    @staticmethod
    def _vicinity_constraint_diagnostic(
        words: Sequence[Any],
    ) -> TranslationDiagnostic | None:
        """Explain a vicinity noun paired with a non-centering predicate."""

        if len(words) < 2:
            return None
        predicate = words[-1]
        if (
            predicate.normalized
            not in {
                *SPATIAL_PREDICATES,
                *TOPOLOGICAL_VALIDITY_PREDICATES,
            }
            or predicate.normalized in VICINITY_LOCATION_PREDICATES
        ):
            return None
        vicinity = next(
            (
                token
                for token in words[:-1]
                if token.normalized in VICINITY_NOMINAL_MODIFIERS
            ),
            None,
        )
        if vicinity is None:
            return None
        return TranslationDiagnostic(
            code="VICINITY_REQUIRES_CENTER_PREDICATE",
            severity=Severity.ERROR,
            message=(
                f"The vicinity noun {vicinity.surface!r} denotes an abstract "
                "area around a deictic center. Use the documented ỏnů "
                "(current/active) or ỏŕa (essential/stative) predicate; "
                f"{predicate.surface!r} treats it as an ordinary landmark."
            ),
            token_index=predicate.index,
        )

    def _physical_spatial_constraint_diagnostic(
        self,
        words: Sequence[Any],
    ) -> TranslationDiagnostic | None:
        """Explain a physical spatial predicate applied to an abstract noun."""

        if len(words) < 2:
            return None
        predicate = words[-1]
        if predicate.normalized not in {
            *SPATIAL_PREDICATES,
            *TOPOLOGICAL_VALIDITY_PREDICATES,
        }:
            return None
        landmark = words[-2]
        readings = self._parse_nominal_atom(landmark, role="location")
        if not any(
            self._nominal_spatial_physicality(reading.nominal)
            == SPATIAL_ABSTRACT
            for reading in readings
        ):
            return None
        return TranslationDiagnostic(
            code="ASAXI_ABSTRACT_SPATIAL_REQUIRES_NPCP",
            severity=Severity.ERROR,
            message=(
                f"{landmark.surface!r} is identified as an abstract landmark. "
                "The documented spatial prefixes and predicates are "
                "physical-only; select the appropriate NPCP relation instead."
            ),
            token_index=landmark.index,
            details={
                "landmark": landmark.normalized,
                "rejected_predicate": predicate.normalized,
                "physicality": SPATIAL_ABSTRACT,
            },
        )

    @staticmethod
    def _essential_location_subject_diagnostic(
        words: Sequence[Any],
    ) -> TranslationDiagnostic | None:
        """Reject a known nonspecific subject under essential location."""

        if len(words) < 2:
            return None
        predicate = words[-1]
        essential_location = (
            predicate.normalized in TOPOLOGICAL_VALIDITY_PREDICATES
            or predicate.normalized
            in {
                "oxiŕa",
                "noxiŕa",
                "koxiŕa",
                "o-xiŕa",
                "no-xiŕa",
                "ko-xiŕa",
                "onèŕa",
            }
        )
        if not essential_location:
            return None
        first = words[0]
        fused = FUSED_SUBJECT_DETERMINERS.get(first.normalized)
        subject_start = 1 if first.normalized in SUBJECT_MARKERS else 0
        nonspecific = (
            fused == "anő"
            or (
                subject_start < len(words) - 1
                and words[subject_start].normalized in {"anő", "mămă"}
            )
        )
        if not nonspecific:
            return None
        return TranslationDiagnostic(
            code="ESSENTIAL_LOCATION_REQUIRES_SPECIFIC_SUBJECT",
            severity=Severity.ERROR,
            message=(
                "Essential -ŕa location defines a stable relation for a "
                "specific subject. This subject is explicitly indefinite or "
                "universal, and no category-definition reading was selected. "
                "Use the corresponding circumstantial or active location."
            ),
            token_index=first.index,
        )

    def _wh_constraint_diagnostic(
        self,
        words: Sequence[Any],
    ) -> TranslationDiagnostic | None:
        """Reject wh layouts whose documented answer slots are unresolved."""

        wh_tokens = tuple(
            token for token in words if token.normalized in WH_WORDS
        )
        if len(wh_tokens) > 1:
            return TranslationDiagnostic(
                code="MULTIPLE_WH_SLOT_UNRESOLVED",
                severity=Severity.ERROR,
                message=(
                    "This clause contains more than one wh form, but the "
                    "documented grammar does not establish a unique answer "
                    "slot for each one. Every form is retained in the "
                    "best-effort gloss without inventing those roles."
                ),
                token_index=wh_tokens[1].index,
            )
        if not wh_tokens:
            return None
        wh_token = wh_tokens[0]
        wh_position = next(
            index
            for index, token in enumerate(words)
            if token.index == wh_token.index
        )
        # Wh forms are in situ before a clause-final predicate.  Earlier
        # lexical material may itself have a predicate reading, so only a wh
        # stranded at the end provides reliable evidence of post-predicate
        # placement.
        if wh_position != len(words) - 1:
            return None
        preceding_predicate = next(
            (
                token
                for token in words[:wh_position]
                if self._all_predicate_readings(token.normalized)
                and not self._parse_nominal_atom(token, role="object")
            ),
            None,
        )
        if preceding_predicate is None:
            return None
        return TranslationDiagnostic(
            code="WH_NOT_IN_SITU",
            severity=Severity.ERROR,
            message=(
                "An Asaxi wh form occupies the position where its answer "
                "would occur. This wh form follows an already recognized "
                "predicate, so its argument role cannot be licensed."
            ),
            token_index=wh_token.index,
            details={"preceding_predicate_index": preceding_predicate.index},
        )

    def _unknown_marked_predicate_diagnostic(
        self,
        words: Sequence[Any],
    ) -> TranslationDiagnostic | None:
        """Identify the unambiguous predicate slot in a marked clause."""

        if len(words) < 3:
            return None
        if (
            words[0].normalized not in SUBJECT_MARKERS
            and words[0].normalized not in FUSED_SUBJECT_DETERMINERS
        ):
            return None
        predicate_token = words[-1]
        if predicate_token.normalized in WH_WORDS:
            return None
        if self._all_predicate_readings(predicate_token.normalized):
            return None
        return TranslationDiagnostic(
            code="PREDICATE_NOT_RECOGNIZED",
            severity=Severity.ERROR,
            message=(
                "The explicitly marked clause has a clause-final predicate "
                "slot, but no documented lexical predicate analysis was "
                f"found for {predicate_token.surface!r}. The token is "
                "retained unchanged in the best-effort translation."
            ),
            token_index=predicate_token.index,
        )

    def _predicate_shape_diagnostic(
        self,
        words: Sequence[Any],
    ) -> TranslationDiagnostic | None:
        """Explain recognized final predicates that lack required structure."""

        if not words:
            return None
        predicate_token = words[-1]
        readings = self._all_predicate_readings(predicate_token.normalized)
        if not readings:
            return None
        if any(reading.directive_form is not None for reading in readings) and any(
            token.normalized in SUBJECT_MARKERS
            or token.normalized in FUSED_SUBJECT_DETERMINERS
            for token in words[:-1]
        ):
            return TranslationDiagnostic(
                code="DIRECTIVE_OVERT_SUBJECT_NOT_LICENSED",
                severity=Severity.ERROR,
                message=(
                    "The documented directive construction has an implicit "
                    "addressee or an overt vocative, not a to-marked "
                    "grammatical subject. The directive force is retained "
                    "in the best-effort gloss."
                ),
                token_index=predicate_token.index,
            )

        argument_words = list(words[:-1])
        if argument_words and (
            argument_words[0].normalized in SUBJECT_MARKERS
            or argument_words[0].normalized in FUSED_SUBJECT_DETERMINERS
        ):
            argument_words = argument_words[1:]
        requires_complement = readings and all(
            reading.requires_complement or reading.takes_complement is True
            for reading in readings
        )
        if requires_complement and len(argument_words) < 2:
            return TranslationDiagnostic(
                code="PREDICATE_COMPLEMENT_REQUIRED",
                severity=Severity.ERROR,
                message=(
                    "The recognized predicate requires a complement in "
                    "addition to its subject. The attempted translation "
                    "shows the missing role explicitly."
                ),
                token_index=predicate_token.index,
            )
        return None

    def _source_conflict_diagnostic(
        self,
        words: Sequence[Any],
    ) -> TranslationDiagnostic | None:
        """Expose contradictory source examples instead of guessing a rule."""

        if not words:
            return None
        predicate = words[-1]
        if predicate.normalized in {"vaxiŕa", "vanèŕa"}:
            return TranslationDiagnostic(
                code="SOURCE_CONFLICT_TOPOLOGICAL_VALIDITY_FORM",
                severity=Severity.ERROR,
                message=(
                    "Note 21's summary table uses this xi-bearing form, but "
                    "its replacement rule and Note 20 attest vaŕa. The "
                    "Workshop preserves that contradiction for review and "
                    "does not silently choose a negative/topological paradigm."
                ),
                token_index=predicate.index,
            )
        if predicate.normalized == "måmåŕa":
            verbal_token = next(
                (
                    token
                    for token in words[1:-1]
                    if any(
                        reading.kind is PredicateKind.ACTION
                        for reading in self._predicate_readings(
                            token.normalized
                        )
                    )
                ),
                None,
            )
            if verbal_token is not None:
                return TranslationDiagnostic(
                    code="SOURCE_CONFLICT_BARE_VERB_EVENT_NOMINAL",
                    severity=Severity.ERROR,
                    message=(
                        "The terminative example in Note 20 places a bare "
                        "verb inside the subject phrase, while the dedicated "
                        "verbal-nominal rule requires anő. The Workshop keeps "
                        "the example visible as a source conflict instead of "
                        "inventing a phrase-specific nominalization rule."
                    ),
                    token_index=verbal_token.index,
                )
        return None

    @staticmethod
    def _validity_constraint_diagnostic(
        words: Sequence[Any],
    ) -> TranslationDiagnostic | None:
        """Reject a bound Slot-A prefix used as a bare predicate."""

        if len(words) < 2:
            return None
        token = words[-1]
        if token.normalized not in BOUND_VALIDITY_PREFIXES:
            return None
        return TranslationDiagnostic(
            code="BOUND_VALIDITY_PREFIX_CANNOT_STAND_ALONE",
            severity=Severity.ERROR,
            message=(
                f"{token.surface!r} is a bound validity prefix. It must retain "
                "the documented definition/validity material and cannot be "
                "used as an independent predicate."
            ),
            token_index=token.index,
        )

    def _causative_constraint_diagnostic(
        self,
        words: Sequence[Any],
    ) -> TranslationDiagnostic | None:
        """Explain a recognized causative predicate without its ``bă`` causer."""

        causative_tokens = tuple(
            token
            for token in words
            if any(
                reading.causative_voice is not None
                for reading in self._predicate_readings(token.normalized)
            )
        )
        if not causative_tokens:
            return None
        causer_markers = tuple(
            token for token in words if token.normalized == "bă"
        )
        if not causer_markers:
            return TranslationDiagnostic(
                code="CAUSATIVE_CAUSER_REQUIRED",
                severity=Severity.ERROR,
                message=(
                    "The recognized causative voice requires a causer "
                    "introduced by bă. The overt grammatical subject remains "
                    "the causee/doer."
                ),
                token_index=causative_tokens[-1].index,
            )
        if len(causer_markers) > 1:
            return TranslationDiagnostic(
                code="CAUSATIVE_CAUSER_MARKER_AMBIGUOUS",
                severity=Severity.ERROR,
                message=(
                    "This bounded causative clause contains more than one bă "
                    "causer marker; their scopes cannot be selected silently."
                ),
                token_index=causer_markers[1].index,
            )
        return None

    def _build_verbalization_bases(
        self,
    ) -> dict[str, tuple[_VerbalizationBase, ...]]:
        """Compile every noun through the twelve documented ``-ů`` modes.

        This index is deliberately based on source noun lexemes rather than
        attested full-form verbs. A newly compiled noun therefore receives the
        productive grammar automatically, while a lexicalized derived verb can
        still contribute its more specific English sense separately.
        """

        work: dict[str, list[_VerbalizationBase]] = {}
        seen: set[tuple[str, str, VerbalizationMode]] = set()
        for lexeme in self.database.lexemes:
            if lexeme.category != "noun" or " " in lexeme.lemma:
                continue
            source_glosses = split_english_gloss(lexeme)
            if not source_glosses:
                continue
            source = Nominal(
                surface=lexeme.lemma,
                lexeme_id=lexeme.identifier,
                noun_class=(
                    str(lexeme.noun_class.value)
                    if lexeme.noun_class.is_present
                    else None
                ),
            )
            reduced = reduce_class_suffix(lexeme.lemma)
            for mode_spec in VERBALIZATION_MODE_SPECS:
                realization = verbalize_nominal(
                    reduced.surface,
                    bridge=mode_spec.bridge,
                    # Reduction applies only when the noun itself ends in a
                    # syllabic nasal. A class suffix may expose ``nn`` in the
                    # stem, but the source examples retain that stem intact.
                    reduce_syllabic_nasal=(
                        reduced.surface == lexeme.lemma
                    ),
                )
                explicit_derived_glosses: list[str] = []
                explicit_derived_term_ids: list[str] = []
                for term in lexeme.derived_terms:
                    if (
                        term.surface is None
                        or term.surface.casefold()
                        != realization.surface.casefold()
                        or term.category != "verb"
                        or term.status is SpecificationStatus.INCOMPLETE
                        or not term.gloss_en.is_present
                        or not term.gloss_en.value
                    ):
                        continue
                    explicit_derived_term_ids.append(term.identifier)
                    for gloss in split_english_gloss_value(
                        str(term.gloss_en.value)
                    ):
                        if gloss.casefold() not in {
                            value.casefold()
                            for value in explicit_derived_glosses
                        }:
                            explicit_derived_glosses.append(gloss)
                key = (
                    realization.surface,
                    lexeme.identifier,
                    mode_spec.mode,
                )
                if key in seen:
                    continue
                seen.add(key)
                work.setdefault(realization.surface, []).append(
                    _VerbalizationBase(
                        surface=realization.surface,
                        derivation=VerbalDerivation(
                            source=source,
                            mode=mode_spec.mode,
                            bridge=mode_spec.bridge,
                        ),
                        source_glosses=source_glosses,
                        explicit_derived_glosses=tuple(
                            explicit_derived_glosses
                        ),
                        explicit_derived_term_ids=tuple(
                            sorted(set(explicit_derived_term_ids))
                        ),
                        morphemes=(
                            (
                                *reduced.morphemes,
                                *realization.morphemes[1:],
                            )
                            if reduced.surface != lexeme.lemma
                            else realization.morphemes
                        ),
                        rule_trace=(
                            "verbalization.productive-noun-source",
                            "verbalization.mode."
                            + mode_spec.mode.value,
                            "verbalization.activity-aspect",
                            *reduced.rule_trace,
                            *realization.rule_trace,
                        ),
                    )
                )
        return {
            surface: tuple(
                sorted(
                    bases,
                    key=lambda base: (
                        base.derivation.source.lexeme_id or "",
                        base.derivation.mode.value,
                    ),
                )
            )
            for surface, bases in work.items()
        }

    @staticmethod
    def _expanded_verbalization_morphemes(
        realization_morphemes: Sequence[str],
        base: _VerbalizationBase,
    ) -> tuple[str, ...]:
        expanded: list[str] = []
        for morpheme in realization_morphemes:
            if morpheme == base.surface:
                expanded.extend(base.morphemes)
            else:
                expanded.append(morpheme)
        return tuple(expanded)

    def _productive_verbalization_predicates(
        self,
        surface: str,
    ) -> tuple[_PredicateReading, ...]:
        """Recover a productive base without scanning all noun derivations."""

        if surface in self._productive_predicate_cache:
            return self._productive_predicate_cache[surface]
        readings: list[_PredicateReading] = []
        seen: set[tuple[str, str, str, str, str]] = set()
        sentinel = "Q"
        for tense, polarity, modality in itertools.product(
            tuple(Tense),
            tuple(Polarity),
            tuple(Modality),
        ):
            frame = realize_verb_complex(
                VerbComplexSpec(
                    root=sentinel,
                    tense=CANONICAL_TENSE_TO_VERB[tense],
                    polarity=CANONICAL_POLARITY_TO_VERB[polarity],
                    mood=CANONICAL_MODALITY_TO_VERB[modality],
                    root_kind=VerbRootKind.DERIVED,
                )
            )
            prefix, suffix = frame.surface.split(sentinel)
            if not surface.startswith(prefix) or (
                suffix and not surface.endswith(suffix)
            ):
                continue
            end = len(surface) - len(suffix) if suffix else len(surface)
            base_surface = surface[len(prefix):end]
            if not base_surface:
                continue
            for base in self._verbalization_bases.get(base_surface, ()):
                mode_spec = VERBALIZATION_MODE_BY_MODE[
                    base.derivation.mode
                ]
                realization = realize_verb_complex(
                    VerbComplexSpec(
                        root=base.surface,
                        tense=CANONICAL_TENSE_TO_VERB[tense],
                        polarity=CANONICAL_POLARITY_TO_VERB[polarity],
                        mood=CANONICAL_MODALITY_TO_VERB[modality],
                        root_kind=VerbRootKind.DERIVED,
                    )
                )
                if realization.surface != surface:
                    continue
                for explicit_gloss in base.explicit_derived_glosses:
                    key = (
                        base.derivation.source.lexeme_id or "",
                        base.derivation.mode.value,
                        "explicit:" + explicit_gloss,
                        tense.value,
                        polarity.value + ":" + modality.value,
                    )
                    if key in seen:
                        continue
                    seen.add(key)
                    readings.append(
                        _PredicateReading(
                            surface=surface,
                            lemma=base.surface,
                            kind=PredicateKind.ACTION,
                            english_glosses=(explicit_gloss,),
                            tense=tense,
                            polarity=polarity,
                            modality=modality,
                            takes_complement=False,
                            verbal_derivation=replace(
                                base.derivation,
                                attested_derived_term_id=(
                                    base.explicit_derived_term_ids[0]
                                ),
                                attested_derived_surface=base.surface,
                            ),
                            explicit_derived_term=True,
                            morphemes=(
                                self._expanded_verbalization_morphemes(
                                    realization.morphemes,
                                    base,
                                )
                            ),
                            rule_trace=(
                                "clause.explicit-derived-term",
                                "lexicon.explicit-derived-term-gloss",
                                *base.rule_trace,
                                *realization.rule_trace,
                            ),
                        )
                    )
                for source_gloss in base.source_glosses:
                    key = (
                        base.derivation.source.lexeme_id or "",
                        base.derivation.mode.value,
                        source_gloss,
                        tense.value,
                        polarity.value + ":" + modality.value,
                    )
                    if key in seen:
                        continue
                    seen.add(key)
                    readings.append(
                        _PredicateReading(
                            surface=surface,
                            lemma=base.surface,
                            kind=PredicateKind.ACTION,
                            english_glosses=(mode_spec.english_head,),
                            tense=tense,
                            polarity=polarity,
                            modality=modality,
                            takes_complement=mode_spec.takes_complement,
                            requires_complement=(
                                mode_spec.requires_complement
                            ),
                            verbal_derivation=base.derivation,
                            verbalization_source_gloss=source_gloss,
                            verbalization_source_glosses=(
                                base.source_glosses
                            ),
                            morphemes=(
                                self._expanded_verbalization_morphemes(
                                    realization.morphemes,
                                    base,
                                )
                            ),
                            rule_trace=(
                                "clause.productive-noun-verbalization",
                                *base.rule_trace,
                                *realization.rule_trace,
                            ),
                        )
                    )
        result = tuple(readings)
        self._productive_predicate_cache[surface] = result
        return result

    def _productive_causative_predicates(
        self,
        surface: str,
    ) -> tuple[_PredicateReading, ...]:
        """Recover causative voice over a productively derived predicate."""

        if surface in self._productive_causative_cache:
            return self._productive_causative_cache[surface]
        readings: list[_PredicateReading] = []
        seen: set[tuple[str, str, str, str, str, str]] = set()
        sentinel = "Q"
        for tense, causative_spec in itertools.product(
            tuple(Tense),
            CAUSATIVE_REALIZATIONS,
        ):
            (
                causative_voice,
                canonical_polarity,
                morphology_voice,
                morphology_polarity,
            ) = causative_spec
            frame = realize_verb_complex(
                VerbComplexSpec(
                    root=sentinel,
                    tense=CANONICAL_TENSE_TO_VERB[tense],
                    polarity=morphology_polarity,
                    voice=morphology_voice,
                    root_kind=VerbRootKind.DERIVED,
                )
            )
            prefix, suffix = frame.surface.split(sentinel)
            if not surface.startswith(prefix) or (
                suffix and not surface.endswith(suffix)
            ):
                continue
            end = len(surface) - len(suffix) if suffix else len(surface)
            base_surface = surface[len(prefix):end]
            if not base_surface:
                continue
            for base in self._verbalization_bases.get(base_surface, ()):
                mode_spec = VERBALIZATION_MODE_BY_MODE[
                    base.derivation.mode
                ]
                realization = realize_verb_complex(
                    VerbComplexSpec(
                        root=base.surface,
                        tense=CANONICAL_TENSE_TO_VERB[tense],
                        polarity=morphology_polarity,
                        voice=morphology_voice,
                        root_kind=VerbRootKind.DERIVED,
                    )
                )
                if realization.surface != surface:
                    continue
                for explicit_gloss in base.explicit_derived_glosses:
                    key = (
                        base.derivation.source.lexeme_id or "",
                        base.derivation.mode.value,
                        "explicit:" + explicit_gloss,
                        tense.value,
                        causative_voice.value,
                        canonical_polarity.value,
                    )
                    if key in seen:
                        continue
                    seen.add(key)
                    readings.append(
                        _PredicateReading(
                            surface=surface,
                            lemma=base.surface,
                            kind=PredicateKind.ACTION,
                            english_glosses=(explicit_gloss,),
                            tense=tense,
                            polarity=canonical_polarity,
                            causative_voice=causative_voice,
                            takes_complement=False,
                            verbal_derivation=base.derivation,
                            explicit_derived_term=True,
                            morphemes=(
                                self._expanded_verbalization_morphemes(
                                    realization.morphemes,
                                    base,
                                )
                            ),
                            rule_trace=(
                                "clause.explicit-derived-term",
                                "lexicon.explicit-derived-term-gloss",
                                "verb.causative-prefix-stack",
                                "clause.causative-agency",
                                "voice." + causative_voice.value,
                                *base.rule_trace,
                                *realization.rule_trace,
                            ),
                        )
                    )
                for source_gloss in base.source_glosses:
                    key = (
                        base.derivation.source.lexeme_id or "",
                        base.derivation.mode.value,
                        source_gloss,
                        tense.value,
                        causative_voice.value,
                        canonical_polarity.value,
                    )
                    if key in seen:
                        continue
                    seen.add(key)
                    readings.append(
                        _PredicateReading(
                            surface=surface,
                            lemma=base.surface,
                            kind=PredicateKind.ACTION,
                            english_glosses=(mode_spec.english_head,),
                            tense=tense,
                            polarity=canonical_polarity,
                            causative_voice=causative_voice,
                            takes_complement=mode_spec.takes_complement,
                            requires_complement=(
                                mode_spec.requires_complement
                            ),
                            verbal_derivation=base.derivation,
                            verbalization_source_gloss=source_gloss,
                            verbalization_source_glosses=(
                                base.source_glosses
                            ),
                            morphemes=(
                                self._expanded_verbalization_morphemes(
                                    realization.morphemes,
                                    base,
                                )
                            ),
                            rule_trace=(
                                "clause.productive-noun-verbalization",
                                "verb.causative-prefix-stack",
                                "clause.causative-agency",
                                "voice." + causative_voice.value,
                                *(
                                    ("voice.prohibitive-causative",)
                                    if causative_voice
                                    is CausativeVoice.PROHIBITIVE
                                    else ()
                                ),
                                *base.rule_trace,
                                *realization.rule_trace,
                            ),
                        )
                    )
        result = tuple(readings)
        self._productive_causative_cache[surface] = result
        return result

    def _predicate_readings(
        self,
        surface: str,
    ) -> tuple[_PredicateReading, ...]:
        lexical = self._predicates.get(surface, ())
        lexical_derivations = {
            (
                reading.verbal_derivation.source.lexeme_id,
                reading.verbal_derivation.mode,
                reading.tense,
                reading.polarity,
                reading.modality,
                reading.causative_voice,
            )
            for reading in lexical
            if reading.verbal_derivation is not None
        }
        productive = tuple(
            reading
            for reading in (
                *self._productive_verbalization_predicates(surface),
                *self._productive_causative_predicates(surface),
            )
            if (
                reading.verbal_derivation.source.lexeme_id,
                reading.verbal_derivation.mode,
                reading.tense,
                reading.polarity,
                reading.modality,
                reading.causative_voice,
            )
            not in lexical_derivations
        )
        return (*lexical, *productive)

    @staticmethod
    def _directive_morphemes(
        base: _PredicateReading,
        form: _DirectiveForm,
    ) -> tuple[str, ...]:
        if form.placement is DirectivePlacement.PREFIX:
            return (
                *(f"{marker}-" for marker in form.markers),
                *base.morphemes,
            )
        if form.placement is DirectivePlacement.CIRCUMFIX:
            first, *remaining = form.markers
            return (
                f"{first}-",
                *base.morphemes,
                *(f"-{marker}" for marker in remaining),
            )
        return (
            *base.morphemes,
            *(f"-{marker}" for marker in form.markers),
        )

    def _directive_predicate_readings(
        self,
        surface: str,
    ) -> tuple[_PredicateReading, ...]:
        """Analyze directives whose base predicate was derived productively."""

        if surface in self._directive_predicate_cache:
            return self._directive_predicate_cache[surface]

        readings: list[_PredicateReading] = []
        for root in _directive_root_candidates(surface):
            matching_forms = tuple(
                form
                for generated_surface, form in _directive_forms(root)
                if generated_surface == surface
            )
            if not matching_forms:
                continue
            for base in self._predicate_readings(root):
                if (
                    base.kind is not PredicateKind.ACTION
                    or base.surface != root
                    or base.surface != base.lemma
                    or base.tense is not Tense.NONPAST
                    or base.polarity is not Polarity.POSITIVE
                    or base.modality is not Modality.NONE
                    or base.causative_voice is not None
                    or base.directive_form is not None
                ):
                    continue
                for form in matching_forms:
                    if (
                        form.kind is DirectiveKind.CESSATION
                        and form.fused
                        and not (
                            base.explicit_derived_term
                            and base.lexeme is None
                            and base.verbal_derivation is not None
                            and base.verbal_derivation.mode
                            is VerbalizationMode.PERFORMANCE
                            and base.verbal_derivation.bridge == "n"
                        )
                    ):
                        continue
                    reading = replace(
                        base,
                        surface=surface,
                        polarity=(
                            Polarity.NEGATIVE
                            if form.kind
                            in {
                                DirectiveKind.PROHIBITION,
                                DirectiveKind.ABSOLUTE_PROHIBITION,
                                DirectiveKind.POLITE_PROHIBITION,
                            }
                            else Polarity.POSITIVE
                        ),
                        directive_form=form,
                        morphemes=self._directive_morphemes(base, form),
                        rule_trace=(
                            *base.rule_trace,
                            "clause.directive",
                            "directive." + form.kind.value,
                            "directive.placement." + form.placement.value,
                            "directive.focus." + form.focus.value,
                            *(
                                (
                                    "directive.nu-cessation-contraction",
                                )
                                if (
                                    form.fused
                                    and form.kind
                                    is DirectiveKind.CESSATION
                                )
                                else ("directive.u-he-fusion",)
                                if form.fused
                                else ()
                            ),
                            *(
                                ("directive.h-elision",)
                                if "è" in form.markers
                                else ()
                            ),
                            *(
                                ("directive.rapid-speech-vowel-elision",)
                                if form.rapid_speech
                                else ()
                            ),
                            "directive.regenerated-surface-validation",
                        ),
                    )
                    if reading not in readings:
                        readings.append(reading)
        result = tuple(readings)
        self._directive_predicate_cache[surface] = result
        return result

    @staticmethod
    def _split_fused_word_time_surface(
        surface: str,
    ) -> tuple[str, str, WordTimePlacement] | None:
        """Split one productive word-time marker from a single host token."""

        normalized = surface.strip().casefold()
        for marker in WORD_TIME_MARKERS:
            if normalized.startswith(marker) and len(normalized) > len(marker):
                host = normalized[len(marker):]
                if host.startswith("-"):
                    host = host[1:]
                if host:
                    return marker, host, WordTimePlacement.PREFIX
            if normalized.endswith(marker) and len(normalized) > len(marker):
                host = normalized[:-len(marker)]
                if host.endswith("-"):
                    host = host[:-1]
                if host:
                    return marker, host, WordTimePlacement.SUFFIX
        return None

    @staticmethod
    def _make_word_time_binding(
        marker: str,
        *,
        scope: WordTimeScope,
        placement: WordTimePlacement,
        fused: bool,
        source_form: str,
    ) -> WordTimeBinding:
        return WordTimeBinding(
            marker=marker,
            orientation=WORD_TIME_ORIENTATION_BY_MARKER[marker],
            scope=scope,
            placement=placement,
            fused=fused,
            source_form=source_form,
        )

    def _all_predicate_readings(
        self,
        surface: str,
    ) -> tuple[_PredicateReading, ...]:
        readings = list(self._predicate_readings(surface))
        for reading in self._directive_predicate_readings(surface):
            if reading not in readings:
                readings.append(reading)
        if readings:
            return tuple(readings)

        split = self._split_fused_word_time_surface(surface)
        if split is None:
            return ()
        marker, host, placement = split
        binding = self._make_word_time_binding(
            marker,
            scope=WordTimeScope.ADVERBIAL_PREDICATE,
            placement=placement,
            fused=True,
            source_form=surface,
        )
        for base in self._all_predicate_readings(host):
            if (
                base.kind is not PredicateKind.ACTION
                or base.directive_form is not None
                or base.word_time_binding is not None
            ):
                continue
            morphemes = (
                (marker, *base.morphemes)
                if placement is WordTimePlacement.PREFIX
                else (*base.morphemes, marker)
            )
            readings.append(
                replace(
                    base,
                    surface=surface,
                    morphemes=tuple(morphemes),
                    rule_trace=(*base.rule_trace, *binding.rule_trace()),
                    word_time_binding=binding,
                )
            )
        return tuple(readings)

    def lexical_verbal_derivation(
        self,
        lexeme: Lexeme,
    ) -> VerbalDerivation | None:
        """Expose unambiguous productive provenance to the legacy parser."""

        bases = self._verbalization_bases.get(lexeme.lemma, ())
        derivations = {
            (
                base.derivation.source.lexeme_id,
                base.derivation.mode,
                base.derivation.bridge,
            ): base.derivation
            for base in bases
        }
        if len(derivations) != 1:
            return None
        return replace(
            next(iter(derivations.values())),
            lexicalized_predicate_id=lexeme.identifier,
        )

    def explicit_derived_verbal_derivation(
        self,
        source_lexeme: Lexeme,
        surface: str,
    ) -> VerbalDerivation | None:
        """Return provenance only for an explicitly listed derived verb.

        The compiler retains arbitrary derived entries, but canonical
        generation may use one only when its surface is also licensed by a
        documented productive verbalization mode. This keeps an authored
        exception inspectable without guessing at an opaque derivation.
        """

        normalized = surface.strip().casefold()
        derivations = {
            (
                base.derivation.source.lexeme_id,
                base.derivation.mode,
                base.derivation.bridge,
            ): replace(
                base.derivation,
                attested_derived_term_id=(
                    base.explicit_derived_term_ids[0]
                ),
                attested_derived_surface=base.surface,
            )
            for base in self._verbalization_bases.get(normalized, ())
            if (
                base.derivation.source.lexeme_id
                == source_lexeme.identifier
                and base.explicit_derived_glosses
            )
        }
        if len(derivations) != 1:
            return None
        return next(iter(derivations.values()))

    def _build_predicate_index(
        self,
    ) -> dict[str, tuple[_PredicateReading, ...]]:
        work: dict[str, list[_PredicateReading]] = {}
        for lexeme in self.database.lexemes:
            if lexeme.category != "verb" or " " in lexeme.lemma:
                continue
            if (
                lexeme.lemma in RELATIONAL_PREDICATES
                or lexeme.lemma in RELATIONAL_PREDICATE_ALIASES
            ):
                # These forms are grammatical validity compounds or
                # independent relational particles. Treating the same
                # spelling as an ordinary action root crowds the documented
                # essential/circumstantial readings out of the bounded parse
                # lattice and loses their structural contrast.
                continue
            glosses = split_english_gloss(lexeme)
            if not glosses:
                continue
            root_kind = (
                VerbRootKind.DERIVED
                if lexeme.lexical_subtype == "derived_u"
                else VerbRootKind.ROOT
            )
            verbalization_bases: tuple[
                _VerbalizationBase | None,
                ...,
            ] = (
                self._verbalization_bases.get(lexeme.lemma, ())
                if root_kind is VerbRootKind.DERIVED
                else ()
            ) or (None,)
            morphology_roots: list[tuple[str, LexicalVariant | None]] = [
                (lexeme.lemma, None)
            ]
            for variant in lexeme.variants:
                if "before-following-material" in variant.contexts:
                    morphology_roots.append(
                        (variant.surface.casefold(), variant)
                    )
                    continue
                surface = variant.surface.casefold()
                morphology_roots.append((surface, variant))
                work.setdefault(surface, []).append(
                    _PredicateReading(
                        surface=surface,
                        lemma=lexeme.lemma,
                        kind=PredicateKind.ACTION,
                        english_glosses=glosses,
                        lexeme=lexeme,
                        morphemes=(variant.surface,),
                        rule_trace=(
                            "clause.lexical-predicate",
                            "lexicon.source-variant",
                            *(
                                "lexicon.variant-context." + context
                                for context in variant.contexts
                            ),
                        ),
                        takes_complement=(
                            valency_allows_direct_object(
                                str(lexeme.valency.value)
                            )
                            if lexeme.valency.is_present
                            else False
                        ),
                    )
                )
            for tense, polarity, modality in itertools.product(
                tuple(Tense),
                tuple(Polarity),
                tuple(Modality),
            ):
                for morphology_root, source_variant in morphology_roots:
                    realization = realize_verb_complex(
                        VerbComplexSpec(
                            root=morphology_root,
                            tense=CANONICAL_TENSE_TO_VERB[tense],
                            polarity=CANONICAL_POLARITY_TO_VERB[polarity],
                            mood=CANONICAL_MODALITY_TO_VERB[modality],
                            root_kind=root_kind,
                        )
                    )
                    if (
                        source_variant is not None
                        and "before-following-material"
                        in source_variant.contexts
                        and realization.morphemes[-1] == morphology_root
                    ):
                        # The source licenses this allomorph only when
                        # material follows it. Prefixes alone do not satisfy
                        # that condition; a suffix in the generated complex
                        # does. Separate post-verbal words are handled by the
                        # clause parser, where their context is observable.
                        continue
                    variant_trace = (
                        (
                            "lexicon.source-variant-as-inflection-stem",
                            *(
                                "lexicon.variant-context." + context
                                for context in source_variant.contexts
                            ),
                        )
                        if source_variant is not None
                        else ()
                    )
                    for base in verbalization_bases:
                        derivation = (
                            replace(
                                base.derivation,
                                lexicalized_predicate_id=lexeme.identifier,
                            )
                            if base is not None
                            else None
                        )
                        work.setdefault(realization.surface, []).append(
                            _PredicateReading(
                                surface=realization.surface,
                                lemma=lexeme.lemma,
                                kind=PredicateKind.ACTION,
                                english_glosses=glosses,
                                tense=tense,
                                polarity=polarity,
                                modality=modality,
                                lexeme=lexeme,
                                verbal_derivation=derivation,
                                morphemes=(
                                    self._expanded_verbalization_morphemes(
                                        realization.morphemes,
                                        base,
                                    )
                                    if base is not None
                                    else realization.morphemes
                                ),
                                rule_trace=(
                                    "clause.lexical-predicate",
                                    *variant_trace,
                                    *(
                                        base.rule_trace
                                        if base is not None
                                        else ()
                                    ),
                                    *realization.rule_trace,
                                ),
                                takes_complement=(
                                    valency_allows_direct_object(
                                        str(lexeme.valency.value)
                                    )
                                    if lexeme.valency.is_present
                                    else False
                                ),
                            )
                        )
            for (
                tense,
                (
                    causative_voice,
                    canonical_polarity,
                    morphology_voice,
                    morphology_polarity,
                ),
            ) in itertools.product(
                tuple(Tense),
                CAUSATIVE_REALIZATIONS,
            ):
                realization = realize_verb_complex(
                    VerbComplexSpec(
                        root=lexeme.lemma,
                        tense=CANONICAL_TENSE_TO_VERB[tense],
                        polarity=morphology_polarity,
                        voice=morphology_voice,
                        root_kind=root_kind,
                    )
                )
                for base in verbalization_bases:
                    derivation = (
                        replace(
                            base.derivation,
                            lexicalized_predicate_id=lexeme.identifier,
                        )
                        if base is not None
                        else None
                    )
                    work.setdefault(realization.surface, []).append(
                        _PredicateReading(
                            surface=realization.surface,
                            lemma=lexeme.lemma,
                            kind=PredicateKind.ACTION,
                            english_glosses=glosses,
                            tense=tense,
                            polarity=canonical_polarity,
                            causative_voice=causative_voice,
                            lexeme=lexeme,
                            verbal_derivation=derivation,
                            morphemes=(
                                self._expanded_verbalization_morphemes(
                                    realization.morphemes,
                                    base,
                                )
                                if base is not None
                                else realization.morphemes
                            ),
                            rule_trace=(
                                "clause.lexical-predicate",
                                "verb.causative-prefix-stack",
                                "clause.causative-agency",
                                "voice." + causative_voice.value,
                                *(
                                    ("voice.prohibitive-causative",)
                                    if causative_voice
                                    is CausativeVoice.PROHIBITIVE
                                    else ()
                                ),
                                *(
                                    base.rule_trace
                                    if base is not None
                                    else ()
                                ),
                                *realization.rule_trace,
                            ),
                            takes_complement=(
                                valency_allows_direct_object(
                                    str(lexeme.valency.value)
                                )
                                if lexeme.valency.is_present
                                else False
                            ),
                        )
                    )
            for directive_surface, directive_form in _directive_forms(
                lexeme.lemma
            ):
                if (
                    directive_form.kind is DirectiveKind.CESSATION
                    and directive_form.fused
                ):
                    # The contracted -nů + nă realization belongs to an
                    # explicit but not independently lexicalized derived
                    # term. A lexical verb keeps its full root before -nă.
                    continue
                for base in verbalization_bases:
                    derivation = (
                        replace(
                            base.derivation,
                            lexicalized_predicate_id=lexeme.identifier,
                        )
                        if base is not None
                        else None
                    )
                    root_morphemes = (
                        self._expanded_verbalization_morphemes(
                            (lexeme.lemma,),
                            base,
                        )
                        if base is not None
                        else (lexeme.lemma,)
                    )
                    if (
                        directive_form.placement
                        is DirectivePlacement.PREFIX
                    ):
                        morphemes = (
                            *(
                                f"{marker}-"
                                for marker in directive_form.markers
                            ),
                            *root_morphemes,
                        )
                    elif (
                        directive_form.placement
                        is DirectivePlacement.CIRCUMFIX
                    ):
                        first, *remaining = directive_form.markers
                        morphemes = (
                            f"{first}-",
                            *root_morphemes,
                            *(f"-{marker}" for marker in remaining),
                        )
                    else:
                        morphemes = (
                            *root_morphemes,
                            *(
                                f"-{marker}"
                                for marker in directive_form.markers
                            ),
                        )
                    work.setdefault(directive_surface, []).append(
                        _PredicateReading(
                            surface=directive_surface,
                            lemma=lexeme.lemma,
                            kind=PredicateKind.ACTION,
                            english_glosses=glosses,
                            polarity=(
                                Polarity.NEGATIVE
                                if directive_form.kind
                                in {
                                    DirectiveKind.PROHIBITION,
                                    DirectiveKind.ABSOLUTE_PROHIBITION,
                                    DirectiveKind.POLITE_PROHIBITION,
                                }
                                else Polarity.POSITIVE
                            ),
                            directive_form=directive_form,
                            lexeme=lexeme,
                            verbal_derivation=derivation,
                            morphemes=tuple(morphemes),
                            rule_trace=(
                                "clause.lexical-predicate",
                                "clause.directive",
                                "directive."
                                + directive_form.kind.value,
                                "directive.placement."
                                + directive_form.placement.value,
                                "directive.focus."
                                + directive_form.focus.value,
                                *(
                                    ("directive.u-he-fusion",)
                                    if directive_form.fused
                                    else ()
                                ),
                                *(
                                    ("directive.h-elision",)
                                    if "è"
                                    in directive_form.markers
                                    else ()
                                ),
                                *(
                                    (
                                        "directive.rapid-speech-vowel-elision",
                                    )
                                    if directive_form.rapid_speech
                                    else ()
                                ),
                                *(
                                    base.rule_trace
                                    if base is not None
                                    else ()
                                ),
                            ),
                            takes_complement=(
                                valency_allows_direct_object(
                                    str(lexeme.valency.value)
                                )
                                if lexeme.valency.is_present
                                else False
                            ),
                        )
                    )

        for surface, (tense, polarity) in IDENTITY_FORMS.items():
            work.setdefault(surface, []).append(
                _PredicateReading(
                    surface=surface,
                    lemma="xiŕa",
                    kind=PredicateKind.IDENTITY,
                    english_glosses=("be",),
                    tense=tense,
                    polarity=polarity,
                    validity_mode=ValidityMode.ESSENTIAL,
                    morphemes=(surface,),
                    rule_trace=("clause.identity-copula",),
                )
            )
        for surface, (tense, polarity) in PERFORMANCE_FORMS.items():
            work.setdefault(surface, []).append(
                _PredicateReading(
                    surface=surface,
                    lemma=(
                        "bů"
                        if surface
                        in {"bů", "bůná", "pabů", "panábů"}
                        else "ů"
                    ),
                    kind=PredicateKind.PERFORMANCE,
                    english_glosses=("act as",),
                    tense=tense,
                    polarity=polarity,
                    validity_mode=ValidityMode.DYNAMIC,
                    morphemes=(surface,),
                    rule_trace=("clause.performance-copula",),
                )
            )
        for surface, relation in SPATIAL_PREDICATES.items():
            work.setdefault(surface, []).append(
                _PredicateReading(
                    surface=surface,
                    lemma=surface,
                    kind=PredicateKind.LOCATION,
                    english_glosses=(relation,),
                    validity_mode=ValidityMode.DYNAMIC,
                    morphemes=(surface,),
                    rule_trace=(
                        "clause.active-spatial-predicate",
                        *(
                            ("clause.vicinity-center-predicate",)
                            if surface in VICINITY_LOCATION_PREDICATES
                            else ()
                        ),
                    ),
                    takes_complement=True,
                )
            )
        for surface, relation in DEICTIC_PREDICATES.items():
            negative_proximal = surface == "onèŕa"
            work.setdefault(surface, []).append(
                _PredicateReading(
                    surface=surface,
                    lemma="o-xiŕa" if negative_proximal else surface,
                    kind=PredicateKind.LOCATION,
                    english_glosses=(relation,),
                    polarity=(
                        Polarity.NEGATIVE
                        if negative_proximal
                        else Polarity.POSITIVE
                    ),
                    validity_mode=(
                        ValidityMode.ESSENTIAL
                        if (
                            surface.endswith("xiŕa")
                            or negative_proximal
                        )
                        else ValidityMode.CIRCUMSTANTIAL
                    ),
                    morphemes=(
                        ("o", "nè", "ŕa")
                        if negative_proximal
                        else (surface,)
                    ),
                    rule_trace=(
                        "clause.deictic-location-predicate",
                        *(
                            (
                                "clause.validity-essential",
                                "clause.validity-proximal-negation",
                            )
                            if negative_proximal
                            else ()
                        ),
                    ),
                    takes_complement=False,
                )
            )
        for surface, relation in TOPOLOGICAL_VALIDITY_PREDICATES.items():
            work.setdefault(surface, []).append(
                _PredicateReading(
                    surface=surface,
                    lemma=surface,
                    kind=PredicateKind.LOCATION,
                    english_glosses=(relation,),
                    validity_mode=ValidityMode.ESSENTIAL,
                    morphemes=(surface[:-2], "ŕa"),
                    rule_trace=(
                        "clause.topological-validity-predicate",
                        "clause.validity-essential",
                        *(
                            ("clause.vicinity-center-predicate",)
                            if surface in VICINITY_LOCATION_PREDICATES
                            else ()
                        ),
                    ),
                    # Topological statives may name a landmark ("the moon is
                    # inside outer space") or leave it contextually implicit
                    # ("the moon is above").
                    takes_complement=True,
                )
            )
        for canonical, (kind, glosses) in RELATIONAL_PREDICATES.items():
            validity_mode = (
                ValidityMode.ESSENTIAL
                if canonical.endswith("ŕa")
                else ValidityMode.CIRCUMSTANTIAL
            )
            for tense, polarity in itertools.product(tuple(Tense), tuple(Polarity)):
                surface, morphemes, inflection_trace = _validity_surface(
                    canonical,
                    tense,
                    polarity,
                )
                circumstantial_productivity_unresolved = (
                    validity_mode is ValidityMode.CIRCUMSTANTIAL
                    and not (
                        tense is Tense.NONPAST
                        and polarity is Polarity.POSITIVE
                    )
                    and not (
                        canonical == "ni"
                        and tense is Tense.FUTURE
                        and polarity is Polarity.NEGATIVE
                    )
                )
                work.setdefault(surface, []).append(
                    _PredicateReading(
                        surface=surface,
                        lemma=canonical,
                        kind=kind,
                        english_glosses=glosses,
                        tense=tense,
                        polarity=polarity,
                        validity_mode=validity_mode,
                        morphemes=morphemes,
                        rule_trace=(
                            "clause.relational-predicate",
                            "clause.validity-compound",
                            (
                                "clause.validity-essential"
                                if validity_mode is ValidityMode.ESSENTIAL
                                else "clause.validity-circumstantial"
                            ),
                            *inflection_trace,
                            *(
                                (
                                    "clause.validity-productivity-unresolved",
                                )
                                if circumstantial_productivity_unresolved
                                else ()
                            ),
                        ),
                        takes_complement=True,
                    )
                )
        for alias, canonical in RELATIONAL_PREDICATE_ALIASES.items():
            for reading in work.get(canonical, ()):
                if (
                    reading.tense is Tense.NONPAST
                    and reading.polarity is Polarity.POSITIVE
                ):
                    work.setdefault(alias, []).append(
                        replace(
                            reading,
                            surface=alias,
                            morphemes=(alias[:-2], "ŕa"),
                            rule_trace=(
                                *reading.rule_trace,
                                "clause.validity-spelling-variant",
                            ),
                        )
                    )

        for lexeme in self.database.lexemes:
            if "ga-noun" not in lexeme.tags:
                continue
            reduced = reduce_class_suffix(lexeme.lemma)
            reduced_features = dict(reduced.features)
            class_suffix_reduced = (
                reduced_features.get("class_suffix_reduced") == "true"
            )
            glosses = _constitutional_predicate_glosses(
                lexeme,
                class_suffix_reduced=class_suffix_reduced,
            )
            if not glosses:
                continue
            canonical = reduced.surface + "ŕa"
            for tense, polarity in itertools.product(tuple(Tense), tuple(Polarity)):
                surface, morphemes, inflection_trace = _validity_surface(
                    canonical,
                    tense,
                    polarity,
                )
                work.setdefault(surface, []).append(
                    _PredicateReading(
                        surface=surface,
                        lemma=canonical,
                        kind=PredicateKind.CONSTITUTION,
                        english_glosses=glosses,
                        tense=tense,
                        polarity=polarity,
                        validity_mode=ValidityMode.ESSENTIAL,
                        lexeme=lexeme,
                        morphemes=morphemes,
                        rule_trace=(
                            "clause.constitutional-ga-predicate",
                            "clause.validity-compound",
                            "clause.validity-essential",
                            *reduced.rule_trace,
                            *inflection_trace,
                        ),
                        takes_complement=False,
                    )
                )
        return {
            surface: tuple(
                sorted(
                    {
                        (
                            reading.lemma,
                            reading.kind.value,
                            reading.tense.value,
                            reading.polarity.value,
                            reading.modality.value,
                            reading.validity_mode.value,
                            reading.takes_complement,
                            reading.lexeme.identifier
                            if reading.lexeme
                            else "",
                        ): reading
                        for reading in readings
                    }.values(),
                    key=lambda reading: (
                        (
                            0
                            if (
                                "clause.active-spatial-predicate"
                                in reading.rule_trace
                                or "clause.topological-validity-predicate"
                                in reading.rule_trace
                            )
                            else 1
                        ),
                        reading.kind.value,
                        reading.lemma,
                        reading.tense.value,
                        reading.polarity.value,
                        reading.modality.value,
                        reading.validity_mode.value,
                        reading.lexeme.identifier
                        if reading.lexeme
                        else "",
                    ),
                )
            )
            for surface, readings in work.items()
        }

    def _parse_single(
        self,
        words: Sequence[Any],
        *,
        interrogative: bool,
        question_indices: set[int],
        comma_indices: set[int],
        discourse_state: DiscourseState | None,
    ) -> list[_ClauseReading]:
        if not words:
            return []
        if words[-1].normalized in DISTRIBUTIVE_PARTICLES:
            token = words[-1]
            base_readings = self._parse_single(
                words[:-1],
                interrogative=interrogative,
                question_indices=question_indices,
                comma_indices=comma_indices,
                discourse_state=discourse_state,
            )
            modifier = DistributiveModifier(
                marker=token.normalized,
                kind=DISTRIBUTIVE_PARTICLES[token.normalized],
                scope=DistributionScope.EVENT,
            )
            phrase = DISTRIBUTIVE_ENGLISH[modifier.kind]
            return [
                replace(
                    reading,
                    clause=replace(
                        reading.clause,
                        distribution=modifier,
                    ),
                    output_text=_append_event_distribution(
                        reading.output_text,
                        phrase,
                    ),
                    roles=tuple(
                        sorted(
                            {
                                **dict(reading.roles),
                                token.index: "event-distributive",
                            }.items()
                        )
                    ),
                    rule_trace=(
                        *reading.rule_trace,
                        "clause.event-distributive",
                        f"distribution.{modifier.kind.value}",
                        "distribution.scope.event",
                    ),
                )
                for reading in base_readings
                if (
                    reading.clause.distribution is None
                    and reading.clause.predicate_kind
                    is PredicateKind.ACTION
                )
            ][:MAX_CLAUSE_ALTERNATIVES]
        tail_result = self._extract_inner_post_verbal_scope(words)
        if tail_result is None:
            return []
        scoped_words, post_verbal_scope, post_verbal_indices = tail_result
        modifier_result = self._extract_event_modifiers(scoped_words)
        if modifier_result is None:
            return []
        (
            core_words,
            temporal_aspect,
            temporal_aspect_index,
            frequency,
            frequency_index,
        ) = modifier_result
        if not core_words:
            return []
        if (
            len(core_words) >= 2
            and core_words[-1].normalized in SEPARATE_DIRECTIVE_MARKERS
        ):
            marker_token = core_words[-1]
            root_token = core_words[-2]
            kind, placement, markers = SEPARATE_DIRECTIVE_MARKERS[
                marker_token.normalized
            ]
            separate_readings: list[_ClauseReading] = []
            for base in self._predicate_readings(root_token.normalized):
                if (
                    base.kind is not PredicateKind.ACTION
                    or base.surface != base.lemma
                    or base.tense is not Tense.NONPAST
                    or base.polarity is not Polarity.POSITIVE
                    or base.modality is not Modality.NONE
                    or base.causative_voice is not None
                    or base.directive_form is not None
                ):
                    continue
                directive = replace(
                    base,
                    surface=base.surface + marker_token.normalized,
                    polarity=(
                        Polarity.NEGATIVE
                        if kind
                        in {
                            DirectiveKind.PROHIBITION,
                            DirectiveKind.ABSOLUTE_PROHIBITION,
                            DirectiveKind.POLITE_PROHIBITION,
                        }
                        else Polarity.POSITIVE
                    ),
                    directive_form=_DirectiveForm(
                        kind=kind,
                        placement=placement,
                        markers=markers,
                    ),
                    morphemes=(
                        *base.morphemes,
                        *(f"-{marker}" for marker in markers),
                    ),
                    rule_trace=(
                        *base.rule_trace,
                        "clause.directive",
                        "directive." + kind.value,
                        "directive.placement." + placement.value,
                        "directive.separate-particle-spelling",
                    ),
                )
                separate_readings.extend(
                    self._parse_directive_clause(
                        core_words[:-2],
                        directive,
                        root_token.index,
                        directive_marker_indices={marker_token.index},
                        comma_indices=comma_indices,
                    )
                )
            return separate_readings[:MAX_CLAUSE_ALTERNATIVES]
        predicate_token = core_words[-1]
        predicate_jobs: list[
            tuple[_PredicateReading, tuple[Any, ...], int]
        ] = [
            (predicate, tuple(core_words[:-1]), predicate_token.index)
            for predicate in self._all_predicate_readings(
                predicate_token.normalized
            )
        ]
        if (
            len(core_words) >= 2
            and core_words[-2].normalized
            in WORD_TIME_ORIENTATION_BY_MARKER
        ):
            marker_token = core_words[-2]
            binding = self._make_word_time_binding(
                marker_token.normalized,
                scope=WordTimeScope.ADVERBIAL_PREDICATE,
                placement=WordTimePlacement.PREFIX,
                fused=False,
                source_form=(
                    marker_token.surface + " " + predicate_token.surface
                ),
            )
            predicate_jobs.extend(
                (
                    replace(
                        base,
                        surface=(
                            marker_token.normalized + " " + base.surface
                        ),
                        morphemes=(
                            marker_token.normalized,
                            *base.morphemes,
                        ),
                        rule_trace=(
                            *base.rule_trace,
                            *binding.rule_trace(),
                        ),
                        word_time_binding=binding,
                        word_time_index=marker_token.index,
                    ),
                    tuple(core_words[:-2]),
                    predicate_token.index,
                )
                for base in self._all_predicate_readings(
                    predicate_token.normalized
                )
                if (
                    base.kind is PredicateKind.ACTION
                    and base.directive_form is None
                    and base.word_time_binding is None
                )
            )
        if (
            len(core_words) >= 2
            and core_words[-1].normalized
            in WORD_TIME_ORIENTATION_BY_MARKER
        ):
            marker_token = core_words[-1]
            predicate_token = core_words[-2]
            binding = self._make_word_time_binding(
                marker_token.normalized,
                scope=WordTimeScope.ADVERBIAL_PREDICATE,
                placement=WordTimePlacement.SUFFIX,
                fused=False,
                source_form=(
                    predicate_token.surface + " " + marker_token.surface
                ),
            )
            predicate_jobs.extend(
                (
                    replace(
                        base,
                        surface=(
                            base.surface + " " + marker_token.normalized
                        ),
                        morphemes=(*base.morphemes, marker_token.normalized),
                        rule_trace=(
                            *base.rule_trace,
                            *binding.rule_trace(),
                        ),
                        word_time_binding=binding,
                        word_time_index=marker_token.index,
                    ),
                    tuple(core_words[:-2]),
                    predicate_token.index,
                )
                for base in self._all_predicate_readings(
                    predicate_token.normalized
                )
                if (
                    base.kind is PredicateKind.ACTION
                    and base.directive_form is None
                    and base.word_time_binding is None
                )
            )
        if predicate_jobs:
            readings: list[_ClauseReading] = []
            for (
                predicate,
                predicate_argument_words,
                active_predicate_index,
            ) in predicate_jobs:
                predicate = replace(
                    predicate,
                    temporal_aspect=temporal_aspect,
                    temporal_aspect_index=temporal_aspect_index,
                    frequency=frequency,
                    frequency_index=frequency_index,
                    post_verbal_scope=post_verbal_scope,
                    post_verbal_indices=post_verbal_indices,
                )
                if predicate.directive_form is not None:
                    if not post_verbal_scope.is_empty:
                        continue
                    if predicate.directive_form.kind is DirectiveKind.SWITCH:
                        switch_readings = self._parse_action_switch_clause(
                            predicate_argument_words,
                            predicate,
                            active_predicate_index,
                            comma_indices=comma_indices,
                        )
                        if switch_readings:
                            readings.extend(switch_readings)
                            continue
                    readings.extend(
                        self._parse_directive_clause(
                            predicate_argument_words,
                            predicate,
                            active_predicate_index,
                            directive_marker_indices=set(),
                            comma_indices=comma_indices,
                        )
                    )
                else:
                    readings.extend(
                        self._parse_predicated_clause(
                            predicate_argument_words,
                            predicate,
                            active_predicate_index,
                            interrogative=interrogative,
                            question_indices=question_indices,
                            discourse_state=discourse_state,
                        )
                    )
            # A recognized predicate that violates its documented valency
            # must not be recycled as a nominal zero-copula complement.
            return readings[:MAX_CLAUSE_ALTERNATIVES]
        if (
            temporal_aspect is not TemporalAspect.NONE
            or frequency is not None
            or not post_verbal_scope.is_empty
        ):
            return []
        frontloaded = self._parse_frontloaded_particle_copula(
            core_words,
            interrogative=interrogative,
            question_indices=question_indices,
            discourse_state=discourse_state,
        )
        if frontloaded:
            return frontloaded
        zero_copula = self._parse_zero_copula(
            core_words,
            interrogative=interrogative,
            question_indices=question_indices,
        )
        fragments = self._parse_nominal_fragment(
            core_words,
            interrogative=interrogative,
            question_indices=question_indices,
        )
        return [
            *zero_copula,
            *(
                reading
                for reading in fragments
                if reading not in zero_copula
            ),
        ][:MAX_CLAUSE_ALTERNATIVES]

    def _parse_action_switch_clause(
        self,
        source_words: Sequence[Any],
        replacement: _PredicateReading,
        replacement_index: int,
        *,
        comma_indices: set[int],
    ) -> list[_ClauseReading]:
        """Compose ``action + tomo + nåhè-action`` as one switch graph."""

        form = replacement.directive_form
        if (
            form is None
            or form.kind is not DirectiveKind.SWITCH
            or len(source_words) < 2
            or source_words[-1].normalized not in RESULTATIVE_TAIL_FORMS
        ):
            return []
        marker = source_words[-1]
        discontinued_words = tuple(source_words[:-1])
        shared_addressee = DiscourseState(
            topic=DiscourseReferent(
                nominal=Nominal(
                    surface="na",
                    person=PronounPerson.SECOND,
                    animacy=PronounAnimacy.ANIMATE,
                    pronoun_kind=PronounKind.PERSONAL,
                    pronoun_base="na",
                ),
                english_text="you",
            )
        )
        discontinued = [
            reading
            for reading in self._parse_single(
                discontinued_words,
                interrogative=False,
                question_indices=set(),
                comma_indices=comma_indices,
                discourse_state=shared_addressee,
            )
            if (
                reading.clause.predicate_kind is PredicateKind.ACTION
                and reading.clause.directive is None
                and reading.predicate_english is not None
            )
        ]
        replacements = self._parse_directive_clause(
            (),
            replacement,
            replacement_index,
            directive_marker_indices=set(),
            comma_indices=comma_indices,
        )
        output: list[_ClauseReading] = []
        for prior, following in itertools.product(discontinued, replacements):
            prior_verb = prior.predicate_english or "act"
            first, *rest = prior_verb.split(" ", 1)
            prior_action = present_participle(first)
            if rest:
                prior_action += " " + rest[0]
            if prior.complement_english:
                prior_action += " " + prior.complement_english
            replacement_action = following.predicate_english or "act"
            if following.complement_english:
                replacement_action += " " + following.complement_english
            clause = replace(
                following.clause,
                action_switch=ActionSwitch(
                    discontinued_clause=prior.clause,
                    cessation_marker=marker.normalized,
                ),
            )
            output.append(
                _ClauseReading(
                    clause=clause,
                    output_text=_capitalize(
                        f"stop {prior_action}; "
                        f"{replacement_action} instead!"
                    ),
                    roles=tuple(
                        sorted(
                            {
                                **dict(prior.roles),
                                **dict(following.roles),
                                marker.index: "action-switch-cessation",
                            }.items()
                        )
                    ),
                    predicate=following.predicate,
                    predicate_index=following.predicate_index,
                    subject_english=following.subject_english,
                    assumptions=(
                        *prior.assumptions,
                        *following.assumptions,
                    ),
                    ambiguities=(
                        *prior.ambiguities,
                        *following.ambiguities,
                    ),
                    rule_trace=(
                        "translation.asaxi-action-switch",
                        "clause.action-switch",
                        "clause.action-switch-shared-addressee",
                        "post-verbal.result",
                        *prior.rule_trace,
                        *following.rule_trace,
                    ),
                    predicate_english=following.predicate_english,
                    complement_english=following.complement_english,
                )
            )
        return output[:MAX_CLAUSE_ALTERNATIVES]

    def _parse_directive_vocative(
        self,
        words: Sequence[Any],
    ) -> tuple[_NominalReading, ...]:
        """Parse a vocative, retaining legacy lowercase names explicitly.

        The current orthography requires capitalized proper names.  Note 53
        predates that convention, so its lowercase examples are accepted only
        in the tightly bounded comma-vocative slot and are marked as a
        compatibility assumption rather than generalized to ordinary nouns.
        """

        parsed = self._parse_nominal_span(words, role="vocative")
        if parsed:
            return tuple(parsed)
        if (
            len(words) != 1
            or words[0].kind != "word"
            or words[0].surface.casefold()
            not in LEGACY_LOWERCASE_DIRECTIVE_VOCATIVES
        ):
            return ()
        token = words[0]
        return (
            _NominalReading(
                nominal=Nominal(
                    surface=token.surface,
                    person=PronounPerson.THIRD,
                ),
                english_text=(
                    token.surface[:1].upper() + token.surface[1:]
                ),
                token_indices=(token.index,),
                roles=((token.index, "vocative"),),
                assumptions=(
                    TranslationAssumption(
                        code="LOWERCASE_VOCATIVE_COMPATIBILITY",
                        message=(
                            f"{token.surface!r} was retained as a legacy "
                            "lowercase vocative. Current Asaxi orthography "
                            "capitalizes proper names."
                        ),
                    ),
                ),
                rule_trace=(
                    "clause.directive-lowercase-vocative-compatibility",
                ),
            ),
        )

    def _parse_directive_arguments(
        self,
        words: Sequence[Any],
        predicate: _PredicateReading,
    ) -> tuple[_DirectiveArgumentReading, ...]:
        """Parse one optional object followed by typed case arguments."""

        if not words:
            return (_DirectiveArgumentReading(),)
        case_positions = tuple(
            index
            for index, token in enumerate(words)
            if token.normalized in CASE_MARKERS
        )
        if not case_positions:
            if not predicate.is_transitive:
                return ()
            return tuple(
                _DirectiveArgumentReading(
                    direct=direct,
                    roles=direct.roles,
                    assumptions=direct.assumptions,
                    ambiguities=direct.ambiguities,
                    rule_trace=direct.rule_trace,
                    structural_cost=direct.structural_cost,
                )
                for direct in self._parse_nominal_span(
                    words,
                    role="object",
                )
            )

        direct_words = words[:case_positions[0]]
        if direct_words:
            if not predicate.is_transitive:
                return ()
            direct_options: tuple[_NominalReading | None, ...] = tuple(
                self._parse_nominal_span(direct_words, role="object")
            )
            if not direct_options:
                return ()
        else:
            direct_options = (None,)

        case_groups: list[tuple[_CaseArgumentReading, ...]] = []
        for group_index, position in enumerate(case_positions):
            marker = words[position]
            end = (
                case_positions[group_index + 1]
                if group_index + 1 < len(case_positions)
                else len(words)
            )
            nominal_words = words[position + 1:end]
            if not nominal_words:
                return ()
            relation, function, defaults = CASE_MARKERS[marker.normalized]
            prepositions = self._case_prepositions(
                relation,
                predicate,
                defaults,
            )
            options: list[_CaseArgumentReading] = []
            for nominal in self._parse_nominal_span(
                nominal_words,
                role=CASE_ARGUMENT_ROLES[relation],
            ):
                for preposition in prepositions:
                    ambiguities = list(nominal.ambiguities)
                    if len(prepositions) > 1:
                        ambiguities.append(
                            TranslationAmbiguity(
                                code="CASE_FUNCTION_AMBIGUOUS",
                                message=(
                                    f"The {relation.value} marker "
                                    f"{marker.surface!r} permits more than "
                                    "one English relation in this lexical "
                                    "context."
                                ),
                                choices=prepositions,
                                selected=preposition,
                            )
                        )
                    options.append(
                        _CaseArgumentReading(
                            phrase=RelationalPhrase(
                                marker=marker.normalized,
                                relation=relation,
                                nominal=nominal.nominal,
                                function=function,
                            ),
                            english_text=(
                                f"{preposition} {nominal.english_text}"
                            ).strip(),
                            roles=tuple(
                                sorted(
                                    {
                                        **dict(nominal.roles),
                                        marker.index: (
                                            f"{relation.value}-marker"
                                        ),
                                    }.items()
                                )
                            ),
                            assumptions=nominal.assumptions,
                            ambiguities=tuple(ambiguities),
                            rule_trace=(
                                f"argument.{relation.value}",
                                *nominal.rule_trace,
                            ),
                            structural_cost=nominal.structural_cost,
                        )
                    )
            if not options:
                return ()
            case_groups.append(tuple(options))

        readings: list[_DirectiveArgumentReading] = []
        for direct, obliques in itertools.product(
            direct_options,
            itertools.product(*case_groups),
        ):
            readings.append(
                _DirectiveArgumentReading(
                    direct=direct,
                    obliques=tuple(obliques),
                    roles=tuple(
                        sorted(
                            {
                                **(
                                    dict(direct.roles)
                                    if direct is not None
                                    else {}
                                ),
                                **{
                                    index: role
                                    for oblique in obliques
                                    for index, role in oblique.roles
                                },
                            }.items()
                        )
                    ),
                    assumptions=(
                        *(
                            direct.assumptions
                            if direct is not None
                            else ()
                        ),
                        *(
                            assumption
                            for oblique in obliques
                            for assumption in oblique.assumptions
                        ),
                    ),
                    ambiguities=(
                        *(
                            direct.ambiguities
                            if direct is not None
                            else ()
                        ),
                        *(
                            ambiguity
                            for oblique in obliques
                            for ambiguity in oblique.ambiguities
                        ),
                    ),
                    rule_trace=(
                        *(
                            direct.rule_trace
                            if direct is not None
                            else ()
                        ),
                        *(
                            rule
                            for oblique in obliques
                            for rule in oblique.rule_trace
                        ),
                    ),
                    structural_cost=(
                        (
                            direct.structural_cost
                            if direct is not None
                            else 0
                        )
                        + sum(
                            oblique.structural_cost
                            for oblique in obliques
                        )
                    ),
                )
            )
        return tuple(
            sorted(readings, key=lambda reading: reading.structural_cost)
        )[:MAX_CLAUSE_ALTERNATIVES]

    @staticmethod
    def _is_continuation_goal_idiom(
        clause: CanonicalClause,
        predicate: _PredicateReading,
    ) -> bool:
        """Recognize Note 53's typed persistence construction."""

        directive = clause.directive
        return bool(
            directive is not None
            and directive.kind is DirectiveKind.CONTINUATION
            and directive.placement is DirectivePlacement.PREFIX
            and directive.focus is DirectiveFocus.PERSISTENCE
            and predicate.lemma.casefold() == "ijo"
            and clause.object is None
            and len(clause.obliques) == 1
            and clause.obliques[0].relation is CaseRelation.ALLATIVE
            and clause.obliques[0].nominal.surface.casefold() == "jåhjo"
        )

    def _parse_directive_clause(
        self,
        argument_words: Sequence[Any],
        predicate: _PredicateReading,
        predicate_index: int,
        *,
        directive_marker_indices: set[int],
        comma_indices: set[int],
    ) -> list[_ClauseReading]:
        """Parse imperative force without pretending its vocative is a case."""

        form = predicate.directive_form
        if form is None or any(
            token.normalized in SUBJECT_MARKERS
            for token in argument_words
        ):
            return []
        relevant_commas = tuple(
            comma
            for comma in sorted(comma_indices)
            if (
                argument_words
                and argument_words[0].index < comma < predicate_index
            )
        )
        if len(relevant_commas) > 1:
            return []

        if relevant_commas:
            comma = relevant_commas[0]
            vocative_words = tuple(
                token for token in argument_words if token.index < comma
            )
            object_words = tuple(
                token for token in argument_words if token.index > comma
            )
            if not vocative_words:
                return []
            addressee_options = self._parse_directive_vocative(
                vocative_words
            )
            implicit_addressee = False
            vocative_addressee = True
        elif (
            form.kind
            in {
                DirectiveKind.REQUEST,
                DirectiveKind.INSTRUCTION,
                DirectiveKind.POLITE_PROHIBITION,
            }
            and argument_words
            and argument_words[0].normalized in {"no", "na"}
        ):
            addressee_options = self._parse_nominal_span(
                argument_words[:1],
                role="subject",
            )
            implicit_addressee = False
            vocative_addressee = False
            object_words = tuple(argument_words[1:])
        else:
            addressee_options = (
                _NominalReading(
                    nominal=Nominal(
                        surface="na",
                        person=PronounPerson.SECOND,
                        animacy=PronounAnimacy.ANIMATE,
                        pronoun_kind=PronounKind.PERSONAL,
                        pronoun_base="na",
                    ),
                    english_text="you",
                    token_indices=(),
                    roles=(),
                    rule_trace=("clause.implicit-second-person-addressee",),
                ),
            )
            implicit_addressee = True
            vocative_addressee = False
            object_words = tuple(argument_words)

        if not addressee_options:
            return []
        argument_options = self._parse_directive_arguments(
            object_words,
            predicate,
        )
        if not argument_options:
            return []

        readings: list[_ClauseReading] = []
        joint_participant = (
            Nominal(
                surface="wa",
                person=PronounPerson.FIRST,
                animacy=PronounAnimacy.ANIMATE,
                pronoun_kind=PronounKind.PERSONAL,
                pronoun_base="wa",
                number="plural",
            )
            if form.kind
            in {
                DirectiveKind.HORTATIVE,
                DirectiveKind.POLITE_HORTATIVE,
            }
            else None
        )
        idiom_emitted = False
        for addressee, arguments in itertools.product(
            addressee_options,
            argument_options,
        ):
            directive = Directive(
                kind=form.kind,
                placement=form.placement,
                markers=form.markers,
                addressee=addressee.nominal,
                implicit_addressee=implicit_addressee,
                fused=form.fused,
                rapid_speech=form.rapid_speech,
                joint_participant=joint_participant,
                focus=form.focus,
            )
            object_reading = arguments.direct
            for gloss in predicate.english_glosses:
                rendered_verb = gloss
                rendered_object = (
                    object_reading.english_text
                    if object_reading is not None
                    else None
                )
                if predicate.verbalization_source_gloss is not None:
                    (
                        rendered_verb,
                        rendered_object,
                    ) = self._productive_verbalization_terms(
                        predicate,
                        rendered_object,
                        (
                            object_reading.nominal
                            if object_reading is not None
                            else None
                        ),
                    )
                clause = CanonicalClause(
                    predicate=predicate.lemma,
                    subject=addressee.nominal,
                    object=(
                        object_reading.nominal
                        if object_reading is not None
                        else None
                    ),
                    polarity=predicate.polarity,
                    predicate_kind=PredicateKind.ACTION,
                    verbal_derivation=predicate.verbal_derivation,
                    directive=directive,
                    omitted_subject=implicit_addressee,
                    obliques=tuple(
                        oblique.phrase for oblique in arguments.obliques
                    ),
                )
                roles = {
                    **dict(addressee.roles),
                    **dict(arguments.roles),
                    predicate_index: "predicate",
                    **{
                        index: "directive-marker"
                        for index in directive_marker_indices
                    },
                }
                ambiguities = [
                    *addressee.ambiguities,
                    *arguments.ambiguities,
                ]
                if len(predicate.english_glosses) > 1:
                    ambiguities.append(
                        TranslationAmbiguity(
                            code="UNSPLIT_SOURCE_GLOSS",
                            message=(
                                f"The source entry for {predicate.lemma!r} "
                                "contains multiple English gloss terms."
                            ),
                            choices=predicate.english_glosses,
                            selected=gloss,
                        )
                    )
                ordinary = _ClauseReading(
                    clause=clause,
                    output_text=self._directive_sentence(
                        rendered_verb,
                        rendered_object,
                        directive=directive,
                        oblique_texts=tuple(
                            oblique.english_text
                            for oblique in arguments.obliques
                        ),
                        vocative_text=(
                            addressee.english_text
                            if vocative_addressee
                            else None
                        ),
                    ),
                    roles=tuple(sorted(roles.items())),
                    predicate=predicate,
                    predicate_index=predicate_index,
                    subject_english=addressee.english_text,
                    assumptions=(
                        *addressee.assumptions,
                        *arguments.assumptions,
                    ),
                    ambiguities=tuple(ambiguities),
                    predicate_english=rendered_verb,
                    complement_english=rendered_object,
                    rule_trace=(
                        "translation.asaxi-expanded-clause",
                        "clause.directive",
                        "clause.directive-addressee",
                        *(
                            ("clause.directive-vocative",)
                            if vocative_addressee
                            else (
                                "clause.directive-explicit-addressee",
                            )
                            if not implicit_addressee
                            else (
                                "clause.implicit-second-person-addressee",
                            )
                        ),
                        *addressee.rule_trace,
                        *arguments.rule_trace,
                        *predicate.rule_trace,
                        *(
                            ("clause.inclusive-joint-participant",)
                            if joint_participant is not None
                            else ()
                        ),
                    ),
                )
                if (
                    not idiom_emitted
                    and self._is_continuation_goal_idiom(
                        clause,
                        predicate,
                    )
                ):
                    idiom_emitted = True
                    vocative = (
                        addressee.english_text + ", "
                        if vocative_addressee
                        else ""
                    )
                    idiom_choices = (
                        "don't give up",
                        "continue looking toward the destination",
                    )
                    readings.append(
                        replace(
                            ordinary,
                            output_text=_capitalize(
                                vocative + idiom_choices[0] + "!"
                            ),
                            ambiguities=(
                                *ordinary.ambiguities,
                                TranslationAmbiguity(
                                    code=(
                                        "CONTINUATION_GOAL_IDIOMATIC_"
                                        "INTERPRETATION"
                                    ),
                                    message=(
                                        "The documented continuation plus "
                                        "goal construction has both an "
                                        "idiomatic and a literal English "
                                        "rendering."
                                    ),
                                    choices=idiom_choices,
                                    selected=idiom_choices[0],
                                ),
                            ),
                            rule_trace=(
                                *ordinary.rule_trace,
                                "directive.continuation-goal-"
                                "persistence-idiom",
                            ),
                        )
                    )
                    readings.append(
                        replace(
                            ordinary,
                            output_text=_capitalize(
                                vocative + idiom_choices[1] + "!"
                            ),
                            ambiguities=(
                                *ordinary.ambiguities,
                                TranslationAmbiguity(
                                    code=(
                                        "CONTINUATION_GOAL_IDIOMATIC_"
                                        "INTERPRETATION"
                                    ),
                                    message=(
                                        "The documented continuation plus "
                                        "goal construction has both an "
                                        "idiomatic and a literal English "
                                        "rendering."
                                    ),
                                    choices=idiom_choices,
                                    selected=idiom_choices[1],
                                ),
                            ),
                            rule_trace=(
                                *ordinary.rule_trace,
                                "directive.continuation-goal-"
                                "persistence-literal",
                            ),
                        )
                    )
                    # This exact typed construction has two documented
                    # realizations. Further lexical glosses of ``ijo`` would
                    # manufacture malformed variants of the authored idiom.
                    return readings
                else:
                    readings.append(ordinary)
        return readings[:MAX_CLAUSE_ALTERNATIVES]

    def _parse_frontloaded_particle_copula(
        self,
        words: Sequence[Any],
        *,
        interrogative: bool,
        question_indices: set[int],
        discourse_state: DiscourseState | None,
    ) -> list[_ClauseReading]:
        """Parse ``subject + particle + nominal`` circumstantial clauses.

        The particle is written before its nominal complement even though its
        semantic predicate corresponds to the bare, circumstantial member of
        the documented ``particle``/``particle-ŕa`` contrast.
        """

        positions = tuple(
            index
            for index, token in enumerate(words)
            if token.normalized in CIRCUMSTANTIAL_NPCP_PREDICATES
            and index > 0
            and index + 1 < len(words)
        )
        if len(positions) != 1:
            return []
        position = positions[0]
        particle = words[position]
        kind, gloss = CIRCUMSTANTIAL_NPCP_PREDICATES[
            particle.normalized
        ]
        argument_words = (
            *words[:position],
            *words[position + 1:],
        )
        predicate = _PredicateReading(
            surface=particle.normalized,
            lemma=particle.normalized,
            kind=kind,
            english_glosses=(gloss,),
            validity_mode=ValidityMode.CIRCUMSTANTIAL,
            morphemes=(particle.normalized,),
            rule_trace=(
                "clause.frontloaded-npcp-predicate",
                "clause.validity-circumstantial",
            ),
            takes_complement=True,
        )
        readings = self._parse_predicated_clause(
            argument_words,
            predicate,
            particle.index,
            interrogative=interrogative,
            question_indices=question_indices,
            discourse_state=discourse_state,
        )
        return [
            replace(
                reading,
                clause=replace(reading.clause, zero_copula=True),
                rule_trace=(
                    "clause.frontloaded-npcp-zero-copula",
                    *reading.rule_trace,
                ),
            )
            for reading in readings
        ]

    @staticmethod
    def _extract_inner_post_verbal_scope(
        words: Sequence[Any],
    ) -> tuple[
        tuple[Any, ...],
        PostVerbalScope,
        tuple[tuple[int, str], ...],
    ] | None:
        """Peel result, potential, and irrealis as one ordered scope chain.

        The outer inquiry, discourse, and connector slots are extracted by
        the clause/document parser because they own larger spans.  Scanning
        these inner slots from right to left lets us reject a scrambled tail
        without guessing which marker the writer intended to scope first.
        """

        core = list(words)
        values: dict[str, Any] = {
            "resultative": ResultativeMode.NONE,
            "potential": PotentialMode.NONE,
            "subjunctive": SubjunctiveMode.NONE,
        }
        indices: list[tuple[int, str]] = []
        next_slot = len(INNER_POST_VERBAL_ORDER)
        while len(core) >= 2:
            token = core[-1]
            matched = INNER_POST_VERBAL_FORMS.get(token.normalized)
            if matched is None:
                break
            slot, value = matched
            slot_index = INNER_POST_VERBAL_ORDER.index(slot)
            if slot_index >= next_slot or values[slot].value != "none":
                return None
            core.pop()
            values[slot] = value
            indices.append((token.index, f"post-verbal-{slot}"))
            next_slot = slot_index
        return (
            tuple(core),
            PostVerbalScope(**values),
            tuple(sorted(indices)),
        )

    @staticmethod
    def _extract_event_modifiers(
        words: Sequence[Any],
    ) -> tuple[
        tuple[Any, ...],
        TemporalAspect,
        int | None,
        EventFrequency | None,
        int | None,
    ] | None:
        """Remove one documented aspect tail and one floating frequency.

        The remaining sequence is parsed by the ordinary argument grammar.
        Multiple particles of either class are left unsupported rather than
        silently choosing or dropping one.
        """

        core = list(words)
        aspect = TemporalAspect.NONE
        aspect_index: int | None = None
        frequency: EventFrequency | None = None
        frequency_index: int | None = None

        if core and core[-1].normalized in TEMPORAL_ASPECT_MARKERS:
            token = core.pop()
            aspect = TEMPORAL_ASPECT_MARKERS[token.normalized]
            aspect_index = token.index
        elif core and core[-1].normalized in FREQUENCY_MARKERS:
            token = core.pop()
            frequency = EventFrequency(
                marker=token.normalized,
                kind=FREQUENCY_MARKERS[token.normalized],
            )
            frequency_index = token.index

        frequency_positions = [
            index
            for index, token in enumerate(core[:-1])
            if token.normalized in FREQUENCY_MARKERS
        ]
        if frequency_positions:
            if frequency is not None or len(frequency_positions) != 1:
                return None
            position = frequency_positions[0]
            token = core.pop(position)
            frequency = EventFrequency(
                marker=token.normalized,
                kind=FREQUENCY_MARKERS[token.normalized],
            )
            frequency_index = token.index

        if any(
            token.normalized in TEMPORAL_ASPECT_MARKERS
            for token in core[:-1]
        ):
            return None
        return (
            tuple(core),
            aspect,
            aspect_index,
            frequency,
            frequency_index,
        )

    def _parse_predicated_clause(
        self,
        argument_words: Sequence[Any],
        predicate: _PredicateReading,
        predicate_index: int,
        *,
        interrogative: bool,
        question_indices: set[int],
        discourse_state: DiscourseState | None,
        _suppress_temporal_prefix: bool = False,
    ) -> list[_ClauseReading]:
        subject_marker_positions = [
            position
            for position, token in enumerate(argument_words)
            if (
                token.normalized in SUBJECT_MARKERS
                or token.normalized in FUSED_SUBJECT_DETERMINERS
            )
        ]
        if len(subject_marker_positions) > 1:
            return []
        subject_marker_position = (
            subject_marker_positions[0]
            if subject_marker_positions
            else None
        )
        preserved_topological_readings: list[_ClauseReading] = []
        if (
            not _suppress_temporal_prefix
            and subject_marker_position is None
            and self._has_ambiguous_topological_landmark_layout(
                argument_words,
                predicate,
            )
        ):
            # A lexeme such as mao can denote either a temporal expression
            # (night) or an ordinary subject (moon). Preserve the complete
            # subject+landmark parse before trying the normal temporal-prefix
            # analysis, so valency evidence can rank it without deleting the
            # genuinely available temporal reading.
            preserved_topological_readings = self._parse_predicated_clause(
                argument_words,
                predicate,
                predicate_index,
                interrogative=interrogative,
                question_indices=question_indices,
                discourse_state=discourse_state,
                _suppress_temporal_prefix=True,
            )
        preposed_content = (
            tuple(argument_words[:subject_marker_position])
            if subject_marker_position not in {None, 0}
            else ()
        )
        temporal_readings: tuple[_NominalReading | None, ...] = (None,)
        if preposed_content:
            temporal_candidates = tuple(
                reading
                for reading in self._parse_nominal_span(
                    preposed_content,
                    role="time",
                )
                if self._nominal_is_temporal(reading.nominal)
            )
            if temporal_candidates:
                temporal_readings = temporal_candidates
                preposed_content = ()
        marker_words = (
            argument_words[subject_marker_position:]
            if subject_marker_position is not None
            else argument_words
        )
        marker_token, fused_determiner_token = (
            self._split_subject_marker(marker_words)
        )
        register = (
            Register.OBJECTIVE
            if fused_determiner_token is not None
            else SUBJECT_MARKERS[marker_token.normalized]
            if marker_token is not None
            else Register.OBJECTIVE
        )
        content = (
            (
                fused_determiner_token,
                *marker_words[1:],
            )
            if fused_determiner_token is not None
            else marker_words[1:]
            if marker_token is not None
            else marker_words
        )
        if (
            not _suppress_temporal_prefix
            and temporal_readings == (None,)
            and marker_token is None
        ):
            for temporal_end in range(len(content) - 1, 0, -1):
                temporal_candidates = tuple(
                    reading
                    for reading in self._parse_nominal_span(
                        content[:temporal_end],
                        role="time",
                    )
                    if self._nominal_is_temporal(reading.nominal)
                )
                if temporal_candidates:
                    temporal_readings = temporal_candidates
                    content = content[temporal_end:]
                    break
        if any(
            token.normalized in CASE_MARKERS
            for token in (*preposed_content, *content)
        ):
            if preposed_content:
                # The case parser preserves case-bearing spans separately.
                # Its scrambled marked-subject layout is handled explicitly
                # rather than flattening those spans into one nominal.
                return []
            case_readings = self._parse_marked_case_clause(
                marker_token,
                content,
                predicate,
                predicate_index,
                register=register,
                interrogative=interrogative,
                question_indices=question_indices,
            )
            if case_readings:
                return case_readings
        if predicate.causative_voice is not None:
            # A recognized causative prefix may not fall through into the
            # ordinary SOV parser: that would silently reinterpret its causee
            # as an English matrix subject and erase the required bă causer.
            return []
        layouts: list[
            tuple[
                _NominalReading | None,
                _NominalReading | None,
                _NominalReading | None,
                bool,
                bool,
                tuple[TranslationAssumption, ...],
                tuple[TranslationAmbiguity, ...],
                tuple[str, ...],
            ]
        ] = []

        if marker_token is not None:
            if preposed_content:
                subjects = self._parse_nominal_span(
                    content,
                    role="subject",
                )
                complements = self._parse_nominal_span(
                    preposed_content,
                    role=self._complement_role(predicate),
                )
                for subject, complement in itertools.product(
                    subjects,
                    complements,
                ):
                    if self._layout_allowed(predicate, complement, subject):
                        layouts.append(
                            (
                                subject,
                                complement,
                                None,
                                False,
                                False,
                                (),
                                (),
                                (
                                    "clause.explicit-subject",
                                    "clause.marked-argument-scrambling",
                                ),
                            )
                        )
            else:
                for split in range(1, len(content) + 1):
                    if self._split_breaks_determiner_anchor(content, split):
                        continue
                    subjects = self._parse_nominal_span(
                        content[:split],
                        role="subject",
                    )
                    if split == len(content):
                        complements: tuple[
                            _NominalReading | None,
                            ...,
                        ] = (None,)
                    else:
                        complements = self._parse_nominal_span(
                            content[split:],
                            role=self._complement_role(predicate),
                        )
                    for subject, complement in itertools.product(
                        subjects,
                        complements,
                    ):
                        if self._layout_allowed(predicate, complement, subject):
                            layouts.append(
                                (
                                    subject,
                                    complement,
                                    None,
                                    False,
                                    False,
                                    (),
                                    (),
                                    ("clause.explicit-subject",),
                                )
                            )
            if predicate.kind is PredicateKind.ACTION:
                for subject_end in range(1, len(content) - 1):
                    if self._split_breaks_determiner_anchor(
                        content,
                        subject_end,
                    ):
                        continue
                    for object_end in range(
                        subject_end + 1,
                        len(content),
                    ):
                        if self._split_breaks_determiner_anchor(
                            content,
                            object_end,
                        ):
                            continue
                        subjects = self._parse_nominal_span(
                            content[:subject_end],
                            role="subject",
                        )
                        objects = self._parse_nominal_span(
                            content[subject_end:object_end],
                            role="object",
                        )
                        adjuncts = tuple(
                            adjunct
                            for adjunct in self._parse_nominal_span(
                                content[object_end:],
                                role="location",
                            )
                            if adjunct.nominal.wh_word
                            in {"where", "when", "why", "how"}
                        )
                        for subject, object_reading, adjunct in (
                            itertools.product(
                                subjects,
                                objects,
                                adjuncts,
                            )
                        ):
                            if not self._layout_allowed(
                                predicate,
                                object_reading,
                                subject,
                            ):
                                continue
                            layouts.append(
                                (
                                    subject,
                                    object_reading,
                                    adjunct,
                                    False,
                                    False,
                                    (),
                                    (),
                                    (
                                        "clause.explicit-subject",
                                        "clause.action-wh-adjunct",
                                    ),
                                )
                            )
        elif not content:
            if discourse_state and discourse_state.topic:
                layouts.append(
                    (
                        _NominalReading(
                            nominal=discourse_state.topic.nominal,
                            english_text=discourse_state.topic.english_text,
                            token_indices=(),
                            roles=(),
                            assumptions=(
                                TranslationAssumption(
                                    code="DISCOURSE_TOPIC_RESOLVED",
                                    message=(
                                        "The omitted subject was resolved from "
                                        "the caller-supplied discourse state."
                                    ),
                                    details=discourse_state.to_dict(),
                                ),
                            ),
                            rule_trace=("discourse.explicit-topic-input",),
                        ),
                        None,
                        None,
                        True,
                        True,
                        (),
                        (),
                        ("clause.pro-drop-resolved",),
                    )
                )
            else:
                layouts.append(
                    (
                        _NominalReading(
                            nominal=Nominal("[omitted topic]"),
                            english_text="someone or something",
                            token_indices=(),
                            roles=(),
                            ambiguities=(
                                TranslationAmbiguity(
                                    code="UNRESOLVED_OMITTED_TOPIC",
                                    message=(
                                        "Asaxi licenses an omitted subject, "
                                        "but this isolated clause provides no "
                                        "discourse referent for it."
                                    ),
                                    choices=(
                                        "animate discourse topic",
                                        "inanimate discourse topic",
                                    ),
                                    selected="unresolved discourse topic",
                                ),
                            ),
                            rule_trace=(
                                "discourse.unresolved-omitted-topic",
                            ),
                        ),
                        None,
                        None,
                        True,
                        False,
                        (),
                        (),
                        ("clause.pro-drop-unresolved",),
                    )
                )
        else:
            split_layouts = self._strict_unmarked_layouts(content, predicate)
            if split_layouts:
                layouts.extend(split_layouts)
            else:
                subjects = self._parse_nominal_span(
                    content,
                    role="subject",
                )
                objects = (
                    self._parse_nominal_span(content, role="object")
                    if predicate.is_transitive
                    else ()
                )
                if discourse_state and discourse_state.topic and objects:
                    topic = discourse_state.topic
                    for object_reading in objects:
                        layouts.append(
                            (
                                _NominalReading(
                                    nominal=topic.nominal,
                                    english_text=topic.english_text,
                                    token_indices=(),
                                    roles=(),
                                    assumptions=(
                                        TranslationAssumption(
                                            code="DISCOURSE_TOPIC_RESOLVED",
                                            message=(
                                                "The omitted subject was "
                                                "resolved from explicit "
                                                "discourse state."
                                            ),
                                            details=discourse_state.to_dict(),
                                        ),
                                    ),
                                    rule_trace=(
                                        "discourse.explicit-topic-input",
                                    ),
                                ),
                                object_reading,
                                None,
                                True,
                                True,
                                (),
                                (),
                                ("clause.pro-drop-object",),
                            )
                        )
                else:
                    for subject in subjects:
                        if not self._layout_allowed(
                            predicate,
                            None,
                            subject,
                        ):
                            continue
                        layouts.append(
                            (
                                subject,
                                None,
                                None,
                                False,
                                False,
                                (),
                                (),
                                ("clause.single-unmarked-subject",),
                            )
                        )
                    for object_reading in objects:
                        layouts.append(
                            (
                                _NominalReading(
                                    nominal=Nominal("[omitted topic]"),
                                    english_text="[omitted topic]",
                                    token_indices=(),
                                    roles=(),
                                ),
                                object_reading,
                                None,
                                True,
                                False,
                                (),
                                (
                                    TranslationAmbiguity(
                                        code="UNRESOLVED_OMITTED_TOPIC",
                                        message=(
                                            "The lone unmarked nominal phrase "
                                            "may be an object whose discourse "
                                            "topic was omitted."
                                        ),
                                        choices=(
                                            "overt nominal is subject",
                                            "overt nominal is object",
                                        ),
                                        selected="overt nominal is object",
                                    ),
                                ),
                                ("clause.pro-drop-unresolved",),
                            )
                        )

        layouts = [
            layout
            for layout in layouts
            if (
                layout[3]
                or layout[0] is None
                or pronoun_binding_is_licensed(
                    layout[0].nominal,
                    (
                        layout[1].nominal
                        if layout[1] is not None
                        else None
                    ),
                )
            )
        ]

        if (
            marker_token is not None
            and predicate.is_transitive
            and any(complement is not None for _, complement, *_ in layouts)
        ):
            layouts = [
                layout for layout in layouts if layout[1] is not None
            ]

        layouts.sort(
            key=lambda layout: (
                (
                    layout[0].structural_cost
                    if layout[0] is not None
                    else 0
                )
                + (
                    layout[1].structural_cost
                    if layout[1] is not None
                    else 0
                ),
                (
                    layout[2].structural_cost
                    if layout[2] is not None
                    else 0
                ),
            )
        )
        readings: list[_ClauseReading] = []
        expanded_layouts = [
            (*layout, temporal)
            for layout in layouts
            for temporal in temporal_readings
        ]
        for (
            subject,
            complement,
            adjunct,
            omitted_subject,
            discourse_subject,
            layout_assumptions,
            layout_ambiguities,
            layout_trace,
            temporal,
        ) in expanded_layouts:
            if subject is None:
                continue
            (
                predicate_glosses,
                predicate_sense_trace,
            ) = self._ordered_predicate_glosses(
                predicate,
                complement,
            )
            for gloss in predicate_glosses:
                clause_kind = predicate.kind
                locative_copula = (
                    predicate.kind
                    in {
                        PredicateKind.IDENTITY,
                        PredicateKind.PERFORMANCE,
                    }
                    and complement is not None
                    and complement.nominal.deixis is not None
                    and complement.nominal.surface
                    in VICINITY_NOMINAL_MODIFIERS
                )
                if locative_copula:
                    clause_kind = PredicateKind.LOCATION
                if (
                    predicate.kind is PredicateKind.IDENTITY
                    and complement is None
                ):
                    clause_kind = PredicateKind.EXISTENCE
                wh_role = self._wh_role(
                    subject,
                    (
                        adjunct
                        if adjunct is not None
                        else complement
                    ),
                    predicate.kind,
                )
                effective_interrogative = interrogative or wh_role is not None
                complement_nominal = (
                    complement.nominal if complement is not None else None
                )
                object_nominal = (
                    complement_nominal
                    if clause_kind is PredicateKind.ACTION
                    and (
                        adjunct is not None
                        or wh_role
                        not in {
                            WhRole.LOCATION,
                            WhRole.TIME,
                            WhRole.REASON,
                            WhRole.MANNER,
                        }
                    )
                    else None
                )
                location_nominal = (
                    adjunct.nominal
                    if adjunct is not None
                    else (
                        complement_nominal
                        if clause_kind is PredicateKind.LOCATION
                        or wh_role
                        in {
                            WhRole.LOCATION,
                            WhRole.TIME,
                            WhRole.REASON,
                            WhRole.MANNER,
                        }
                        else None
                    )
                )
                semantic_complement = (
                    complement_nominal
                    if clause_kind
                    in {
                        PredicateKind.IDENTITY,
                        PredicateKind.PERFORMANCE,
                        PredicateKind.POSSESSION,
                        PredicateKind.RELATION,
                    }
                    else None
                )
                clause = CanonicalClause(
                    predicate=predicate.lemma,
                    subject=subject.nominal,
                    object=object_nominal,
                    tense=predicate.tense,
                    polarity=predicate.polarity,
                    register=register,
                    interrogative=effective_interrogative,
                    predicate_kind=clause_kind,
                    complement=semantic_complement,
                    location=location_nominal,
                    time=(
                        temporal.nominal
                        if temporal is not None
                        else None
                    ),
                    modality=predicate.modality,
                    validity_mode=predicate.validity_mode,
                    verbal_derivation=predicate.verbal_derivation,
                    predicate_time_binding=predicate.word_time_binding,
                    temporal_aspect=predicate.temporal_aspect,
                    frequency=predicate.frequency,
                    post_verbal_scope=predicate.post_verbal_scope,
                    wh_role=wh_role,
                    omitted_subject=omitted_subject,
                    discourse_subject=discourse_subject,
                    subject_marked=marker_token is not None,
                )
                ambiguities = [
                    *subject.ambiguities,
                    *(
                        complement.ambiguities
                        if complement is not None
                        else ()
                    ),
                    *(
                        adjunct.ambiguities
                        if adjunct is not None
                        else ()
                    ),
                    *(
                        temporal.ambiguities
                        if temporal is not None
                        else ()
                    ),
                    *layout_ambiguities,
                ]
                if len(predicate.english_glosses) > 1:
                    ambiguities.append(
                        TranslationAmbiguity(
                            code="UNSPLIT_SOURCE_GLOSS",
                            message=(
                                f"The source entry for {predicate.lemma!r} "
                                "contains multiple English gloss terms."
                            ),
                            choices=predicate.english_glosses,
                            selected=gloss,
                        )
                    )
                if (
                    predicate.verbalization_source_gloss is not None
                    and len(predicate.verbalization_source_glosses) > 1
                ):
                    ambiguities.append(
                        TranslationAmbiguity(
                            code="VERBALIZATION_SOURCE_SENSE_AMBIGUOUS",
                            message=(
                                "The noun incorporated into this productive "
                                "verb has multiple compiled English senses."
                            ),
                            choices=(
                                predicate.verbalization_source_glosses
                            ),
                            selected=(
                                predicate.verbalization_source_gloss
                            ),
                        )
                    )
                if wh_role is not None and not interrogative:
                    ambiguities.append(
                        TranslationAmbiguity(
                            code="WH_FORCE_WITHOUT_QUESTION_MARKER",
                            message=(
                                "The wh form is in situ without kè or question "
                                "punctuation; direct and indirect readings "
                                "remain context-dependent."
                            ),
                            choices=(
                                "direct question",
                                "indirect/contextual question",
                            ),
                            selected="direct question",
                        )
                    )
                assumptions = [
                    *subject.assumptions,
                    *(
                        complement.assumptions
                        if complement is not None
                        else ()
                    ),
                    *(
                        adjunct.assumptions
                        if adjunct is not None
                        else ()
                    ),
                    *(
                        temporal.assumptions
                        if temporal is not None
                        else ()
                    ),
                    *layout_assumptions,
                ]
                roles = {
                    **dict(subject.roles),
                    **(
                        dict(complement.roles)
                        if complement is not None
                        else {}
                    ),
                    **(
                        dict(adjunct.roles)
                        if adjunct is not None
                        else {}
                    ),
                    **(
                        dict(temporal.roles)
                        if temporal is not None
                        else {}
                    ),
                    predicate_index: "predicate",
                    **{index: "question" for index in question_indices},
                }
                if marker_token is not None:
                    roles[marker_token.index] = (
                        "subject-marker+determiner"
                        if fused_determiner_token is not None
                        else "subject-marker"
                    )
                if predicate.temporal_aspect_index is not None:
                    roles[predicate.temporal_aspect_index] = (
                        "temporal-aspect"
                    )
                if predicate.frequency_index is not None:
                    roles[predicate.frequency_index] = "frequency-adverb"
                if (
                    predicate.word_time_index is not None
                    and predicate.word_time_index != predicate_index
                ):
                    roles[predicate.word_time_index] = "word-time-marker"
                roles.update(dict(predicate.post_verbal_indices))
                output = self._render_clause(
                    clause,
                    subject.english_text,
                    (
                        complement.english_text
                        if complement is not None
                        else None
                    ),
                    gloss,
                    predicate=predicate,
                )
                if temporal is not None:
                    if self._uses_weather_expletive(clause, predicate):
                        time_text = temporal.english_text
                        if time_text.casefold().startswith(
                            "all day "
                        ):
                            time_text = "all " + time_text[8:]
                        output = self._append_temporal_nominal(
                            output,
                            time_text,
                        )
                    else:
                        output = self._front_temporal_nominal(
                            temporal.english_text,
                            output,
                        )
                readings.append(
                    _ClauseReading(
                        clause=clause,
                        output_text=output,
                        roles=tuple(sorted(roles.items())),
                        predicate=predicate,
                        predicate_index=predicate_index,
                        subject_english=subject.english_text,
                        assumptions=tuple(assumptions),
                        ambiguities=tuple(ambiguities),
                        predicate_english=gloss,
                        complement_english=(
                            complement.english_text
                            if complement is not None
                            else None
                        ),
                        rule_trace=(
                            "translation.asaxi-expanded-clause",
                            *_fused_subject_rules(
                                marker_token.normalized
                                if marker_token is not None
                                else ""
                            ),
                            *layout_trace,
                            *subject.rule_trace,
                            *(
                                complement.rule_trace
                                if complement is not None
                                else ()
                            ),
                            *(
                                adjunct.rule_trace
                                if adjunct is not None
                                else ()
                            ),
                            *(
                                (
                                    "clause.time-nominal.fronted",
                                    *temporal.rule_trace,
                                )
                                if temporal is not None
                                else ()
                            ),
                            *(
                                ("english.render.weather-expletive",)
                                if self._uses_weather_expletive(
                                    clause,
                                    predicate,
                                )
                                else ()
                            ),
                            *(
                                (
                                    "english.render.full-extent-"
                                    "durative-progressive",
                                )
                                if self._uses_full_extent_progressive(
                                    clause,
                                    predicate,
                                )
                                else ()
                            ),
                            *_pronoun_binding_rule(
                                (
                                    complement.nominal
                                    if complement is not None
                                    else None
                                )
                            ),
                            *predicate.rule_trace,
                            *predicate_sense_trace,
                            *(
                                (
                                    "clause.temporal-aspect-tail",
                                    "temporal."
                                    + predicate.temporal_aspect.value,
                                )
                                if predicate.temporal_aspect
                                is not TemporalAspect.NONE
                                else ()
                            ),
                            *(
                                (
                                    "clause.frequency-adverb",
                                    "frequency."
                                    + predicate.frequency.kind.value,
                                )
                                if predicate.frequency is not None
                                else ()
                            ),
                            *(
                                (
                                    "post-verbal.result",
                                    "post-verbal.strict-slot-order",
                                )
                                if predicate.post_verbal_scope.resultative
                                is not ResultativeMode.NONE
                                else ()
                            ),
                            *(
                                (
                                    "post-verbal.potential",
                                    "post-verbal.strict-slot-order",
                                )
                                if predicate.post_verbal_scope.potential
                                is not PotentialMode.NONE
                                else ()
                            ),
                            *(
                                (
                                    "post-verbal.subjunctive",
                                    "post-verbal.strict-slot-order",
                                )
                                if predicate.post_verbal_scope.subjunctive
                                is not SubjunctiveMode.NONE
                                else ()
                            ),
                        ),
                    )
                )
        combined: list[_ClauseReading] = []
        for reading in (*preserved_topological_readings, *readings):
            if reading not in combined:
                combined.append(reading)
        return combined[:MAX_CLAUSE_ALTERNATIVES]

    def _has_ambiguous_topological_landmark_layout(
        self,
        words: Sequence[Any],
        predicate: _PredicateReading,
    ) -> bool:
        """Detect a temporal-looking prefix that also fills subject valency."""

        if (
            "clause.topological-validity-predicate"
            not in predicate.rule_trace
            or len(words) < 2
        ):
            return False
        has_temporal_prefix = any(
            self._nominal_is_temporal(reading.nominal)
            for end in range(len(words) - 1, 0, -1)
            for reading in self._parse_nominal_span(
                words[:end],
                role="time",
            )
        )
        if not has_temporal_prefix:
            return False
        return any(
            not self._nominal_is_temporal(subject.nominal)
            for subject, _complement, *_rest in self._strict_unmarked_layouts(
                words,
                predicate,
            )
        )

    def _ordered_predicate_glosses(
        self,
        predicate: _PredicateReading,
        complement: _NominalReading | None,
    ) -> tuple[tuple[str, ...], tuple[str, ...]]:
        """Rank polysemous relational senses from grammatical evidence.

        The validity documentation contrasts ``niŕa`` as a change into a
        constitutional/type complement with its allative "lead to" reading.
        A compiled ga-noun or adjective is strong evidence for the former;
        an ordinary destination nominal is evidence for the latter. Both
        senses remain materialized so this ranking never hides ambiguity.
        """

        glosses = predicate.english_glosses
        if (
            predicate.word_time_binding is not None
            and predicate.lexeme is not None
        ):
            licensed_bases = english_verb_bases(predicate.lexeme)
            if licensed_bases:
                return (
                    tuple(dict.fromkeys((*licensed_bases, *glosses))),
                    (),
                )
        if predicate.lemma != "niŕa" or len(glosses) < 2:
            return glosses, ()
        complement_lexeme = (
            self._lexemes_by_id.get(complement.nominal.lexeme_id)
            if (
                complement is not None
                and complement.nominal.lexeme_id is not None
            )
            else None
        )
        constitutional = bool(
            complement_lexeme is not None
            and (
                "ga-noun" in complement_lexeme.tags
                or complement_lexeme.category == "adjective"
            )
        )
        preferred = "become" if constitutional else "lead to"
        ordered = tuple(
            sorted(
                glosses,
                key=lambda gloss: (
                    gloss != preferred,
                    glosses.index(gloss),
                ),
            )
        )
        return ordered, ("clause.relational-sense-selection",)

    def _parse_marked_case_clause(
        self,
        marker_token: Any | None,
        content: Sequence[Any],
        predicate: _PredicateReading,
        predicate_index: int,
        *,
        register: Register,
        interrogative: bool,
        question_indices: set[int],
    ) -> list[_ClauseReading]:
        """Parse one NPCP argument without flattening its role.

        With an explicit subject marker, the unmarked direct object may occur
        before or after the NPCP block. Without a marker, the first unmarked
        nominal remains the subject and the second remains the object.
        """

        if predicate.kind is not PredicateKind.ACTION:
            return []
        if predicate.causative_voice is not None:
            if marker_token is None:
                return []
            return self._parse_causative_case_clause(
                marker_token,
                content,
                predicate,
                predicate_index,
                register=register,
                interrogative=interrogative,
                question_indices=question_indices,
            )
        case_positions = [
            index
            for index, token in enumerate(content)
            if token.normalized in CASE_MARKERS
        ]
        if len(case_positions) > 1:
            return self._parse_multiple_case_clause(
                marker_token,
                content,
                predicate,
                predicate_index,
                register=register,
                interrogative=interrogative,
                question_indices=question_indices,
            )
        if len(case_positions) != 1 or case_positions[0] == 0:
            return []
        case_position = case_positions[0]
        case_token = content[case_position]
        case_distribution_token = (
            content[case_position - 1]
            if (
                case_position > 0
                and content[case_position - 1].normalized
                in DISTRIBUTIVE_PARTICLES
            )
            else None
        )
        relation, function, prepositions = CASE_MARKERS[
            case_token.normalized
        ]
        prepositions = self._case_prepositions(
            relation,
            predicate,
            prepositions,
        )
        leading = content[
            :(
                case_position - 1
                if case_distribution_token is not None
                else case_position
            )
        ]
        following = content[case_position + 1:]
        if not leading or not following:
            return []

        candidates: list[tuple[tuple[int, int, int], _ClauseReading]] = []
        for subject_length in range(1, len(leading) + 1):
            subject_options = self._parse_nominal_span(
                leading[:subject_length],
                role="subject",
            )
            if not subject_options:
                continue
            leading_direct_words = leading[subject_length:]
            leading_direct_options: tuple[
                _NominalReading | None, ...
            ]
            if leading_direct_words:
                parsed_leading_direct = self._parse_nominal_span(
                    leading_direct_words,
                    role="object",
                )
                if not parsed_leading_direct:
                    continue
                leading_direct_options = tuple(parsed_leading_direct)
            else:
                leading_direct_options = (None,)

            for case_length in range(1, len(following) + 1):
                case_nominals = self._parse_nominal_span(
                    following[:case_length],
                    role=CASE_ARGUMENT_ROLES[relation],
                )
                if case_distribution_token is not None:
                    case_nominals = tuple(
                        attached
                        for nominal in case_nominals
                        if (
                            attached
                            := self._attach_distributive_to_nominal(
                                nominal,
                                token=case_distribution_token,
                                role=CASE_ARGUMENT_ROLES[relation],
                                placement="pre-case",
                            )
                        )
                        is not None
                    )
                if not case_nominals:
                    continue
                trailing_direct_words = following[case_length:]
                if leading_direct_words and trailing_direct_words:
                    continue
                direct_options: tuple[
                    _NominalReading | None, ...
                ]
                if leading_direct_words:
                    direct_options = leading_direct_options
                elif trailing_direct_words:
                    parsed_trailing_direct = self._parse_nominal_span(
                        trailing_direct_words,
                        role="object",
                    )
                    if not parsed_trailing_direct:
                        continue
                    direct_options = tuple(parsed_trailing_direct)
                else:
                    direct_options = (None,)

                for subject, case_nominal, direct in itertools.product(
                    subject_options,
                    case_nominals,
                    direct_options,
                ):
                    self._append_case_clause_candidates(
                        candidates,
                        marker_token=marker_token,
                        case_token=case_token,
                        relation=relation,
                        function=function,
                        prepositions=prepositions,
                        subject=subject,
                        case_nominal=case_nominal,
                        direct=direct,
                        predicate=predicate,
                        predicate_index=predicate_index,
                        register=register,
                        interrogative=interrogative,
                        question_indices=question_indices,
                    )
        candidates.sort(key=lambda item: item[0])
        return [
            reading
            for _, reading in candidates[:MAX_CLAUSE_ALTERNATIVES]
        ]

    def _append_case_clause_candidates(
        self,
        candidates: list[tuple[tuple[int, int, int], _ClauseReading]],
        *,
        marker_token: Any | None,
        case_token: Any,
        relation: CaseRelation,
        function: str,
        prepositions: tuple[str, ...],
        subject: _NominalReading,
        case_nominal: _NominalReading,
        direct: _NominalReading | None,
        predicate: _PredicateReading,
        predicate_index: int,
        register: Register,
        interrogative: bool,
        question_indices: set[int],
    ) -> None:
        """Append all lexical renderings for one structural case analysis."""

        if direct is not None and not predicate.is_transitive:
            return
        if direct is None and predicate.requires_complement:
            return
        if not pronoun_binding_is_licensed(
            subject.nominal,
            direct.nominal if direct is not None else None,
        ):
            return
        if not pronoun_binding_is_licensed(
            subject.nominal,
            case_nominal.nominal,
        ):
            return
        phrase = RelationalPhrase(
            marker=case_token.normalized,
            relation=relation,
            nominal=case_nominal.nominal,
            function=function,
        )
        for preposition_index, preposition in enumerate(prepositions):
            ambiguities = [
                *subject.ambiguities,
                *case_nominal.ambiguities,
                *(
                    direct.ambiguities
                    if direct is not None
                    else ()
                ),
            ]
            if len(prepositions) > 1:
                ambiguities.append(
                    TranslationAmbiguity(
                        code="CASE_FUNCTION_AMBIGUOUS",
                        message=(
                            f"The {relation.value} marker "
                            f"{case_token.surface!r} permits more "
                            "than one English relation in this "
                            "lexical context."
                        ),
                        choices=prepositions,
                        selected=preposition,
                    )
                )
            for gloss in predicate.english_glosses:
                if len(predicate.english_glosses) > 1:
                    predicate_ambiguities = (
                        TranslationAmbiguity(
                            code="UNSPLIT_SOURCE_GLOSS",
                            message=(
                                "The source entry for "
                                f"{predicate.lemma!r} contains "
                                "multiple English gloss terms."
                            ),
                            choices=predicate.english_glosses,
                            selected=gloss,
                        ),
                    )
                else:
                    predicate_ambiguities = ()
                clause = CanonicalClause(
                    predicate=predicate.lemma,
                    subject=subject.nominal,
                    object=(
                        direct.nominal
                        if direct is not None
                        else None
                    ),
                    tense=predicate.tense,
                    polarity=predicate.polarity,
                    register=register,
                    interrogative=interrogative,
                    predicate_kind=predicate.kind,
                    modality=predicate.modality,
                    validity_mode=predicate.validity_mode,
                    temporal_aspect=predicate.temporal_aspect,
                    frequency=predicate.frequency,
                    obliques=(phrase,),
                )
                roles = {
                    **dict(subject.roles),
                    **dict(case_nominal.roles),
                    **(
                        dict(direct.roles)
                        if direct is not None
                        else {}
                    ),
                    case_token.index: (
                        f"{relation.value}-marker"
                    ),
                    predicate_index: "predicate",
                    **{
                        index: "question"
                        for index in question_indices
                    },
                }
                if marker_token is not None:
                    roles[marker_token.index] = (
                        "subject-marker+determiner"
                        if marker_token.normalized
                        in FUSED_SUBJECT_DETERMINERS
                        else "subject-marker"
                    )
                if predicate.temporal_aspect_index is not None:
                    roles[predicate.temporal_aspect_index] = (
                        "temporal-aspect"
                    )
                if predicate.frequency_index is not None:
                    roles[predicate.frequency_index] = (
                        "frequency-adverb"
                    )
                directed_feeling_target = (
                    relation is CaseRelation.ALLATIVE
                    and preposition == ""
                )
                oblique_text = (
                    case_nominal.english_text
                    if directed_feeling_target
                    else f"{preposition} {case_nominal.english_text}"
                )
                reading = _ClauseReading(
                    clause=clause,
                    output_text=self._action_sentence(
                        subject.english_text,
                        gloss,
                        (
                            direct.english_text
                            if direct is not None
                            else None
                        ),
                        tense=predicate.tense,
                        polarity=predicate.polarity,
                        modality=predicate.modality,
                        interrogative=interrogative,
                        wh_role=None,
                        temporal_aspect=(
                            predicate.temporal_aspect
                        ),
                        frequency=predicate.frequency,
                        oblique_texts=(oblique_text,),
                    ),
                    roles=tuple(sorted(roles.items())),
                    predicate=predicate,
                    predicate_index=predicate_index,
                    subject_english=subject.english_text,
                    assumptions=(
                        *subject.assumptions,
                        *case_nominal.assumptions,
                        *(
                            direct.assumptions
                            if direct is not None
                            else ()
                        ),
                    ),
                    ambiguities=(
                        *ambiguities,
                        *predicate_ambiguities,
                    ),
                    rule_trace=(
                        "translation.asaxi-expanded-clause",
                        *_fused_subject_rules(
                            marker_token.normalized
                            if marker_token is not None
                            else ""
                        ),
                        (
                            "clause.explicit-subject"
                            if marker_token is not None
                            else "clause.strict-unmarked-sov"
                        ),
                        "clause.case-argument",
                        *(
                            ("clause.unmarked-case-argument",)
                            if marker_token is None
                            else ()
                        ),
                        f"argument.{relation.value}",
                        *(
                            ("argument.directed-feeling-target",)
                            if directed_feeling_target
                            else ()
                        ),
                        *subject.rule_trace,
                        *case_nominal.rule_trace,
                        *(
                            direct.rule_trace
                            if direct is not None
                            else ()
                        ),
                        *_pronoun_binding_rule(
                            (
                                direct.nominal
                                if direct is not None
                                else None
                            )
                        ),
                        *_pronoun_binding_rule(
                            case_nominal.nominal
                        ),
                        *predicate.rule_trace,
                        *(
                            (
                                "clause.temporal-aspect-tail",
                                "temporal."
                                + predicate.temporal_aspect.value,
                            )
                            if predicate.temporal_aspect
                            is not TemporalAspect.NONE
                            else ()
                        ),
                        *(
                            (
                                "clause.frequency-adverb",
                                "frequency."
                                + predicate.frequency.kind.value,
                            )
                            if predicate.frequency is not None
                            else ()
                        ),
                    ),
                )
                candidates.append(
                    (
                        (
                            int(
                                predicate.is_transitive
                                and direct is None
                            ),
                            (
                                subject.structural_cost
                                + case_nominal.structural_cost
                                + (
                                    direct.structural_cost
                                    if direct is not None
                                    else 0
                                )
                            ),
                            preposition_index,
                        ),
                        reading,
                    )
                )

    def _parse_multiple_case_clause(
        self,
        marker_token: Any | None,
        content: Sequence[Any],
        predicate: _PredicateReading,
        predicate_index: int,
        *,
        register: Register,
        interrogative: bool,
        question_indices: set[int],
    ) -> list[_ClauseReading]:
        """Parse two or more independently typed NPCP arguments.

        Each case marker owns a non-empty nominal span. At most one unmarked
        span is licensed as the direct object, preserving the documented
        distinction between the theme and every oblique participant.
        """

        if (
            predicate.kind is not PredicateKind.ACTION
            or predicate.causative_voice is not None
        ):
            return []
        case_positions = tuple(
            index
            for index, token in enumerate(content)
            if token.normalized in CASE_MARKERS
        )
        if len(case_positions) < 2:
            return []
        case_distributors = tuple(
            (
                content[position - 1]
                if (
                    position > 0
                    and content[position - 1].normalized
                    in DISTRIBUTIVE_PARTICLES
                )
                else None
            )
            for position in case_positions
        )
        leading_end = case_positions[0] - (
            1 if case_distributors[0] is not None else 0
        )
        if leading_end <= 0:
            return []
        leading = content[:leading_end]
        runs = tuple(
            (
                content[position],
                case_distributors[index],
                content[
                    position + 1:
                    (
                        case_positions[index + 1]
                        - (
                            1
                            if case_distributors[index + 1]
                            is not None
                            else 0
                        )
                        if index + 1 < len(case_positions)
                        else len(content)
                    )
                ],
            )
            for index, position in enumerate(case_positions)
        )
        if any(not words for _, _, words in runs):
            return []

        candidates: list[
            tuple[tuple[int, int, tuple[int, ...]], _ClauseReading]
        ] = []
        for subject_length in range(1, len(leading) + 1):
            subject_options = self._parse_nominal_span(
                leading[:subject_length],
                role="subject",
            )
            if not subject_options:
                continue
            leading_direct_words = leading[subject_length:]
            if leading_direct_words:
                leading_direct_options: tuple[
                    _NominalReading | None, ...
                ] = tuple(
                    self._parse_nominal_span(
                        leading_direct_words,
                        role="object",
                    )
                )
                if not leading_direct_options:
                    continue
            else:
                leading_direct_options = (None,)

            case_groups: list[
                tuple[
                    tuple[
                        _CaseArgumentReading,
                        _NominalReading | None,
                        int,
                    ],
                    ...,
                ]
            ] = []
            for case_token, case_distribution_token, run_words in runs:
                relation, function, default_prepositions = CASE_MARKERS[
                    case_token.normalized
                ]
                prepositions = self._case_prepositions(
                    relation,
                    predicate,
                    default_prepositions,
                )
                options: list[
                    tuple[
                        _CaseArgumentReading,
                        _NominalReading | None,
                        int,
                    ]
                ] = []
                for nominal_length in range(1, len(run_words) + 1):
                    nominal_options = self._parse_nominal_span(
                        run_words[:nominal_length],
                        role=CASE_ARGUMENT_ROLES[relation],
                    )
                    if case_distribution_token is not None:
                        nominal_options = tuple(
                            attached
                            for nominal in nominal_options
                            if (
                                attached
                                := self._attach_distributive_to_nominal(
                                    nominal,
                                    token=case_distribution_token,
                                    role=CASE_ARGUMENT_ROLES[relation],
                                    placement="pre-case",
                                )
                            )
                            is not None
                        )
                    if not nominal_options:
                        continue
                    trailing_words = run_words[nominal_length:]
                    if trailing_words:
                        direct_options: tuple[
                            _NominalReading | None, ...
                        ] = tuple(
                            self._parse_nominal_span(
                                trailing_words,
                                role="object",
                            )
                        )
                        if not direct_options:
                            continue
                    else:
                        direct_options = (None,)
                    for nominal, direct in itertools.product(
                        nominal_options,
                        direct_options,
                    ):
                        for preposition_index, preposition in enumerate(
                            prepositions
                        ):
                            ambiguities = list(nominal.ambiguities)
                            if len(prepositions) > 1:
                                ambiguities.append(
                                    TranslationAmbiguity(
                                        code="CASE_FUNCTION_AMBIGUOUS",
                                        message=(
                                            f"The {relation.value} marker "
                                            f"{case_token.surface!r} permits "
                                            "more than one English relation "
                                            "in this lexical context."
                                        ),
                                        choices=prepositions,
                                        selected=preposition,
                                    )
                                )
                            options.append(
                                (
                                    _CaseArgumentReading(
                                        phrase=RelationalPhrase(
                                            marker=case_token.normalized,
                                            relation=relation,
                                            nominal=nominal.nominal,
                                            function=function,
                                        ),
                                        english_text=(
                                            f"{preposition} "
                                            f"{nominal.english_text}"
                                        ),
                                        roles=tuple(
                                            sorted(
                                                {
                                                    **dict(nominal.roles),
                                                    case_token.index: (
                                                        f"{relation.value}"
                                                        "-marker"
                                                    ),
                                                }.items()
                                            )
                                        ),
                                        assumptions=nominal.assumptions,
                                        ambiguities=tuple(ambiguities),
                                        rule_trace=(
                                            f"argument.{relation.value}",
                                            *nominal.rule_trace,
                                        ),
                                        structural_cost=(
                                            nominal.structural_cost
                                        ),
                                    ),
                                    direct,
                                    preposition_index,
                                )
                            )
                if not options:
                    case_groups = []
                    break
                case_groups.append(tuple(options))
            if not case_groups:
                continue

            for subject, leading_direct, case_choices in itertools.product(
                subject_options,
                leading_direct_options,
                itertools.product(*case_groups),
            ):
                trailing_directs = tuple(
                    direct
                    for _, direct, _ in case_choices
                    if direct is not None
                )
                all_directs = (
                    *((leading_direct,) if leading_direct is not None else ()),
                    *trailing_directs,
                )
                if len(all_directs) > 1:
                    continue
                direct = all_directs[0] if all_directs else None
                if direct is not None and not predicate.is_transitive:
                    continue
                if direct is None and predicate.requires_complement:
                    continue
                if not pronoun_binding_is_licensed(
                    subject.nominal,
                    direct.nominal if direct is not None else None,
                ):
                    continue
                arguments = tuple(
                    argument for argument, _, _ in case_choices
                )
                if any(
                    not pronoun_binding_is_licensed(
                        subject.nominal,
                        argument.phrase.nominal,
                    )
                    for argument in arguments
                ):
                    continue

                for gloss in predicate.english_glosses:
                    predicate_ambiguities = (
                        (
                            TranslationAmbiguity(
                                code="UNSPLIT_SOURCE_GLOSS",
                                message=(
                                    "The source entry for "
                                    f"{predicate.lemma!r} contains multiple "
                                    "English gloss terms."
                                ),
                                choices=predicate.english_glosses,
                                selected=gloss,
                            ),
                        )
                        if len(predicate.english_glosses) > 1
                        else ()
                    )
                    clause = CanonicalClause(
                        predicate=predicate.lemma,
                        subject=subject.nominal,
                        object=(
                            direct.nominal if direct is not None else None
                        ),
                        tense=predicate.tense,
                        polarity=predicate.polarity,
                        register=register,
                        interrogative=interrogative,
                        predicate_kind=predicate.kind,
                        modality=predicate.modality,
                        validity_mode=predicate.validity_mode,
                        temporal_aspect=predicate.temporal_aspect,
                        frequency=predicate.frequency,
                        obliques=tuple(
                            argument.phrase for argument in arguments
                        ),
                    )
                    roles = {
                        **dict(subject.roles),
                        **(
                            dict(direct.roles)
                            if direct is not None
                            else {}
                        ),
                        **{
                            index: role
                            for argument in arguments
                            for index, role in argument.roles
                        },
                        predicate_index: "predicate",
                        **{
                            index: "question"
                            for index in question_indices
                        },
                    }
                    if marker_token is not None:
                        roles[marker_token.index] = (
                            "subject-marker+determiner"
                            if marker_token.normalized
                            in FUSED_SUBJECT_DETERMINERS
                            else "subject-marker"
                        )
                    if predicate.temporal_aspect_index is not None:
                        roles[predicate.temporal_aspect_index] = (
                            "temporal-aspect"
                        )
                    if predicate.frequency_index is not None:
                        roles[predicate.frequency_index] = (
                            "frequency-adverb"
                        )
                    reading = _ClauseReading(
                        clause=clause,
                        output_text=self._action_sentence(
                            subject.english_text,
                            gloss,
                            (
                                direct.english_text
                                if direct is not None
                                else None
                            ),
                            tense=predicate.tense,
                            polarity=predicate.polarity,
                            modality=predicate.modality,
                            interrogative=interrogative,
                            wh_role=None,
                            temporal_aspect=predicate.temporal_aspect,
                            frequency=predicate.frequency,
                            oblique_texts=tuple(
                                argument.english_text
                                for argument in arguments
                            ),
                        ),
                        roles=tuple(sorted(roles.items())),
                        predicate=predicate,
                        predicate_index=predicate_index,
                        subject_english=subject.english_text,
                        assumptions=(
                            *subject.assumptions,
                            *(
                                direct.assumptions
                                if direct is not None
                                else ()
                            ),
                            *(
                                assumption
                                for argument in arguments
                                for assumption in argument.assumptions
                            ),
                        ),
                        ambiguities=(
                            *subject.ambiguities,
                            *(
                                direct.ambiguities
                                if direct is not None
                                else ()
                            ),
                            *(
                                ambiguity
                                for argument in arguments
                                for ambiguity in argument.ambiguities
                            ),
                            *predicate_ambiguities,
                        ),
                        rule_trace=(
                            "translation.asaxi-expanded-clause",
                            (
                                "clause.explicit-subject"
                                if marker_token is not None
                                else "clause.strict-unmarked-sov"
                            ),
                            "clause.case-argument",
                            "clause.multi-case-argument",
                            *(
                                ("clause.unmarked-case-argument",)
                                if marker_token is None
                                else ()
                            ),
                            *subject.rule_trace,
                            *(
                                direct.rule_trace
                                if direct is not None
                                else ()
                            ),
                            *(
                                trace
                                for argument in arguments
                                for trace in argument.rule_trace
                            ),
                            *predicate.rule_trace,
                        ),
                    )
                    candidates.append(
                        (
                            (
                                int(
                                    predicate.is_transitive
                                    and direct is None
                                ),
                                (
                                    subject.structural_cost
                                    + (
                                        direct.structural_cost
                                        if direct is not None
                                        else 0
                                    )
                                    + sum(
                                        argument.structural_cost
                                        for argument in arguments
                                    )
                                ),
                                tuple(
                                    preposition_index
                                    for _, _, preposition_index
                                    in case_choices
                                ),
                            ),
                            reading,
                        )
                    )
        candidates.sort(key=lambda item: item[0])
        return [
            reading
            for _, reading in candidates[:MAX_CLAUSE_ALTERNATIVES]
        ]

    def _parse_causative_case_clause(
        self,
        marker_token: Any,
        content: Sequence[Any],
        predicate: _PredicateReading,
        predicate_index: int,
        *,
        register: Register,
        interrogative: bool,
        question_indices: set[int],
    ) -> list[_ClauseReading]:
        """Parse ``[subject/causee] bă [causer] [object] CAUSATIVE-verb``."""

        voice = predicate.causative_voice
        if voice is None:
            return []
        case_positions = [
            index
            for index, token in enumerate(content)
            if token.normalized in CASE_MARKERS
        ]
        if (
            len(case_positions) != 1
            or case_positions[0] == 0
            or content[case_positions[0]].normalized != "bă"
        ):
            return []
        case_position = case_positions[0]
        case_token = content[case_position]
        causee_options = self._parse_nominal_span(
            content[:case_position],
            role="subject",
        )
        following = content[case_position + 1:]
        if not causee_options or not following:
            return []

        candidates: list[tuple[tuple[int, int], _ClauseReading]] = []
        for causer_length in range(1, len(following) + 1):
            causer_options = self._parse_nominal_span(
                following[:causer_length],
                role="causer",
            )
            direct_words = following[causer_length:]
            direct_options: tuple[_NominalReading | None, ...]
            if direct_words:
                parsed_direct = self._parse_nominal_span(
                    direct_words,
                    role="object",
                )
                if not parsed_direct:
                    continue
                direct_options = tuple(parsed_direct)
            else:
                direct_options = (None,)

            for causee, causer, direct in itertools.product(
                causee_options,
                causer_options,
                direct_options,
            ):
                if (
                    direct is not None
                    and not predicate.is_transitive
                ):
                    continue
                if (
                    direct is None
                    and predicate.requires_complement
                ):
                    continue
                if not pronoun_binding_is_licensed(
                    causee.nominal,
                    direct.nominal if direct is not None else None,
                ):
                    continue
                if not pronoun_binding_is_licensed(
                    causee.nominal,
                    causer.nominal,
                ):
                    continue
                phrase = RelationalPhrase(
                    marker="bă",
                    relation=CaseRelation.INSTRUMENTAL,
                    nominal=causer.nominal,
                    function="causer",
                )
                agency = CausativeAgency(
                    voice=voice,
                    causer=causer.nominal,
                    marker="bă",
                )
                for gloss in predicate.english_glosses:
                    rendered_verb = gloss
                    rendered_object = (
                        direct.english_text
                        if direct is not None
                        else None
                    )
                    if predicate.verbalization_source_gloss is not None:
                        (
                            rendered_verb,
                            rendered_object,
                        ) = self._productive_verbalization_terms(
                            predicate,
                            rendered_object,
                            (
                                direct.nominal
                                if direct is not None
                                else None
                            ),
                        )
                    predicate_ambiguities = (
                        (
                            TranslationAmbiguity(
                                code="UNSPLIT_SOURCE_GLOSS",
                                message=(
                                    "The source entry for "
                                    f"{predicate.lemma!r} contains multiple "
                                    "English gloss terms."
                                ),
                                choices=predicate.english_glosses,
                                selected=gloss,
                            ),
                        )
                        if len(predicate.english_glosses) > 1
                        else ()
                    )
                    clause = CanonicalClause(
                        predicate=predicate.lemma,
                        subject=causee.nominal,
                        object=(
                            direct.nominal
                            if direct is not None
                            else None
                        ),
                        tense=predicate.tense,
                        polarity=predicate.polarity,
                        register=register,
                        interrogative=interrogative,
                        predicate_kind=PredicateKind.ACTION,
                        verbal_derivation=predicate.verbal_derivation,
                        causative_agency=agency,
                        temporal_aspect=predicate.temporal_aspect,
                        frequency=predicate.frequency,
                        obliques=(phrase,),
                    )
                    roles = {
                        **dict(causee.roles),
                        **dict(causer.roles),
                        **(
                            dict(direct.roles)
                            if direct is not None
                            else {}
                        ),
                        marker_token.index: (
                            "subject-marker+determiner"
                            if marker_token.normalized
                            in FUSED_SUBJECT_DETERMINERS
                            else "subject-marker"
                        ),
                        case_token.index: "causative-causer-marker",
                        predicate_index: "predicate",
                        **{
                            index: "question"
                            for index in question_indices
                        },
                    }
                    if predicate.temporal_aspect_index is not None:
                        roles[predicate.temporal_aspect_index] = (
                            "temporal-aspect"
                        )
                    if predicate.frequency_index is not None:
                        roles[predicate.frequency_index] = (
                            "frequency-adverb"
                        )
                    reading = _ClauseReading(
                        clause=clause,
                        output_text=self._causative_action_sentence(
                            causee.english_text,
                            causer.english_text,
                            rendered_verb,
                            rendered_object,
                            voice=voice,
                            tense=predicate.tense,
                            polarity=predicate.polarity,
                            interrogative=interrogative,
                            temporal_aspect=predicate.temporal_aspect,
                            frequency=predicate.frequency,
                        ),
                        roles=tuple(sorted(roles.items())),
                        predicate=predicate,
                        predicate_index=predicate_index,
                        subject_english=causee.english_text,
                        assumptions=(
                            *causee.assumptions,
                            *causer.assumptions,
                            *(
                                direct.assumptions
                                if direct is not None
                                else ()
                            ),
                        ),
                        ambiguities=(
                            *causee.ambiguities,
                            *causer.ambiguities,
                            *(
                                direct.ambiguities
                                if direct is not None
                                else ()
                            ),
                            *predicate_ambiguities,
                        ),
                        rule_trace=(
                            "translation.asaxi-expanded-clause",
                            *_fused_subject_rules(marker_token.normalized),
                            "clause.explicit-subject",
                            "clause.causative-agency",
                            "clause.causative-source-subject-is-causee",
                            "argument.instrumental-causer",
                            "voice." + voice.value,
                            *causee.rule_trace,
                            *causer.rule_trace,
                            *(
                                direct.rule_trace
                                if direct is not None
                                else ()
                            ),
                            *_pronoun_binding_rule(
                                direct.nominal
                                if direct is not None
                                else None
                            ),
                            *_pronoun_binding_rule(causer.nominal),
                            *predicate.rule_trace,
                        ),
                    )
                    candidates.append(
                        (
                            (
                                int(
                                    predicate.is_transitive
                                    and direct is None
                                ),
                                (
                                    causee.structural_cost
                                    + causer.structural_cost
                                    + (
                                        direct.structural_cost
                                        if direct is not None
                                        else 0
                                    )
                                ),
                            ),
                            reading,
                        )
                    )
        candidates.sort(key=lambda item: item[0])
        return [
            reading
            for _, reading in candidates[:MAX_CLAUSE_ALTERNATIVES]
        ]

    @staticmethod
    def _case_prepositions(
        relation: CaseRelation,
        predicate: _PredicateReading,
        defaults: tuple[str, ...],
    ) -> tuple[str, ...]:
        """Order ambiguous English case realizations by predicate semantics."""

        if (
            relation is CaseRelation.ALLATIVE
            and predicate.verbal_derivation is not None
            and predicate.verbal_derivation.mode
            is VerbalizationMode.INTERACTION
        ):
            # Directed-feeling predicates retain an Asaxi allative target,
            # while idiomatic English realizes that target as the verb's
            # direct complement (``love John``, not ``love to John``).
            return ("",)
        if relation is not CaseRelation.DATIVE:
            return defaults
        gloss_heads = {
            gloss.casefold().split(" ", 1)[0]
            for gloss in predicate.english_glosses
            if gloss
        }
        beneficiary_predicate = bool(
            gloss_heads
            & {"have", "possess", "hold", "make", "do"}
        )
        if beneficiary_predicate:
            return ("for", "to")
        return defaults

    def _strict_unmarked_layouts(
        self,
        words: Sequence[Any],
        predicate: _PredicateReading,
    ) -> list[
        tuple[
            _NominalReading,
            _NominalReading,
            _NominalReading | None,
            bool,
            bool,
            tuple[TranslationAssumption, ...],
            tuple[TranslationAmbiguity, ...],
            tuple[str, ...],
        ]
    ]:
        layouts = []
        for split in range(1, len(words)):
            if self._split_breaks_determiner_anchor(words, split):
                continue
            subjects = self._parse_nominal_span(
                words[:split],
                role="subject",
            )
            complements = self._parse_nominal_span(
                words[split:],
                role=self._complement_role(predicate),
            )
            for subject, complement in itertools.product(
                subjects,
                complements,
            ):
                if not self._layout_allowed(predicate, complement, subject):
                    continue
                layouts.append(
                    (
                        subject,
                        complement,
                        None,
                        False,
                        False,
                        (),
                        (),
                        ("clause.strict-unmarked-sov",),
                    )
                )
        if predicate.kind is PredicateKind.ACTION:
            for subject_end in range(1, len(words) - 1):
                if self._split_breaks_determiner_anchor(
                    words,
                    subject_end,
                ):
                    continue
                for object_end in range(subject_end + 1, len(words)):
                    if self._split_breaks_determiner_anchor(
                        words,
                        object_end,
                    ):
                        continue
                    subjects = self._parse_nominal_span(
                        words[:subject_end],
                        role="subject",
                    )
                    objects = self._parse_nominal_span(
                        words[subject_end:object_end],
                        role="object",
                    )
                    adjuncts = tuple(
                        adjunct
                        for adjunct in self._parse_nominal_span(
                            words[object_end:],
                            role="location",
                        )
                        if adjunct.nominal.wh_word
                        in {"where", "when", "why", "how"}
                    )
                    for subject, object_reading, adjunct in (
                        itertools.product(
                            subjects,
                            objects,
                            adjuncts,
                        )
                    ):
                        if not self._layout_allowed(
                            predicate,
                            object_reading,
                            subject,
                        ):
                            continue
                        layouts.append(
                            (
                                subject,
                                object_reading,
                                adjunct,
                                False,
                                False,
                                (),
                                (),
                                (
                                    "clause.strict-unmarked-sov",
                                    "clause.action-wh-adjunct",
                                ),
                            )
                        )
        return layouts

    def _layout_allowed(
        self,
        predicate: _PredicateReading,
        complement: _NominalReading | None,
        subject: _NominalReading | None = None,
    ) -> bool:
        adverbial_wh = (
            complement is not None
            and complement.nominal.wh_word
            in {"where", "when", "why", "how"}
        )
        if predicate.requires_complement and complement is None:
            return False
        if (
            predicate.kind is PredicateKind.LOCATION
            and predicate.validity_mode is ValidityMode.ESSENTIAL
            and subject is not None
            and (
                subject.nominal.determiner == "indefinite"
                or subject.nominal.quantifier is not None
            )
        ):
            # -ŕa location defines a specific subject's stable relation. An
            # indefinite or exhaustive class reading needs an explicitly
            # selected category-definition analysis, which this layout does
            # not silently invent.
            return False
        if (
            complement is not None
            and complement.nominal.surface in VICINITY_NOMINAL_MODIFIERS
            and predicate.lemma
            in {
                *SPATIAL_PREDICATES,
                *TOPOLOGICAL_VALIDITY_PREDICATES,
            }
            and predicate.lemma not in VICINITY_LOCATION_PREDICATES
        ):
            # Vicinity nouns denote an area around a deictic center. The
            # grammar licenses them with ỏnů/ỏŕa, not ordinary containment
            # such as vanů.
            return False
        if (
            complement is not None
            and predicate.lemma
            in {
                *SPATIAL_PREDICATES,
                *TOPOLOGICAL_VALIDITY_PREDICATES,
            }
            and self._nominal_spatial_physicality(complement.nominal)
            == SPATIAL_ABSTRACT
        ):
            return False
        if predicate.takes_complement is False:
            return complement is None or adverbial_wh
        if (
            predicate.kind is PredicateKind.ACTION
            and not predicate.is_transitive
        ):
            return complement is None or adverbial_wh
        if predicate.kind is PredicateKind.IDENTITY:
            return True
        if predicate.kind in {
            PredicateKind.PERFORMANCE,
            PredicateKind.POSSESSION,
            PredicateKind.RELATION,
        }:
            return complement is not None
        return True

    def _nominal_spatial_physicality(self, nominal: Nominal) -> str:
        lexeme = (
            self._lexemes_by_id.get(nominal.lexeme_id)
            if nominal.lexeme_id is not None
            else None
        )
        return classify_spatial_landmark(
            nominal.surface,
            (lexeme,) if lexeme is not None else (),
        )

    @staticmethod
    def _complement_role(predicate: _PredicateReading) -> str:
        if predicate.kind is PredicateKind.ACTION:
            return "object"
        if predicate.kind is PredicateKind.LOCATION:
            return "location"
        if predicate.kind is PredicateKind.POSSESSION:
            return "possessor"
        return "complement"

    def _parse_zero_copula(
        self,
        words: Sequence[Any],
        *,
        interrogative: bool,
        question_indices: set[int],
    ) -> list[_ClauseReading]:
        if len(words) == 1:
            subjects = self._parse_nominal_span(words, role="subject")
            return [
                self._zero_copula_reading(
                    subject,
                    None,
                    PredicateKind.EXISTENCE,
                    interrogative,
                    question_indices,
                )
                for subject in subjects
            ]
        readings: list[_ClauseReading] = []
        marker_token, fused_determiner_token = (
            self._split_subject_marker(words)
        )
        register = (
            Register.OBJECTIVE
            if fused_determiner_token is not None
            else SUBJECT_MARKERS[marker_token.normalized]
            if marker_token is not None
            else Register.OBJECTIVE
        )
        content = (
            (fused_determiner_token, *words[1:])
            if fused_determiner_token is not None
            else words[1:]
            if marker_token is not None
            else words
        )
        for split in range(1, len(content)):
            if self._split_breaks_determiner_anchor(content, split):
                continue
            for subject, complement in itertools.product(
                self._parse_nominal_span(content[:split], role="subject"),
                self._parse_nominal_span(content[split:], role="complement"),
            ):
                reading = self._zero_copula_reading(
                    subject,
                    complement,
                    PredicateKind.IDENTITY,
                    interrogative,
                    question_indices,
                    register=register,
                )
                roles = dict(reading.roles)
                if marker_token is not None:
                    roles[marker_token.index] = (
                        "subject-marker+determiner"
                        if fused_determiner_token is not None
                        else "subject-marker"
                    )
                readings.append(
                    _ClauseReading(
                        clause=reading.clause,
                        output_text=reading.output_text,
                        roles=tuple(sorted(roles.items())),
                        predicate=None,
                        predicate_index=None,
                        subject_english=reading.subject_english,
                        assumptions=reading.assumptions,
                        ambiguities=reading.ambiguities,
                        rule_trace=(
                            *_fused_subject_rules(
                                marker_token.normalized
                                if marker_token is not None
                                else ""
                            ),
                            *reading.rule_trace,
                        ),
                    )
                )
        return readings[:MAX_CLAUSE_ALTERNATIVES]

    def _parse_nominal_fragment(
        self,
        words: Sequence[Any],
        *,
        interrogative: bool,
        question_indices: set[int],
    ) -> list[_ClauseReading]:
        """Preserve a complete nominal constituent as a licensed utterance."""

        if len(words) < 2:
            return []
        readings: list[_ClauseReading] = []
        for nominal in self._parse_nominal_span(words, role="subject"):
            clause = CanonicalClause(
                predicate="[fragment]",
                subject=nominal.nominal,
                interrogative=interrogative,
                predicate_kind=PredicateKind.FRAGMENT,
                subject_marked=False,
            )
            punctuation = "?" if interrogative else "."
            readings.append(
                _ClauseReading(
                    clause=clause,
                    output_text=_capitalize(nominal.english_text) + punctuation,
                    roles=tuple(
                        sorted(
                            {
                                **dict(nominal.roles),
                                **{
                                    index: "question"
                                    for index in question_indices
                                },
                            }.items()
                        )
                    ),
                    predicate=None,
                    predicate_index=None,
                    subject_english=nominal.english_text,
                    assumptions=nominal.assumptions,
                    ambiguities=nominal.ambiguities,
                    rule_trace=(
                        "translation.asaxi-nominal-fragment",
                        "clause.licensed-nominal-fragment",
                        *nominal.rule_trace,
                    ),
                )
            )
        return readings[:MAX_CLAUSE_ALTERNATIVES]

    @staticmethod
    def _split_breaks_determiner_anchor(
        words: Sequence[Any],
        split: int,
    ) -> bool:
        """Keep a determiner attached to the following nominal head."""

        return (
            0 < split < len(words)
            and words[split - 1].normalized in DETERMINERS
        )

    def _zero_copula_reading(
        self,
        subject: _NominalReading,
        complement: _NominalReading | None,
        kind: PredicateKind,
        interrogative: bool,
        question_indices: set[int],
        *,
        register: Register = Register.OBJECTIVE,
    ) -> _ClauseReading:
        wh_role = self._wh_role(subject, complement, kind)
        clause = CanonicalClause(
            predicate="xiŕa",
            subject=subject.nominal,
            register=register,
            interrogative=interrogative or wh_role is not None,
            predicate_kind=kind,
            validity_mode=ValidityMode.ESSENTIAL,
            complement=(
                complement.nominal if complement is not None else None
            ),
            wh_role=wh_role,
            zero_copula=True,
        )
        roles = {
            **dict(subject.roles),
            **(
                dict(complement.roles)
                if complement is not None
                else {}
            ),
            **{index: "question" for index in question_indices},
        }
        return _ClauseReading(
            clause=clause,
            output_text=self._render_clause(
                clause,
                subject.english_text,
                complement.english_text if complement else None,
                "be",
            ),
            roles=tuple(sorted(roles.items())),
            predicate=None,
            predicate_index=None,
            subject_english=subject.english_text,
            assumptions=(
                *subject.assumptions,
                *(
                    complement.assumptions if complement is not None else ()
                ),
            ),
            ambiguities=(
                *subject.ambiguities,
                *(
                    complement.ambiguities if complement is not None else ()
                ),
            ),
            rule_trace=(
                "translation.asaxi-zero-copula",
                *subject.rule_trace,
                *(
                    complement.rule_trace if complement is not None else ()
                ),
            ),
        )

    def _word_time_scope_for_nominal(
        self,
        nominal: Nominal,
    ) -> WordTimeScope | None:
        lexeme = self._lexemes_by_id.get(nominal.lexeme_id or "")
        if lexeme is None:
            return None
        if lexeme.category == "adjective":
            return WordTimeScope.ADJECTIVE
        if lexeme.category == "noun":
            return WordTimeScope.NOUN
        return None

    def _word_time_nominal_english(
        self,
        english: str,
        binding: WordTimeBinding,
    ) -> str:
        bare = self._remove_article(english)
        if binding.scope is WordTimeScope.ADJECTIVE:
            modifier = (
                "formerly"
                if binding.orientation is WordTimeOrientation.RETROSPECTIVE
                else "soon-to-be"
            )
            return f"{modifier} {bare}"

        modifier = (
            "former"
            if binding.orientation is WordTimeOrientation.RETROSPECTIVE
            else "soon-to-be"
        )
        modified = f"{modifier} {bare}"
        lowered = english.casefold()
        for article in (
            "a certain ",
            "a specific ",
            "the ",
            "this ",
            "that ",
            "some ",
        ):
            if lowered.startswith(article):
                return english[: len(article)].strip() + " " + modified
        if lowered.startswith(("a ", "an ")):
            return f"{_indefinite_article(modified)} {modified}"
        return modified

    def _parse_separate_word_time_nominal(
        self,
        words: Sequence[Any],
        *,
        role: str,
    ) -> tuple[_NominalReading, ...]:
        if len(words) < 2:
            return ()
        if words[0].normalized in WORD_TIME_ORIENTATION_BY_MARKER:
            marker_token = words[0]
            host_words = words[1:]
            placement = WordTimePlacement.PREFIX
        elif words[-1].normalized in WORD_TIME_ORIENTATION_BY_MARKER:
            marker_token = words[-1]
            host_words = words[:-1]
            placement = WordTimePlacement.SUFFIX
        else:
            return ()

        readings: list[_NominalReading] = []
        for base in self._parse_nominal_span(host_words, role=role):
            if base.nominal.word_time_binding is not None:
                continue
            scope = self._word_time_scope_for_nominal(base.nominal)
            if scope is None:
                continue
            binding = self._make_word_time_binding(
                marker_token.normalized,
                scope=scope,
                placement=placement,
                fused=False,
                source_form=" ".join(token.surface for token in words),
            )
            roles = dict(base.roles)
            roles[marker_token.index] = "word-time-marker"
            readings.append(
                replace(
                    base,
                    nominal=replace(
                        base.nominal,
                        word_time_binding=binding,
                    ),
                    english_text=self._word_time_nominal_english(
                        base.english_text,
                        binding,
                    ),
                    token_indices=tuple(token.index for token in words),
                    roles=tuple(sorted(roles.items())),
                    rule_trace=(*binding.rule_trace(), *base.rule_trace),
                )
            )
        return tuple(readings)

    def _parse_fused_word_time_nominal_atom(
        self,
        token: Any,
        *,
        role: str,
    ) -> tuple[_NominalReading, ...]:
        if self.lexicon.asaxi_matches(token.normalized):
            return ()
        split = self._split_fused_word_time_surface(token.normalized)
        if split is None:
            return ()
        marker, host, placement = split
        host_token = replace(
            token,
            surface=host,
            normalized=host,
        )
        readings: list[_NominalReading] = []
        for base in self._parse_nominal_atom(host_token, role=role):
            if base.nominal.word_time_binding is not None:
                continue
            scope = self._word_time_scope_for_nominal(base.nominal)
            if scope is None:
                continue
            binding = self._make_word_time_binding(
                marker,
                scope=scope,
                placement=placement,
                fused=True,
                source_form=token.surface,
            )
            readings.append(
                replace(
                    base,
                    nominal=replace(
                        base.nominal,
                        surface=host,
                        word_time_binding=binding,
                    ),
                    english_text=self._word_time_nominal_english(
                        base.english_text,
                        binding,
                    ),
                    token_indices=(token.index,),
                    roles=((token.index, role),),
                    rule_trace=(*binding.rule_trace(), *base.rule_trace),
                )
            )
        return tuple(readings)

    def _parse_nominal_span(
        self,
        words: Sequence[Any],
        *,
        role: str,
    ) -> tuple[_NominalReading, ...]:
        if not words:
            return ()
        separate_word_time = self._parse_separate_word_time_nominal(
            words,
            role=role,
        )
        if separate_word_time:
            return separate_word_time
        extent = self._parse_separate_extent_nominal(words, role=role)
        if extent:
            return extent
        universally_quantified = (
            self._parse_universally_quantified_nominal(
                words,
                role=role,
            )
        )
        if universally_quantified:
            return universally_quantified
        distributed = self._parse_distributed_nominal(words, role=role)
        if distributed:
            return distributed
        verbal_nominal = self._parse_verbal_nominalization(
            words,
            role=role,
        )
        if verbal_nominal:
            return verbal_nominal
        options: list[_NominalReading] = []
        if len(words) == 1:
            options.extend(self._parse_nominal_atom(words[0], role=role))
        else:
            ja_positions = [
                index
                for index, token in enumerate(words)
                if token.normalized == "ja"
                and index > 0
                and index + 1 < len(words)
            ]
            if len(ja_positions) > 1:
                return ()
            for position in ja_positions:
                # Commas are punctuation tokens and therefore absent from
                # ``words``. A gap in source token indexes recovers each
                # comma-delimited item before the single final ``ja``.
                groups: list[Sequence[Any]] = []
                group_start = 0
                for index in range(1, position):
                    if words[index].index > words[index - 1].index + 1:
                        groups.append(words[group_start:index])
                        group_start = index
                groups.append(words[group_start:position])
                groups.append(words[position + 1:])
                if any(not group for group in groups):
                    continue
                parsed_groups = tuple(
                    self._parse_nominal_span(group, role=role)
                    for group in groups
                )
                if any(not readings for readings in parsed_groups):
                    continue
                for readings in itertools.product(*parsed_groups):
                    english = _english_coordination(
                        tuple(
                            reading.english_text
                            for reading in readings
                        )
                    )
                    nominal = Nominal(
                        surface=" ".join(
                            token.normalized for token in words
                        ),
                        number="plural",
                        coordinated=tuple(
                            reading.nominal for reading in readings
                        ),
                    )
                    roles = {
                        index: role_name
                        for reading in readings
                        for index, role_name in reading.roles
                    }
                    roles[words[position].index] = "nominal-connector"
                    options.append(
                        _NominalReading(
                            nominal=nominal,
                            english_text=english,
                            token_indices=tuple(
                                token.index for token in words
                            ),
                            roles=tuple(sorted(roles.items())),
                            assumptions=tuple(
                                assumption
                                for reading in readings
                                for assumption in reading.assumptions
                            ),
                            ambiguities=tuple(
                                ambiguity
                                for reading in readings
                                for ambiguity in reading.ambiguities
                            ),
                            rule_trace=(
                                "noun.coordination-ja",
                                *(
                                    trace
                                    for reading in readings
                                    for trace in reading.rule_trace
                                ),
                            ),
                            structural_cost=sum(
                                reading.structural_cost
                                for reading in readings
                            ),
                        )
                    )

            if words[0].normalized == "sè" and len(words) in {3, 4}:
                head_start = 2
                if (
                    len(words) == 4
                    and words[2].normalized == "to"
                ):
                    head_start = 3
                for possessor, head in itertools.product(
                    self._parse_nominal_span(
                        words[1:2],
                        role="possessor",
                    ),
                    self._parse_nominal_span(
                        words[head_start:],
                        role=role,
                    ),
                ):
                    possessor_text = possessor.english_text
                    possessor_lexeme = self._lexemes_by_id.get(
                        possessor.nominal.lexeme_id or ""
                    )
                    temporal_source = bool(
                        possessor_lexeme is not None
                        and any(
                            field.removeprefix("Smntc_Field ")
                            .strip()
                            .casefold()
                            == "time"
                            for field in possessor_lexeme.semantic_fields
                        )
                    )
                    if temporal_source:
                        # Calendar/time adverbials such as ``yesterday`` do
                        # not take an English indefinite article when used as
                        # the documented genitive source of an event nominal.
                        possessor_text = self._remove_article(possessor_text)
                    head_text = self._remove_article(head.english_text)
                    possessive = self._possessive_determiner(
                        possessor_text
                    )
                    if possessive is not None:
                        english = f"{possessive} {head_text}"
                    else:
                        english = (
                            f"{possessor_text}' {head_text}"
                            if possessor_text.endswith("s")
                            else f"{possessor_text}'s {head_text}"
                        )
                    roles = {
                        **dict(possessor.roles),
                        **dict(head.roles),
                        words[0].index: "genitive-marker",
                    }
                    if head_start == 3:
                        roles[words[2].index] = "nested-subject-marker"
                    options.append(
                        _NominalReading(
                            nominal=replace(
                                head.nominal,
                                surface=" ".join(
                                    token.normalized for token in words
                                ),
                                possessor=possessor.nominal,
                            ),
                            english_text=english,
                            token_indices=tuple(
                                token.index for token in words
                            ),
                            roles=tuple(sorted(roles.items())),
                            assumptions=(
                                *possessor.assumptions,
                                *head.assumptions,
                            ),
                            ambiguities=(
                                *possessor.ambiguities,
                                *head.ambiguities,
                            ),
                            rule_trace=(
                                "noun.genitive-possession",
                                *(
                                    ("noun.genitive-temporal-source",)
                                    if temporal_source
                                    else ()
                                ),
                                *possessor.rule_trace,
                                *head.rule_trace,
                            ),
                            structural_cost=(
                                possessor.structural_cost
                                + head.structural_cost
                            ),
                        )
                    )

            if words[0].normalized in DETERMINERS:
                options.extend(
                    self._parse_determined_nominal(words, role=role)
                )

            if not options:
                options.extend(
                    self._parse_head_final_nominal(words, role=role)
                )
        unique: dict[tuple[str, str], _NominalReading] = {}
        for option in options:
            key = (
                option.english_text,
                repr(option.nominal.to_dict()),
            )
            unique[key] = option
        return tuple(list(unique.values())[:MAX_NOMINAL_OPTIONS])

    @staticmethod
    def _split_extent_surface(
        surface: str,
    ) -> tuple[NominalExtent, str] | None:
        """Split a documented fused extent prefix from its nominal head."""

        compact = surface.casefold()
        for marker, emphasized in (("săsă", True), ("să", False)):
            if compact.startswith(marker) and len(compact) > len(marker):
                head = compact[len(marker):]
                if head.startswith("-"):
                    head = head[1:]
                if not head or "-" in head:
                    return None
                return (
                    NominalExtent(
                        marker=marker,
                        kind=NominalExtentKind.COMPLETE,
                        emphasized=emphasized,
                        source_form=surface,
                    ),
                    head,
                )
        if not compact.startswith("pù"):
            return None
        remainder = compact[2:]
        for denominator in sorted(
            FRACTION_DENOMINATOR_VALUE_BY_FORM,
            key=lambda value: (-len(value), value),
        ):
            if remainder.startswith(denominator):
                head = remainder[len(denominator):]
                if head.startswith("-"):
                    head = head[1:]
                if not head or "-" in head:
                    return None
                return (
                    NominalExtent(
                        marker="pù",
                        kind=NominalExtentKind.FRACTIONAL,
                        denominator=denominator,
                        denominator_value=(
                            FRACTION_DENOMINATOR_VALUE_BY_FORM[denominator]
                        ),
                        source_form=surface,
                    ),
                    head,
                )
        return None

    def _extent_english_text(
        self,
        extent: NominalExtent,
        head: _NominalReading,
    ) -> str:
        bare = self._remove_article(head.english_text)
        temporal = self._nominal_is_temporal(head.nominal)
        if extent.kind is NominalExtentKind.COMPLETE:
            if extent.marker == "să" and temporal:
                if bare.casefold() == "yesterday":
                    return "all day yesterday"
                return f"all {bare}"
            adjective = "entire" if extent.emphasized else "whole"
            return f"the {adjective} {bare}"
        fraction = (
            english_unit_fraction(extent.denominator_value or 0)
            or f"one part in {extent.denominator_value}"
        )
        if temporal:
            return f"{fraction} of {bare}"
        return f"{fraction} of the {bare}"

    def _nominal_is_temporal(self, nominal: Nominal) -> bool:
        """Return whether a nominal's lexical head is documented as time."""

        lexeme = self._lexemes_by_id.get(nominal.lexeme_id or "")
        return bool(
            lexeme is not None
            and any(
                field.removeprefix("Smntc_Field ").strip().casefold()
                == "time"
                for field in lexeme.semantic_fields
            )
        )

    def _parse_extent_nominal_atom(
        self,
        token: Any,
        *,
        role: str,
    ) -> tuple[_NominalReading, ...]:
        split = self._split_extent_surface(token.normalized)
        if split is None:
            return ()
        extent, head_surface = split
        head_token = replace(
            token,
            surface=head_surface,
            normalized=head_surface,
            start=max(token.start, token.end - len(head_surface)),
        )
        heads = self._parse_nominal_atom(head_token, role=role)
        return tuple(
            _NominalReading(
                nominal=replace(
                    head.nominal,
                    surface=token.normalized,
                    determiner=None,
                    extent=extent,
                ),
                english_text=self._extent_english_text(extent, head),
                token_indices=(token.index,),
                roles=((token.index, f"{role}-extent-compound"),),
                assumptions=head.assumptions,
                ambiguities=head.ambiguities,
                rule_trace=(
                    "noun.extent.number-prefix",
                    (
                        "noun.extent.complete"
                        if extent.kind is NominalExtentKind.COMPLETE
                        else "noun.extent.fractional"
                    ),
                    "noun.extent.fused",
                    *head.rule_trace,
                ),
                structural_cost=head.structural_cost + 1,
            )
            for head in heads
        )

    def _parse_separate_extent_nominal(
        self,
        words: Sequence[Any],
        *,
        role: str,
    ) -> tuple[_NominalReading, ...]:
        """Accept the separately written săsă variant attested in its note."""

        if len(words) != 2 or words[0].normalized != "săsă":
            return ()
        marker, head_token = words
        extent = NominalExtent(
            marker="săsă",
            kind=NominalExtentKind.COMPLETE,
            emphasized=True,
            source_form=marker.normalized,
        )
        heads = self._parse_nominal_atom(head_token, role=role)
        return tuple(
            _NominalReading(
                nominal=replace(
                    head.nominal,
                    surface=f"săsă {head.nominal.surface}",
                    determiner=None,
                    extent=extent,
                ),
                english_text=self._extent_english_text(extent, head),
                token_indices=(marker.index, *head.token_indices),
                roles=tuple(
                    sorted(
                        {
                            **dict(head.roles),
                            marker.index: f"{role}-extent",
                        }.items()
                    )
                ),
                assumptions=head.assumptions,
                ambiguities=head.ambiguities,
                rule_trace=(
                    "noun.extent.number-prefix",
                    "noun.extent.complete",
                    "noun.extent.separate-attested-variant",
                    *head.rule_trace,
                ),
                structural_cost=head.structural_cost,
            )
            for head in heads
        )

    @staticmethod
    def _is_bare_nominalizable_predicate(
        predicate: _PredicateReading,
    ) -> bool:
        """Accept a lexical bare verb, not an inflected verbal complex."""

        return (
            predicate.lexeme is not None
            and predicate.lexeme.category == "verb"
            and predicate.surface == predicate.lemma
            and predicate.tense is Tense.NONPAST
            and predicate.polarity is Polarity.POSITIVE
            and predicate.modality is Modality.NONE
            and predicate.causative_voice is None
            and predicate.directive_form is None
            and predicate.validity_mode is ValidityMode.NONE
            and predicate.temporal_aspect is TemporalAspect.NONE
            and predicate.frequency is None
        )

    def _parse_verbal_nominal_atom(
        self,
        token: Any,
        *,
        role: str,
        allow_specific: bool,
    ) -> tuple[_NominalReading, ...]:
        specific = False
        predicate_surface = token.normalized
        deictic = _split_deictic_surface(predicate_surface)
        if deictic is not None:
            prefix, predicate_surface, distance = deictic
            if (
                not allow_specific
                or prefix != "o"
                or distance is not DeicticDistance.PROXIMAL
            ):
                return ()
            specific = True

        predicates = tuple(
            predicate
            for predicate in self._predicate_readings(predicate_surface)
            if self._is_bare_nominalizable_predicate(predicate)
        )
        options: list[_NominalReading] = []
        for predicate in predicates:
            for gloss in predicate.english_glosses:
                for english_head in english_gerund_forms(gloss):
                    article = (
                        "the"
                        if specific
                        else _indefinite_article(english_head)
                    )
                    options.append(
                        _NominalReading(
                            nominal=Nominal(
                                surface=token.normalized,
                                noun_class="cold",
                                determiner="indefinite",
                                relation="verbal-nominalization",
                                deixis=(
                                    DeicticDistance.PROXIMAL
                                    if specific
                                    else None
                                ),
                                verbal_nominalization=VerbalNominalization(
                                    predicate=predicate.lemma,
                                    predicate_lexeme_id=(
                                        predicate.lexeme.identifier
                                        if predicate.lexeme is not None
                                        else None
                                    ),
                                    specific=specific,
                                    proximal_marker=(
                                        "o" if specific else None
                                    ),
                                ),
                            ),
                            english_text=f"{article} {english_head}",
                            token_indices=(token.index,),
                            roles=((token.index, "nominalized-predicate"),),
                            rule_trace=(
                                "noun.verbal-nominalization-anő",
                                "noun.verbal-nominalization-cold-class",
                                *(
                                    (
                                        "noun.verbal-nominalization-proximal-specific",
                                    )
                                    if specific
                                    else ()
                                ),
                                *predicate.rule_trace,
                            ),
                        )
                    )

        choices = tuple(
            dict.fromkeys(option.english_text for option in options)
        )
        if len(choices) < 2:
            return tuple(options)
        return tuple(
            replace(
                option,
                ambiguities=(
                    *option.ambiguities,
                    TranslationAmbiguity(
                        code="VERBAL_NOMINAL_GLOSS_AMBIGUOUS",
                        message=(
                            "The nominalized verb has multiple documented "
                            "English lexical senses."
                        ),
                        choices=choices,
                        selected=option.english_text,
                    ),
                ),
            )
            for option in options
        )

    def _parse_verbal_nominalization(
        self,
        words: Sequence[Any],
        *,
        role: str,
    ) -> tuple[_NominalReading, ...]:
        """Parse ``anő + Verb`` and the documented one-anchor gerund list."""

        if len(words) < 2 or words[0].normalized != "anő":
            return ()
        nominalizer = words[0]
        surface = " ".join(token.normalized for token in words)

        if len(words) == 2:
            return tuple(
                replace(
                    option,
                    nominal=replace(option.nominal, surface=surface),
                    token_indices=(nominalizer.index, *option.token_indices),
                    roles=tuple(
                        sorted(
                            {
                                **dict(option.roles),
                                nominalizer.index: "determiner",
                            }.items()
                        )
                    ),
                )
                for option in self._parse_verbal_nominal_atom(
                    words[1],
                    role=role,
                    allow_specific=True,
                )
            )

        ja_positions = tuple(
            index
            for index, token in enumerate(words)
            if token.normalized == "ja"
        )
        if len(ja_positions) != 1:
            return ()
        ja_position = ja_positions[0]
        if ja_position <= 1 or ja_position == len(words) - 1:
            return ()

        groups: list[Sequence[Any]] = []
        group_start = 1
        for index in range(2, ja_position):
            if words[index].index > words[index - 1].index + 1:
                groups.append(words[group_start:index])
                group_start = index
        groups.append(words[group_start:ja_position])
        groups.append(words[ja_position + 1:])
        if any(len(group) != 1 for group in groups):
            return ()

        parsed_groups = tuple(
            self._parse_verbal_nominal_atom(
                group[0],
                role=role,
                allow_specific=False,
            )
            for group in groups
        )
        if any(not options for options in parsed_groups):
            return ()

        readings: list[_NominalReading] = []
        for items in itertools.product(*parsed_groups):
            roles = {
                index: token_role
                for item in items
                for index, token_role in item.roles
            }
            roles[nominalizer.index] = "determiner"
            roles[words[ja_position].index] = "nominal-connector"
            readings.append(
                _NominalReading(
                    nominal=Nominal(
                        surface=surface,
                        noun_class="cold",
                        determiner="indefinite",
                        number="plural",
                        coordinated=tuple(
                            item.nominal for item in items
                        ),
                        relation="coordinated-verbal-nominalization",
                    ),
                    english_text=_english_coordination(
                        tuple(
                            self._remove_article(item.english_text)
                            for item in items
                        )
                    ),
                    token_indices=tuple(
                        token.index for token in words
                    ),
                    roles=tuple(sorted(roles.items())),
                    assumptions=tuple(
                        assumption
                        for item in items
                        for assumption in item.assumptions
                    ),
                    ambiguities=tuple(
                        ambiguity
                        for item in items
                        for ambiguity in item.ambiguities
                    ),
                    rule_trace=(
                        "noun.verbal-nominalization-anő",
                        "noun.verbal-nominalization-cold-class",
                        "noun.gerund-list-single-anchor",
                        "noun.coordination-ja",
                        *(
                            trace
                            for item in items
                            for trace in item.rule_trace
                        ),
                    ),
                )
            )
        return tuple(readings[:MAX_NOMINAL_OPTIONS])

    def _parse_universally_quantified_nominal(
        self,
        words: Sequence[Any],
        *,
        role: str,
    ) -> tuple[_NominalReading, ...]:
        """Attach the documented exhaustive ``mămă`` nominal quantifier."""

        if (
            len(words) < 2
            or words[0].normalized
            not in UNIVERSAL_NOMINAL_QUANTIFIERS
        ):
            return ()
        marker = words[0]
        options: list[_NominalReading] = []
        for base in self._parse_nominal_span(words[1:], role=role):
            if base.nominal.quantifier is not None:
                continue
            quantifier = NominalQuantifier(
                marker=marker.normalized,
                kind=UNIVERSAL_NOMINAL_QUANTIFIERS[
                    marker.normalized
                ],
            )
            bare = self._remove_article(base.english_text)
            english = (
                f"all {bare}"
                if base.nominal.number == "plural"
                else f"every {bare}"
            )
            options.append(
                replace(
                    base,
                    nominal=replace(
                        base.nominal,
                        surface=" ".join(
                            token.normalized for token in words
                        ),
                        quantifier=quantifier,
                    ),
                    english_text=english,
                    token_indices=tuple(
                        sorted({*base.token_indices, marker.index})
                    ),
                    roles=tuple(
                        sorted(
                            {
                                **dict(base.roles),
                                marker.index: f"{role}-quantifier",
                            }.items()
                        )
                    ),
                    rule_trace=(
                        "noun.quantifier.mămă-universal",
                        *base.rule_trace,
                    ),
                )
            )
        return tuple(options[:MAX_NOMINAL_OPTIONS])

    def _parse_distributed_nominal(
        self,
        words: Sequence[Any],
        *,
        role: str,
    ) -> tuple[_NominalReading, ...]:
        """Attach one documented floating quantifier to its nominal target."""

        if len(words) < 2 or role not in NOMINAL_DISTRIBUTIVE_ROLES:
            return ()
        placements: list[tuple[Any, Sequence[Any], str]] = []
        if words[0].normalized in DISTRIBUTIVE_PARTICLES:
            placements.append((words[0], words[1:], "pre-nominal"))
        if words[-1].normalized in POST_NOMINAL_DISTRIBUTIVES:
            placements.append((words[-1], words[:-1], "post-nominal"))
        options: list[_NominalReading] = []
        for token, core_words, placement in placements:
            for base in self._parse_nominal_span(core_words, role=role):
                attached = self._attach_distributive_to_nominal(
                    base,
                    token=token,
                    role=role,
                    placement=placement,
                    surface_words=words,
                )
                if attached is not None:
                    options.append(attached)
        unique = {
            (
                option.english_text,
                repr(option.nominal.to_dict()),
            ): option
            for option in options
        }
        return tuple(list(unique.values())[:MAX_NOMINAL_OPTIONS])

    def _attach_distributive_to_nominal(
        self,
        base: _NominalReading,
        *,
        token: Any,
        role: str,
        placement: str,
        surface_words: Sequence[Any] | None = None,
    ) -> _NominalReading | None:
        if base.nominal.distribution is not None:
            return None
        modifier = DistributiveModifier(
            marker=token.normalized,
            kind=DISTRIBUTIVE_PARTICLES[token.normalized],
            scope=DistributionScope.NOMINAL,
            target_role=role,
        )
        phrase = DISTRIBUTIVE_ENGLISH[modifier.kind]
        english = (
            f"{base.english_text}, {phrase},"
            if role == "subject"
            else f"{base.english_text} {phrase}"
        )
        surface = (
            " ".join(item.normalized for item in surface_words)
            if surface_words is not None
            else f"{token.normalized} {base.nominal.surface}"
        )
        return replace(
            base,
            nominal=replace(
                base.nominal,
                surface=surface,
                distribution=modifier,
            ),
            english_text=english,
            token_indices=tuple(
                sorted({*base.token_indices, token.index})
            ),
            roles=tuple(
                sorted(
                    {
                        **dict(base.roles),
                        token.index: f"{role}-distributive",
                    }.items()
                )
            ),
            rule_trace=(
                "noun.floating-distributive",
                f"distribution.{modifier.kind.value}",
                f"distribution.scope.{role}",
                f"distribution.{placement}",
                *base.rule_trace,
            ),
        )

    def _parse_determined_nominal(
        self,
        words: Sequence[Any],
        *,
        role: str,
    ) -> list[_NominalReading]:
        determiner = words[0]
        kind = DETERMINERS[determiner.normalized]
        options: list[_NominalReading] = []
        if len(words) == 2:
            for head in self._parse_nominal_atom(words[1], role=role):
                if not self._determiner_head_compatible(
                    determiner,
                    head,
                ):
                    continue
                options.append(
                    self._with_determiner(
                        determiner,
                        kind,
                        head,
                        words,
                    )
                )
            return options

        head_options = tuple(
            head
            for head in self._parse_nominal_atom(words[-1], role=role)
            if self._determiner_head_compatible(determiner, head)
        )
        relative_words = words[1:-1]
        if not head_options or not relative_words:
            return options

        # Determiners scope over complete nominal constructions.  This lets
        # an already typed genitive, extent, or productive prefix constituent
        # become the head instead of flattening its internal grammar into a
        # modifier string (for example ``onă sè wo frë``).
        for head in self._parse_nominal_span(words[1:], role=role):
            if not self._determiner_head_compatible(
                determiner,
                head,
            ):
                continue
            options.append(
                self._with_determiner(
                    determiner,
                    kind,
                    head,
                    words,
                )
            )

        # A determiner scopes over the complete head-final noun phrase, not
        # merely the first word after it.  Try ordinary modifier-head syntax
        # before interpreting the intervening material as a relative clause.
        for head in self._parse_head_final_nominal(
            words[1:],
            role=role,
        ):
            if not self._determiner_head_compatible(
                determiner,
                head,
            ):
                continue
            options.append(
                self._with_determiner(
                    determiner,
                    kind,
                    head,
                    words,
                )
            )

        predicate_token = relative_words[-1]
        predicates = self._predicate_readings(predicate_token.normalized)
        if not predicates:
            return options
        internal_words = relative_words[:-1]
        for head, predicate in itertools.product(
            head_options,
            predicates,
        ):
            for gloss in predicate.english_glosses:
                if not internal_words:
                    relative_roles = (RelativeRole.SUBJECT,)
                    internals: tuple[_NominalReading | None, ...] = (None,)
                else:
                    relative_roles = (
                        RelativeRole.OBJECT,
                        RelativeRole.OBLIQUE,
                    )
                    internals = self._parse_nominal_span(
                        internal_words,
                        role="relative-subject",
                    )
                for relative_role, internal in itertools.product(
                    relative_roles,
                    internals,
                ):
                    if relative_role is RelativeRole.SUBJECT:
                        relative = RelativeClause(
                            predicate=predicate.lemma,
                            role=relative_role,
                            tense=predicate.tense,
                            polarity=predicate.polarity,
                            modality=predicate.modality,
                        )
                        relative_english = self._relative_subject_english(
                            gloss,
                            predicate,
                        )
                    elif relative_role is RelativeRole.OBJECT:
                        if internal is None:
                            continue
                        relative = RelativeClause(
                            predicate=predicate.lemma,
                            role=relative_role,
                            subject=internal.nominal,
                            tense=predicate.tense,
                            polarity=predicate.polarity,
                            modality=predicate.modality,
                        )
                        relative_english = (
                            f"that {internal.english_text} "
                            f"{self._finite_predicate(gloss, predicate, internal.english_text)}"
                        )
                    else:
                        if internal is None:
                            continue
                        relative = RelativeClause(
                            predicate=predicate.lemma,
                            role=relative_role,
                            subject=internal.nominal,
                            tense=predicate.tense,
                            polarity=predicate.polarity,
                            modality=predicate.modality,
                        )
                        relative_english = (
                            f"where {internal.english_text} "
                            f"{self._finite_predicate(gloss, predicate, internal.english_text)}"
                        )
                    article = (
                        "a"
                        if kind == "indefinite"
                        else "a certain"
                        if kind == "specific-indefinite"
                        else "this"
                        if kind == "demonstrative"
                        else "the"
                    )
                    head_text = self._remove_article(head.english_text)
                    if article == "a":
                        article = _indefinite_article(head_text)
                    english = (
                        f"{article} {head_text} {relative_english}"
                    )
                    roles = {
                        **dict(head.roles),
                        determiner.index: "determiner",
                        predicate_token.index: "relative-predicate",
                    }
                    if internal is not None:
                        roles.update(dict(internal.roles))
                        for index in internal.token_indices:
                            roles[index] = "relative-subject"
                    ambiguities = [
                        *head.ambiguities,
                        *(
                            internal.ambiguities
                            if internal is not None
                            else ()
                        ),
                    ]
                    if len(relative_roles) > 1:
                        ambiguities.append(
                            TranslationAmbiguity(
                                code="RELATIVE_GAP_ROLE",
                                message=(
                                    "The same determiner-anchored relative "
                                    "surface permits object and oblique gaps."
                                ),
                                choices=("object", "oblique"),
                                selected=relative_role.value,
                            )
                        )
                    options.append(
                        _NominalReading(
                            nominal=Nominal(
                                surface=" ".join(
                                    token.normalized for token in words
                                ),
                                lexeme_id=head.nominal.lexeme_id,
                                noun_class=head.nominal.noun_class,
                                determiner=kind,
                                number=head.nominal.number,
                                relative_clause=relative,
                                person=head.nominal.person,
                                animacy=head.nominal.animacy,
                                pronoun_kind=head.nominal.pronoun_kind,
                                pronoun_base=head.nominal.pronoun_base,
                            ),
                            english_text=english,
                            token_indices=tuple(
                                token.index for token in words
                            ),
                            roles=tuple(sorted(roles.items())),
                            assumptions=(
                                *head.assumptions,
                                *(
                                    internal.assumptions
                                    if internal is not None
                                    else ()
                                ),
                            ),
                            ambiguities=tuple(ambiguities),
                            rule_trace=(
                                "noun.relative-clause-prenominal",
                                "noun.determiner.inventory",
                                "noun.determiner-class-agreement",
                                *head.rule_trace,
                                *predicate.rule_trace,
                            ),
                            structural_cost=(
                                head.structural_cost
                                + (
                                    internal.structural_cost
                                    if internal is not None
                                    else 0
                                )
                            ),
                        )
                    )
        return options

    @staticmethod
    def _determiner_head_compatible(
        determiner: Any,
        head: _NominalReading,
    ) -> bool:
        if head.nominal.deixis in {
            DeicticDistance.PROXIMAL,
            DeicticDistance.MEDIAL,
            DeicticDistance.DISTAL,
        } and DETERMINERS.get(determiner.normalized) != "definite":
            return False
        if determiner_agrees_with_noun_class(
            determiner.normalized,
            head.nominal.noun_class,
        ):
            return True
        return (
            head.nominal.noun_class is None
            and determiner.normalized in {"onă", "onýj"}
            and "noun.ga-compound-analysis" in head.rule_trace
        )

    def _with_determiner(
        self,
        token: Any,
        kind: str,
        head: _NominalReading,
        words: Sequence[Any],
    ) -> _NominalReading:
        head_text = self._remove_article(head.english_text)
        article = {
            "indefinite": _indefinite_article(head_text),
            "definite": "the",
            "demonstrative": "this",
            "specific-indefinite": "a certain",
        }[kind]
        if head.nominal.deixis is DeicticDistance.PROXIMAL:
            article = "this"
        elif head.nominal.deixis in {
            DeicticDistance.MEDIAL,
            DeicticDistance.DISTAL,
        }:
            article = "that"
        english_text = f"{article} {head_text}"
        possessive = self._split_english_possessive(head_text)
        if possessive is not None:
            possessive_determiner, possessed_head = possessive
            if kind == "definite":
                # English possessive determiners already make an NP definite.
                # The Asaxi determiner still remains in canonical structure for
                # agreement and generation; only its duplicate English article
                # is suppressed.
                english_text = head_text
            else:
                independent = {
                    "my": "mine",
                    "your": "yours",
                    "his": "his",
                    "her": "hers",
                    "its": "its",
                    "our": "ours",
                    "their": "theirs",
                }[possessive_determiner]
                if kind == "indefinite":
                    article = _indefinite_article(possessed_head)
                english_text = (
                    f"{article} {possessed_head} of {independent}"
                )
        roles = {
            **dict(head.roles),
            token.index: "determiner",
        }
        inferred_ga_class = (
            head.nominal.noun_class is None
            and token.normalized in {"onă", "onýj"}
            and "noun.ga-compound-analysis" in head.rule_trace
        )
        noun_class = (
            "warm"
            if inferred_ga_class and token.normalized == "onă"
            else "cold"
            if inferred_ga_class
            else head.nominal.noun_class
        )
        return _NominalReading(
            nominal=replace(
                head.nominal,
                surface=" ".join(item.normalized for item in words),
                determiner=kind,
                noun_class=noun_class,
            ),
            english_text=english_text,
            token_indices=tuple(item.index for item in words),
            roles=tuple(sorted(roles.items())),
            assumptions=head.assumptions,
            ambiguities=(
                *head.ambiguities,
                *(
                    (
                        TranslationAmbiguity(
                            code="GA_COMPOUND_CLASS_FROM_DETERMINER",
                            message=(
                                "The productive ga compound has no compiled "
                                "semantic noun class; the agreeing determiner "
                                "supplies the class for this occurrence."
                            ),
                            choices=("warm", "cold"),
                            selected=noun_class,
                        ),
                    )
                    if inferred_ga_class
                    else ()
                ),
            ),
            rule_trace=(
                "noun.determiner-anchor",
                "noun.determiner.inventory",
                "noun.determiner-class-agreement",
                *(
                    (
                        "noun.deictic-demonstrative",
                        f"noun.deixis.{head.nominal.deixis.value}",
                    )
                    if head.nominal.deixis is not None
                    else ()
                ),
                *(
                    ("noun.ga-compound-class-from-determiner",)
                    if inferred_ga_class
                    else ()
                ),
                *(
                    ("noun.possessive-determiner-definiteness",)
                    if possessive is not None
                    else ()
                ),
                *head.rule_trace,
            ),
            structural_cost=head.structural_cost,
        )

    @staticmethod
    def _split_english_possessive(
        text: str,
    ) -> tuple[str, str] | None:
        """Split a possessive determiner from an already composed NP."""

        first, separator, remainder = text.partition(" ")
        normalized = first.casefold()
        if (
            not separator
            or normalized
            not in {"my", "your", "his", "her", "its", "our", "their"}
        ):
            return None
        return normalized, remainder

    def _parse_head_final_nominal(
        self,
        words: Sequence[Any],
        *,
        role: str,
    ) -> list[_NominalReading]:
        head_options = self._parse_nominal_atom(words[-1], role=role)
        modifier_options = [
            self._parse_nominal_atom(word, role="modifier")
            for word in words[:-1]
        ]
        if not head_options or any(not options for options in modifier_options):
            return []
        readings: list[_NominalReading] = []
        for combination in itertools.product(
            *modifier_options,
            head_options,
        ):
            modifiers = combination[:-1]
            head = combination[-1]
            head_text = self._remove_article(head.english_text)
            premodifiers = tuple(
                item
                for item in modifiers
                if item.nominal.surface not in VICINITY_MODIFIER_ENGLISH
            )
            postmodifiers = tuple(
                VICINITY_MODIFIER_ENGLISH[item.nominal.surface]
                for item in modifiers
                if item.nominal.surface in VICINITY_MODIFIER_ENGLISH
            )
            article = ""
            lowered_head = head.english_text.casefold()
            for candidate in (
                "a certain ",
                "a specific ",
                "a ",
                "an ",
                "the ",
                "this ",
            ):
                if lowered_head.startswith(candidate):
                    article = head.english_text[: len(candidate)].strip()
                    break
            english = " ".join(
                [
                     *([article] if article else []),
                     *(
                         self._remove_article(item.english_text)
                         for item in premodifiers
                     ),
                     head_text,
                     *postmodifiers,
                 ]
             )
            roles = dict(head.roles)
            for modifier in modifiers:
                roles.update(
                    {
                        index: "modifier"
                        for index in modifier.token_indices
                    }
                )
            readings.append(
                _NominalReading(
                    nominal=Nominal(
                        surface=" ".join(
                            token.normalized for token in words
                        ),
                        lexeme_id=head.nominal.lexeme_id,
                        noun_class=head.nominal.noun_class,
                        number=head.nominal.number,
                        modifiers=tuple(
                            modifier.nominal for modifier in modifiers
                        ),
                        person=head.nominal.person,
                        animacy=head.nominal.animacy,
                        pronoun_kind=head.nominal.pronoun_kind,
                        pronoun_base=head.nominal.pronoun_base,
                        word_time_binding=head.nominal.word_time_binding,
                    ),
                    english_text=english,
                    token_indices=tuple(
                        token.index for token in words
                    ),
                    roles=tuple(sorted(roles.items())),
                    assumptions=tuple(
                        assumption
                        for item in combination
                        for assumption in item.assumptions
                    ),
                    ambiguities=tuple(
                        ambiguity
                        for item in combination
                        for ambiguity in item.ambiguities
                    ),
                     rule_trace=(
                         "noun.head-final-multiword",
                         *(
                             ("noun.vicinity-modifier",)
                             if postmodifiers
                             else ()
                         ),
                         *(
                             trace
                             for item in combination
                            for trace in item.rule_trace
                        ),
                    ),
                    structural_cost=(
                        sum(
                            item.structural_cost
                            for item in combination
                        )
                        + len(modifiers)
                    ),
                )
            )
        return readings

    def _parse_deictic_nominal_atom(
        self,
        token: Any,
        *,
        role: str,
    ) -> tuple[_NominalReading, ...]:
        parts = _split_deictic_surface(token.normalized)
        if parts is None:
            return ()
        prefix, normalized_head, distance = parts
        surface_parts = token.surface.split("-", 1)
        surface_head = (
            surface_parts[1]
            if len(surface_parts) == 2 and surface_parts[1]
            else normalized_head
        )
        head_token = replace(
            token,
            surface=surface_head,
            normalized=normalized_head,
            start=min(token.end, token.start + len(prefix) + 1),
        )
        heads = self._parse_nominal_atom(head_token, role=role)
        readings: list[_NominalReading] = []
        for head in heads:
            head_text = self._remove_article(head.english_text)
            if distance is DeicticDistance.PROXIMAL:
                english = f"this {head_text}"
            elif distance is DeicticDistance.MEDIAL:
                english = f"that {head_text} near you"
            elif distance is DeicticDistance.DISTAL:
                english = f"that {head_text} over there"
            else:
                english = (
                    f"{_indefinite_article(head_text)} "
                    f"{head_text} somewhere"
                )
            readings.append(
                _NominalReading(
                    nominal=replace(
                        head.nominal,
                        surface=token.normalized,
                        deixis=distance,
                    ),
                    english_text=english,
                    token_indices=(token.index,),
                    roles=((token.index, role),),
                    assumptions=head.assumptions,
                    ambiguities=head.ambiguities,
                    rule_trace=(
                        "noun.deictic-prefix",
                        f"noun.deixis.{distance.value}",
                        *head.rule_trace,
                    ),
                    structural_cost=head.structural_cost,
                )
            )
        return tuple(readings)

    def _parse_attainable_nominal_atom(
        self,
        token: Any,
        *,
        role: str,
    ) -> tuple[_NominalReading, ...]:
        """Analyze ``ono-N`` as an attainable/within-reach nominal."""

        normalized_head = _split_attainable_surface(token.normalized)
        if normalized_head is None:
            return ()
        surface_parts = token.surface.split("-", 1)
        surface_head = (
            surface_parts[1]
            if len(surface_parts) == 2 and surface_parts[1]
            else normalized_head
        )
        head_token = replace(
            token,
            surface=surface_head,
            normalized=normalized_head,
            start=min(token.end, token.start + len("ono-")),
        )
        readings: list[_NominalReading] = []
        for head in self._parse_nominal_atom(head_token, role=role):
            bare = self._remove_article(head.english_text)
            lowered = head.english_text.casefold()
            if lowered.startswith("the ") or role == "subject":
                article = "the"
            elif lowered.startswith(("a ", "an ")):
                article = "an"
            else:
                article = "an" if role != "modifier" else ""
            english = " ".join(
                part for part in (article, "attainable", bare) if part
            )
            readings.append(
                _NominalReading(
                    nominal=replace(
                        head.nominal,
                        surface=token.normalized,
                        relation="attainable",
                    ),
                    english_text=english,
                    token_indices=(token.index,),
                    roles=((token.index, role),),
                    assumptions=head.assumptions,
                    ambiguities=head.ambiguities,
                    rule_trace=(
                        "noun.attainable-ono-prefix",
                        "noun.productive-prefix-construction",
                        *head.rule_trace,
                    ),
                    structural_cost=head.structural_cost + 1,
                )
            )
        return tuple(readings)

    def _parse_nominal_atom(
        self,
        token: Any,
        *,
        role: str,
    ) -> tuple[_NominalReading, ...]:
        word_time = self._parse_fused_word_time_nominal_atom(
            token,
            role=role,
        )
        if word_time:
            return word_time
        wh = WH_WORDS.get(token.normalized)
        if wh is not None:
            english, wh_role = wh
            return (
                _NominalReading(
                    nominal=Nominal(
                        token.normalized,
                        wh_word=english,
                    ),
                    english_text=english,
                    token_indices=(token.index,),
                    roles=((token.index, f"wh-{wh_role.value}"),),
                    rule_trace=("nominal.wh-in-situ",),
                ),
            )
        if token.kind == "number":
            return (
                _NominalReading(
                    nominal=Nominal(
                        token.surface,
                        person=PronounPerson.THIRD,
                    ),
                    english_text=token.surface,
                    token_indices=(token.index,),
                    roles=((token.index, role),),
                    rule_trace=("nominal.number",),
                ),
            )
        if token.surface.isupper() and role != "modifier":
            proper = token.surface[:1].upper() + token.surface[1:].lower()
            return (
                _NominalReading(
                    nominal=Nominal(
                        token.surface,
                        person=PronounPerson.THIRD,
                    ),
                    english_text=proper,
                    token_indices=(token.index,),
                    roles=((token.index, role),),
                    assumptions=(
                        TranslationAssumption(
                            code="UPPERCASE_PROPER_TERM",
                            message=(
                                f"{token.surface!r} was retained under the "
                                "documented proper-term convention."
                            ),
                        ),
                    ),
                    rule_trace=("nominal.uppercase-proper-term",),
                ),
            )

        extent = self._parse_extent_nominal_atom(token, role=role)

        attainable = self._parse_attainable_nominal_atom(
            token,
            role=role,
        )
        if attainable:
            return (*attainable, *extent)

        deictic = self._parse_deictic_nominal_atom(token, role=role)
        if deictic:
            return (*deictic, *extent)

        analyses = self.morphology.analyze(token.normalized)
        closed_pronouns = (
            self._parse_closed_pronoun(token, role=role)
            if role != "modifier"
            else ()
        )
        if token.normalized in PRONOMINAL_PARTICLE_FORMS:
            # Closed pronouns are grammatical forms, not ordinary lexical
            # nouns. Falling through to dictionary glosses would bypass
            # person/number binding and syntactic-role restrictions.
            return closed_pronouns
        determiner_pronouns = (
            self._parse_determiner_pronoun(token, role=role)
            if role != "modifier"
            else ()
        )
        exact_matches = self.lexicon.asaxi_matches(token.normalized)
        exact_lexemes = tuple(match.lexeme for match in exact_matches)
        variants_by_lexeme = {
            match.lexeme.identifier: match.variant
            for match in exact_matches
            if match.variant is not None
        }
        lexemes: dict[str, Lexeme] = {
            lexeme.identifier: lexeme
            for lexeme in exact_lexemes
            if lexeme_allowed_for_nominal_role(lexeme, role)
        }
        if not exact_lexemes:
            # Productive morphology may recover a noun behind an inflected
            # form, but it must not reinterpret an exact adjective as that
            # source noun merely to fill a subject or object slot.
            for analysis in analyses:
                if not category_allowed_for_nominal_role(
                    analysis.category,
                    role,
                ):
                    continue
                if analysis.lexeme_id in self._lexemes_by_id:
                    lexeme = self._lexemes_by_id[analysis.lexeme_id]
                    if lexeme_allowed_for_nominal_role(lexeme, role):
                        lexemes[lexeme.identifier] = lexeme
        plural = any(
            dict(analysis.features).get("number") == "plural"
            for analysis in analyses
        )
        records = [
            (lexeme, gloss, variants_by_lexeme.get(lexeme.identifier))
            for lexeme in (
                lexemes[key] for key in sorted(lexemes)
            )
            for gloss in split_english_gloss(lexeme)
        ]
        if not records:
            return (
                *closed_pronouns,
                *determiner_pronouns,
                *self._parse_ga_compound_atom(token, role=role),
                *extent,
            )
        choices = tuple(
            dict.fromkeys(
                f"{gloss} [{lexeme.identifier}]"
                for lexeme, gloss, _variant in records
            )
        )
        options: list[_NominalReading] = []
        for lexeme, gloss, variant in records:
            english = plural_noun(gloss) if plural else gloss
            article_defaulted = False
            predicative_ga_property = (
                role == "complement"
                and "ga-noun" in lexeme.tags
                and "ga-idiomatic" in lexeme.tags
            )
            if role in {"subject", "relative-subject", "causer"}:
                if (
                    lexeme.category == "noun"
                    and not english.casefold().startswith(
                        ("a ", "an ", "the ", "some ", "this ", "that ")
                    )
                ):
                    english = "the " + english
            elif role in {
                "object",
                "complement",
                "location",
                "possessor",
            }:
                if english.casefold() in OBJECT_PRONOUNS:
                    english = OBJECT_PRONOUNS[english.casefold()]
                elif (
                    lexeme.category == "noun"
                    and not plural
                    and not predicative_ga_property
                    and not english.casefold().startswith(
                        ("a ", "an ", "the ", "some ", "this ", "that ")
                    )
                ):
                    english = _indefinite_article(english) + " " + english
                    article_defaulted = True
            ambiguities: list[TranslationAmbiguity] = []
            assumptions: list[TranslationAssumption] = []
            if variant is not None:
                assumptions.append(
                    TranslationAssumption(
                        code="LEXICAL_SURFACE_VARIANT",
                        message=(
                            f"{token.surface!r} is a documented surface "
                            f"variant of {lexeme.lemma!r}."
                        ),
                        details={
                            "contexts": list(variant.contexts),
                            "source_line": variant.source_line,
                        },
                    )
                )
            if predicative_ga_property:
                assumptions.append(
                    TranslationAssumption(
                        code="GA_NOUN_PREDICATIVE_PROPERTY",
                        message=(
                            "The idiomatic ga-noun is functioning as a bare "
                            "predicative property, following documented "
                            "examples such as 'apo gapo xiŕa' ('the apple is "
                            "red')."
                        ),
                    )
                )
            if article_defaulted:
                assumptions.append(
                    TranslationAssumption(
                        code="BARE_NOUN_INDEFINITE_DEFAULT",
                        message=(
                            "The bare singular nominal was rendered with an "
                            "English indefinite article."
                        ),
                    )
                )
                ambiguities.append(
                    TranslationAmbiguity(
                        code="BARE_NOUN_DEFINITENESS",
                        message=(
                            "The bare Asaxi nominal does not force one English "
                            "article interpretation."
                        ),
                        choices=("indefinite", "definite", "generic/bare"),
                        selected="indefinite",
                    )
                )
            if len(choices) > 1:
                ambiguities.append(
                    TranslationAmbiguity(
                        code="NOMINAL_LEXICAL_AMBIGUITY",
                        message=(
                            f"The {role} has multiple compiled English "
                            "interpretations."
                        ),
                        choices=choices,
                        selected=f"{gloss} [{lexeme.identifier}]",
                    )
                )
            options.append(
                _NominalReading(
                    nominal=Nominal(
                        surface=token.normalized,
                        lexeme_id=lexeme.identifier,
                        noun_class=(
                            str(lexeme.noun_class.value)
                            if lexeme.noun_class.is_present
                            else None
                        ),
                        number="plural" if plural else "singular",
                        person=PronounPerson.THIRD,
                    ),
                    english_text=english,
                    token_indices=(token.index,),
                    roles=((token.index, role),),
                    assumptions=tuple(assumptions),
                    ambiguities=tuple(ambiguities),
                    rule_trace=(
                        "lexicon.nominal",
                        *(
                            ("lexicon.source-variant",)
                            if variant is not None
                            else ()
                        ),
                        *(
                            ("clause.ga-noun-predicative-property",)
                            if predicative_ga_property
                            else ()
                        ),
                    ),
                )
            )
        return (
            *closed_pronouns,
            *determiner_pronouns,
            *options,
            *extent,
        )

    @staticmethod
    def _parse_closed_pronoun(
        token: Any,
        *,
        role: str,
    ) -> tuple[_NominalReading, ...]:
        surface = token.normalized
        if surface in PERSONAL_PRONOUN_ENGLISH:
            english = PERSONAL_PRONOUN_ENGLISH[surface]
            if role in {
                "object",
                "complement",
                "location",
                "possessor",
            }:
                english = OBJECT_PRONOUNS.get(
                    english.casefold(),
                    english,
                )
            number = (
                "plural"
                if surface in PLURAL_PERSONAL_PRONOUNS
                else "singular"
            )
            person, animacy = PERSONAL_PRONOUN_FEATURES[surface]
            pronoun_kind = PronounKind.PERSONAL
            pronoun_base = surface
            trace = ("nominal.personal-pronoun.inventory",)
        elif surface in REFLEXIVE_PRONOUN_ENGLISH:
            if role != "object":
                return ()
            english = REFLEXIVE_PRONOUN_ENGLISH[surface]
            number = (
                "plural"
                if english.endswith("selves")
                else "singular"
            )
            pronoun_base = surface[2:]
            person, animacy = PERSONAL_PRONOUN_FEATURES[pronoun_base]
            pronoun_kind = PronounKind.REFLEXIVE
            trace = (
                "nominal.reflexive-pronoun",
                "nominal.reflexive-ni-derivation",
            )
        elif surface in RECIPROCAL_PRONOUNS:
            if role == "subject":
                return ()
            english = "each other"
            number = "plural"
            person = None
            animacy = None
            pronoun_kind = PronounKind.RECIPROCAL
            pronoun_base = None
            trace = ("nominal.reciprocal-pronoun",)
        else:
            return ()
        return (
            _NominalReading(
                nominal=Nominal(
                    surface=surface,
                    number=number,
                    relation="pronoun",
                    person=person,
                    animacy=animacy,
                    pronoun_kind=pronoun_kind,
                    pronoun_base=pronoun_base,
                ),
                english_text=english,
                token_indices=(token.index,),
                roles=((token.index, role),),
                rule_trace=trace,
            ),
        )

    def _parse_determiner_pronoun(
        self,
        token: Any,
        *,
        role: str,
    ) -> tuple[_NominalReading, ...]:
        meanings = {
            "anő": "one",
            "onă": "this one",
            "onýj": "this one",
            "ponă": "a certain one",
            "ponýj": "a certain one",
        }
        english = meanings.get(token.normalized)
        if english is None:
            return ()
        kind = DETERMINERS[token.normalized]
        return (
            _NominalReading(
                nominal=Nominal(
                    surface=token.normalized,
                    determiner=kind,
                    relation="determiner-pronoun",
                ),
                english_text=english,
                token_indices=(token.index,),
                roles=((token.index, role),),
                rule_trace=(
                    "noun.determiner-pronoun",
                    "noun.determiner.inventory",
                ),
            ),
        )

    @staticmethod
    def _category_allowed_for_nominal_role(
        category: str,
        role: str,
    ) -> bool:
        """Apply the documented head/modifier distinction.

        Argument positions require a nominal head. Adjectives remain valid
        before a head and as identity complements, but cannot become subjects
        or objects merely because they have an English gloss.
        """

        return category_allowed_for_nominal_role(category, role)

    def _build_ga_part_indexes(
        self,
    ) -> tuple[
        dict[str, tuple[tuple[str, tuple[Lexeme, ...]], ...]],
        dict[str, tuple[tuple[str, tuple[Lexeme, ...]], ...]],
    ]:
        modifier_work: dict[str, list[tuple[str, tuple[Lexeme, ...]]]] = {}
        head_work: dict[str, list[tuple[str, tuple[Lexeme, ...]]]] = {}
        for surface, lexemes in self.lexicon.by_surface.items():
            if not surface or " " in surface:
                continue
            modifiers = tuple(
                lexeme
                for lexeme in lexemes
                if lexeme.category in GA_MODIFIER_CATEGORIES
                and split_english_gloss(lexeme)
            )
            heads = tuple(
                lexeme
                for lexeme in lexemes
                if lexeme.category in GA_HEAD_CATEGORIES
                and split_english_gloss(lexeme)
            )
            if modifiers:
                modifier_work.setdefault(surface[0], []).append(
                    (surface, modifiers)
                )
            if heads:
                head_work.setdefault(surface[-1], []).append(
                    (surface, heads)
                )
        return (
            {
                key: tuple(
                    sorted(
                        values,
                        key=lambda item: (-len(item[0]), item[0]),
                    )
                )
                for key, values in modifier_work.items()
            },
            {
                key: tuple(
                    sorted(
                        values,
                        key=lambda item: (-len(item[0]), item[0]),
                    )
                )
                for key, values in head_work.items()
            },
        )

    @staticmethod
    def _inverse_ga_payloads(surface: str) -> tuple[str, ...]:
        """Return payload candidates for the three documented ga fusions."""

        payloads: list[str] = []
        if surface.startswith("ga") and len(surface) > 2:
            # Default ga + payload.
            payloads.append(surface[2:])
            # Before /a/, ga loses its vowel: g + a...
            payloads.append(surface[1:])
        if surface.startswith("gă") and len(surface) > 2:
            # Before /i/, ga + i... coalesces to gă...
            payloads.append("i" + surface[2:])
        return tuple(dict.fromkeys(payloads))

    def _segment_ga_modifiers(
        self,
        payload: str,
    ) -> tuple[
        tuple[tuple[tuple[str, tuple[Lexeme, ...]], ...], ...],
        bool,
    ]:
        memo: dict[
            tuple[int, int],
            tuple[tuple[tuple[str, tuple[Lexeme, ...]], ...], ...],
        ] = {}
        limited = False

        def visit(
            offset: int,
            remaining: int,
        ) -> tuple[
            tuple[tuple[str, tuple[Lexeme, ...]], ...],
            ...,
        ]:
            nonlocal limited
            key = (offset, remaining)
            if key in memo:
                return memo[key]
            if offset == len(payload):
                return ((),)
            if remaining == 0:
                limited = True
                return ()
            options: list[
                tuple[tuple[str, tuple[Lexeme, ...]], ...]
            ] = []
            for surface, lexemes in self._ga_modifier_surfaces.get(
                payload[offset],
                (),
            ):
                if not payload.startswith(surface, offset):
                    continue
                for tail in visit(offset + len(surface), remaining - 1):
                    options.append(((surface, lexemes), *tail))
                    if len(options) >= MAX_NOMINAL_OPTIONS:
                        limited = True
                        break
                if len(options) >= MAX_NOMINAL_OPTIONS:
                    break
            memo[key] = tuple(options)
            return memo[key]

        segmentations = [
            segmentation
            for segmentation in visit(0, MAX_GA_MODIFIERS)
            if segmentation
        ]
        return (
            tuple(
                sorted(
                    segmentations,
                    key=lambda parts: (
                        len(parts),
                        tuple(-len(surface) for surface, _ in parts),
                        tuple(surface for surface, _ in parts),
                    ),
                )
            ),
            limited,
        )

    def _ga_compound_candidates(
        self,
        surface: str,
    ) -> _GaCompoundAnalysis:
        if surface in self._ga_compound_cache:
            return self._ga_compound_cache[surface]

        candidates: list[_GaCompoundCandidate] = []
        seen: set[tuple[tuple[str, ...], str]] = set()
        limited = False
        for payload in self._inverse_ga_payloads(surface):
            if not payload:
                continue
            for head_surface, head_lexemes in self._ga_head_surfaces.get(
                payload[-1],
                (),
            ):
                if not payload.endswith(head_surface):
                    continue
                modifier_payload = payload[:-len(head_surface)]
                if not modifier_payload:
                    continue
                segmentations, segmentation_limited = (
                    self._segment_ga_modifiers(modifier_payload)
                )
                limited = limited or segmentation_limited
                for segmentation in segmentations:
                    modifier_surfaces = tuple(
                        item[0] for item in segmentation
                    )
                    generated = compose_ga_compound(
                        modifier_surfaces,
                        head_surface,
                    )
                    if generated.surface != surface:
                        continue
                    modifier_sets = tuple(
                        item[1] for item in segmentation
                    )
                    for values in itertools.product(
                        *modifier_sets,
                        head_lexemes,
                    ):
                        modifiers = tuple(values[:-1])
                        head = values[-1]
                        key = (
                            tuple(
                                modifier.identifier
                                for modifier in modifiers
                            ),
                            head.identifier,
                        )
                        if key in seen:
                            continue
                        seen.add(key)
                        candidates.append(
                            _GaCompoundCandidate(
                                modifiers=modifiers,
                                head=head,
                                rule_trace=(
                                    "noun.ga-compound-analysis",
                                    "noun.ga.fusion",
                                    *generated.rule_trace,
                                ),
                            )
                        )
                        if len(candidates) >= MAX_NOMINAL_OPTIONS:
                            limited = True
                            break
                    if len(candidates) >= MAX_NOMINAL_OPTIONS:
                        break
                if len(candidates) >= MAX_NOMINAL_OPTIONS:
                    break
            if len(candidates) >= MAX_NOMINAL_OPTIONS:
                break
        self._ga_compound_cache[surface] = _GaCompoundAnalysis(
            candidates=tuple(candidates),
            limited=limited,
        )
        return self._ga_compound_cache[surface]

    def _parse_ga_compound_atom(
        self,
        token: Any,
        *,
        role: str,
    ) -> tuple[_NominalReading, ...]:
        analysis = self._ga_compound_candidates(token.normalized)
        lexical_options: list[
            tuple[_GaCompoundCandidate, tuple[str, ...], str]
        ] = []
        limited = analysis.limited
        for candidate in analysis.candidates:
            modifier_glosses = tuple(
                split_english_gloss(modifier)
                for modifier in candidate.modifiers
            )
            head_glosses = split_english_gloss(candidate.head)
            if any(not glosses for glosses in modifier_glosses):
                continue
            for combination in itertools.product(
                *modifier_glosses,
                head_glosses,
            ):
                base = " ".join(combination)
                lexical_options.append(
                    (candidate, combination, base)
                )
                if len(lexical_options) >= MAX_GA_LEXICAL_OPTIONS:
                    limited = True
                    break
            if len(lexical_options) >= MAX_GA_LEXICAL_OPTIONS:
                break
        if not lexical_options:
            return ()

        choices = tuple(
            dict.fromkeys(
                f"{base} [{candidate.head.identifier}]"
                for candidate, _, base in lexical_options
            )
        )
        readings: list[_NominalReading] = []
        for candidate, glosses, base in lexical_options:
            english = base
            assumptions: list[TranslationAssumption] = []
            ambiguities: list[TranslationAmbiguity] = []
            if role in {"subject", "relative-subject"}:
                english = "the " + english
            elif role in {
                "object",
                "complement",
                "location",
                "possessor",
            }:
                english = _indefinite_article(english) + " " + english
                assumptions.append(
                    TranslationAssumption(
                        code="BARE_NOUN_INDEFINITE_DEFAULT",
                        message=(
                            "The bare singular ga compound was rendered "
                            "with an English indefinite article."
                        ),
                    )
                )
                ambiguities.append(
                    TranslationAmbiguity(
                        code="BARE_NOUN_DEFINITENESS",
                        message=(
                            "The bare Asaxi nominal does not force one "
                            "English article interpretation."
                        ),
                        choices=(
                            "indefinite",
                            "definite",
                            "generic/bare",
                        ),
                        selected="indefinite",
                    )
                )
            if len(choices) > 1:
                ambiguities.append(
                    TranslationAmbiguity(
                        code="GA_COMPOUND_LEXICAL_AMBIGUITY",
                        message=(
                            "The productive ga compound has multiple "
                            "compiled lexical interpretations."
                        ),
                        choices=choices,
                        selected=(
                            f"{base} [{candidate.head.identifier}]"
                        ),
                    )
                )
            if limited:
                assumptions.append(
                    TranslationAssumption(
                        code="ANALYSIS_LIMIT_REACHED",
                        message=(
                            "Productive ga-compound analysis exceeded the "
                            "deterministic interpretation beam; lower-ranked "
                            "segmentations or lexical combinations remain "
                            "unmaterialized."
                        ),
                        details={
                            "surface": token.normalized,
                            "modifier_limit": MAX_GA_MODIFIERS,
                            "interpretation_limit": (
                                MAX_GA_LEXICAL_OPTIONS
                            ),
                        },
                    )
                )
            readings.append(
                _NominalReading(
                    nominal=Nominal(
                        surface=token.normalized,
                        lexeme_id=candidate.head.identifier,
                        # The grammar says a ga compound's class follows the
                        # resulting concept, not mechanically its final root.
                        noun_class=None,
                        modifiers=tuple(
                            Nominal(
                                surface=modifier.surface_form,
                                lexeme_id=modifier.identifier,
                                noun_class=(
                                    str(modifier.noun_class.value)
                                    if modifier.noun_class.is_present
                                    else None
                                ),
                            )
                            for modifier in candidate.modifiers
                        ),
                    ),
                    english_text=english,
                    token_indices=(token.index,),
                    roles=((token.index, role),),
                    assumptions=tuple(assumptions),
                    ambiguities=tuple(ambiguities),
                    rule_trace=candidate.rule_trace,
                    structural_cost=max(
                        0,
                        len(candidate.modifiers) - 1,
                    ),
                )
            )
        return tuple(readings)

    @staticmethod
    def _remove_article(text: str) -> str:
        lowered = text.casefold()
        for article in (
            "a certain ",
            "a specific ",
            "a ",
            "an ",
            "the ",
            "this ",
            "that ",
        ):
            if lowered.startswith(article):
                return text[len(article):]
        return text

    @staticmethod
    def _possessive_determiner(text: str) -> str | None:
        """Return English possessive morphology for a pronoun possessor."""

        normalized = re.sub(
            r"\s+\([^)]*\)\s*$",
            "",
            text.casefold(),
        )
        return {
            "i": "my",
            "me": "my",
            "you": "your",
            "he": "his",
            "him": "his",
            "she": "her",
            "her": "her",
            "it": "its",
            "we": "our",
            "us": "our",
            "they": "their",
            "them": "their",
        }.get(normalized)

    @staticmethod
    def _wh_role(
        subject: _NominalReading,
        complement: _NominalReading | None,
        predicate_kind: PredicateKind,
    ) -> WhRole | None:
        if subject.nominal.wh_word:
            return WhRole.SUBJECT
        if complement is not None and complement.nominal.wh_word:
            lexical_role = {
                "where": WhRole.LOCATION,
                "when": WhRole.TIME,
                "why": WhRole.REASON,
                "how": WhRole.MANNER,
            }.get(complement.nominal.wh_word)
            if lexical_role is not None:
                return lexical_role
            if predicate_kind is PredicateKind.ACTION:
                return WhRole.OBJECT
            return WhRole.COMPLEMENT
        return None

    @staticmethod
    def _clause_wh_word(clause: CanonicalClause) -> str | None:
        for nominal in (
            clause.subject,
            clause.object,
            clause.complement,
            clause.location,
            clause.time,
        ):
            if nominal is not None and nominal.wh_word:
                return nominal.wh_word
        return None

    @staticmethod
    def _front_temporal_nominal(time_text: str, sentence: str) -> str:
        """Render the documented clause-initial temporal nominal."""

        return f"{_capitalize(time_text)}, {sentence}"

    @staticmethod
    def _append_temporal_nominal(sentence: str, time_text: str) -> str:
        terminal = sentence[-1:] if sentence[-1:] in ".?!" else ""
        body = sentence[:-1] if terminal else sentence
        return f"{body} {time_text}{terminal}"

    def _uses_weather_expletive(
        self,
        clause: CanonicalClause,
        predicate: _PredicateReading,
    ) -> bool:
        """Detect a weather-event noun repeated as its derived predicate."""

        if (
            clause.predicate_kind is not PredicateKind.ACTION
            or clause.object is not None
            or clause.subject is None
            or clause.subject.lexeme_id is None
            or predicate.lexeme is None
        ):
            return False
        subject = self._lexemes_by_id.get(clause.subject.lexeme_id)
        if subject is None:
            return False
        fields = {
            field.removeprefix("Smntc_Field ").strip().casefold()
            for field in (
                *subject.semantic_fields,
                *predicate.lexeme.semantic_fields,
            )
        }
        if "weather & climate" not in fields:
            return False
        root_names = {
            root.split(" (", 1)[0].strip().casefold()
            for root in predicate.lexeme.root_links
        }
        return subject.lemma.casefold() in root_names

    def _uses_full_extent_progressive(
        self,
        clause: CanonicalClause,
        predicate: _PredicateReading,
    ) -> bool:
        if (
            clause.tense is not Tense.PAST
            or clause.time is None
            or clause.time.extent is None
            or clause.time.extent.kind is not NominalExtentKind.COMPLETE
            or predicate.lexeme is None
            or self._uses_weather_expletive(clause, predicate)
        ):
            return False
        lexical_aspect = predicate.lexeme.lexical_aspect
        if not lexical_aspect.is_present:
            return False
        value = str(lexical_aspect.value).casefold()
        return "durative" in value or "activity" in value

    @staticmethod
    def _append_word_time_manner(
        statement: str,
        subject: str,
        binding: WordTimeBinding,
    ) -> str:
        punctuation = statement[-1] if statement[-1:] in ".?!" else "."
        body = statement[:-1] if statement[-1:] in ".?!" else statement
        if binding.orientation is WordTimeOrientation.RETROSPECTIVE:
            manner = f"as {subject} once did"
        else:
            manner = f"as {subject} soon will"
        return f"{body} {manner}{punctuation}"

    def _render_word_time_adjective_copula(
        self,
        clause: CanonicalClause,
        subject: str,
        complement: str,
        binding: WordTimeBinding,
    ) -> str:
        if binding.orientation is WordTimeOrientation.RETROSPECTIVE:
            adjective = complement.removeprefix("formerly ")
            if clause.tense is Tense.NONPAST:
                if clause.interrogative:
                    auxiliary = (
                        "Did" if clause.polarity is Polarity.POSITIVE
                        else "Didn't"
                    )
                    return _capitalize(
                        f"{auxiliary} {subject} use to be {adjective}?"
                    )
                auxiliary = (
                    "used to be"
                    if clause.polarity is Polarity.POSITIVE
                    else "did not use to be"
                )
                return _capitalize(f"{subject} {auxiliary} {adjective}.")
            complement = f"formerly {adjective}"
        else:
            adjective = complement.removeprefix("soon-to-be ")
            complement = f"soon to be {adjective}"
        return self._copular_sentence(
            subject,
            complement,
            tense=clause.tense,
            polarity=clause.polarity,
            interrogative=clause.interrogative,
            wh_role=clause.wh_role,
            wh_word=self._clause_wh_word(clause),
            subject_plural=self._nominal_is_plural(clause.subject),
        )

    def _render_clause(
        self,
        clause: CanonicalClause,
        subject: str,
        complement: str | None,
        predicate_gloss: str,
        *,
        predicate: _PredicateReading | None = None,
    ) -> str:
        if clause.predicate_time_binding is not None:
            bare_clause = replace(clause, predicate_time_binding=None)
            statement = self._render_clause(
                bare_clause,
                subject,
                complement,
                predicate_gloss,
                predicate=predicate,
            )
            return self._append_word_time_manner(
                statement,
                subject,
                clause.predicate_time_binding,
            )
        wh_word = self._clause_wh_word(clause)
        if clause.predicate_kind is PredicateKind.FRAGMENT:
            return _capitalize(subject) + (
                "?" if clause.interrogative else "."
            )
        if not clause.post_verbal_scope.is_empty:
            return self._render_post_verbal_clause(
                clause,
                subject,
                complement,
                predicate_gloss,
                predicate=predicate,
            )
        if (
            predicate is not None
            and predicate.verbalization_source_gloss is not None
        ):
            return self._render_productive_verbalization(
                clause,
                subject,
                complement,
                predicate,
            )
        if clause.predicate_kind is PredicateKind.EXISTENCE:
            article_subject = subject
            if (
                clause.subject is not None
                and clause.subject.determiner is None
                and subject.casefold().startswith("the ")
            ):
                bare_subject = self._remove_article(subject)
                article_subject = (
                    _indefinite_article(bare_subject)
                    + " "
                    + bare_subject
                )
            elif not self._english_np_is_determined(subject):
                article_subject = (
                    _indefinite_article(subject) + " " + subject
                )
            statement = self._existence_statement(
                article_subject,
                clause.tense,
                clause.polarity,
            )
            return statement + ("?" if clause.interrogative else ".")

        if clause.predicate_kind in {
            PredicateKind.IDENTITY,
            PredicateKind.PERFORMANCE,
        }:
            complement_text = complement or ""
            complement_binding = (
                clause.complement.word_time_binding
                if clause.complement is not None
                else None
            )
            if (
                complement_binding is not None
                and complement_binding.scope is WordTimeScope.ADJECTIVE
            ):
                return self._render_word_time_adjective_copula(
                    clause,
                    subject,
                    complement_text,
                    complement_binding,
                )
            if clause.predicate_kind is PredicateKind.PERFORMANCE:
                complement_text = "acting as " + complement_text
            return self._copular_sentence(
                subject,
                complement_text,
                tense=clause.tense,
                polarity=clause.polarity,
                interrogative=clause.interrogative,
                wh_role=clause.wh_role,
                wh_word=wh_word,
                subject_plural=self._nominal_is_plural(clause.subject),
            )

        if clause.predicate_kind is PredicateKind.CONSTITUTION:
            return self._copular_sentence(
                subject,
                predicate_gloss,
                tense=clause.tense,
                polarity=clause.polarity,
                interrogative=clause.interrogative,
                wh_role=clause.wh_role,
                wh_word=wh_word,
                subject_plural=self._nominal_is_plural(clause.subject),
            )

        if clause.predicate_kind is PredicateKind.LOCATION:
            if (
                clause.location is not None
                and clause.location.deixis is not None
                and clause.location.surface
                in VICINITY_NOMINAL_MODIFIERS
            ):
                if clause.predicate in VICINITY_LOCATION_PREDICATES:
                    predicate_text = VICINITY_LOCATION_ENGLISH[
                        clause.location.surface
                    ]
                else:
                    predicate_text = {
                        DeicticDistance.PROXIMAL: "here",
                        DeicticDistance.MEDIAL: "there",
                        DeicticDistance.DISTAL: "over there",
                        DeicticDistance.INDEFINITE: "somewhere",
                    }[clause.location.deixis]
            elif predicate_gloss in {"here", "there", "over there"}:
                predicate_text = predicate_gloss
            elif complement:
                predicate_text = f"{predicate_gloss} {complement}"
            else:
                predicate_text = predicate_gloss
            return self._copular_sentence(
                subject,
                predicate_text,
                tense=clause.tense,
                polarity=clause.polarity,
                interrogative=clause.interrogative,
                wh_role=clause.wh_role,
                wh_word=wh_word,
                subject_plural=self._nominal_is_plural(clause.subject),
            )

        if clause.predicate_kind in {
            PredicateKind.POSSESSION,
            PredicateKind.RELATION,
        }:
            if predicate_gloss.startswith("be "):
                relation = predicate_gloss[3:]
                if complement:
                    relation += " " + complement
                return self._copular_sentence(
                    subject,
                    relation,
                    tense=clause.tense,
                    polarity=clause.polarity,
                    interrogative=clause.interrogative,
                    wh_role=clause.wh_role,
                    wh_word=wh_word,
                    subject_plural=self._nominal_is_plural(clause.subject),
                )
            return self._action_sentence(
                subject,
                predicate_gloss,
                complement,
                tense=clause.tense,
                polarity=clause.polarity,
                modality=Modality.NONE,
                interrogative=clause.interrogative,
                wh_role=clause.wh_role,
                wh_word=wh_word,
            )

        weather_expletive = (
            predicate is not None
            and self._uses_weather_expletive(clause, predicate)
        )
        return self._action_sentence(
            "it" if weather_expletive else subject,
            predicate_gloss,
            complement if clause.object is not None else None,
            tense=clause.tense,
            polarity=clause.polarity,
            modality=clause.modality,
            interrogative=clause.interrogative,
            wh_role=clause.wh_role,
            wh_word=wh_word,
            temporal_aspect=clause.temporal_aspect,
            frequency=clause.frequency,
            progressive=(
                predicate is not None
                and self._uses_full_extent_progressive(clause, predicate)
            ),
        )

    def _render_post_verbal_clause(
        self,
        clause: CanonicalClause,
        subject: str,
        complement: str | None,
        predicate_gloss: str,
        *,
        predicate: _PredicateReading | None,
    ) -> str:
        """Realize the inner tail as nested semantic scope.

        The source order is resultative < potential < subjunctive.  English
        moves those operators around the lexical action, so this routine
        builds the inner action first and applies each outer scope in turn.
        """

        tail = clause.post_verbal_scope
        bare_clause = replace(clause, post_verbal_scope=PostVerbalScope())
        if clause.predicate_kind is not PredicateKind.ACTION:
            base = self._render_clause(
                bare_clause,
                subject,
                complement,
                predicate_gloss,
                predicate=predicate,
            )
            body = base.rstrip(".?!")
            if tail.resultative is not ResultativeMode.NONE:
                body = f"it ceases to be the case that {body}"
            if tail.potential is PotentialMode.AFFIRMATIVE:
                body = f"it is possible that {body}"
            elif tail.potential is PotentialMode.NEGATIVE:
                body = f"it is not possible that {body}"
            if tail.subjunctive is SubjunctiveMode.HYPOTHETICAL:
                body = f"it would be the case that {body}"
            elif tail.subjunctive is SubjunctiveMode.OPTATIVE:
                body = f"hopefully, {body}"
            elif tail.subjunctive is SubjunctiveMode.AVERSIVE:
                body = f"hopefully, it is not the case that {body}"
            elif tail.subjunctive is SubjunctiveMode.SUPPLICATIVE:
                body = f"may it be the case that {body}"
            return _capitalize(body) + (
                "?" if clause.interrogative else "."
            )

        verb = self._modal_infinitive(predicate_gloss, clause.modality)
        argument = complement if clause.object is not None else None
        if tail.resultative is ResultativeMode.CESSATIVE:
            first, *rest = verb.split(" ", 1)
            gerund = present_participle(first)
            if rest:
                gerund += " " + rest[0]
            verb = "stop"
            argument = " ".join(
                part for part in (gerund, argument) if part
            )

        if tail.subjunctive is SubjunctiveMode.HYPOTHETICAL:
            return self._hypothetical_action_sentence(
                subject,
                verb,
                argument,
                clause,
            )
        if tail.subjunctive is SubjunctiveMode.SUPPLICATIVE:
            infinitive = " ".join(
                part for part in (verb, argument) if part
            )
            if tail.potential is PotentialMode.AFFIRMATIVE:
                infinitive = "be able to " + infinitive
            elif tail.potential is PotentialMode.NEGATIVE:
                infinitive = "be unable to " + infinitive
            return _capitalize(f"may {subject} {infinitive}.")

        inner = self._potential_action_sentence(
            subject,
            verb,
            argument,
            bare_clause,
            potential=tail.potential,
        )
        if tail.subjunctive is SubjunctiveMode.OPTATIVE:
            return "Hopefully, " + inner
        if tail.subjunctive is SubjunctiveMode.AVERSIVE:
            body = inner.rstrip(".?!")
            return f"Hopefully, it is not the case that {body}."
        return inner

    def _potential_action_sentence(
        self,
        subject: str,
        verb: str,
        object_text: str | None,
        clause: CanonicalClause,
        *,
        potential: PotentialMode,
    ) -> str:
        if potential is PotentialMode.NONE:
            return self._action_sentence(
                subject,
                verb,
                object_text,
                tense=clause.tense,
                polarity=clause.polarity,
                modality=Modality.NONE,
                interrogative=clause.interrogative,
                wh_role=clause.wh_role,
                wh_word=self._clause_wh_word(clause),
                temporal_aspect=clause.temporal_aspect,
                frequency=clause.frequency,
            )
        infinitive = " ".join(
            part for part in (verb, object_text) if part
        )
        if clause.polarity is Polarity.NEGATIVE:
            infinitive = "not " + infinitive
        if clause.tense is Tense.FUTURE:
            auxiliary = (
                "will be able to"
                if potential is PotentialMode.AFFIRMATIVE
                else "will be unable to"
            )
        elif clause.tense is Tense.PAST:
            auxiliary = (
                "could"
                if potential is PotentialMode.AFFIRMATIVE
                else "could not"
            )
        else:
            auxiliary = (
                "can"
                if potential is PotentialMode.AFFIRMATIVE
                else "cannot"
            )
        if clause.interrogative:
            return _capitalize(f"{auxiliary} {subject} {infinitive}?")
        return _capitalize(f"{subject} {auxiliary} {infinitive}.")

    def _hypothetical_action_sentence(
        self,
        subject: str,
        verb: str,
        object_text: str | None,
        clause: CanonicalClause,
    ) -> str:
        infinitive = " ".join(
            part for part in (verb, object_text) if part
        )
        potential = clause.post_verbal_scope.potential
        if potential is PotentialMode.AFFIRMATIVE:
            auxiliary = "could"
        elif potential is PotentialMode.NEGATIVE:
            auxiliary = "would be unable to"
        else:
            auxiliary = "would"
        if clause.polarity is Polarity.NEGATIVE:
            infinitive = "not " + infinitive
        punctuation = "?" if clause.interrogative else "."
        return _capitalize(
            f"{auxiliary} {subject} {infinitive}{punctuation}"
            if clause.interrogative
            else f"{subject} {auxiliary} {infinitive}{punctuation}"
        )

    def _render_productive_verbalization(
        self,
        clause: CanonicalClause,
        subject: str,
        complement: str | None,
        predicate: _PredicateReading,
    ) -> str:
        """Render transparent controlled English for an unlexicalized mode."""

        verb, object_text = self._productive_verbalization_terms(
            predicate,
            complement,
            clause.object or clause.complement,
        )
        return self._action_sentence(
            subject,
            verb,
            object_text,
            tense=clause.tense,
            polarity=clause.polarity,
            modality=clause.modality,
            interrogative=clause.interrogative,
            wh_role=clause.wh_role,
            wh_word=self._clause_wh_word(clause),
            temporal_aspect=clause.temporal_aspect,
            frequency=clause.frequency,
        )

    def _productive_verbalization_terms(
        self,
        predicate: _PredicateReading,
        complement: str | None,
        external_nominal: Nominal | None = None,
    ) -> tuple[str, str | None]:
        """Expose a productive source noun in every English realization."""

        derivation = predicate.verbal_derivation
        source_gloss = predicate.verbalization_source_gloss
        if derivation is None or source_gloss is None:
            raise ValueError(
                "Productive verbalization lacks derivational provenance"
            )
        source = source_gloss.strip()
        if not source.casefold().startswith(
            ("a ", "an ", "the ", "some ", "this ", "that ")
        ):
            source = f"{_indefinite_article(source)} {source}"
        mode = derivation.mode
        verb = VERBALIZATION_MODE_BY_MODE[mode].english_head
        source_is_external = self._same_verbalization_nominal(
            derivation.source,
            external_nominal,
        )
        object_text: str | None
        if mode is VerbalizationMode.PERFORMANCE:
            object_text = (
                complement
                if complement and source_is_external
                else f"{source} on {complement}"
                if complement
                else source
            )
        elif mode is VerbalizationMode.INTERACTION:
            object_text = (
                f"{source} to {complement}"
                if complement
                else source
            )
        elif mode in {
            VerbalizationMode.SEMBLANCE,
            VerbalizationMode.SUBJECTIVE,
            VerbalizationMode.VISUAL,
            VerbalizationMode.AUDITORY,
            VerbalizationMode.OLFACTORY,
            VerbalizationMode.TACTILE,
            VerbalizationMode.GUSTATORY,
        }:
            object_text = source
        elif mode is VerbalizationMode.TRANSFORMATIVE:
            object_text = (
                f"{complement} into {source}"
                if complement
                else f"into {source}"
            )
        elif mode is VerbalizationMode.GENERATIVE:
            object_text = (
                complement
                if complement and source_is_external
                else f"{complement} as {source}"
                if complement
                else source
            )
        elif mode is VerbalizationMode.PRIVATIVE:
            bare = self._remove_article(source)
            words = bare.split()
            if words:
                words[-1] = plural_noun(words[-1])
            removed = " ".join(words)
            object_text = (
                f"{removed} from {complement}"
                if complement
                else removed
            )
        else:
            raise ValueError(
                f"Unsupported verbalization mode: {mode.value}"
            )
        return verb, object_text

    @staticmethod
    def _same_verbalization_nominal(
        source: Nominal,
        external: Nominal | None,
    ) -> bool:
        if external is None:
            return False
        if source.lexeme_id and external.lexeme_id:
            return source.lexeme_id == external.lexeme_id
        return source.surface.casefold() == external.surface.casefold()

    def _causative_action_sentence(
        self,
        causee: str,
        causer: str,
        verb: str,
        object_text: str | None,
        *,
        voice: CausativeVoice,
        tense: Tense,
        polarity: Polarity,
        interrogative: bool,
        temporal_aspect: TemporalAspect,
        frequency: EventFrequency | None,
    ) -> str:
        """Render English while retaining Asaxi causee/causer semantics."""

        lexical_suffix = f" {object_text}" if object_text else ""
        if voice is CausativeVoice.PERMISSIVE:
            matrix_verb = "allow"
            matrix_object = f"{causee} to {verb}{lexical_suffix}"
        elif voice is CausativeVoice.COERCIVE:
            matrix_verb = "force"
            matrix_object = f"{causee} to {verb}{lexical_suffix}"
        elif voice is CausativeVoice.PROHIBITIVE:
            first, *rest = verb.split(" ", 1)
            gerund = present_participle(first)
            if rest:
                gerund += " " + rest[0]
            matrix_verb = "prohibit"
            matrix_object = (
                f"{causee} from {gerund}{lexical_suffix}"
            )
        else:
            raise ValueError(f"Unsupported causative voice: {voice.value}")
        return self._action_sentence(
            causer,
            matrix_verb,
            matrix_object,
            tense=tense,
            polarity=polarity,
            modality=Modality.NONE,
            interrogative=interrogative,
            wh_role=None,
            temporal_aspect=temporal_aspect,
            frequency=frequency,
        )

    @staticmethod
    def _directive_sentence(
        verb: str,
        object_text: str | None,
        *,
        directive: Directive,
        vocative_text: str | None,
        oblique_texts: Sequence[str] = (),
    ) -> str:
        argument_parts = tuple(
            part for part in (object_text, *oblique_texts) if part
        )
        argument = (
            " " + " ".join(argument_parts) if argument_parts else ""
        )
        first, *rest = verb.split(" ", 1)
        gerund = present_participle(first)
        if rest:
            gerund += " " + rest[0]
        terminal = "!"
        if directive.kind is DirectiveKind.COMMAND:
            body = f"{verb}{argument}"
        elif directive.kind is DirectiveKind.PROHIBITION:
            body = f"do not {verb}{argument}"
        elif directive.kind is DirectiveKind.ABSOLUTE_PROHIBITION:
            body = f"{gerund}{argument} is strictly forbidden"
        elif directive.kind is DirectiveKind.REQUEST:
            body = f"please {verb}{argument}"
        elif directive.kind is DirectiveKind.INSTRUCTION:
            body = f"please {verb}{argument}"
        elif directive.kind is DirectiveKind.POLITE_PROHIBITION:
            body = f"please do not {verb}{argument}"
        elif directive.kind is DirectiveKind.CESSATION:
            body = f"stop {gerund}{argument}"
        elif directive.kind is DirectiveKind.CONTINUATION:
            body = f"continue {gerund}{argument}"
        elif directive.kind is DirectiveKind.SWITCH:
            body = f"{verb}{argument} now"
        elif directive.kind is DirectiveKind.HORTATIVE:
            body = f"let's {verb}{argument}"
        elif directive.kind is DirectiveKind.POLITE_HORTATIVE:
            body = f"shall we {verb}{argument}"
            terminal = "?"
        else:
            raise ValueError(
                f"Unsupported directive kind: {directive.kind.value}"
            )
        prefix = f"{vocative_text}, " if vocative_text else ""
        return _capitalize(prefix + body + terminal)

    def _action_sentence(
        self,
        subject: str,
        verb: str,
        object_text: str | None,
        *,
        tense: Tense,
        polarity: Polarity,
        modality: Modality,
        interrogative: bool,
        wh_role: WhRole | None,
        wh_word: str | None = None,
        temporal_aspect: TemporalAspect = TemporalAspect.NONE,
        frequency: EventFrequency | None = None,
        oblique_texts: Sequence[str] = (),
        progressive: bool = False,
    ) -> str:
        object_suffix = (
            f" {object_text}"
            if object_text and wh_role is not WhRole.OBJECT
            else ""
        )
        oblique_suffix = "".join(
            f" {text}" for text in oblique_texts if text
        )
        argument_suffix = object_suffix + oblique_suffix
        middle_frequency = (
            MID_CLAUSE_FREQUENCY.get(frequency.kind)
            if frequency is not None
            else None
        )
        final_frequency = (
            FINAL_FREQUENCY.get(frequency.kind)
            if frequency is not None
            else None
        )
        event_suffix = (
            f" {final_frequency}" if final_frequency else ""
        )
        if progressive:
            return self._progressive_action_sentence(
                subject,
                verb,
                argument_suffix,
                tense=tense,
                polarity=polarity,
                middle_frequency=middle_frequency,
                event_suffix=event_suffix,
                interrogative=interrogative,
                wh_role=wh_role,
                wh_word=wh_word,
            )
        if temporal_aspect is not TemporalAspect.NONE:
            return self._aspectual_action_sentence(
                subject,
                verb,
                argument_suffix,
                tense=tense,
                polarity=polarity,
                modality=modality,
                temporal_aspect=temporal_aspect,
                middle_frequency=middle_frequency,
                event_suffix=event_suffix,
                interrogative=interrogative,
                wh_role=wh_role,
                wh_word=wh_word,
            )
        if wh_role is WhRole.SUBJECT:
            wh = _capitalize(wh_word or "who")
            predicate = self._finite_predicate(
                verb,
                _PredicateReading(
                    surface="",
                    lemma="",
                    kind=PredicateKind.ACTION,
                    english_glosses=(verb,),
                    tense=tense,
                    polarity=polarity,
                    modality=modality,
                ),
                wh.casefold(),
                frequency_word=middle_frequency,
            )
            return (
                f"{wh} {predicate}{argument_suffix}{event_suffix}?"
            )
        if wh_role is not None:
            wh = _capitalize(wh_word) if wh_word else {
                WhRole.OBJECT: "What",
                WhRole.COMPLEMENT: "What",
                WhRole.LOCATION: "Where",
                WhRole.TIME: "When",
                WhRole.REASON: "Why",
                WhRole.MANNER: "How",
            }[wh_role]
            auxiliary = self._question_auxiliary(subject, tense)
            modal_verb = self._modal_infinitive(verb, modality)
            if middle_frequency:
                modal_verb = middle_frequency + " " + modal_verb
            return (
                f"{wh} {auxiliary.casefold()} {subject} "
                f"{'not ' if polarity is Polarity.NEGATIVE else ''}"
                f"{modal_verb}{object_suffix}{oblique_suffix}"
                f"{event_suffix}?"
            )
        if interrogative:
            auxiliary = self._question_auxiliary(subject, tense)
            modal_verb = self._modal_infinitive(verb, modality)
            if middle_frequency:
                modal_verb = middle_frequency + " " + modal_verb
            return (
                f"{auxiliary} {subject} "
                f"{'not ' if polarity is Polarity.NEGATIVE else ''}"
                f"{modal_verb}{argument_suffix}{event_suffix}?"
            )
        predicate = self._finite_predicate(
            verb,
            _PredicateReading(
                surface="",
                lemma="",
                kind=PredicateKind.ACTION,
                english_glosses=(verb,),
                tense=tense,
                polarity=polarity,
                modality=modality,
            ),
            subject,
            frequency_word=middle_frequency,
        )
        return _capitalize(
            f"{subject} {predicate}{argument_suffix}{event_suffix}."
        )

    def _progressive_action_sentence(
        self,
        subject: str,
        verb: str,
        argument_suffix: str,
        *,
        tense: Tense,
        polarity: Polarity,
        middle_frequency: str | None,
        event_suffix: str,
        interrogative: bool,
        wh_role: WhRole | None,
        wh_word: str | None,
    ) -> str:
        """Render a durative event covering an explicitly complete span."""

        first, *rest = verb.split(" ", 1)
        lexical = present_participle(first)
        if rest:
            lexical += " " + rest[0]
        if middle_frequency:
            lexical = middle_frequency + " " + lexical
        predicate = (
            ("not " if polarity is Polarity.NEGATIVE else "")
            + lexical
            + argument_suffix
            + event_suffix
        )
        if tense is Tense.FUTURE:
            auxiliary = "will"
            predicate = (
                ("not " if polarity is Polarity.NEGATIVE else "")
                + "be "
                + lexical
                + argument_suffix
                + event_suffix
            )
        elif tense is Tense.PAST:
            normalized_subject = _subject_for_agreement(subject)
            auxiliary = (
                "were"
                if normalized_subject in {"you", "we", "they"}
                or " and " in normalized_subject
                else "was"
            )
        else:
            auxiliary = self._present_be(subject)
        if wh_role is WhRole.SUBJECT:
            wh = _capitalize(wh_word or "who")
            return f"{wh} {auxiliary} {predicate}?"
        if wh_role is not None:
            wh = _capitalize(wh_word) if wh_word else {
                WhRole.OBJECT: "What",
                WhRole.COMPLEMENT: "What",
                WhRole.LOCATION: "Where",
                WhRole.TIME: "When",
                WhRole.REASON: "Why",
                WhRole.MANNER: "How",
            }[wh_role]
            return f"{wh} {auxiliary} {subject} {predicate}?"
        if interrogative:
            return _capitalize(f"{auxiliary} {subject} {predicate}?")
        return _capitalize(f"{subject} {auxiliary} {predicate}.")

    def _aspectual_action_sentence(
        self,
        subject: str,
        verb: str,
        argument_suffix: str,
        *,
        tense: Tense,
        polarity: Polarity,
        modality: Modality,
        temporal_aspect: TemporalAspect,
        middle_frequency: str | None,
        event_suffix: str,
        interrogative: bool,
        wh_role: WhRole | None,
        wh_word: str | None = None,
    ) -> str:
        base = self._modal_infinitive(verb, modality)
        first, *rest = base.split(" ", 1)
        tail = " " + rest[0] if rest else ""
        perfect = (
            temporal_aspect is TemporalAspect.RETROSPECTIVE
            or temporal_aspect is TemporalAspect.PROSPECTIVE
            or (
                temporal_aspect is TemporalAspect.CURRENT
                and tense is Tense.PAST
            )
        )
        if perfect:
            auxiliary = self._present_have(subject)
            lexical = past_participle(first) + tail
            if temporal_aspect is TemporalAspect.PROSPECTIVE:
                marker_before = "not "
                marker_after = " yet"
            else:
                marker_before = (
                    "not already "
                    if polarity is Polarity.NEGATIVE
                    else "already "
                )
                marker_after = ""
        else:
            auxiliary = self._present_be(subject)
            lexical = present_participle(first) + tail
            marker_before = (
                "not "
                if polarity is Polarity.NEGATIVE
                else ""
            )
            if temporal_aspect is TemporalAspect.PERSISTIVE:
                marker_before += "still "
                marker_after = ""
            else:
                marker_after = " now"
        if middle_frequency:
            marker_before += middle_frequency + " "

        predicate = (
            f"{marker_before}{lexical}{argument_suffix}"
            f"{marker_after}{event_suffix}"
        )
        if wh_role is WhRole.SUBJECT:
            wh = _capitalize(wh_word or "who")
            subject_auxiliary = (
                "has" if perfect else "is"
            )
            return f"{wh} {subject_auxiliary} {predicate}?"
        if wh_role is not None:
            wh = _capitalize(wh_word) if wh_word else {
                WhRole.OBJECT: "What",
                WhRole.COMPLEMENT: "What",
                WhRole.LOCATION: "Where",
                WhRole.TIME: "When",
                WhRole.REASON: "Why",
                WhRole.MANNER: "How",
            }[wh_role]
            return (
                f"{wh} {auxiliary} {subject} {predicate}?"
            )
        if interrogative:
            return _capitalize(
                f"{auxiliary} {subject} {predicate}?"
            )
        return _capitalize(
            f"{subject} {auxiliary} {predicate}."
        )

    @classmethod
    def _present_be(cls, subject: str) -> str:
        normalized = _subject_for_agreement(subject)
        if normalized == "i":
            return "am"
        if normalized == "you" or cls._plural_subject(subject):
            return "are"
        return "is"

    @classmethod
    def _present_have(cls, subject: str) -> str:
        return "have" if cls._plural_subject(subject) else "has"

    @staticmethod
    def _plural_subject(subject: str) -> bool:
        normalized = _subject_for_agreement(subject)
        return normalized in {
            "i",
            "you",
            "we",
            "they",
        } or " and " in normalized

    def _finite_predicate(
        self,
        verb: str,
        predicate: _PredicateReading,
        subject: str,
        *,
        frequency_word: str | None = None,
    ) -> str:
        plural = self._plural_subject(subject)
        if predicate.modality is Modality.DESIDERATIVE:
            base = "want to " + verb
        elif predicate.modality is Modality.CONATIVE:
            base = "try to " + verb
        else:
            base = verb
        frequency_prefix = (
            frequency_word + " " if frequency_word else ""
        )
        if predicate.tense is Tense.FUTURE:
            return (
                "will "
                + ("not " if predicate.polarity is Polarity.NEGATIVE else "")
                + frequency_prefix
                + base
            )
        if predicate.tense is Tense.PAST:
            if predicate.polarity is Polarity.NEGATIVE:
                return "did not " + frequency_prefix + base
            first, *rest = base.split(" ", 1)
            inflected = past_tense(first)
            finite = (
                inflected
                if not rest
                else inflected + " " + rest[0]
            )
            return frequency_prefix + finite
        if predicate.polarity is Polarity.NEGATIVE:
            return (
                ("do" if plural else "does")
                + " not "
                + frequency_prefix
                + base
            )
        first, *rest = base.split(" ", 1)
        inflected = first if plural else present_third_person(first)
        finite = inflected if not rest else inflected + " " + rest[0]
        return frequency_prefix + finite

    @staticmethod
    def _modal_infinitive(verb: str, modality: Modality) -> str:
        if modality is Modality.DESIDERATIVE:
            return "want to " + verb
        if modality is Modality.CONATIVE:
            return "try to " + verb
        return verb

    def _question_auxiliary(self, subject: str, tense: Tense) -> str:
        if tense is Tense.FUTURE:
            return "Will"
        if tense is Tense.PAST:
            return "Did"
        return "Do" if self._plural_subject(subject) else "Does"

    @staticmethod
    def _existence_statement(
        subject: str,
        tense: Tense,
        polarity: Polarity,
    ) -> str:
        if tense is Tense.PAST:
            copula = "was"
        elif tense is Tense.FUTURE:
            return _capitalize(
                "there will "
                + ("not " if polarity is Polarity.NEGATIVE else "")
                + f"be {subject}"
            )
        else:
            copula = "is"
        if polarity is Polarity.NEGATIVE:
            copula += " not"
        return _capitalize(f"there {copula} {subject}")

    @staticmethod
    def _nominal_is_plural(nominal: Nominal | None) -> bool:
        return bool(
            nominal is not None
            and (
                nominal.number == "plural"
                or len(nominal.coordinated) > 1
            )
        )

    @staticmethod
    def _english_np_is_determined(text: str) -> bool:
        """Recognize articles and possessives already realized in English."""

        normalized = text.casefold()
        return normalized == "one" or normalized.startswith(
            (
                "a ",
                "an ",
                "the ",
                "this ",
                "that ",
                "one ",
                "my ",
                "your ",
                "his ",
                "her ",
                "its ",
                "our ",
                "their ",
            )
        )

    @staticmethod
    def _copular_sentence(
        subject: str,
        complement: str,
        *,
        tense: Tense,
        polarity: Polarity,
        interrogative: bool,
        wh_role: WhRole | None,
        wh_word: str | None = None,
        subject_plural: bool = False,
    ) -> str:
        if wh_role is not None:
            wh = _capitalize(wh_word) if wh_word else {
                WhRole.SUBJECT: "Who",
                WhRole.OBJECT: "What",
                WhRole.COMPLEMENT: "What",
                WhRole.LOCATION: "Where",
                WhRole.TIME: "When",
                WhRole.REASON: "Why",
                WhRole.MANNER: "How",
            }[wh_role]
            if wh_role is WhRole.SUBJECT:
                if tense is Tense.FUTURE:
                    return (
                        f"{wh} will "
                        f"{'not ' if polarity is Polarity.NEGATIVE else ''}"
                        f"be {complement}?"
                    )
                copula = "was" if tense is Tense.PAST else "is"
                negative = (
                    " not" if polarity is Polarity.NEGATIVE else ""
                )
                return f"{wh} {copula}{negative} {complement}?"
            if tense is Tense.FUTURE:
                return (
                    f"{wh} will {subject} "
                    f"{'not ' if polarity is Polarity.NEGATIVE else ''}"
                    "be?"
                )
            copula = (
                "were"
                if tense is Tense.PAST
                and (
                    subject.casefold() in {"you", "we", "they"}
                    or subject_plural
                )
                else "was"
                if tense is Tense.PAST
                else "are"
                if subject.casefold() in {"you", "we", "they"}
                or " and " in subject.casefold()
                or subject_plural
                else "am"
                if subject.casefold() == "i"
                else "is"
            )
            return (
                f"{wh} {copula} "
                f"{'not ' if polarity is Polarity.NEGATIVE else ''}"
                f"{subject}?"
            )
        if tense is Tense.PAST:
            copula = (
                "were"
                if subject.casefold() in {"you", "we", "they"}
                or subject_plural
                else "was"
            )
        elif tense is Tense.FUTURE:
            if interrogative:
                return (
                    f"Will {subject} "
                    f"{'not ' if polarity is Polarity.NEGATIVE else ''}"
                    f"be {complement}?"
                )
            return _capitalize(
                f"{subject} will "
                f"{'not ' if polarity is Polarity.NEGATIVE else ''}"
                f"be {complement}."
            )
        else:
            copula = (
                "are"
                if subject.casefold() in {"you", "we", "they"}
                or " and " in subject.casefold()
                or subject_plural
                else "am"
                if subject.casefold() == "i"
                else "is"
            )
        if interrogative:
            return (
                f"{_capitalize(copula)} {subject} "
                f"{'not ' if polarity is Polarity.NEGATIVE else ''}"
                f"{complement}?"
            )
        negative = " not" if polarity is Polarity.NEGATIVE else ""
        return _capitalize(f"{subject} {copula}{negative} {complement}.")

    def _relative_subject_english(
        self,
        gloss: str,
        predicate: _PredicateReading,
    ) -> str:
        finite = self._finite_predicate(gloss, predicate, "who")
        return f"that {finite}"

    @staticmethod
    def _linked_discourse_state(
        reading: _ClauseReading,
        fallback: DiscourseState | None,
    ) -> DiscourseState | None:
        """Expose an overt antecedent to a following pro-drop clause."""

        if (
            reading.clause.subject is None
            or reading.subject_english is None
        ):
            return fallback
        return DiscourseState(
            topic=DiscourseReferent(
                nominal=reading.clause.subject,
                english_text=reading.subject_english,
            )
        )

    @staticmethod
    def _embedded_clause_text(
        reading: _ClauseReading,
        text: str,
    ) -> str:
        """Lower ordinary clause initials without damaging I or names."""

        if not text or text.startswith("I "):
            return text
        subject = reading.clause.subject
        if subject is not None and subject.surface.isupper():
            return text
        return text[:1].lower() + text[1:]

    def _coordinate(
        self,
        left: Sequence[_ClauseReading],
        right: Sequence[_ClauseReading],
        connector_token: Any,
        all_tokens: Sequence[Any],
    ) -> list[TranslationAlternative]:
        connector = CONNECTORS[connector_token.normalized]
        output: list[TranslationAlternative] = []
        for first, second in itertools.product(left, right):
            first_text = _strip_terminal_punctuation(first.output_text)
            second_text = second.output_text
            if connector in PREFIXED_CONNECTORS:
                embedded_first = self._embedded_clause_text(
                    first,
                    first_text,
                )
                embedded_second = self._embedded_clause_text(
                    second,
                    second_text,
                )
                combined_text = (
                    f"{_capitalize(CONNECTOR_ENGLISH[connector])} "
                    f"{embedded_first}, {embedded_second}"
                )
            elif connector in COMMA_INFIX_CONNECTORS:
                embedded_second = self._embedded_clause_text(
                    second,
                    second_text,
                )
                combined_text = (
                    f"{first_text}, {CONNECTOR_ENGLISH[connector]} "
                    f"{embedded_second}"
                )
            else:
                embedded_second = self._embedded_clause_text(
                    second,
                    second_text,
                )
                combined_text = (
                    f"{first_text} {CONNECTOR_ENGLISH[connector]} "
                    f"{embedded_second}"
                )
            clause = CanonicalClause(
                **{
                    **first.clause.__dict__,
                    "connector": connector,
                    "coordinated_clause": second.clause,
                }
            )
            roles = {
                **dict(first.roles),
                **dict(second.roles),
                connector_token.index: "clause-connector",
            }
            reading = _ClauseReading(
                clause=clause,
                output_text=combined_text,
                roles=tuple(sorted(roles.items())),
                predicate=first.predicate,
                predicate_index=first.predicate_index,
                subject_english=first.subject_english,
                assumptions=(
                    *first.assumptions,
                    *second.assumptions,
                ),
                ambiguities=(
                    *first.ambiguities,
                    *second.ambiguities,
                ),
                rule_trace=(
                    CONNECTOR_RULES[connector],
                    *(
                        ("clause.linked-subject-inheritance",)
                        if second.clause.discourse_subject
                        else ()
                    ),
                    *first.rule_trace,
                    *second.rule_trace,
                ),
            )
            output.append(self._to_alternative(reading, all_tokens))
        return output[:MAX_CLAUSE_ALTERNATIVES]

    def _to_alternative(
        self,
        reading: _ClauseReading,
        tokens: Sequence[Any],
    ) -> TranslationAlternative:
        roles = dict(reading.roles)
        rendered: list[TranslationToken] = []
        for token in tokens:
            morphology = (
                self.morphology.analyze(token.normalized)
                if token.kind == "word"
                else ()
            )
            deictic_parts = _split_deictic_surface(token.normalized)
            if deictic_parts is not None:
                prefix, head, distance = deictic_parts
                head_analyses = self.morphology.analyze(head)
                morphology = (
                    tuple(
                        replace(
                            analysis,
                            surface=token.normalized,
                            features=(
                                *analysis.features,
                                ("deixis", distance.value),
                            ),
                            morphemes=(
                                f"{prefix}-",
                                *analysis.morphemes,
                            ),
                            rule_trace=(
                                "noun.deictic-prefix",
                                f"noun.deixis.{distance.value}",
                                *analysis.rule_trace,
                            ),
                        )
                        for analysis in head_analyses
                    )
                    if head_analyses
                    else (
                        MorphologicalAnalysis(
                            surface=token.normalized,
                            lemma=head,
                            category="deictic-nominal",
                            features=(("deixis", distance.value),),
                            morphemes=(f"{prefix}-", head),
                            rule_trace=(
                                "noun.deictic-prefix",
                                f"noun.deixis.{distance.value}",
                            ),
                            confidence="attested-rule",
                        ),
                    )
                )
            fused_determiner = FUSED_SUBJECT_DETERMINERS.get(
                token.normalized
            )
            if fused_determiner is not None:
                morphology = (
                    MorphologicalAnalysis(
                        surface=token.normalized,
                        lemma=f"to+{fused_determiner}",
                        category="fused-subject-determiner",
                        features=(
                            ("register", Register.OBJECTIVE.value),
                            (
                                "determiner_kind",
                                DETERMINERS[fused_determiner],
                            ),
                            (
                                "noun_class",
                                DETERMINER_NOUN_CLASSES[
                                    fused_determiner
                                ]
                                or "neutral",
                            ),
                        ),
                        morphemes=("to", fused_determiner),
                        rule_trace=(
                            *_fused_subject_rules(token.normalized),
                            "noun.determiner.inventory",
                        ),
                        confidence="attested-rule",
                    ),
                )
            if (
                reading.predicate is not None
                and reading.predicate_index == token.index
            ):
                predicate = reading.predicate
                morphology = (
                    MorphologicalAnalysis(
                        surface=predicate.surface,
                        lemma=predicate.lemma,
                        category=(
                            predicate.lexeme.category
                            if predicate.lexeme
                            else "predicate"
                        ),
                        features=(
                            ("tense", predicate.tense.value),
                            ("polarity", predicate.polarity.value),
                            ("modality", predicate.modality.value),
                            ("predicate_kind", predicate.kind.value),
                            *(
                                (
                                    (
                                        "causative_voice",
                                        predicate.causative_voice.value,
                                    ),
                                )
                                if predicate.causative_voice is not None
                                else ()
                            ),
                            *(
                                (
                                    (
                                        "directive_kind",
                                        predicate.directive_form.kind.value,
                                    ),
                                    (
                                        "directive_placement",
                                        predicate.directive_form
                                        .placement.value,
                                    ),
                                )
                                if predicate.directive_form is not None
                                else ()
                            ),
                            *(
                                (
                                    (
                                        "verbalization_mode",
                                        predicate.verbal_derivation.mode.value,
                                    ),
                                    (
                                        "verbalization_source_lexeme",
                                        predicate.verbal_derivation.source
                                        .lexeme_id
                                        or "",
                                    ),
                                    (
                                        "lexical_aspect",
                                        predicate.verbal_derivation
                                        .aspectual_class,
                                    ),
                                )
                                if predicate.verbal_derivation is not None
                                else ()
                            ),
                        ),
                        morphemes=predicate.morphemes,
                        rule_trace=predicate.rule_trace,
                        confidence="rule-confirmed",
                        lexeme_id=(
                            predicate.lexeme.identifier
                            if predicate.lexeme
                            else None
                        ),
                    ),
                )
            role = roles.get(token.index)
            if token.kind == "punctuation":
                role = role or "punctuation"
            rendered.append(
                TranslationToken(
                    index=token.index,
                    surface=token.surface,
                    normalized=token.normalized,
                    start=token.start,
                    end=token.end,
                    kind=token.kind,
                    role=role,
                    morphology=morphology,
                )
            )
        return TranslationAlternative(
            identifier="",
            output_text=reading.output_text,
            canonical_clause=reading.clause,
            tokens=tuple(rendered),
            assumptions=(
                *reading.assumptions,
                *(
                    (
                        TranslationAssumption(
                            code=(
                                "CIRCUMSTANTIAL_INFLECTION_PRODUCTIVITY_UNRESOLVED"
                            ),
                            message=(
                                "This tense/polarity stack on a bare "
                                "relational particle is a reviewable "
                                "productive inference. The notes directly "
                                "attest the positive bases and future-negative "
                                "panáni, but not the complete matrix."
                            ),
                        ),
                    )
                    if (
                        "clause.validity-productivity-unresolved"
                        in reading.rule_trace
                    )
                    else ()
                ),
            ),
            ambiguities=reading.ambiguities,
            rule_trace=reading.rule_trace,
            subject_text=reading.subject_english,
        )
