"""Typed productive morphology beyond the first translation slice.

This module keeps generation and analysis close together.  It does not extend
the unrestricted syntax parser: callers must provide lexical identity and
class information that the authoritative database already knows.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import itertools
from typing import Any, Iterable

from .morphology import GeneratedForm, pluralize_nominal


ASAXI_VOWELS = frozenset("aeioùýáèůåăěëỏő")
SYLLABIC_NASALS = ("mm", "nn")


class NounClass(str, Enum):
    WARM = "warm"
    COLD = "cold"


class Definiteness(str, Enum):
    BARE = "bare"
    INDEFINITE = "indefinite"
    DEFINITE = "definite"
    SPECIFIC_INDEFINITE = "specific-indefinite"
    # Compatibility alias for the pre-0.5 label. The detailed grammar note
    # identifies ponă/ponýj as specific indefinites, not demonstratives.
    DEMONSTRATIVE = "specific-indefinite"


class Number(str, Enum):
    SINGULAR = "singular"
    PLURAL = "plural"


class VerbTense(str, Enum):
    NONPAST = "nonpast"
    PAST = "past"
    FUTURE = "future"
    IMMEDIATE_PAST = "immediate-past"
    IMMEDIATE_FUTURE = "immediate-future"
    FUTURE_PERFECT = "future-perfect"
    PLUPERFECT = "pluperfect"
    PAST_FUTURE = "past-future"
    HABITUAL_PAST = "habitual-past"
    MYTHIC_PAST = "mythic-past"
    DISTANT_FUTURE = "distant-future"
    SUBJECTIVE_PAST = "subjective-past"
    SUBJECTIVE_PRESENT = "subjective-present"


class VerbPolarity(str, Enum):
    POSITIVE = "positive"
    NEGATIVE = "negative"
    EMPHATIC = "emphatic"
    NEGATIVE_EMPHATIC = "negative-emphatic"


class VerbMood(str, Enum):
    NONE = "none"
    DESIDERATIVE = "desiderative"
    CONATIVE = "conative"


class VerbVoice(str, Enum):
    ACTIVE = "active"
    PERMISSIVE = "permissive"
    COERCIVE = "coercive"


class VerbAspect(str, Enum):
    NONE = "none"
    INCEPTIVE = "inceptive"
    COMPLETIVE = "completive"
    ITERATIVE = "iterative"
    SEMELFACTIVE = "semelfactive"


class VerbRootKind(str, Enum):
    ROOT = "root"
    DERIVED = "derived"


CLASS_FORMS = {
    NounClass.WARM: {
        "definite": "onă",
        "specific-indefinite": "ponă",
        "adjective": "nă",
        "adjective_reduced": "na",
        "degree": "nă",
    },
    NounClass.COLD: {
        "definite": "onýj",
        "specific-indefinite": "ponýj",
        "adjective": "nýj",
        "adjective_reduced": "ný",
        "degree": "nýj",
    },
}

RELATIONAL_PARTICLES = (
    "måmå",
    "izo",
    "dhè",
    "ăni",
    "to",
    "sè",
    "bă",
    "zá",
    "då",
    "ni",
    "ă",
)
LOCATIVE_PREFIXES = ("o", "no", "ko", "na", "hù", "pù")
REDUCIBLE_CLASS_SUFFIXES = ("båbå", "shá", "gă")

TENSE_PREFIXES = {
    VerbTense.NONPAST: "",
    VerbTense.PAST: "zè",
    VerbTense.FUTURE: "pa",
    VerbTense.IMMEDIATE_PAST: "ozè",
    VerbTense.IMMEDIATE_FUTURE: "opa",
    VerbTense.FUTURE_PERFECT: "pazè",
    VerbTense.PLUPERFECT: "hùzè",
    VerbTense.PAST_FUTURE: "hùpa",
    VerbTense.HABITUAL_PAST: "izozè",
    VerbTense.MYTHIC_PAST: "kozè",
    VerbTense.DISTANT_FUTURE: "kopa",
    VerbTense.SUBJECTIVE_PAST: "sỏ",
    VerbTense.SUBJECTIVE_PRESENT: "mi",
}
POLARITY_MARKERS = {
    VerbPolarity.POSITIVE: "",
    VerbPolarity.NEGATIVE: "ná",
    VerbPolarity.EMPHATIC: "xă",
    VerbPolarity.NEGATIVE_EMPHATIC: "náxă",
}
MOOD_PREFIXES = {
    VerbMood.NONE: "",
    VerbMood.DESIDERATIVE: "jå",
    VerbMood.CONATIVE: "xè",
}
VOICE_PREFIXES = {
    VerbVoice.ACTIVE: "",
    VerbVoice.PERMISSIVE: "băhè",
    VerbVoice.COERCIVE: "xăhè",
}
ASPECT_PREFIXES = {
    VerbAspect.NONE: "",
    VerbAspect.INCEPTIVE: "ni",
    VerbAspect.COMPLETIVE: "chå",
    VerbAspect.ITERATIVE: "na",
    VerbAspect.SEMELFACTIVE: "tå",
}

POST_VERBAL_INVENTORY = {
    "result": ("tomo'", "tomo"),
    "potential": ("ken", "ken.ná"),
    "subjunctive": ("xăxă", "dăxă", "pùxă", "xădăchỏxă"),
    "inquiry": ("kè",),
    "discourse": ("me", "ë", "aŕa", "ő"),
    "connector": ("dzè", "si", "sèni"),
}
POST_VERBAL_ORDER = tuple(POST_VERBAL_INVENTORY)

PREDICATIVE_NPCP = {
    "sè": "sèŕa",
    "då": "dåŕa",
    "izo": "izoŕa",
    "bă": "băŕa",
    "zá": "záŕa",
    "ni": "niŕa",
}


def _coerce_enum(value: object, enum_type: type[Enum]) -> Enum:
    if isinstance(value, enum_type):
        return value
    return enum_type(str(value))


def _native_surface(value: str) -> str:
    text = value.strip()
    if not text:
        raise ValueError("Morphological surface is empty")
    return text if text.isupper() else text.casefold()


def agreement_form(
    noun_class: NounClass | str,
    target: str,
) -> str:
    category = _coerce_enum(noun_class, NounClass)
    try:
        return CLASS_FORMS[category][target]
    except KeyError as error:
        raise ValueError(f"Unknown noun-class agreement target: {target}") from error


def select_determiner(
    definiteness: Definiteness | str,
    noun_class: NounClass | str | None = None,
) -> str:
    # Preserve the pre-0.5 serialized spelling while exposing the grammar's
    # more accurate specific-indefinite name in the typed API.
    if definiteness == "demonstrative":
        definiteness = Definiteness.SPECIFIC_INDEFINITE
    kind = _coerce_enum(definiteness, Definiteness)
    if kind is Definiteness.BARE:
        return ""
    if kind is Definiteness.INDEFINITE:
        return "anő"
    if noun_class is None:
        raise ValueError(f"{kind.value} determiner requires a noun class")
    target = (
        "definite"
        if kind is Definiteness.DEFINITE
        else "specific-indefinite"
    )
    return agreement_form(noun_class, target)


def reduce_class_suffix(
    lemma: str,
    *,
    reducible_suffix: str | None = None,
) -> GeneratedForm:
    """Remove a documented semantic class suffix before derivation.

    ``-kam`` is semantically ambiguous in the source grammar, so it is never
    removed without the caller explicitly selecting it.
    """

    word = _native_surface(lemma)
    suffix = (
        _native_surface(reducible_suffix)
        if reducible_suffix is not None
        else next(
            (
                candidate
                for candidate in REDUCIBLE_CLASS_SUFFIXES
                if word.endswith(candidate) and len(word) > len(candidate)
            ),
            "",
        )
    )
    if not suffix:
        return GeneratedForm(
            surface=word,
            lemma=word,
            features=(("class_suffix_reduced", "false"),),
            morphemes=(word,),
            rule_trace=("class-suffix.retain",),
        )
    if suffix == "kam" and reducible_suffix != "kam":
        raise ValueError("-kam reduction requires explicit lexical permission")
    if not word.endswith(suffix) or len(word) <= len(suffix):
        raise ValueError(
            f"{word!r} does not have reducible suffix {suffix!r}"
        )
    root = word[: -len(suffix)]
    return GeneratedForm(
        surface=root,
        lemma=word,
        features=(
            ("class_suffix_reduced", "true"),
            ("class_suffix", suffix),
        ),
        morphemes=(root, f"-{suffix}"),
        rule_trace=("class-suffix.reduce-before-derivation",),
    )


def derive_qualitative_adjective(
    lemma: str,
    *,
    noun_class: NounClass | str,
    final: bool = True,
    reducible_suffix: str | None = None,
) -> GeneratedForm:
    reduced = reduce_class_suffix(
        lemma,
        reducible_suffix=reducible_suffix,
    )
    root = reduced.surface
    trace = list(reduced.rule_trace)
    if root.endswith(SYLLABIC_NASALS):
        root = root[:-1]
        trace.append("adjective.resolve-syllabic-nasal")
    target = "adjective" if final else "adjective_reduced"
    suffix = agreement_form(noun_class, target)
    if root.endswith("n") and suffix.startswith("n"):
        suffix = suffix[1:]
        trace.append("adjective.coalesce-n-boundary")
    trace.append(
        "adjective.full-class-agreement"
        if final
        else "adjective.nonfinal-chain-reduction"
    )
    return GeneratedForm(
        surface=root + suffix,
        lemma=_native_surface(lemma),
        features=(
            ("noun_class", _coerce_enum(noun_class, NounClass).value),
            ("modifier_position", "final" if final else "nonfinal"),
        ),
        morphemes=(root, f"-{suffix}"),
        rule_trace=tuple(trace),
    )


def compose_adjective_chain(
    lemmas: Iterable[str],
    *,
    noun_class: NounClass | str,
    head: str,
    reducible_suffixes: Iterable[str | None] = (),
) -> GeneratedForm:
    roots = tuple(lemmas)
    if not roots:
        raise ValueError("Adjective chain requires at least one modifier")
    explicit_suffixes = tuple(reducible_suffixes)
    if explicit_suffixes and len(explicit_suffixes) != len(roots):
        raise ValueError("One reducible-suffix value is required per modifier")
    if not explicit_suffixes:
        explicit_suffixes = (None,) * len(roots)
    modifiers = tuple(
        derive_qualitative_adjective(
            lemma,
            noun_class=noun_class,
            final=index == len(roots) - 1,
            reducible_suffix=explicit_suffixes[index],
        )
        for index, lemma in enumerate(roots)
    )
    head_form = _native_surface(head)
    return GeneratedForm(
        surface=" ".join(
            tuple(modifier.surface for modifier in modifiers) + (head_form,)
        ),
        lemma=head_form,
        features=(
            ("noun_class", _coerce_enum(noun_class, NounClass).value),
            ("modifier_count", str(len(modifiers))),
        ),
        morphemes=tuple(
            morpheme
            for modifier in modifiers
            for morpheme in modifier.morphemes
        ) + (head_form,),
        rule_trace=tuple(
            trace
            for modifier in modifiers
            for trace in modifier.rule_trace
        ) + ("adjective-chain.before-head",),
    )


def _fuse_ga_payload(payload: str) -> tuple[str, str]:
    if payload.startswith("a"):
        return "g" + payload, "ga.coalesce-before-a"
    if payload.startswith("i"):
        return "gă" + payload[1:], "ga.coalesce-before-i"
    return "ga" + payload, "ga.default-fusion"


def compose_ga_compound(
    modifiers: Iterable[str],
    head: str,
) -> GeneratedForm:
    roots = tuple(_native_surface(value) for value in modifiers)
    if not roots:
        raise ValueError("ga compound requires at least one modifier")
    head_form = _native_surface(head)
    fused, rule = _fuse_ga_payload("".join(roots) + head_form)
    return GeneratedForm(
        surface=fused,
        lemma=head_form,
        features=(
            ("derivation", "ga-compound"),
            ("modifier_count", str(len(roots))),
        ),
        morphemes=("ga-",) + roots + (head_form,),
        rule_trace=(rule, "ga.single-prefix-modifier-stack"),
    )


@dataclass(frozen=True)
class NounPhraseSpec:
    head: str
    noun_class: NounClass
    number: Number = Number.SINGULAR
    definiteness: Definiteness = Definiteness.BARE
    relational_particles: tuple[str, ...] = ()
    ga_modifiers: tuple[str, ...] = ()
    locative_prefix: str | None = None
    locative_bridge: str = "w"

    def to_dict(self) -> dict[str, Any]:
        return {
            "head": self.head,
            "noun_class": self.noun_class.value,
            "number": self.number.value,
            "definiteness": self.definiteness.value,
            "relational_particles": list(self.relational_particles),
            "ga_modifiers": list(self.ga_modifiers),
            "locative_prefix": self.locative_prefix,
            "locative_bridge": self.locative_bridge,
        }


@dataclass(frozen=True)
class NounPhraseRealization:
    surface: str
    spec: NounPhraseSpec
    morphemes: tuple[str, ...]
    rule_trace: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "surface": self.surface,
            "spec": self.spec.to_dict(),
            "morphemes": list(self.morphemes),
            "rule_trace": list(self.rule_trace),
        }


def realize_noun_phrase(spec: NounPhraseSpec) -> NounPhraseRealization:
    head = _native_surface(spec.head)
    trace: list[str] = []
    morphemes: list[str] = []
    if spec.number is Number.PLURAL:
        plural = pluralize_nominal(head)
        head = plural.surface
        trace.extend(plural.rule_trace)
        morphemes.extend(plural.morphemes)
    else:
        morphemes.append(head)

    relational = tuple(
        _native_surface(particle)
        for particle in spec.relational_particles
    )
    unknown_relational = set(relational) - set(RELATIONAL_PARTICLES)
    if unknown_relational:
        raise ValueError(
            "Unknown relational particle(s): "
            + ", ".join(sorted(unknown_relational))
        )
    locative = (
        _native_surface(spec.locative_prefix)
        if spec.locative_prefix
        else ""
    )
    if locative and locative not in LOCATIVE_PREFIXES:
        raise ValueError(f"Unknown locative prefix: {locative}")
    bridge = _native_surface(spec.locative_bridge)
    if bridge not in {"w", "x"}:
        raise ValueError("Locative bridge must be w or x")

    inner = head
    if locative:
        inner = locative + inner
        morphemes.insert(0, f"{locative}-")
        trace.append("npcp.locative-prefix-fuses-to-head")
    if spec.ga_modifiers:
        modifier_payload = "".join(
            _native_surface(value)
            for value in spec.ga_modifiers
        )
        if locative:
            modifier_payload += bridge
            morphemes.insert(0, f"-{bridge}-")
            trace.append("npcp.modifier-locative-bridge")
        inner, ga_rule = _fuse_ga_payload(modifier_payload + inner)
        morphemes = ["ga-"] + [
            _native_surface(value)
            for value in spec.ga_modifiers
        ] + morphemes
        trace.extend((ga_rule, "ga.single-prefix-modifier-stack"))

    if relational:
        relational_block = "".join(relational)
        if spec.ga_modifiers:
            inner = relational_block + inner
            trace.append("npcp.relational-fuses-before-ga")
        elif locative:
            inner = relational_block + bridge + inner
            morphemes.insert(0, f"-{bridge}-")
            trace.append("npcp.relational-locative-bridge")
        else:
            inner = relational_block + " " + inner
            trace.append("npcp.break-before-head")
        morphemes = [f"{particle}-" for particle in relational] + morphemes
        if len(relational) > 1:
            trace.append("npcp.relational-stack-fusion")

    determiner = select_determiner(
        spec.definiteness,
        spec.noun_class,
    )
    surface = f"{determiner} {inner}" if determiner else inner
    if determiner:
        morphemes.insert(0, determiner)
        trace.append("determiner.before-npcp-block")
    return NounPhraseRealization(
        surface=surface,
        spec=spec,
        morphemes=tuple(morphemes),
        rule_trace=tuple(trace),
    )


def analyze_noun_phrase(
    surface: str,
    candidates: Iterable[NounPhraseSpec],
) -> tuple[NounPhraseRealization, ...]:
    """Return every supplied structural candidate that realizes the surface."""

    normalized = " ".join(surface.strip().split())
    matches: dict[tuple[Any, ...], NounPhraseRealization] = {}
    for spec in candidates:
        realization = realize_noun_phrase(spec)
        if realization.surface != normalized:
            continue
        key = (
            realization.surface,
            spec.head,
            spec.noun_class.value,
            spec.number.value,
            spec.definiteness.value,
            spec.relational_particles,
            spec.ga_modifiers,
            spec.locative_prefix,
            spec.locative_bridge,
        )
        matches[key] = realization
    return tuple(
        sorted(
            matches.values(),
            key=lambda item: (
                item.spec.head,
                item.spec.number.value,
                item.spec.definiteness.value,
                item.spec.relational_particles,
                item.spec.ga_modifiers,
                item.spec.locative_prefix or "",
            ),
        )
    )


@dataclass(frozen=True)
class VerbComplexSpec:
    root: str
    tense: VerbTense = VerbTense.NONPAST
    polarity: VerbPolarity = VerbPolarity.POSITIVE
    mood: VerbMood = VerbMood.NONE
    aspect: VerbAspect = VerbAspect.NONE
    voice: VerbVoice = VerbVoice.ACTIVE
    root_kind: VerbRootKind = VerbRootKind.ROOT

    def to_dict(self) -> dict[str, str]:
        return {
            "root": self.root,
            "tense": self.tense.value,
            "polarity": self.polarity.value,
            "mood": self.mood.value,
            "aspect": self.aspect.value,
            "voice": self.voice.value,
            "root_kind": self.root_kind.value,
        }


@dataclass(frozen=True)
class VerbComplexRealization:
    surface: str
    spec: VerbComplexSpec
    morphemes: tuple[str, ...]
    rule_trace: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "surface": self.surface,
            "spec": self.spec.to_dict(),
            "morphemes": list(self.morphemes),
            "rule_trace": list(self.rule_trace),
        }


def _verb_bridge(
    root: str,
    *,
    preceding_prefix: str,
    tense: VerbTense,
    root_kind: VerbRootKind,
) -> str:
    if not preceding_prefix or root[0] not in ASAXI_VOWELS:
        return ""
    if preceding_prefix == "mi":
        return "j"
    if preceding_prefix == "sỏ":
        # The diphthong's off-glide supplies the buffer in the documented
        # subjective past; unlike ordinary vowel-final prefixes it takes no
        # x bridge before a vowel-initial root.
        return ""
    if root_kind is VerbRootKind.DERIVED:
        return ""
    if root == "ů" and tense is VerbTense.PAST:
        return "b"
    return "x"


def realize_verb_complex(spec: VerbComplexSpec) -> VerbComplexRealization:
    if spec.tense in {
        VerbTense.SUBJECTIVE_PRESENT,
        VerbTense.SUBJECTIVE_PAST,
    } and (
        spec.polarity is not VerbPolarity.POSITIVE
        or spec.mood is not VerbMood.NONE
        or spec.aspect is not VerbAspect.NONE
        or spec.voice is not VerbVoice.ACTIVE
    ):
        raise ValueError(
            "The source grammar licenses subjective tense only as a "
            "positive, unmodified active predicate"
        )
    root = _native_surface(spec.root)
    if " " in root:
        raise ValueError("Verb complex requires one root")
    tense_prefix = TENSE_PREFIXES[spec.tense]
    polarity = POLARITY_MARKERS[spec.polarity]
    mood = MOOD_PREFIXES[spec.mood]
    aspect = ASPECT_PREFIXES[spec.aspect]
    voice = VOICE_PREFIXES[spec.voice]
    if mood and voice:
        raise ValueError("Mood and causative voice share one prefix slot")
    operator = mood or voice
    trace = ["verb-prefix-order.tense-polarity-aspect-operator-root"]
    morphemes: list[str] = []

    if spec.tense is VerbTense.NONPAST:
        # Ordinary nonpast negation follows the verb, but the documented
        # causative agency series is a closed prefix stack:
        # băhè-, ná-băhè-, xăhè-, and ná-xă-băhè-.  Keep polarity before the
        # voice operator here so negative permission is not misgenerated as
        # *băhè-VERB-ná.
        causative_polarity_prefix = bool(voice and polarity)
        prefix_pieces = [
            piece
            for piece in (
                polarity if causative_polarity_prefix else "",
                aspect,
                operator,
            )
            if piece
        ]
        prefix = "".join(prefix_pieces)
        for piece in prefix_pieces:
            morphemes.append(f"{piece}-")
        bridge = _verb_bridge(
            root,
            preceding_prefix=prefix_pieces[-1] if prefix_pieces else "",
            tense=spec.tense,
            root_kind=spec.root_kind,
        )
        if bridge:
            trace.append(f"phonology.{bridge}-hiatus-bridge")
            morphemes.append(f"-{bridge}-")
        surface = prefix + bridge + root
        morphemes.append(root)
        if polarity and not causative_polarity_prefix:
            surface += polarity
            morphemes.append(f"-{polarity}")
            trace.append("negation.nonpast-suffix")
        elif causative_polarity_prefix:
            trace.append("negation.causative-prefix-stack")
    else:
        prefix_pieces = [
            piece
            for piece in (tense_prefix, polarity, aspect, operator)
            if piece
        ]
        prefix = "".join(prefix_pieces)
        for index, piece in enumerate(prefix_pieces):
            morphemes.append(
                f"{piece}-"
                if index != 1 or not polarity
                else f"-{piece}-"
            )
        bridge = _verb_bridge(
            root,
            preceding_prefix=prefix_pieces[-1],
            tense=spec.tense,
            root_kind=spec.root_kind,
        )
        if bridge:
            trace.append(f"phonology.{bridge}-hiatus-bridge")
            morphemes.append(f"-{bridge}-")
        surface = prefix + bridge + root
        morphemes.append(root)
        if polarity:
            trace.append("negation.tensed-infix")

    if tense_prefix:
        trace.append(f"tense.{spec.tense.value}-prefix")
    if mood:
        trace.append(f"mood.{spec.mood.value}")
    if voice:
        trace.append(f"voice.{spec.voice.value}")
    if aspect:
        trace.append(f"aspect.{spec.aspect.value}")
    return VerbComplexRealization(
        surface=surface,
        spec=spec,
        morphemes=tuple(morphemes),
        rule_trace=tuple(trace),
    )


def analyze_verb_complex(
    surface: str,
    roots: Iterable[str],
    *,
    root_kinds: Iterable[VerbRootKind] = (
        VerbRootKind.ROOT,
        VerbRootKind.DERIVED,
    ),
) -> tuple[VerbComplexRealization, ...]:
    """Analyze by deterministic regeneration over the bounded slot inventory."""

    word = _native_surface(surface)
    matches: dict[tuple[str, ...], VerbComplexRealization] = {}
    for root, tense, polarity, mood, aspect, voice, root_kind in itertools.product(
        tuple(roots),
        tuple(VerbTense),
        tuple(VerbPolarity),
        tuple(VerbMood),
        tuple(VerbAspect),
        tuple(VerbVoice),
        tuple(root_kinds),
    ):
        if mood is not VerbMood.NONE and voice is not VerbVoice.ACTIVE:
            continue
        if tense in {
            VerbTense.SUBJECTIVE_PRESENT,
            VerbTense.SUBJECTIVE_PAST,
        } and (
            polarity is not VerbPolarity.POSITIVE
            or mood is not VerbMood.NONE
            or aspect is not VerbAspect.NONE
            or voice is not VerbVoice.ACTIVE
        ):
            continue
        spec = VerbComplexSpec(
            root=root,
            tense=tense,
            polarity=polarity,
            mood=mood,
            aspect=aspect,
            voice=voice,
            root_kind=root_kind,
        )
        realization = realize_verb_complex(spec)
        if realization.surface != word:
            continue
        key = tuple(spec.to_dict().values())
        matches[key] = realization
    return tuple(
        matches[key]
        for key in sorted(matches)
    )


@dataclass(frozen=True)
class PostVerbalTail:
    result: str = ""
    potential: str = ""
    subjunctive: str = ""
    inquiry: str = ""
    discourse: str = ""
    connector: str = ""

    def to_dict(self) -> dict[str, str]:
        return {
            slot: getattr(self, slot)
            for slot in POST_VERBAL_ORDER
        }


@dataclass(frozen=True)
class PredicatePhrase:
    surface: str
    verb: str
    tail: PostVerbalTail
    morphemes: tuple[str, ...]
    rule_trace: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "surface": self.surface,
            "verb": self.verb,
            "tail": self.tail.to_dict(),
            "morphemes": list(self.morphemes),
            "rule_trace": list(self.rule_trace),
        }


def compose_post_verbal_tail(
    verb: str,
    tail: PostVerbalTail,
) -> PredicatePhrase:
    verb_form = _native_surface(verb)
    pieces = [verb_form]
    trace: list[str] = []
    for slot in POST_VERBAL_ORDER:
        value = _native_surface(getattr(tail, slot)) if getattr(tail, slot) else ""
        if not value:
            continue
        if value not in POST_VERBAL_INVENTORY[slot]:
            raise ValueError(f"{value!r} is not a documented {slot} particle")
        pieces.append(value)
        trace.append(f"post-verbal.{slot}")
    return PredicatePhrase(
        surface=" ".join(pieces),
        verb=verb_form,
        tail=tail,
        morphemes=tuple(pieces),
        rule_trace=tuple(trace) + ("post-verbal.strict-slot-order",),
    )


def analyze_post_verbal_tail(surface: str) -> PredicatePhrase:
    tokens = tuple(surface.strip().split())
    if not tokens:
        raise ValueError("Predicate phrase is empty")
    values = {slot: "" for slot in POST_VERBAL_ORDER}
    last_index = -1
    for token in tokens[1:]:
        matches = [
            slot
            for slot, inventory in POST_VERBAL_INVENTORY.items()
            if token in inventory
        ]
        if len(matches) != 1:
            raise ValueError(f"Unknown or ambiguous post-verbal particle: {token}")
        slot = matches[0]
        slot_index = POST_VERBAL_ORDER.index(slot)
        if slot_index <= last_index:
            raise ValueError("Post-verbal particles are out of canonical order")
        values[slot] = token
        last_index = slot_index
    return compose_post_verbal_tail(
        tokens[0],
        PostVerbalTail(**values),
    )


def compose_predicative_npcp(
    particle: str,
    *,
    polarity: VerbPolarity | str = VerbPolarity.POSITIVE,
) -> GeneratedForm:
    relational = _native_surface(particle)
    try:
        base = PREDICATIVE_NPCP[relational]
    except KeyError as error:
        raise ValueError(
            f"{relational!r} has no documented predicative NPCP form"
        ) from error
    polarity_value = _coerce_enum(polarity, VerbPolarity)
    if polarity_value is VerbPolarity.POSITIVE:
        prefix = ""
    elif polarity_value is VerbPolarity.NEGATIVE:
        prefix = "ná"
    elif polarity_value is VerbPolarity.EMPHATIC:
        prefix = "xă"
    else:
        prefix = "náxă"
    return GeneratedForm(
        surface=prefix + base,
        lemma=relational,
        features=(
            ("derivation", "predicative-npcp"),
            ("polarity", polarity_value.value),
        ),
        morphemes=tuple(
            value
            for value in (f"{prefix}-" if prefix else "", relational, "-ŕa")
            if value
        ),
        rule_trace=("predicative-npcp.fuse-with-validity",),
    )
