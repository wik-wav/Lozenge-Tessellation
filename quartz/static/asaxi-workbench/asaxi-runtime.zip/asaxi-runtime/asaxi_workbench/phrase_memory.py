"""Reviewed phrase translations kept separate from grammar inference."""

from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass, replace
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
from threading import RLock
import time
import unicodedata
from typing import Any, Iterable

from .translation_models import TranslationDirection


PHRASE_MEMORY_SCHEMA_VERSION = "2.0"
DEFAULT_PHRASE_MEMORY_PATH = (
    Path(__file__).resolve().parent / "data" / "authored_phrases.json"
)
MAX_PHRASE_CHARACTERS = 4_000
MAX_VARIANTS = 100
MAX_DEVELOPER_NOTE_CHARACTERS = 20_000
MAX_PROVENANCE_CHARACTERS = 2_000
MAX_REVIEWER_CHARACTERS = 200
STORE_LOCK_TIMEOUT_SECONDS = 5.0
_SPACE_RE = re.compile(r"\s+")
_SPACE_BEFORE_PUNCTUATION_RE = re.compile(r"\s+([,.;:!?])")
_WORD_RE = re.compile(r"[^\W_]+", re.UNICODE)
_PRIVATE_PATH_RE = re.compile(
    r"(?i)(?:[a-z]:[\\/]|\\\\|file://|/(?:users|home|mnt|private|tmp)/)"
)
_NUMBER_WORDS = {
    0: "zero",
    1: "one",
    2: "two",
    3: "three",
    4: "four",
    5: "five",
    6: "six",
    7: "seven",
    8: "eight",
    9: "nine",
    10: "ten",
    11: "eleven",
    12: "twelve",
    13: "thirteen",
    14: "fourteen",
    15: "fifteen",
    16: "sixteen",
    17: "seventeen",
    18: "eighteen",
    19: "nineteen",
    20: "twenty",
}
_WORD_NUMBERS = {word: value for value, word in _NUMBER_WORDS.items()}
_ENTRY_FIELDS = frozenset(
    {
        "id",
        "direction",
        "source_text",
        "target_text",
        "variants",
        "verified",
        "revision",
        "reviewed_with_grammar_model",
        "reviewed_with_translation_engine_version",
        "reviewed_with_source_digest",
        "reviewed_by",
        "reviewed_at",
        "verification_source",
        "developer_note",
    }
)
_REQUIRED_ENTRY_FIELDS = frozenset(
    {
        "id",
        "direction",
        "source_text",
        "target_text",
        "variants",
        "verified",
        "revision",
    }
)


class PhraseMemoryError(ValueError):
    """Raised when reviewed phrase data is invalid."""


class PhraseMemoryConflictError(PhraseMemoryError):
    """Raised when a revision or identity conflict would lose authored data."""


def _reject_controls(value: str, label: str) -> None:
    for character in value:
        category = unicodedata.category(character)
        if category in {"Cc", "Cs"} and character not in {"\t", "\r", "\n"}:
            raise PhraseMemoryError(f"{label} contains an unsupported control character")


def _bounded_text(
    value: object,
    label: str,
    *,
    maximum: int,
    allow_empty: bool = False,
    collapse_layout: bool = False,
) -> str:
    if not isinstance(value, str):
        raise PhraseMemoryError(f"{label} must be a string")
    if len(value) > maximum:
        raise PhraseMemoryError(f"{label} exceeds the {maximum:,} character limit")
    _reject_controls(value, label)
    result = normalize_phrase(value) if collapse_layout else value.strip()
    if not result and not allow_empty:
        raise PhraseMemoryError(f"{label} cannot be empty")
    return result


def normalize_phrase(text: str) -> str:
    """Normalize layout only; case and punctuation remain meaningful."""

    if not isinstance(text, str):
        raise PhraseMemoryError("Phrase text must be a string")
    normalized = unicodedata.normalize("NFC", text).replace("\u00a0", " ")
    normalized = _SPACE_RE.sub(" ", normalized.strip())
    return _SPACE_BEFORE_PUNCTUATION_RE.sub(r"\1", normalized)


def _search_key(text: str) -> str:
    return normalize_phrase(text).casefold()


def _stable_id(
    direction: TranslationDirection,
    source_text: str,
    target_text: str,
) -> str:
    material = (
        f"{direction.value}\0{normalize_phrase(source_text)}"
        f"\0{normalize_phrase(target_text)}"
    )
    digest = hashlib.sha256(material.encode("utf-8")).hexdigest()[:16]
    return f"phrase-{digest}"


def _dedupe_phrases(values: Iterable[str]) -> tuple[str, ...]:
    result: list[str] = []
    seen: set[str] = set()
    for value in values:
        normalized = _bounded_text(
            value,
            "Phrase variant",
            maximum=MAX_PHRASE_CHARACTERS,
            collapse_layout=True,
        )
        if normalized in seen:
            continue
        seen.add(normalized)
        result.append(normalized)
    return tuple(result)


def _normalized_timestamp(value: object, label: str) -> str:
    text = _bounded_text(
        value,
        label,
        maximum=100,
        collapse_layout=True,
    )
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError as error:
        raise PhraseMemoryError(f"{label} must be an ISO-8601 timestamp") from error
    if parsed.tzinfo is None:
        raise PhraseMemoryError(f"{label} must include a timezone")
    return (
        parsed.astimezone(timezone.utc)
        .isoformat(timespec="seconds")
        .replace("+00:00", "Z")
    )


def _reject_private_path(value: str, label: str) -> None:
    if _PRIVATE_PATH_RE.search(value):
        raise PhraseMemoryError(
            f"{label} must cite a public note, corpus, or review method "
            "without an absolute private path"
        )


@dataclass(frozen=True)
class AuthoredPhrase:
    identifier: str
    direction: TranslationDirection
    source_text: str
    target_text: str
    variants: tuple[str, ...] = ()
    verified: bool = False
    revision: int = 1
    reviewed_with_grammar_model: str | None = None
    reviewed_with_translation_engine_version: str | None = None
    reviewed_with_source_digest: str | None = None
    reviewed_by: str | None = None
    reviewed_at: str | None = None
    verification_source: str | None = None
    developer_note: str = ""

    @classmethod
    def create(
        cls,
        *,
        direction: TranslationDirection | str,
        source_text: str,
        target_text: str,
        variants: Iterable[str] = (),
        verified: bool = False,
        revision: int = 1,
        reviewed_with_grammar_model: str | None = None,
        reviewed_with_translation_engine_version: str | None = None,
        reviewed_with_source_digest: str | None = None,
        reviewed_by: str | None = None,
        reviewed_at: str | None = None,
        verification_source: str | None = None,
        developer_note: str = "",
        identifier: str | None = None,
    ) -> "AuthoredPhrase":
        try:
            selected = TranslationDirection(direction)
        except (TypeError, ValueError) as error:
            raise PhraseMemoryError(f"Unsupported translation direction: {direction!r}") from error
        source = _bounded_text(
            source_text,
            "Authored phrase source",
            maximum=MAX_PHRASE_CHARACTERS,
            collapse_layout=True,
        )
        target = _bounded_text(
            target_text,
            "Authored phrase translation",
            maximum=MAX_PHRASE_CHARACTERS,
            collapse_layout=True,
        )
        if isinstance(variants, (str, bytes)):
            raise PhraseMemoryError("Phrase variants must be an iterable of strings")
        normalized_variants = tuple(
            value for value in _dedupe_phrases(variants) if value != source
        )
        if len(normalized_variants) > MAX_VARIANTS:
            raise PhraseMemoryError(
                f"Phrase variants exceed the {MAX_VARIANTS} item limit"
            )
        if type(verified) is not bool:
            raise PhraseMemoryError("Authored phrase verified must be a boolean")
        if type(revision) is not int or revision < 1:
            raise PhraseMemoryError("Authored phrase revision must be a positive integer")
        entry_id = identifier or _stable_id(selected, source, target)
        if not isinstance(entry_id, str) or not re.fullmatch(
            r"phrase-[a-z0-9][a-z0-9-]{5,63}", entry_id
        ):
            raise PhraseMemoryError(f"Invalid authored phrase id: {entry_id!r}")
        note = _bounded_text(
            developer_note,
            "Developer note",
            maximum=MAX_DEVELOPER_NOTE_CHARACTERS,
            allow_empty=True,
        )
        if verified:
            reviewer = _bounded_text(
                reviewed_by,
                "Verified phrase reviewer",
                maximum=MAX_REVIEWER_CHARACTERS,
                collapse_layout=True,
            )
            reviewed_time = _normalized_timestamp(
                reviewed_at,
                "Verified phrase review time",
            )
            source_reference = _bounded_text(
                verification_source,
                "Verified phrase source",
                maximum=MAX_PROVENANCE_CHARACTERS,
                collapse_layout=True,
            )
            _reject_private_path(source_reference, "Verified phrase source")
            model = _bounded_text(
                reviewed_with_grammar_model,
                "Reviewed grammar model",
                maximum=200,
                collapse_layout=True,
            )
            engine = _bounded_text(
                reviewed_with_translation_engine_version,
                "Reviewed translation engine",
                maximum=200,
                collapse_layout=True,
            )
            source_digest = _bounded_text(
                reviewed_with_source_digest,
                "Reviewed grammar source digest",
                maximum=128,
                collapse_layout=True,
            )
            if not re.fullmatch(r"[0-9a-fA-F]{64}", source_digest):
                raise PhraseMemoryError(
                    "Reviewed grammar source digest must be a SHA-256 hex digest"
                )
            source_digest = source_digest.lower()
        else:
            reviewer = None
            reviewed_time = None
            source_reference = None
            model = None
            engine = None
            source_digest = None
        return cls(
            identifier=entry_id,
            direction=selected,
            source_text=source,
            target_text=target,
            variants=normalized_variants,
            verified=verified,
            revision=revision,
            reviewed_with_grammar_model=model,
            reviewed_with_translation_engine_version=engine,
            reviewed_with_source_digest=source_digest,
            reviewed_by=reviewer,
            reviewed_at=reviewed_time,
            verification_source=source_reference,
            developer_note=note,
        )

    @classmethod
    def from_dict(cls, payload: object) -> "AuthoredPhrase":
        if not isinstance(payload, dict):
            raise PhraseMemoryError("Each phrase-memory entry must be an object")
        unknown = set(payload) - _ENTRY_FIELDS
        missing = _REQUIRED_ENTRY_FIELDS - set(payload)
        if unknown:
            raise PhraseMemoryError(
                "Unknown phrase-memory entry fields: " + ", ".join(sorted(unknown))
            )
        if missing:
            raise PhraseMemoryError(
                "Missing phrase-memory entry fields: " + ", ".join(sorted(missing))
            )
        variants = payload["variants"]
        if not isinstance(variants, list) or not all(
            isinstance(item, str) for item in variants
        ):
            raise PhraseMemoryError("Phrase variants must be a list of strings")
        return cls.create(
            identifier=payload["id"],
            direction=payload["direction"],
            source_text=payload["source_text"],
            target_text=payload["target_text"],
            variants=variants,
            verified=payload["verified"],
            revision=payload["revision"],
            reviewed_with_grammar_model=payload.get("reviewed_with_grammar_model"),
            reviewed_with_translation_engine_version=payload.get(
                "reviewed_with_translation_engine_version"
            ),
            reviewed_with_source_digest=payload.get(
                "reviewed_with_source_digest"
            ),
            reviewed_by=payload.get("reviewed_by"),
            reviewed_at=payload.get("reviewed_at"),
            verification_source=payload.get("verification_source"),
            developer_note=payload.get("developer_note", ""),
        )

    @property
    def match_forms(self) -> tuple[str, ...]:
        return (self.source_text, *self.variants)

    @property
    def substantive_signature(self) -> tuple[object, ...]:
        return (
            self.direction,
            self.source_text,
            self.target_text,
            self.variants,
        )

    def to_dict(self, *, public: bool = False) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "id": self.identifier,
            "direction": self.direction.value,
            "source_text": self.source_text,
            "target_text": self.target_text,
            "variants": list(self.variants),
            "verified": self.verified,
            "revision": self.revision,
            "reviewed_with_grammar_model": self.reviewed_with_grammar_model,
            "reviewed_with_translation_engine_version": (
                self.reviewed_with_translation_engine_version
            ),
            "reviewed_with_source_digest": self.reviewed_with_source_digest,
            "reviewed_by": self.reviewed_by,
            "reviewed_at": self.reviewed_at,
            "verification_source": self.verification_source,
        }
        if not public:
            payload["developer_note"] = self.developer_note
        return payload


@dataclass(frozen=True)
class PhraseSearchHit:
    phrase: AuthoredPhrase
    matched_text: str
    match_kind: str

    def to_dict(self) -> dict[str, Any]:
        return {
            **self.phrase.to_dict(public=True),
            "matched_text": self.matched_text,
            "match_kind": self.match_kind,
            "authored": True,
        }


def suggest_phrase_variants(
    source_text: str,
    direction: TranslationDirection | str,
) -> tuple[str, ...]:
    """Propose conservative variants for explicit developer review.

    Punctuation and apostrophes are linguistic data, so the helper never
    removes or rewrites them. Case and number-word suggestions are limited to
    English source text.
    """

    selected = TranslationDirection(direction)
    source = normalize_phrase(source_text)
    if not source:
        return ()
    work: list[str] = [source]
    if selected is TranslationDirection.ENGLISH_TO_ASAXI:
        first = next(
            (index for index, char in enumerate(source) if char.isalpha()),
            None,
        )
        if first is not None:
            work.append(source[:first] + source[first].upper() + source[first + 1 :])
            work.append(source[:first] + source[first].lower() + source[first + 1 :])
        for value in tuple(work):
            replaced_digits = value
            for number, word in _NUMBER_WORDS.items():
                replaced_digits = re.sub(
                    rf"(?<!\w){number}(?!\w)",
                    word,
                    replaced_digits,
                )
            work.append(replaced_digits)
            replaced_words = value
            for word, number in _WORD_NUMBERS.items():
                replaced_words = re.sub(
                    rf"(?<!\w){word}(?!\w)",
                    str(number),
                    replaced_words,
                    flags=re.IGNORECASE,
                )
            work.append(replaced_words)
    return tuple(value for value in _dedupe_phrases(work) if value != source)


@contextmanager
def _exclusive_store_lock(path: Path):
    """Serialize writers across store instances and local processes."""

    lock_path = path.with_name(path.name + ".lock")
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    deadline = time.monotonic() + STORE_LOCK_TIMEOUT_SECONDS
    descriptor: int | None = None
    while descriptor is None:
        try:
            descriptor = os.open(
                lock_path,
                os.O_CREAT | os.O_EXCL | os.O_WRONLY,
            )
        except FileExistsError as error:
            if time.monotonic() >= deadline:
                raise PhraseMemoryConflictError(
                    "Authored phrase memory is busy; retry after the other "
                    "editor finishes saving"
                ) from error
            time.sleep(0.025)
    try:
        os.write(
            descriptor,
            f"pid={os.getpid()}\n".encode("ascii"),
        )
        os.close(descriptor)
        descriptor = None
        yield
    finally:
        if descriptor is not None:
            os.close(descriptor)
        try:
            lock_path.unlink()
        except FileNotFoundError:
            pass


class PhraseMemoryStore:
    """Thread-safe deterministic store for authored phrase translations."""

    def __init__(self, path: Path | None = None):
        self.path = Path(path or DEFAULT_PHRASE_MEMORY_PATH)
        self._lock = RLock()
        self._entries: tuple[AuthoredPhrase, ...] = ()
        self.reload()

    @property
    def entries(self) -> tuple[AuthoredPhrase, ...]:
        with self._lock:
            return self._entries

    @property
    def count(self) -> int:
        return len(self.entries)

    @property
    def verified_count(self) -> int:
        return sum(entry.verified for entry in self.entries)

    def reload(self) -> None:
        with self._lock:
            self._entries = self._read_entries()

    def _read_entries(self) -> tuple[AuthoredPhrase, ...]:
        if not self.path.exists():
            return ()
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as error:
            raise PhraseMemoryError(
                f"Could not read authored phrase memory: {error}"
            ) from error
        return self._parse_document(payload)

    @classmethod
    def _parse_document(cls, payload: object) -> tuple[AuthoredPhrase, ...]:
        if not isinstance(payload, dict):
            raise PhraseMemoryError("Phrase-memory document must be an object")
        unknown = set(payload) - {"schema_version", "entries"}
        if unknown:
            raise PhraseMemoryError(
                "Unknown phrase-memory document fields: " + ", ".join(sorted(unknown))
            )
        if payload.get("schema_version") != PHRASE_MEMORY_SCHEMA_VERSION:
            raise PhraseMemoryError(
                "Unsupported phrase-memory schema version: "
                f"{payload.get('schema_version')!r}"
            )
        raw_entries = payload.get("entries")
        if not isinstance(raw_entries, list):
            raise PhraseMemoryError("Phrase-memory entries must be a list")
        entries = tuple(AuthoredPhrase.from_dict(item) for item in raw_entries)
        cls._validate_unique(entries)
        return tuple(sorted(entries, key=cls._entry_sort_key))

    @staticmethod
    def _entry_sort_key(entry: AuthoredPhrase) -> tuple[str, str, str, str]:
        return (
            entry.direction.value,
            _search_key(entry.source_text),
            _search_key(entry.target_text),
            entry.identifier,
        )

    @classmethod
    def _validate_unique(cls, entries: Iterable[AuthoredPhrase]) -> None:
        by_id: dict[str, AuthoredPhrase] = {}
        by_translation: dict[tuple[TranslationDirection, str, str], AuthoredPhrase] = {}
        form_owners: dict[tuple[TranslationDirection, str], str] = {}
        for entry in entries:
            if entry.identifier in by_id:
                raise PhraseMemoryConflictError(
                    f"Duplicate authored phrase id: {entry.identifier}"
                )
            by_id[entry.identifier] = entry
            key = (entry.direction, entry.source_text, entry.target_text)
            previous = by_translation.get(key)
            if previous is not None:
                raise PhraseMemoryConflictError(
                    "Duplicate authored phrase translation: "
                    f"{entry.source_text!r} -> {entry.target_text!r}"
                )
            by_translation[key] = entry
            for form in entry.match_forms:
                form_key = (entry.direction, form)
                previous_source = form_owners.get(form_key)
                if (
                    previous_source is not None
                    and previous_source != entry.source_text
                ):
                    raise PhraseMemoryConflictError(
                        "Authored phrase match form overlaps another canonical "
                        f"phrase: {form!r}"
                    )
                form_owners[form_key] = entry.source_text

    def matches(
        self,
        text: str,
        direction: TranslationDirection | str,
        *,
        verified_only: bool = True,
    ) -> tuple[PhraseSearchHit, ...]:
        selected = TranslationDirection(direction)
        normalized = normalize_phrase(text)
        hits: list[PhraseSearchHit] = []
        for entry in self.entries:
            if entry.direction is not selected:
                continue
            if verified_only and not entry.verified:
                continue
            for index, form in enumerate(entry.match_forms):
                if normalized == form:
                    hits.append(
                        PhraseSearchHit(
                            phrase=entry,
                            matched_text=form,
                            match_kind="canonical" if index == 0 else "variant",
                        )
                    )
                    break
        return tuple(
            sorted(
                hits,
                key=lambda hit: (
                    0 if hit.match_kind == "canonical" else 1,
                    self._entry_sort_key(hit.phrase),
                ),
            )
        )

    def match(
        self,
        text: str,
        direction: TranslationDirection | str,
        *,
        verified_only: bool = True,
    ) -> PhraseSearchHit | None:
        matches = self.matches(text, direction, verified_only=verified_only)
        return matches[0] if matches else None

    def search(
        self,
        query: str,
        direction: TranslationDirection | str | None = None,
        *,
        verified_only: bool = True,
        limit: int = 50,
    ) -> tuple[PhraseSearchHit, ...]:
        selected = TranslationDirection(direction) if direction else None
        normalized_needle = normalize_phrase(query)
        needle = normalized_needle.casefold()
        needle_words = set(_WORD_RE.findall(needle))
        ranked: list[tuple[tuple[int, float, str, str, str], PhraseSearchHit]] = []
        for entry in self.entries:
            if selected is not None and entry.direction is not selected:
                continue
            if verified_only and not entry.verified:
                continue
            forms = entry.match_forms
            form_keys = tuple(_search_key(form) for form in forms)
            target_key = _search_key(entry.target_text)
            if not needle:
                match_rank = 6
                overlap = 0.0
                matched = entry.source_text
                kind = "browse"
            elif normalized_needle in forms:
                index = forms.index(normalized_needle)
                match_rank = 0
                overlap = 1.0
                matched = forms[index]
                kind = "canonical" if index == 0 else "variant"
            elif needle in form_keys:
                index = form_keys.index(needle)
                match_rank = 1
                overlap = 1.0
                matched = forms[index]
                kind = "case-insensitive-search"
            else:
                prefix_index = next(
                    (index for index, value in enumerate(form_keys) if value.startswith(needle)),
                    None,
                )
                substring_index = next(
                    (index for index, value in enumerate(form_keys) if needle in value),
                    None,
                )
                if prefix_index is not None:
                    match_rank = 2
                    overlap = 1.0
                    matched = forms[prefix_index]
                    kind = "source-prefix"
                elif substring_index is not None:
                    match_rank = 3
                    overlap = 1.0
                    matched = forms[substring_index]
                    kind = "source-contains"
                elif needle and needle in target_key:
                    match_rank = 4
                    overlap = 1.0
                    matched = entry.target_text
                    kind = "translation-contains"
                else:
                    best_form = entry.source_text
                    best_overlap = 0.0
                    for form, value in zip(forms, form_keys):
                        words = set(_WORD_RE.findall(value))
                        union = needle_words | words
                        score = len(needle_words & words) / len(union) if union else 0.0
                        if score > best_overlap:
                            best_form = form
                            best_overlap = score
                    if best_overlap <= 0:
                        continue
                    match_rank = 5
                    overlap = best_overlap
                    matched = best_form
                    kind = "token-overlap"
            hit = PhraseSearchHit(entry, matched, kind)
            ranked.append(
                (
                    (
                        match_rank,
                        -overlap,
                        _search_key(entry.source_text),
                        _search_key(entry.target_text),
                        entry.identifier,
                    ),
                    hit,
                )
            )
        ranked.sort(key=lambda item: item[0])
        return tuple(hit for _key, hit in ranked[: max(0, min(limit, 200))])

    def insert(self, entry: AuthoredPhrase) -> AuthoredPhrase:
        with self._lock:
            with _exclusive_store_lock(self.path):
                entries = [*self._read_entries(), entry]
                self._validate_unique(entries)
                saved_entries = tuple(
                    sorted(entries, key=self._entry_sort_key)
                )
                self._write_entries(saved_entries)
                self._entries = saved_entries
            return entry

    def update(
        self,
        entry: AuthoredPhrase,
        *,
        expected_revision: int,
    ) -> tuple[AuthoredPhrase, bool]:
        with self._lock:
            with _exclusive_store_lock(self.path):
                disk_entries = self._read_entries()
                current = next(
                    (
                        item
                        for item in disk_entries
                        if item.identifier == entry.identifier
                    ),
                    None,
                )
                if current is None:
                    raise KeyError(entry.identifier)
                if (
                    type(expected_revision) is not int
                    or expected_revision != current.revision
                ):
                    raise PhraseMemoryConflictError(
                        f"Authored phrase {entry.identifier} changed since it "
                        f"was opened (expected revision {expected_revision!r}, "
                        f"current revision {current.revision})"
                    )
                substantive_change = (
                    entry.substantive_signature
                    != current.substantive_signature
                )
                if substantive_change:
                    updated = replace(
                        entry,
                        verified=False,
                        reviewed_with_grammar_model=None,
                        reviewed_with_translation_engine_version=None,
                        reviewed_with_source_digest=None,
                        reviewed_by=None,
                        reviewed_at=None,
                        verification_source=None,
                        revision=current.revision + 1,
                    )
                else:
                    updated = replace(
                        entry,
                        revision=current.revision + 1,
                    )
                entries = [
                    updated if item.identifier == current.identifier else item
                    for item in disk_entries
                ]
                self._validate_unique(entries)
                saved_entries = tuple(
                    sorted(entries, key=self._entry_sort_key)
                )
                self._write_entries(saved_entries)
                self._entries = saved_entries
            return updated, substantive_change and entry.verified

    def delete(self, identifier: str, *, expected_revision: int) -> bool:
        with self._lock:
            with _exclusive_store_lock(self.path):
                disk_entries = self._read_entries()
                current = next(
                    (
                        entry
                        for entry in disk_entries
                        if entry.identifier == identifier
                    ),
                    None,
                )
                if current is None:
                    return False
                if (
                    type(expected_revision) is not int
                    or expected_revision != current.revision
                ):
                    raise PhraseMemoryConflictError(
                        f"Authored phrase {identifier} changed since it was "
                        f"opened (expected revision {expected_revision!r}, "
                        f"current revision {current.revision})"
                    )
                saved_entries = tuple(
                    entry
                    for entry in disk_entries
                    if entry.identifier != identifier
                )
                self._write_entries(saved_entries)
                self._entries = saved_entries
            return True

    def entry(self, identifier: str) -> AuthoredPhrase | None:
        return next(
            (entry for entry in self.entries if entry.identifier == identifier),
            None,
        )

    def _write_entries(
        self,
        entries: tuple[AuthoredPhrase, ...],
    ) -> None:
        payload = {
            "schema_version": PHRASE_MEMORY_SCHEMA_VERSION,
            "entries": [entry.to_dict() for entry in entries],
        }
        rendered = json.dumps(
            payload,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        ) + "\n"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_name(self.path.name + ".tmp")
        try:
            temporary.write_text(
                rendered,
                encoding="utf-8",
                newline="\n",
            )
            temporary.replace(self.path)
        finally:
            try:
                temporary.unlink()
            except FileNotFoundError:
                pass

    def export_public(self, path: Path) -> None:
        with self._lock:
            payload = {
                "schema_version": PHRASE_MEMORY_SCHEMA_VERSION,
                "authorship": "reviewed-human-authored",
                "entries": [
                    entry.to_dict(public=True)
                    for entry in self._entries
                    if entry.verified
                ],
            }
        rendered = json.dumps(
            payload,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        ) + "\n"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(rendered, encoding="utf-8", newline="\n")
